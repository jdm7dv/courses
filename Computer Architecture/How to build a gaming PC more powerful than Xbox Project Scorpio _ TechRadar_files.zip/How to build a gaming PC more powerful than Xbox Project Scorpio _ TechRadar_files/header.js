/*! vanilla front assets (production, v1.5.1) */
!function(t){function e(n){if(r[n])return r[n].exports
var i=r[n]={i:n,l:!1,exports:{}}
return t[n].call(i.exports,i,i.exports,e),i.l=!0,i.exports}var n=window.webpackJsonp
window.webpackJsonp=function(e,r,o){for(var a,s,u=0,c=[];u<e.length;u++)s=e[u],i[s]&&c.push(i[s][0]),i[s]=0
for(a in r)Object.prototype.hasOwnProperty.call(r,a)&&(t[a]=r[a])
for(n&&n(e,r,o);c.length;)c.shift()()}
var r={},i={5:0}
e.e=function(t){function n(){o.onerror=o.onload=null,clearTimeout(a)
var e=i[t]
0!==e&&(e&&e[1](new Error("Loading chunk "+t+" failed.")),i[t]=void 0)}if(0===i[t])return Promise.resolve()
if(i[t])return i[t][2]
var r=document.getElementsByTagName("head")[0],o=document.createElement("script")
o.type="text/javascript",o.charset="utf-8",o.async=!0,o.timeout=12e4,e.nc&&o.setAttribute("nonce",e.nc),o.src=e.p+""+t+".js"
var a=setTimeout(n,12e4)
o.onerror=o.onload=n
var s=new Promise(function(e,n){i[t]=[e,n]})
return i[t][2]=s,r.appendChild(o),s},e.m=t,e.c=r,e.i=function(t){return t},e.d=function(t,n,r){e.o(t,n)||Object.defineProperty(t,n,{configurable:!1,enumerable:!0,get:r})},e.n=function(t){var n=t&&t.__esModule?function(){return t.default}:function(){return t}
return e.d(n,"a",n),n},e.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},e.p="media/js/header/",e.oe=function(t){throw console.error(t),t},e(e.s=348)}([function(t,e,n){"use strict"
var r=n(42),i=n(30)
n.d(e,"g",function(){return a}),n.d(e,"o",function(){return s}),n.d(e,"s",function(){return u}),n.d(e,"p",function(){return c}),n.d(e,"t",function(){return l}),n.d(e,"m",function(){return f}),n.d(e,"f",function(){return d}),n.d(e,"e",function(){return p}),n.d(e,"i",function(){return h}),n.d(e,"b",function(){return v}),n.d(e,"r",function(){return y}),n.d(e,"d",function(){return m}),n.d(e,"c",function(){return b}),n.d(e,"j",function(){return g}),n.d(e,"n",function(){return w}),n.d(e,"a",function(){return x}),n.d(e,"h",function(){return S}),n.d(e,"k",function(){return I}),n.d(e,"q",function(){return O}),n.d(e,"l",function(){return E})
var o=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},a=40,s=728,u=970,c=90,l=250,f=250,d=600,p=300,h="#ededed",v="BLOCK",y="INLINE",m="center",b="before",g="after",w="prepend",_=function(t){if(t.previousElementSibling){if(t.previousElementSibling.classList.contains("_hawk"))return!1
if(t.previousElementSibling.classList.contains("pull-right"))return!1
if(t.previousElementSibling.classList.contains("fancy-box"))return!1}return!0},x=function(t){return t.map(function(t){if(window.preemptionPlaceholders){if(window.preemptionPlaceholders[t.slotify.name])return o({},t,{slotify:o({},t.slotify,{hook:window.preemptionPlaceholders[t.slotify.name],position:"prepend"}),preallocated:!0})
window.preemptionPlaceholders[t.slotify.name]=null}return o({},t,{slotify:o({},t.slotify,{hook:t.hook()})})})},S=function(){for(var t=arguments.length,e=Array(t),n=0;n<t;n++)e[n]=arguments[n]
return function(){for(var t=0;t<e.length;t++){var n=document.querySelector(e[t])
if(n)return n}}},I=function(){return n.i(r.a)()},O=function t(e,n,r){var i=!(arguments.length>3&&void 0!==arguments[3])||arguments[3]
if(void 0!==n&&null!==n&&n instanceof HTMLElement){if(e.has(n))return e.get(n)
var o=r(n)
if(!1===o||void 0===o||null===o)return 0
var a=t(e,i?n.nextElementSibling:n.previousElementSibling,r,i)+o
return e.set(n,a),a}return 0},k=function(t,e,n){return t.map(function(t,r,i){return e.filter(function(e){var o=n(e)
return o>=(i[r-1]||Number.NEGATIVE_INFINITY)&&o<t})})},E=function(t,e,r,o){var a=function(t,e,n){return n.indexOf(t)===e},s=[].map(function(t){return t.textContent.length<10&&"P"===t.nextElementSibling.tagName?t.nextElementSibling:t}),u=function(t){return!t.firstElementChild||"IMG"!==t.firstElementChild.nodeName},c="t3"===e?u:function(t){return!0},l=n.i(i.a)(window.document,r).filter(c).filter(_).map(function(t){return t.textContent.length<10&&t.nextElementSibling&&"P"===t.nextElementSibling.tagName&&c(t)?t.nextElementSibling:t}).splice(6),f=function(t){return!("P"!==t.nodeName||!c(t))&&t.textContent.length},d=function(t){return function(e){return{element:e,amountOfCharacters:O(o,e,t)}}},p=[].concat(s,l).filter(a).reverse().map(d(f))
return k(t,p,function(t){return t.amountOfCharacters})}},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(134),o=n(31),a=n(125),s=n(84),u=function(t){function e(n,r,i){switch(t.call(this),this.syncErrorValue=null,this.syncErrorThrown=!1,this.syncErrorThrowable=!1,this.isStopped=!1,arguments.length){case 0:this.destination=a.empty
break
case 1:if(!n){this.destination=a.empty
break}if("object"==typeof n){n instanceof e?(this.destination=n,this.destination.add(this)):(this.syncErrorThrowable=!0,this.destination=new c(this,n))
break}default:this.syncErrorThrowable=!0,this.destination=new c(this,n,r,i)}}return r(e,t),e.prototype[s.rxSubscriber]=function(){return this},e.create=function(t,n,r){var i=new e(t,n,r)
return i.syncErrorThrowable=!1,i},e.prototype.next=function(t){this.isStopped||this._next(t)},e.prototype.error=function(t){this.isStopped||(this.isStopped=!0,this._error(t))},e.prototype.complete=function(){this.isStopped||(this.isStopped=!0,this._complete())},e.prototype.unsubscribe=function(){this.closed||(this.isStopped=!0,t.prototype.unsubscribe.call(this))},e.prototype._next=function(t){this.destination.next(t)},e.prototype._error=function(t){this.destination.error(t),this.unsubscribe()},e.prototype._complete=function(){this.destination.complete(),this.unsubscribe()},e.prototype._unsubscribeAndRecycle=function(){var t=this,e=t._parent,n=t._parents
return this._parent=null,this._parents=null,this.unsubscribe(),this.closed=!1,this.isStopped=!1,this._parent=e,this._parents=n,this},e}(o.Subscription)
e.Subscriber=u
var c=function(t){function e(e,n,r,o){t.call(this),this._parentSubscriber=e
var s,u=this
i.isFunction(n)?s=n:n&&(s=n.next,r=n.error,o=n.complete,n!==a.empty&&(u=Object.create(n),i.isFunction(u.unsubscribe)&&this.add(u.unsubscribe.bind(u)),u.unsubscribe=this.unsubscribe.bind(this))),this._context=u,this._next=s,this._error=r,this._complete=o}return r(e,t),e.prototype.next=function(t){if(!this.isStopped&&this._next){var e=this._parentSubscriber
e.syncErrorThrowable?this.__tryOrSetError(e,this._next,t)&&this.unsubscribe():this.__tryOrUnsub(this._next,t)}},e.prototype.error=function(t){if(!this.isStopped){var e=this._parentSubscriber
if(this._error)e.syncErrorThrowable?(this.__tryOrSetError(e,this._error,t),this.unsubscribe()):(this.__tryOrUnsub(this._error,t),this.unsubscribe())
else{if(!e.syncErrorThrowable)throw this.unsubscribe(),t
e.syncErrorValue=t,e.syncErrorThrown=!0,this.unsubscribe()}}},e.prototype.complete=function(){if(!this.isStopped){var t=this._parentSubscriber
this._complete?t.syncErrorThrowable?(this.__tryOrSetError(t,this._complete),this.unsubscribe()):(this.__tryOrUnsub(this._complete),this.unsubscribe()):this.unsubscribe()}},e.prototype.__tryOrUnsub=function(t,e){try{t.call(this._context,e)}catch(t){throw this.unsubscribe(),t}},e.prototype.__tryOrSetError=function(t,e,n){try{e.call(this._context,n)}catch(e){return t.syncErrorValue=e,t.syncErrorThrown=!0,!0}return!1},e.prototype._unsubscribe=function(){var t=this._parentSubscriber
this._context=null,this._parentSubscriber=null,t.unsubscribe()},e}(u)},function(t,e,n){"use strict"
var r=n(11),i=n(327),o=n(83),a=function(){function t(t){this._isScalar=!1,t&&(this._subscribe=t)}return t.prototype.lift=function(e){var n=new t
return n.source=this,n.operator=e,n},t.prototype.subscribe=function(t,e,n){var r=this.operator,o=i.toSubscriber(t,e,n)
if(r?r.call(o,this.source):o.add(this._trySubscribe(o)),o.syncErrorThrowable&&(o.syncErrorThrowable=!1,o.syncErrorThrown))throw o.syncErrorValue
return o},t.prototype._trySubscribe=function(t){try{return this._subscribe(t)}catch(e){t.syncErrorThrown=!0,t.syncErrorValue=e,t.error(e)}},t.prototype.forEach=function(t,e){var n=this
if(e||(r.root.Rx&&r.root.Rx.config&&r.root.Rx.config.Promise?e=r.root.Rx.config.Promise:r.root.Promise&&(e=r.root.Promise)),!e)throw new Error("no Promise impl found")
return new e(function(e,r){var i
i=n.subscribe(function(e){if(i)try{t(e)}catch(t){r(t),i.unsubscribe()}else t(e)},r,e)})},t.prototype._subscribe=function(t){return this.source.subscribe(t)},t.prototype[o.observable]=function(){return this},t.create=function(e){return new t(e)},t}()
e.Observable=a},function(t,e,n){"use strict"
var r=0
e.a=function(){return r++}},,,function(t,e,n){"use strict"
function r(t){return i.filter.call(this,function(e){return e.type===t})}var i=n(7)
n.n(i)
e.a=r},function(t,e,n){"use strict"
function r(t,e){return this.lift(new a(t,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.filter=r
var a=function(){function t(t,e){this.predicate=t,this.thisArg=e}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.predicate,this.thisArg))},t}(),s=function(t){function e(e,n,r){t.call(this,e),this.predicate=n,this.thisArg=r,this.count=0,this.predicate=n}return i(e,t),e.prototype._next=function(t){var e
try{e=this.predicate.call(this.thisArg,t,this.count++)}catch(t){return void this.destination.error(t)}e&&this.destination.next(t)},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(t,e){if("function"!=typeof t)throw new TypeError("argument is not a function. Are you looking for `mapTo()`?")
return this.lift(new a(t,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.map=r
var a=function(){function t(t,e){this.project=t,this.thisArg=e}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.project,this.thisArg))},t}()
e.MapOperator=a
var s=function(t){function e(e,n,r){t.call(this,e),this.project=n,this.count=0,this.thisArg=r||this}return i(e,t),e.prototype._next=function(t){var e
try{e=this.project.call(this.thisArg,t,this.count++)}catch(t){return void this.destination.error(t)}this.destination.next(e)},e}(o.Subscriber)},function(t,e){var n
n=function(){return this}()
try{n=n||Function("return this")()||(0,eval)("this")}catch(t){"object"==typeof window&&(n=window)}t.exports=n},,function(t,e,n){"use strict";(function(t){if(e.root="object"==typeof window&&window.window===window&&window||"object"==typeof self&&self.self===self&&self||"object"==typeof t&&t.global===t&&t,!e.root)throw new Error("RxJS could not find any global context (window, self, global)")}).call(e,n(9))},function(t,e,n){"use strict"
var r=n(0),i=n(30)
e.a=function(){return n.i(i.a)(window.document,".sponsored-post").map(function(t,e){return{slotify:{name:"sponsored"+(e+1),hook:t,type:r.b,align:r.d,fluid:!0,whitelist:["sponsored-post"],position:r.n}}})}},function(t,e,n){"use strict"
var r=n(302)
e.never=r.NeverObservable.create},function(t,e,n){"use strict"
function r(t,e,n){return void 0===n&&(n=Number.POSITIVE_INFINITY),"number"==typeof e&&(n=e,e=null),this.lift(new s(t,e,n))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(22),a=n(21)
e.mergeMap=r
var s=function(){function t(t,e,n){void 0===n&&(n=Number.POSITIVE_INFINITY),this.project=t,this.resultSelector=e,this.concurrent=n}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.project,this.resultSelector,this.concurrent))},t}()
e.MergeMapOperator=s
var u=function(t){function e(e,n,r,i){void 0===i&&(i=Number.POSITIVE_INFINITY),t.call(this,e),this.project=n,this.resultSelector=r,this.concurrent=i,this.hasCompleted=!1,this.buffer=[],this.active=0,this.index=0}return i(e,t),e.prototype._next=function(t){this.active<this.concurrent?this._tryNext(t):this.buffer.push(t)},e.prototype._tryNext=function(t){var e,n=this.index++
try{e=this.project(t,n)}catch(t){return void this.destination.error(t)}this.active++,this._innerSub(e,t,n)},e.prototype._innerSub=function(t,e,n){this.add(o.subscribeToResult(this,t,e,n))},e.prototype._complete=function(){this.hasCompleted=!0,0===this.active&&0===this.buffer.length&&this.destination.complete()},e.prototype.notifyNext=function(t,e,n,r,i){this.resultSelector?this._notifyResultSelector(t,e,n,r):this.destination.next(e)},e.prototype._notifyResultSelector=function(t,e,n,r){var i
try{i=this.resultSelector(t,e,n,r)}catch(t){return void this.destination.error(t)}this.destination.next(i)},e.prototype.notifyComplete=function(t){var e=this.buffer
this.remove(t),this.active--,e.length>0?this._next(e.shift()):0===this.active&&this.hasCompleted&&this.destination.complete()},e}(a.OuterSubscriber)
e.MergeMapSubscriber=u},function(t,e,n){"use strict"
var r=n(24),i=(n.n(r),n(41))
n.d(e,"g",function(){return u}),n.d(e,"a",function(){return c}),n.d(e,"d",function(){return l}),n.d(e,"c",function(){return f}),n.d(e,"b",function(){return d}),n.d(e,"j",function(){return p}),n.d(e,"e",function(){return h}),n.d(e,"f",function(){return y}),n.d(e,"k",function(){return m}),n.d(e,"i",function(){return b}),n.d(e,"h",function(){return g})
var o=window,a=o.location,s=a.search,u=i.b,c=i.c,l=(s.indexOf("debug_ad_metrics"),s.indexOf("delay_ads")>=0),f=1500,d=new Promise(function(t){o.debugAds=function(){return t(),d},s.indexOf("debug_ads")>=0&&t()}).then(function(){return new r.ReplaySubject}),p=s.indexOf("debug_undelivered")>=0
Promise.race([u?Promise.resolve():new Promise(function(){}),d]).then(function(){return new Promise(function(t){return n.e(4).then(function(){return t(n(204))}.bind(null,n)).catch(n.oe)})}).then(function(t){t.load({google:{families:["Fira+Mono:400,700"]}})}).catch(function(t){console.error("import('webfontloader')",t)})
var h={fontFamily:"'Fira Mono', monospace",fontWeight:700,textRendering:"optimizeLegibility"},v=function(t){return s.indexOf(t)>=0},y=v("incremental_ads=1")&&!v("incremental_ads=0"),m=v("headertag=0"),b=v("mock_passback"),g=v("mock_undertone")||b},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=n(1),a=n(31),s=n(131),u=n(126),c=n(84),l=function(t){function e(e){t.call(this,e),this.destination=e}return r(e,t),e}(o.Subscriber)
e.SubjectSubscriber=l
var f=function(t){function e(){t.call(this),this.observers=[],this.closed=!1,this.isStopped=!1,this.hasError=!1,this.thrownError=null}return r(e,t),e.prototype[c.rxSubscriber]=function(){return new l(this)},e.prototype.lift=function(t){var e=new d(this,this)
return e.operator=t,e},e.prototype.next=function(t){if(this.closed)throw new s.ObjectUnsubscribedError
if(!this.isStopped)for(var e=this.observers,n=e.length,r=e.slice(),i=0;i<n;i++)r[i].next(t)},e.prototype.error=function(t){if(this.closed)throw new s.ObjectUnsubscribedError
this.hasError=!0,this.thrownError=t,this.isStopped=!0
for(var e=this.observers,n=e.length,r=e.slice(),i=0;i<n;i++)r[i].error(t)
this.observers.length=0},e.prototype.complete=function(){if(this.closed)throw new s.ObjectUnsubscribedError
this.isStopped=!0
for(var t=this.observers,e=t.length,n=t.slice(),r=0;r<e;r++)n[r].complete()
this.observers.length=0},e.prototype.unsubscribe=function(){this.isStopped=!0,this.closed=!0,this.observers=null},e.prototype._trySubscribe=function(e){if(this.closed)throw new s.ObjectUnsubscribedError
return t.prototype._trySubscribe.call(this,e)},e.prototype._subscribe=function(t){if(this.closed)throw new s.ObjectUnsubscribedError
return this.hasError?(t.error(this.thrownError),a.Subscription.EMPTY):this.isStopped?(t.complete(),a.Subscription.EMPTY):(this.observers.push(t),new u.SubjectSubscription(this,t))},e.prototype.asObservable=function(){var t=new i.Observable
return t.source=this,t},e.create=function(t,e){return new d(t,e)},e}(i.Observable)
e.Subject=f
var d=function(t){function e(e,n){t.call(this),this.destination=e,this.source=n}return r(e,t),e.prototype.next=function(t){var e=this.destination
e&&e.next&&e.next(t)},e.prototype.error=function(t){var e=this.destination
e&&e.error&&this.destination.error(t)},e.prototype.complete=function(){var t=this.destination
t&&t.complete&&this.destination.complete()},e.prototype._subscribe=function(t){return this.source?this.source.subscribe(t):a.Subscription.EMPTY},e}(f)
e.AnonymousSubject=d},function(t,e,n){"use strict"
function r(t,e,n){return this.lift(new s(t,e,n,this))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1),a=n(130)
e.first=r
var s=function(){function t(t,e,n,r){this.predicate=t,this.resultSelector=e,this.defaultValue=n,this.source=r}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.predicate,this.resultSelector,this.defaultValue,this.source))},t}(),u=function(t){function e(e,n,r,i,o){t.call(this,e),this.predicate=n,this.resultSelector=r,this.defaultValue=i,this.source=o,this.index=0,this.hasCompleted=!1,this._emitted=!1}return i(e,t),e.prototype._next=function(t){var e=this.index++
this.predicate?this._tryPredicate(t,e):this._emit(t,e)},e.prototype._tryPredicate=function(t,e){var n
try{n=this.predicate(t,e,this.source)}catch(t){return void this.destination.error(t)}n&&this._emit(t,e)},e.prototype._emit=function(t,e){if(this.resultSelector)return void this._tryResultSelector(t,e)
this._emitFinal(t)},e.prototype._tryResultSelector=function(t,e){var n
try{n=this.resultSelector(t,e)}catch(t){return void this.destination.error(t)}this._emitFinal(n)},e.prototype._emitFinal=function(t){var e=this.destination
this._emitted||(this._emitted=!0,e.next(t),e.complete(),this.hasCompleted=!0)},e.prototype._complete=function(){var t=this.destination
this.hasCompleted||void 0===this.defaultValue?this.hasCompleted||t.error(new a.EmptyError):(t.next(this.defaultValue),t.complete())},e}(o.Subscriber)},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"e",function(){return i}),n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a}),n.d(e,"c",function(){return s}),n.d(e,"d",function(){return u})
var i=function(t){t.document.querySelector("#sidebar")&&(t.document.querySelector("#sidebar").style.overflow="visible"),t.document.querySelector("#sidebar .popular-box")&&(t.document.querySelector("#sidebar .popular-box").style.overflow="visible")},o={slotify:{name:"leaderboard",type:r.b,position:r.c,align:r.d,width:r.s,height:r.t,fixed:!0,preactivated:!0},hook:n.i(r.h)("#main"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}},a={slotify:{name:"top of sidebar",type:r.b,position:r.n,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar"),backgroundColor:r.i,boilerplate:!0,style:{marginBottom:"20px"}},s={slotify:{name:"before popular box",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0},u={slotify:{name:"after popular box",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0}},function(t,e){function n(){throw new Error("setTimeout has not been defined")}function r(){throw new Error("clearTimeout has not been defined")}function i(t){if(l===setTimeout)return setTimeout(t,0)
if((l===n||!l)&&setTimeout)return l=setTimeout,setTimeout(t,0)
try{return l(t,0)}catch(e){try{return l.call(null,t,0)}catch(e){return l.call(this,t,0)}}}function o(t){if(f===clearTimeout)return clearTimeout(t)
if((f===r||!f)&&clearTimeout)return f=clearTimeout,clearTimeout(t)
try{return f(t)}catch(e){try{return f.call(null,t)}catch(e){return f.call(this,t)}}}function a(){v&&p&&(v=!1,p.length?h=p.concat(h):y=-1,h.length&&s())}function s(){if(!v){var t=i(a)
v=!0
for(var e=h.length;e;){for(p=h,h=[];++y<e;)p&&p[y].run()
y=-1,e=h.length}p=null,v=!1,o(t)}}function u(t,e){this.fun=t,this.array=e}function c(){}var l,f,d=t.exports={}
!function(){try{l="function"==typeof setTimeout?setTimeout:n}catch(t){l=n}try{f="function"==typeof clearTimeout?clearTimeout:r}catch(t){f=r}}()
var p,h=[],v=!1,y=-1
d.nextTick=function(t){var e=new Array(arguments.length-1)
if(arguments.length>1)for(var n=1;n<arguments.length;n++)e[n-1]=arguments[n]
h.push(new u(t,e)),1!==h.length||v||i(s)},u.prototype.run=function(){this.fun.apply(null,this.array)},d.title="browser",d.browser=!0,d.env={},d.argv=[],d.version="",d.versions={},d.on=c,d.addListener=c,d.once=c,d.off=c,d.removeListener=c,d.removeAllListeners=c,d.emit=c,d.binding=function(t){throw new Error("process.binding is not supported")},d.cwd=function(){return"/"},d.chdir=function(t){throw new Error("process.chdir is not supported")},d.umask=function(){return 0}},,function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(1),o=function(t){function e(){t.apply(this,arguments)}return r(e,t),e.prototype.notifyNext=function(t,e,n,r,i){this.destination.next(e)},e.prototype.notifyError=function(t,e){this.destination.error(t)},e.prototype.notifyComplete=function(t){this.destination.complete()},e}(i.Subscriber)
e.OuterSubscriber=o},function(t,e,n){"use strict"
function r(t,e,n,r){var d=new l.InnerSubscriber(t,n,r)
if(d.closed)return null
if(e instanceof u.Observable)return e._isScalar?(d.next(e.value),d.complete(),null):e.subscribe(d)
if(o.isArrayLike(e)){for(var p=0,h=e.length;p<h&&!d.closed;p++)d.next(e[p])
d.closed||d.complete()}else{if(a.isPromise(e))return e.then(function(t){d.closed||(d.next(t),d.complete())},function(t){return d.error(t)}).then(null,function(t){i.root.setTimeout(function(){throw t})}),d
if(e&&"function"==typeof e[c.iterator])for(var v=e[c.iterator]();;){var y=v.next()
if(y.done){d.complete()
break}if(d.next(y.value),d.closed)break}else if(e&&"function"==typeof e[f.observable]){var m=e[f.observable]()
if("function"==typeof m.subscribe)return m.subscribe(new l.InnerSubscriber(t,n,r))
d.error(new TypeError("Provided object does not correctly implement Symbol.observable"))}else{var b=s.isObject(e)?"an invalid object":"'"+e+"'",g="You provided "+b+" where a stream was expected. You can provide an Observable, Promise, Array, or Iterable."
d.error(new TypeError(g))}}return null}var i=n(11),o=n(132),a=n(136),s=n(135),u=n(2),c=n(82),l=n(295),f=n(83)
e.subscribeToResult=r},function(t,e,n){"use strict"
var r=n(311)
e.merge=r.mergeStatic},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(16),o=n(322),a=n(31),s=n(65),u=n(131),c=n(126),l=function(t){function e(e,n,r){void 0===e&&(e=Number.POSITIVE_INFINITY),void 0===n&&(n=Number.POSITIVE_INFINITY),t.call(this),this.scheduler=r,this._events=[],this._bufferSize=e<1?1:e,this._windowTime=n<1?1:n}return r(e,t),e.prototype.next=function(e){var n=this._getNow()
this._events.push(new f(n,e)),this._trimBufferThenGetEvents(),t.prototype.next.call(this,e)},e.prototype._subscribe=function(t){var e,n=this._trimBufferThenGetEvents(),r=this.scheduler
if(this.closed)throw new u.ObjectUnsubscribedError
this.hasError?e=a.Subscription.EMPTY:this.isStopped?e=a.Subscription.EMPTY:(this.observers.push(t),e=new c.SubjectSubscription(this,t)),r&&t.add(t=new s.ObserveOnSubscriber(t,r))
for(var i=n.length,o=0;o<i&&!t.closed;o++)t.next(n[o].value)
return this.hasError?t.error(this.thrownError):this.isStopped&&t.complete(),e},e.prototype._getNow=function(){return(this.scheduler||o.queue).now()},e.prototype._trimBufferThenGetEvents=function(){for(var t=this._getNow(),e=this._bufferSize,n=this._windowTime,r=this._events,i=r.length,o=0;o<i&&!(t-r[o].time<n);)o++
return i>e&&(o=Math.max(o,i-e)),o>0&&r.splice(0,o),r},e}(i.Subject)
e.ReplaySubject=l
var f=function(){function t(t,e){this.time=t,this.value=e}return t}()},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=n(78),a=n(52),s=n(37),u=function(t){function e(e,n){t.call(this),this.array=e,this.scheduler=n,n||1!==e.length||(this._isScalar=!0,this.value=e[0])}return r(e,t),e.create=function(t,n){return new e(t,n)},e.of=function(){for(var t=[],n=0;n<arguments.length;n++)t[n-0]=arguments[n]
var r=t[t.length-1]
s.isScheduler(r)?t.pop():r=null
var i=t.length
return i>1?new e(t,r):1===i?new o.ScalarObservable(t[0],r):new a.EmptyObservable(r)},e.dispatch=function(t){var e=t.array,n=t.index,r=t.count,i=t.subscriber
if(n>=r)return void i.complete()
i.next(e[n]),i.closed||(t.index=n+1,this.schedule(t))},e.prototype._subscribe=function(t){var n=this.array,r=n.length,i=this.scheduler
if(i)return i.schedule(e.dispatch,0,{array:n,index:0,count:r,subscriber:t})
for(var o=0;o<r&&!t.closed;o++)t.next(n[o])
t.complete()},e}(i.Observable)
e.ArrayObservable=u},function(t,e,n){"use strict"
function r(t,e){void 0===e&&(e=o.async)
var n=a.isDate(t),r=n?+t-e.now():Math.abs(t)
return this.lift(new c(r,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(67),a=n(133),s=n(1),u=n(105)
e.delay=r
var c=function(){function t(t,e){this.delay=t,this.scheduler=e}return t.prototype.call=function(t,e){return e.subscribe(new l(t,this.delay,this.scheduler))},t}(),l=function(t){function e(e,n,r){t.call(this,e),this.delay=n,this.scheduler=r,this.queue=[],this.active=!1,this.errored=!1}return i(e,t),e.dispatch=function(t){for(var e=t.source,n=e.queue,r=t.scheduler,i=t.destination;n.length>0&&n[0].time-r.now()<=0;)n.shift().notification.observe(i)
if(n.length>0){var o=Math.max(0,n[0].time-r.now())
this.schedule(t,o)}else e.active=!1},e.prototype._schedule=function(t){this.active=!0,this.add(t.schedule(e.dispatch,this.delay,{source:this,destination:this.destination,scheduler:t}))},e.prototype.scheduleNotification=function(t){if(!0!==this.errored){var e=this.scheduler,n=new f(e.now()+this.delay,t)
this.queue.push(n),!1===this.active&&this._schedule(e)}},e.prototype._next=function(t){this.scheduleNotification(u.Notification.createNext(t))},e.prototype._error=function(t){this.errored=!0,this.queue=[],this.destination.error(t)},e.prototype._complete=function(){this.scheduleNotification(u.Notification.createComplete())},e}(s.Subscriber),f=function(){function t(t,e){this.time=t,this.notification=e}return t}()},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n
"function"==typeof t[t.length-1]&&(n=t.pop())
var r=t
return this.lift(new s(r,n))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(21),a=n(22)
e.withLatestFrom=r
var s=function(){function t(t,e){this.observables=t,this.project=e}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.observables,this.project))},t}(),u=function(t){function e(e,n,r){t.call(this,e),this.observables=n,this.project=r,this.toRespond=[]
var i=n.length
this.values=new Array(i)
for(var o=0;o<i;o++)this.toRespond.push(o)
for(var o=0;o<i;o++){var s=n[o]
this.add(a.subscribeToResult(this,s,s,o))}}return i(e,t),e.prototype.notifyNext=function(t,e,n,r,i){this.values[n]=e
var o=this.toRespond
if(o.length>0){var a=o.indexOf(n);-1!==a&&o.splice(a,1)}},e.prototype.notifyComplete=function(){},e.prototype._next=function(t){if(0===this.toRespond.length){var e=[t].concat(this.values)
this.project?this._tryProject(e):this.destination.next(e)}},e.prototype._tryProject=function(t){var e
try{e=this.project.apply(this,t)}catch(t){return void this.destination.error(t)}this.destination.next(e)},e}(o.OuterSubscriber)},function(t,e,n){"use strict"
var r=n(25)
e.of=r.ArrayObservable.of},function(t,e,n){"use strict"
var r=n(3)
n.d(e,"e",function(){return a}),n.d(e,"k",function(){return s}),n.d(e,"d",function(){return c}),n.d(e,"h",function(){return f}),n.d(e,"i",function(){return p}),n.d(e,"l",function(){return h}),n.d(e,"c",function(){return v}),n.d(e,"g",function(){return y}),n.d(e,"j",function(){return m}),n.d(e,"n",function(){return b}),n.d(e,"b",function(){return g}),n.d(e,"o",function(){return w}),n.d(e,"a",function(){return _}),n.d(e,"m",function(){return x}),n.d(e,"f",function(){return S})
var i=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=function(t){return Array.isArray(t)?t:[t]},a="occupy",s=function(t){return i({eventID:n.i(r.a)(),type:a},t)},u="priority",c=function(t,e,i){return{eventID:n.i(r.a)(),type:u,id:t,priority:e,eventDeps:o(i)}},l="sticky",f=function(t,e,i){return{eventID:n.i(r.a)(),type:l,id:t,margin:e,sticky:i}},d="collapse-slot",p=function(t){var e=t.slotID,i=t.tileID
return{eventID:n.i(r.a)(),type:d,slotID:e,tileID:i}},h="specify-shrinkwrapped",v=function(t){return function(e){return{eventID:n.i(r.a)(),type:h,id:e,value:t}}},y="slot-resized",m=function(t){var e=t.width,i=t.height,o=t.id,a=t.tileID
return{eventID:n.i(r.a)(),type:y,id:o,tileID:a,width:e,height:i}},b="execute-function",g=function(t){return{eventID:n.i(r.a)(),function:t,type:b}},w="add-script",_=function(t){return{eventID:n.i(r.a)(),url:t,type:w}},x="track-size",S=function(t,e,i,o){return{eventID:n.i(r.a)(),eventDeps:[o],type:x,id:t,width:e,height:i}}},function(t,e,n){"use strict"
var r=n(116)
e.a=function(t){for(var e=arguments.length,i=Array(e>1?e-1:0),o=1;o<e;o++)i[o-1]=arguments[o]
return n.i(r.a)(t.querySelectorAll.apply(t,i))}},function(t,e,n){"use strict"
function r(t){return t.reduce(function(t,e){return t.concat(e instanceof c.UnsubscriptionError?e.errors:e)},[])}var i=n(45),o=n(135),a=n(134),s=n(137),u=n(85),c=n(325),l=function(){function t(t){this.closed=!1,this._parent=null,this._parents=null,this._subscriptions=null,t&&(this._unsubscribe=t)}return t.prototype.unsubscribe=function(){var t,e=!1
if(!this.closed){var n=this,l=n._parent,f=n._parents,d=n._unsubscribe,p=n._subscriptions
this.closed=!0,this._parent=null,this._parents=null,this._subscriptions=null
for(var h=-1,v=f?f.length:0;l;)l.remove(this),l=++h<v&&f[h]||null
if(a.isFunction(d)){var y=s.tryCatch(d).call(this)
y===u.errorObject&&(e=!0,t=t||(u.errorObject.e instanceof c.UnsubscriptionError?r(u.errorObject.e.errors):[u.errorObject.e]))}if(i.isArray(p))for(h=-1,v=p.length;++h<v;){var m=p[h]
if(o.isObject(m)){var y=s.tryCatch(m.unsubscribe).call(m)
if(y===u.errorObject){e=!0,t=t||[]
var b=u.errorObject.e
b instanceof c.UnsubscriptionError?t=t.concat(r(b.errors)):t.push(b)}}}if(e)throw new c.UnsubscriptionError(t)}},t.prototype.add=function(e){if(!e||e===t.EMPTY)return t.EMPTY
if(e===this)return this
var n=e
switch(typeof e){case"function":n=new t(e)
case"object":if(n.closed||"function"!=typeof n.unsubscribe)return n
if(this.closed)return n.unsubscribe(),n
if("function"!=typeof n._addParent){var r=n
n=new t,n._subscriptions=[r]}break
default:throw new Error("unrecognized teardown "+e+" added to Subscription.")}return(this._subscriptions||(this._subscriptions=[])).push(n),n._addParent(this),n},t.prototype.remove=function(t){var e=this._subscriptions
if(e){var n=e.indexOf(t);-1!==n&&e.splice(n,1)}},t.prototype._addParent=function(t){var e=this,n=e._parent,r=e._parents
n&&n!==t?r?-1===r.indexOf(t)&&r.push(t):this._parents=[t]:this._parent=t},t.EMPTY=function(t){return t.closed=!0,t}(new t),t}()
e.Subscription=l},function(t,e,n){"use strict"
var r=function(t,e,n,r,i,o,a,s){if(!t){var u
if(void 0===e)u=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.")
else{var c=[n,r,i,o,a,s],l=0
u=new Error(e.replace(/%s/g,function(){return c[l++]})),u.name="Invariant Violation"}throw u.framesToPop=1,u}}
t.exports=r},,,,function(t,e,n){"use strict"
var r=n(0)
n.d(e,"e",function(){return i}),n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a}),n.d(e,"c",function(){return s}),n.d(e,"d",function(){return u})
var i=function(t){t.document.querySelector("#sidebar")&&(t.document.querySelector("#sidebar").style.overflow="visible"),t.document.querySelector("#sidebar .popular-box")&&(t.document.querySelector("#sidebar .popular-box").style.overflow="visible")},o={slotify:{name:"leaderboard",type:r.b,position:r.n,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)("#main"),style:{marginTop:"20px"}},a={slotify:{name:"top of sidebar",type:r.b,position:r.n,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar"),backgroundColor:r.i,boilerplate:!0},s={slotify:{name:"top of popular box",type:r.b,position:r.n,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0},u={slotify:{name:"after popular box",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0}},function(t,e,n){"use strict"
function r(t){return t&&"function"==typeof t.schedule}e.isScheduler=r},function(t,e,n){"use strict"
var r=n(77)
if(n.n(r)()(n.p)||(n.p=document.querySelector("#static-host-pattern").dataset.staticHost+n.p),!n.p)throw new Error("No __webpack_public_path__ - chunk loading will not work")},function(t,e,n){if(!window.Promise)try{n(75).polyfill()}catch(t){console.error("ERROR WHEN RUNNING PROMISE POLYFILL",t)}},,function(t,e,n){"use strict"
n.d(e,"b",function(){return c}),n.d(e,"a",function(){return f}),n.d(e,"e",function(){return d}),n.d(e,"d",function(){return p}),n.d(e,"c",function(){return h}),n.d(e,"f",function(){return v})
var r=window,i=r.location,o=i.href,a=i.search,s=function(t){return a.indexOf(t)>=0},u=function(t){return o.indexOf(t)>=0},c=(s("mock_ads")||u("local.fte."))&&!s("real_ads"),l="ActiveXObject"in window,f=(s("preallocate=0"),function(t){var e=a.indexOf(t)
if(e>=0){var n=a.indexOf("=",e),r=a.indexOf("&",n+1)
return r>=0?a.substring(n+1,r):a.substring(n+1)}return!1}),d=f("slot_layout"),p=f("ad_format"),h=window.usingBordeauxAds&&!s("force_bordeaux=0")||s("force_bordeaux=1"),v=f("force_locale")},function(t,e,n){"use strict"
var r=n(43),i=n.n(r)
e.a=i.a},function(t,e,n){"use strict"
function r(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(e,"__esModule",{value:!0}),e.default=function(){return window.Map?new Map:new i}
var i=function(){function t(){r(this,t),this.key=[],this.value=[]}return t.prototype.set=function(t,e){var n=this.key.indexOf(t)
if(n>-1)return void(this.value[n]=e)
this.key.push(t),this.value.push(e)},t.prototype.get=function(t){var e=this.key.indexOf(t)
if(e>-1)return this.value[e]},t.prototype.delete=function(t){var e=this.key.indexOf(t)
e>-1&&(this.value[e]=void 0)},t.prototype.has=function(t){return-1!==this.key.indexOf(t)},t.prototype.forEach=function(t){var e=this
this.key.forEach(function(n,r){e.value[r]&&t(e.value[r],n)})},t}()},function(t,e,n){"use strict"
function r(t){return void 0===t&&(t=Number.POSITIVE_INFINITY),this.lift(new s(t))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(21),a=n(22)
e.mergeAll=r
var s=function(){function t(t){this.concurrent=t}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.concurrent))},t}()
e.MergeAllOperator=s
var u=function(t){function e(e,n){t.call(this,e),this.concurrent=n,this.hasCompleted=!1,this.buffer=[],this.active=0}return i(e,t),e.prototype._next=function(t){this.active<this.concurrent?(this.active++,this.add(a.subscribeToResult(this,t))):this.buffer.push(t)},e.prototype._complete=function(){this.hasCompleted=!0,0===this.active&&0===this.buffer.length&&this.destination.complete()},e.prototype.notifyComplete=function(t){var e=this.buffer
this.remove(t),this.active--,e.length>0?this._next(e.shift()):0===this.active&&this.hasCompleted&&this.destination.complete()},e}(o.OuterSubscriber)
e.MergeAllSubscriber=u},function(t,e,n){"use strict"
e.isArray=Array.isArray||function(t){return t&&"number"==typeof t.length}},function(t,e,n){"use strict"
function r(t,e){var n={}
for(var r in t)e.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(t,r)&&(n[r]=t[r])
return n}var i=n(246),o=n(8),a=(n.n(o),n(44)),s=(n.n(a),n(23))
n.n(s)
n.d(e,"a",function(){return l})
var u=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},c=function(t){var e=(t.url,t.script,r(t,["url","script"]))
return u({status:"pending"},e)},l=function(t){return function(e){var r
return n.i(s.merge)(o.map.call(t,c),(r=(r=n.i(i.a)("creative-loaded")(function(t){return"slotify"===t.advert.mode})(5e3)(e),o.map).call(r,function(e){var n=e.eventID
return o.map.call(t,function(t){return u({},t,{eventDeps:[n],status:"active"})})}),a.mergeAll).call(r))}}},function(t,e,n){"use strict"
var r=n(3)
n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a})
var i={t3:{reload:"//tags.onscroll.com/11f75f3c-bedc-4983-870e-30c138826924/tag.min.js",sticky:"//tags.onscroll.com/4c87793a-e436-4dad-b693-44cc0f44165d/tag.min.js"},techradar:{reload:"//tags.onscroll.com/f3e5b408-3d18-4a16-8db9-1dced0d528b5/tag.min.js",sticky:"//tags.onscroll.com/798ccfa0-1764-403b-bc4c-b7c12c2c1f22/tag.min.js"},creativebloq:{reload:"//tags.onscroll.com/38f7da94-8c7d-4b90-b3e3-dd425971ee70/tag.min.js",sticky:"//tags.onscroll.com/e22de8d4-0fbe-4518-a9d4-44d0352cf7de/tag.min.js"},musicradar:{reload:"//tags.onscroll.com/493641ed-021c-408a-b278-9a89d5fad223/tag.min.js",sticky:"//tags.onscroll.com/4e1de118-80ea-4d13-a832-34e4f3138684/tag.min.js"},pcgamer:{reload:"//tags.onscroll.com/f10a9745-d9b4-4ebe-a95a-eb4553b7f3f5/tag.min.js",sticky:"//tags.onscroll.com/91e82672-300e-408a-b902-60f10ab4d22f/tag.min.js"},gamesradar:{reload:"//tags.onscroll.com/ca62e589-d43c-4e91-b00d-634319250cec/tag.min.js",sticky:"//tags.onscroll.com/26db11cf-fb54-48cb-a6a3-508eb08f236a/tag.min.js"},itproportal:{reload:"//tags.onscroll.com/657a5ab0-ad5b-4a4f-919f-e60e26fa74ff/tag.min.js",sticky:"//tags.onscroll.com/40083ebe-b63f-4756-8321-95cab89a9a1c/tag.min.js"}},o=function(t){return{name:"onscroll reloading",brief:"Reloads actively viewed ads every 25 seconds. Correct behaviour can only be checked manually",description:"Reloads actively viewed ads every 25 seconds",url:i[t].reload,eventID:n.i(r.a)()}},a=function(t){return{name:"onscroll sticky mpu",brief:"Extra sticky MPU on right rail. Correct behaviour can only be checked manually",description:"Extra sticky MPU on right rail",url:i[t].sticky,eventID:n.i(r.a)()}}},function(t,e,n){"use strict"
var r=n(3)
n.d(e,"b",function(){return o}),n.d(e,"a",function(){return a})
var i=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=function(t,e){var o=["ukSponsored1","ukSponsored2","ukSponsored3"]
return function(o){return o.filter(function(e){return t(e,!1)>=0}).map(function(o,a){return i({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:o,preempt:!0},"mobile"===e?{fluid:!0}:{width:610,height:190},{category:"sponsored-post",affinities:[{id:t(o),pinned:!0}],dfp:{sizes:[[610,190]],targeting:{pos:a+1,placement:"dfp_rs_"+o.slice(0,2)+"_sponsored_"+(a+1)}},collapsed:!0})})}(o)},a=function(t,e){return["sponsored1","sponsored2","sponsored3"].filter(function(e){return t(e,!1)>=0}).map(function(i,o){return{eventID:n.i(r.a)(),type:"create",mode:"slotify",fluid:!0,name:i,preempt:!0,category:"sponsored-post",affinities:[{id:t(i),pinned:!0}],legacySponsoredPost:"mobile"!==e,dfp:{sizes:[[5,5]],targeting:{pos:o+1,placement:"dfp_rs_"+e+"_sponsored_"+(o+1)}},collapsed:!0}})}},function(t,e,n){"use strict"
var r=n(24)
n.n(r)
n.d(e,"a",function(){return a})
var i=30,o=new r.ReplaySubject(i)
window._adsShimCommunication=window._adsShimCommunication||function(){return{send:function(t){arguments.length>1&&void 0!==arguments[1]&&arguments[1]
o.next(t)},receive:function(t){arguments.length>1&&void 0!==arguments[1]&&arguments[1]
o.subscribe(t)}}}()
var a=(window._adsShimCommunication.send,window._adsShimCommunication.receive)},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=window.location.href.indexOf("debug_hopscotch")>=0},function(t,e){t.exports=function(t){for(var e=[],n=1;n<arguments.length;n++)e[n-1]=arguments[n]
var r=[],i="string"==typeof t?[t]:t.slice()
i[i.length-1]=i[i.length-1].replace(/\r?\n([\t ]*)$/,"")
for(var o=0;o<i.length;o++){var a=void 0;(a=i[o].match(/\n[\t ]+/g))&&r.push.apply(r,a)}if(r.length)for(var s=Math.min.apply(Math,r.map(function(t){return t.length-1})),u=new RegExp("\n[\t ]{"+s+"}","g"),o=0;o<i.length;o++)i[o]=i[o].replace(u,"\n")
i[0]=i[0].replace(/^\r?\n/,"")
for(var c=i[0],o=0;o<e.length;o++)c+=e[o]+i[o+1]
return c}},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=function(t){function e(e){t.call(this),this.scheduler=e}return r(e,t),e.create=function(t){return new e(t)},e.dispatch=function(t){t.subscriber.complete()},e.prototype._subscribe=function(t){var n=this.scheduler
if(n)return n.schedule(e.dispatch,0,{subscriber:t})
t.complete()},e}(i.Observable)
e.EmptyObservable=o},function(t,e,n){"use strict"
var r=n(52)
e.empty=r.EmptyObservable.create},function(t,e,n){"use strict"
function r(t){return t(this)}e.letProto=r},function(t,e,n){"use strict"
function r(t){return this.lift(new a(t))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.mapTo=r
var a=function(){function t(t){this.value=t}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.value))},t}(),s=function(t){function e(e,n){t.call(this,e),this.value=n}return i(e,t),e.prototype._next=function(t){this.destination.next(this.value)},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(t,e){return this.lift(new s(t,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(21),a=n(22)
e.switchMap=r
var s=function(){function t(t,e){this.project=t,this.resultSelector=e}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.project,this.resultSelector))},t}(),u=function(t){function e(e,n,r){t.call(this,e),this.project=n,this.resultSelector=r,this.index=0}return i(e,t),e.prototype._next=function(t){var e,n=this.index++
try{e=this.project(t,n)}catch(t){return void this.destination.error(t)}this._innerSub(e,t,n)},e.prototype._innerSub=function(t,e,n){var r=this.innerSubscription
r&&r.unsubscribe(),this.add(this.innerSubscription=a.subscribeToResult(this,t,e,n))},e.prototype._complete=function(){var e=this.innerSubscription
e&&!e.closed||t.prototype._complete.call(this)},e.prototype._unsubscribe=function(){this.innerSubscription=null},e.prototype.notifyComplete=function(e){this.remove(e),this.innerSubscription=null,this.isStopped&&t.prototype._complete.call(this)},e.prototype.notifyNext=function(t,e,n,r,i){this.resultSelector?this._tryNotifyNext(t,e,n,r):this.destination.next(e)},e.prototype._tryNotifyNext=function(t,e,n,r){var i
try{i=this.resultSelector(t,e,n,r)}catch(t){return void this.destination.error(t)}this.destination.next(i)},e}(o.OuterSubscriber)},,,,,,,,function(t,e,n){"use strict";(function(t){var e=e
e||(e=void 0!==t?t:self),Array.prototype.fill||(Array.prototype.fill=function(t){if(null===this)throw new TypeError("this is null or not defined")
for(var e=Object(this),n=e.length>>>0,r=arguments[1],i=r>>0,o=i<0?Math.max(n+i,0):Math.min(i,n),a=arguments[2],s=void 0===a?n:a>>0,u=s<0?Math.max(n+s,0):Math.min(s,n);o<u;)e[o]=t,o++
return e}),Array.from||(Array.from=function(){var t=Object.prototype.toString,e=function(e){return"function"==typeof e||"[object Function]"===t.call(e)},n=function(t){var e=Number(t)
return isNaN(e)?0:0!==e&&isFinite(e)?(e>0?1:-1)*Math.floor(Math.abs(e)):e},r=Math.pow(2,53)-1,i=function(t){var e=n(t)
return Math.min(Math.max(e,0),r)}
return function(t){var n=this,r=Object(t)
if(null===t)throw new TypeError("Array.from requires an array-like object - not null or undefined")
var o,a=arguments.length>1?arguments[1]:void 0
if(void 0!==a){if(!e(a))throw new TypeError("Array.from: when provided, the second argument must be a function")
arguments.length>2&&(o=arguments[2])}for(var s,u=i(r.length),c=e(n)?Object(new n(u)):new Array(u),l=0;l<u;)s=r[l],c[l]=a?void 0===o?a(s,l):a.call(o,s,l):s,l+=1
return c.length=u,c}}()),"function"!=typeof Object.assign&&function(){Object.assign=function(t){if(void 0===t||null===t)throw new TypeError("Cannot convert undefined or null to object")
for(var e=Object(t),n=1;n<arguments.length;n++){var r=arguments[n]
if(void 0!==r&&null!==r)for(var i in r)r.hasOwnProperty(i)&&(e[i]=r[i])}return e}}(),Number.isInteger=Number.isInteger||function(t){return"number"==typeof t&&isFinite(t)&&Math.floor(t)===t}}).call(e,n(9))},function(t,e,n){"use strict"
function r(t,e){return void 0===e&&(e=0),this.lift(new s(t,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1),a=n(105)
e.observeOn=r
var s=function(){function t(t,e){void 0===e&&(e=0),this.scheduler=t,this.delay=e}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.scheduler,this.delay))},t}()
e.ObserveOnOperator=s
var u=function(t){function e(e,n,r){void 0===r&&(r=0),t.call(this,e),this.scheduler=n,this.delay=r}return i(e,t),e.dispatch=function(t){var e=t.notification,n=t.destination
e.observe(n),this.unsubscribe()},e.prototype.scheduleMessage=function(t){this.add(this.scheduler.schedule(e.dispatch,this.delay,new c(t,this.destination)))},e.prototype._next=function(t){this.scheduleMessage(a.Notification.createNext(t))},e.prototype._error=function(t){this.scheduleMessage(a.Notification.createError(t))},e.prototype._complete=function(){this.scheduleMessage(a.Notification.createComplete())},e}(o.Subscriber)
e.ObserveOnSubscriber=u
var c=function(){function t(t,e){this.notification=t,this.destination=e}return t}()
e.ObserveOnMessage=c},function(t,e,n){"use strict"
function r(t,e){var n=!1
return arguments.length>=2&&(n=!0),this.lift(new a(t,e,n))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.scan=r
var a=function(){function t(t,e,n){void 0===n&&(n=!1),this.accumulator=t,this.seed=e,this.hasSeed=n}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.accumulator,this.seed,this.hasSeed))},t}(),s=function(t){function e(e,n,r,i){t.call(this,e),this.accumulator=n,this._seed=r,this.hasSeed=i,this.index=0}return i(e,t),Object.defineProperty(e.prototype,"seed",{get:function(){return this._seed},set:function(t){this.hasSeed=!0,this._seed=t},enumerable:!0,configurable:!0}),e.prototype._next=function(t){if(this.hasSeed)return this._tryNext(t)
this.seed=t,this.destination.next(t)},e.prototype._tryNext=function(t){var e,n=this.index++
try{e=this.accumulator(this.seed,t,n)}catch(t){this.destination.error(t)}this.seed=e,this.destination.next(e)},e}(o.Subscriber)},function(t,e,n){"use strict"
var r=n(70),i=n(71)
e.async=new i.AsyncScheduler(r.AsyncAction)},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n=null,r=null
return i.isScheduler(t[t.length-1])&&(r=t.pop()),"function"==typeof t[t.length-1]&&(n=t.pop()),1===t.length&&o.isArray(t[0])&&(t=t[0]),new a.ArrayObservable(t,r).lift(new s.CombineLatestOperator(n))}var i=n(37),o=n(45),a=n(25),s=n(127)
e.combineLatest=r},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n=t[t.length-1]
u.isScheduler(n)?t.pop():n=null
var r=t.length
return 1===r?s.concatStatic(new o.ScalarObservable(t[0],n),this):r>1?s.concatStatic(new i.ArrayObservable(t,n),this):s.concatStatic(new a.EmptyObservable(n),this)}var i=n(25),o=n(78),a=n(52),s=n(305),u=n(37)
e.startWith=r},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(11),o=n(316),a=function(t){function e(e,n){t.call(this,e,n),this.scheduler=e,this.work=n,this.pending=!1}return r(e,t),e.prototype.schedule=function(t,e){if(void 0===e&&(e=0),this.closed)return this
this.state=t,this.pending=!0
var n=this.id,r=this.scheduler
return null!=n&&(this.id=this.recycleAsyncId(r,n,e)),this.delay=e,this.id=this.id||this.requestAsyncId(r,this.id,e),this},e.prototype.requestAsyncId=function(t,e,n){return void 0===n&&(n=0),i.root.setInterval(t.flush.bind(t,this),n)},e.prototype.recycleAsyncId=function(t,e,n){return void 0===n&&(n=0),null!==n&&this.delay===n?e:i.root.clearInterval(e)&&void 0||void 0},e.prototype.execute=function(t,e){if(this.closed)return new Error("executing a cancelled action")
this.pending=!1
var n=this._execute(t,e)
if(n)return n
!1===this.pending&&null!=this.id&&(this.id=this.recycleAsyncId(this.scheduler,this.id,null))},e.prototype._execute=function(t,e){var n=!1,r=void 0
try{this.work(t)}catch(t){n=!0,r=!!t&&t||new Error(t)}if(n)return this.unsubscribe(),r},e.prototype._unsubscribe=function(){var t=this.id,e=this.scheduler,n=e.actions,r=n.indexOf(this)
this.work=null,this.delay=null,this.state=null,this.pending=!1,this.scheduler=null,-1!==r&&n.splice(r,1),null!=t&&(this.id=this.recycleAsyncId(e,t,null))},e}(o.Action)
e.AsyncAction=a},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(296),o=function(t){function e(){t.apply(this,arguments),this.actions=[],this.active=!1,this.scheduled=void 0}return r(e,t),e.prototype.flush=function(t){var e=this.actions
if(this.active)return void e.push(t)
var n
this.active=!0
do{if(n=t.execute(t.state,t.delay))break}while(t=e.shift())
if(this.active=!1,n){for(;t=e.shift();)t.unsubscribe()
throw n}},e}(i.Scheduler)
e.AsyncScheduler=o},function(t,e,n){"use strict"
var r=n(6),i=n(8)
n.n(i)
e.a=function(t){return function(e){return function(n){var o
return(o=r.a.call(n,t),i.map).call(o,e)}}}},function(t,e,n){"use strict"
function r(t){for(var e=!1,n=!1,r=!1,i=0;i<t.length;i++){var o=t[i]
e&&/[a-zA-Z]/.test(o)&&o.toUpperCase()===o?(t=t.substr(0,i)+"-"+t.substr(i),e=!1,r=n,n=!0,i++):n&&r&&/[a-zA-Z]/.test(o)&&o.toLowerCase()===o?(t=t.substr(0,i-1)+"-"+t.substr(i-1),r=n,n=!1,e=!0):(e=o.toLowerCase()===o,r=n,n=o.toUpperCase()===o)}return t}e.a=function(){var t=Array.from(arguments).map(function(t){return t.trim()}).filter(function(t){return t.length}).join("-")
return 0===t.length?"":1===t.length?t.toLowerCase():(t=r(t),t.replace(/^[_.\- ]+/,"").toLowerCase().replace(/[_.\- ]+(\w|$)/g,function(t,e){return e.toUpperCase()}))}},function(t,e,n){"use strict"
function r(t,e){if(e.affinities&&e.affinities.some(function(t){return"number"!=typeof t&&"number"!=typeof t.id}))throw new Error("All the affinities should be integer ids for tile "+e.name+".\n      \nAffinities: "+e.affinities)
return{type:"ADD_TILE",tile:e,id:t}}function i(t,e){return{type:"SET_SCORE",score:e,id:t}}function o(t,e){return{type:"SET_SHRINKWRAPPED",value:e,id:t}}function a(t){return n.i(v.a)(t,!1,null,y.a).then(function(t){return t.map(function(t){var e=m
return m++,{action:{type:"ADD_SLOT",slot:Object.assign({},t.slot,{coordinates:t.coordinates,element:t.id}),id:e},element:t.element,id:e}})})}function s(t){return n.i(v.b)(t,!1,null,y.a).then(function(e){var n=m
return m++,{action:{type:"ADD_SLOT",slot:Object.assign({},t,{coordinates:e.coordinates,element:e.id}),id:n},element:e.element,id:n}})}function u(t,e){return e.top,{type:"OUT_OF_VIEW",id:t,time:0|window.performance.now(),event:e}}function c(t,e,n){return{type:"TILE_SIZE",id:t,width:e,height:n}}function l(t,e){return e.top,{type:"IN_VIEW",id:t,time:0|window.performance.now(),event:e}}function f(t,e){return e.top,{type:"VIEW_SLOT",id:t,event:e,time:0|window.performance.now()}}function d(t,e,n){return{type:"VIEW_UPDATES",coordinates:[].concat(t,e,n).filter(function(t){return t.event&&void 0!==t.event.left}).map(function(t){return{left:0|t.event.left,right:0|t.event.right,top:0|t.event.top,bottom:0|t.event.bottom,id:t.id}}),inView:t,view:e,outOfView:n,time:0|window.performance.now()}}function p(t,e,n){return{type:"PLACE",id:t,left:e,top:n}}function h(){return{type:"FILL_PROACTIVE"}}var v=n(120),y=n(123)
e.e=r,e.c=i,e.d=o,e.a=a,e.b=s,e.k=u,e.l=c,e.j=l,e.i=f,e.h=d,e.f=p,e.g=h
var m=0},function(t,e,n){(function(e,r){/*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
 * @version   4.1.0
 */
!function(e,n){t.exports=n()}(0,function(){"use strict"
function t(t){return"function"==typeof t||"object"==typeof t&&null!==t}function i(t){return"function"==typeof t}function o(t){K=t}function a(t){G=t}function s(){return function(){return e.nextTick(d)}}function u(){return void 0!==J?function(){J(d)}:f()}function c(){var t=0,e=new Q(d),n=document.createTextNode("")
return e.observe(n,{characterData:!0}),function(){n.data=t=++t%2}}function l(){var t=new MessageChannel
return t.port1.onmessage=d,function(){return t.port2.postMessage(0)}}function f(){var t=setTimeout
return function(){return t(d,1)}}function d(){for(var t=0;t<Y;t+=2){(0,nt[t])(nt[t+1]),nt[t]=void 0,nt[t+1]=void 0}Y=0}function p(){try{var t=n(87)
return J=t.runOnLoop||t.runOnContext,u()}catch(t){return f()}}function h(t,e){var n=arguments,r=this,i=new this.constructor(y)
void 0===i[it]&&R(i)
var o=r._state
return o?function(){var t=n[o-1]
G(function(){return T(o,i,t,r._result)})}():j(r,i,t,e),i}function v(t){var e=this
if(t&&"object"==typeof t&&t.constructor===e)return t
var n=new e(y)
return I(n,t),n}function y(){}function m(){return new TypeError("You cannot resolve a promise with itself")}function b(){return new TypeError("A promises callback cannot return that same promise.")}function g(t){try{return t.then}catch(t){return ut.error=t,ut}}function w(t,e,n,r){try{t.call(e,n,r)}catch(t){return t}}function _(t,e,n){G(function(t){var r=!1,i=w(n,e,function(n){r||(r=!0,e!==n?I(t,n):k(t,n))},function(e){r||(r=!0,E(t,e))},"Settle: "+(t._label||" unknown promise"))
!r&&i&&(r=!0,E(t,i))},t)}function x(t,e){e._state===at?k(t,e._result):e._state===st?E(t,e._result):j(e,void 0,function(e){return I(t,e)},function(e){return E(t,e)})}function S(t,e,n){e.constructor===t.constructor&&n===h&&e.constructor.resolve===v?x(t,e):n===ut?(E(t,ut.error),ut.error=null):void 0===n?k(t,e):i(n)?_(t,e,n):k(t,e)}function I(e,n){e===n?E(e,m()):t(n)?S(e,n,g(n)):k(e,n)}function O(t){t._onerror&&t._onerror(t._result),P(t)}function k(t,e){t._state===ot&&(t._result=e,t._state=at,0!==t._subscribers.length&&G(P,t))}function E(t,e){t._state===ot&&(t._state=st,t._result=e,G(O,t))}function j(t,e,n,r){var i=t._subscribers,o=i.length
t._onerror=null,i[o]=e,i[o+at]=n,i[o+st]=r,0===o&&t._state&&G(P,t)}function P(t){var e=t._subscribers,n=t._state
if(0!==e.length){for(var r=void 0,i=void 0,o=t._result,a=0;a<e.length;a+=3)r=e[a],i=e[a+n],r?T(n,r,i,o):i(o)
t._subscribers.length=0}}function D(){this.error=null}function A(t,e){try{return t(e)}catch(t){return ct.error=t,ct}}function T(t,e,n,r){var o=i(n),a=void 0,s=void 0,u=void 0,c=void 0
if(o){if(a=A(n,r),a===ct?(c=!0,s=a.error,a.error=null):u=!0,e===a)return void E(e,b())}else a=r,u=!0
e._state!==ot||(o&&u?I(e,a):c?E(e,s):t===at?k(e,a):t===st&&E(e,a))}function C(t,e){try{e(function(e){I(t,e)},function(e){E(t,e)})}catch(e){E(t,e)}}function N(){return lt++}function R(t){t[it]=lt++,t._state=void 0,t._result=void 0,t._subscribers=[]}function M(t,e){this._instanceConstructor=t,this.promise=new t(y),this.promise[it]||R(this.promise),H(e)?(this._input=e,this.length=e.length,this._remaining=e.length,this._result=new Array(this.length),0===this.length?k(this.promise,this._result):(this.length=this.length||0,this._enumerate(),0===this._remaining&&k(this.promise,this._result))):E(this.promise,L())}function L(){return new Error("Array Methods must be provided an Array")}function z(t){return new M(this,t).promise}function B(t){var e=this
return new e(H(t)?function(n,r){for(var i=t.length,o=0;o<i;o++)e.resolve(t[o]).then(n,r)}:function(t,e){return e(new TypeError("You must pass an array to race."))})}function q(t){var e=this,n=new e(y)
return E(n,t),n}function F(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function V(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function U(t){this[it]=N(),this._result=this._state=void 0,this._subscribers=[],y!==t&&("function"!=typeof t&&F(),this instanceof U?C(this,t):V())}function W(){var t=void 0
if(void 0!==r)t=r
else if("undefined"!=typeof self)t=self
else try{t=Function("return this")()}catch(t){throw new Error("polyfill failed because global object is unavailable in this environment")}var e=t.Promise
if(e){var n=null
try{n=Object.prototype.toString.call(e.resolve())}catch(t){}if("[object Promise]"===n&&!e.cast)return}t.Promise=U}var $=void 0
$=Array.isArray?Array.isArray:function(t){return"[object Array]"===Object.prototype.toString.call(t)}
var H=$,Y=0,J=void 0,K=void 0,G=function(t,e){nt[Y]=t,nt[Y+1]=e,2===(Y+=2)&&(K?K(d):rt())},X="undefined"!=typeof window?window:void 0,Z=X||{},Q=Z.MutationObserver||Z.WebKitMutationObserver,tt="undefined"==typeof self&&void 0!==e&&"[object process]"==={}.toString.call(e),et="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,nt=new Array(1e3),rt=void 0
rt=tt?s():Q?c():et?l():void 0===X?p():f()
var it=Math.random().toString(36).substring(16),ot=void 0,at=1,st=2,ut=new D,ct=new D,lt=0
return M.prototype._enumerate=function(){for(var t=this.length,e=this._input,n=0;this._state===ot&&n<t;n++)this._eachEntry(e[n],n)},M.prototype._eachEntry=function(t,e){var n=this._instanceConstructor,r=n.resolve
if(r===v){var i=g(t)
if(i===h&&t._state!==ot)this._settledAt(t._state,e,t._result)
else if("function"!=typeof i)this._remaining--,this._result[e]=t
else if(n===U){var o=new n(y)
S(o,t,i),this._willSettleAt(o,e)}else this._willSettleAt(new n(function(e){return e(t)}),e)}else this._willSettleAt(r(t),e)},M.prototype._settledAt=function(t,e,n){var r=this.promise
r._state===ot&&(this._remaining--,t===st?E(r,n):this._result[e]=n),0===this._remaining&&k(r,this._result)},M.prototype._willSettleAt=function(t,e){var n=this
j(t,void 0,function(t){return n._settledAt(at,e,t)},function(t){return n._settledAt(st,e,t)})},U.all=z,U.race=B,U.resolve=v,U.reject=q,U._setScheduler=o,U._setAsap=a,U._asap=G,U.prototype={constructor:U,then:h,catch:function(t){return this.then(null,t)}},U.polyfill=W,U.Promise=U,U})}).call(e,n(19),n(9))},function(t,e,n){"use strict"
var r=function(t,e,n,r,i,o,a,s){if(!t){var u
if(void 0===e)u=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.")
else{var c=[n,r,i,o,a,s],l=0
u=new Error(e.replace(/%s/g,function(){return c[l++]})),u.name="Invariant Violation"}throw u.framesToPop=1,u}}
t.exports=r},function(t,e,n){"use strict"
t.exports=function(t){if("string"!=typeof t)throw new TypeError("Expected a string")
return/^[a-z][a-z0-9+.-]*:/.test(t)}},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=function(t){function e(e,n){t.call(this),this.value=e,this.scheduler=n,this._isScalar=!0,n&&(this._isScalar=!1)}return r(e,t),e.create=function(t,n){return new e(t,n)},e.dispatch=function(t){var e=t.done,n=t.value,r=t.subscriber
if(e)return void r.complete()
r.next(n),r.closed||(t.done=!0,this.schedule(t))},e.prototype._subscribe=function(t){var n=this.value,r=this.scheduler
if(r)return r.schedule(e.dispatch,0,{done:!1,value:n,subscriber:t})
t.next(n),t.closed||t.complete()},e}(i.Observable)
e.ScalarObservable=o},function(t,e,n){"use strict"
var r=n(300)
e.from=r.FromObservable.create},function(t,e,n){"use strict"
function r(t,e){var n
if(n="function"==typeof t?t:function(){return t},"function"==typeof e)return this.lift(new o(n,e))
var r=Object.create(this,i.connectableObservableDescriptor)
return r.source=this,r.subjectFactory=n,r}var i=n(299)
e.multicast=r
var o=function(){function t(t,e){this.subjectFactory=t,this.selector=e}return t.prototype.call=function(t,e){var n=this.selector,r=this.subjectFactory(),i=n(r).subscribe(t)
return i.add(e.subscribe(r)),i},t}()
e.MulticastOperator=o},function(t,e,n){"use strict"
function r(t,e,n){return void 0===t&&(t=Number.POSITIVE_INFINITY),void 0===e&&(e=Number.POSITIVE_INFINITY),o.multicast.call(this,new i.ReplaySubject(t,e,n))}var i=n(24),o=n(80)
e.publishReplay=r},function(t,e,n){"use strict"
function r(t){var e=t.Symbol
if("function"==typeof e)return e.iterator||(e.iterator=e("iterator polyfill")),e.iterator
var n=t.Set
if(n&&"function"==typeof(new n)["@@iterator"])return"@@iterator"
var r=t.Map
if(r)for(var i=Object.getOwnPropertyNames(r.prototype),o=0;o<i.length;++o){var a=i[o]
if("entries"!==a&&"size"!==a&&r.prototype[a]===r.prototype.entries)return a}return"@@iterator"}var i=n(11)
e.symbolIteratorPonyfill=r,e.iterator=r(i.root),e.$$iterator=e.iterator},function(t,e,n){"use strict"
function r(t){var e,n=t.Symbol
return"function"==typeof n?n.observable?e=n.observable:(e=n("observable"),n.observable=e):e="@@observable",e}var i=n(11)
e.getSymbolObservable=r,e.observable=r(i.root),e.$$observable=e.observable},function(t,e,n){"use strict"
var r=n(11),i=r.root.Symbol
e.rxSubscriber="function"==typeof i&&"function"==typeof i.for?i.for("rxSubscriber"):"@@rxSubscriber",e.$$rxSubscriber=e.rxSubscriber},function(t,e,n){"use strict"
e.errorObject={e:{}}},function(t,e,n){!function(e,n){t.exports=n()}(0,function(){"use strict"
function t(t,e){e&&(t.prototype=Object.create(e.prototype)),t.prototype.constructor=t}function e(t){return o(t)?t:P(t)}function n(t){return a(t)?t:D(t)}function r(t){return s(t)?t:A(t)}function i(t){return o(t)&&!u(t)?t:T(t)}function o(t){return!(!t||!t[cn])}function a(t){return!(!t||!t[ln])}function s(t){return!(!t||!t[fn])}function u(t){return a(t)||s(t)}function c(t){return!(!t||!t[dn])}function l(t){return t.value=!1,t}function f(t){t&&(t.value=!0)}function d(){}function p(t,e){e=e||0
for(var n=Math.max(0,t.length-e),r=Array(n),i=0;n>i;i++)r[i]=t[i+e]
return r}function h(t){return void 0===t.size&&(t.size=t.__iterate(y)),t.size}function v(t,e){if("number"!=typeof e){var n=e>>>0
if(""+n!==e||4294967295===n)return NaN
e=n}return 0>e?h(t)+e:e}function y(){return!0}function m(t,e,n){return(0===t||void 0!==n&&-n>=t)&&(void 0===e||void 0!==n&&e>=n)}function b(t,e){return w(t,e,0)}function g(t,e){return w(t,e,e)}function w(t,e,n){return void 0===t?n:0>t?Math.max(0,e+t):void 0===e?t:Math.min(e,t)}function _(t){this.next=t}function x(t,e,n,r){var i=0===t?e:1===t?n:[e,n]
return r?r.value=i:r={value:i,done:!1},r}function S(){return{value:void 0,done:!0}}function I(t){return!!E(t)}function O(t){return t&&"function"==typeof t.next}function k(t){var e=E(t)
return e&&e.call(t)}function E(t){var e=t&&(Sn&&t[Sn]||t[In])
return"function"==typeof e?e:void 0}function j(t){return t&&"number"==typeof t.length}function P(t){return null===t||void 0===t?z():o(t)?t.toSeq():F(t)}function D(t){return null===t||void 0===t?z().toKeyedSeq():o(t)?a(t)?t.toSeq():t.fromEntrySeq():B(t)}function A(t){return null===t||void 0===t?z():o(t)?a(t)?t.entrySeq():t.toIndexedSeq():q(t)}function T(t){return(null===t||void 0===t?z():o(t)?a(t)?t.entrySeq():t:q(t)).toSetSeq()}function C(t){this._array=t,this.size=t.length}function N(t){var e=Object.keys(t)
this._object=t,this._keys=e,this.size=e.length}function R(t){this._iterable=t,this.size=t.length||t.size}function M(t){this._iterator=t,this._iteratorCache=[]}function L(t){return!(!t||!t[kn])}function z(){return En||(En=new C([]))}function B(t){var e=Array.isArray(t)?new C(t).fromEntrySeq():O(t)?new M(t).fromEntrySeq():I(t)?new R(t).fromEntrySeq():"object"==typeof t?new N(t):void 0
if(!e)throw new TypeError("Expected Array or iterable object of [k, v] entries, or keyed object: "+t)
return e}function q(t){var e=V(t)
if(!e)throw new TypeError("Expected Array or iterable object of values: "+t)
return e}function F(t){var e=V(t)||"object"==typeof t&&new N(t)
if(!e)throw new TypeError("Expected Array or iterable object of values, or keyed object: "+t)
return e}function V(t){return j(t)?new C(t):O(t)?new M(t):I(t)?new R(t):void 0}function U(t,e,n,r){var i=t._cache
if(i){for(var o=i.length-1,a=0;o>=a;a++){var s=i[n?o-a:a]
if(!1===e(s[1],r?s[0]:a,t))return a+1}return a}return t.__iterateUncached(e,n)}function W(t,e,n,r){var i=t._cache
if(i){var o=i.length-1,a=0
return new _(function(){var t=i[n?o-a:a]
return a++>o?S():x(e,r?t[0]:a-1,t[1])})}return t.__iteratorUncached(e,n)}function $(t,e){return e?H(e,t,"",{"":t}):Y(t)}function H(t,e,n,r){return Array.isArray(e)?t.call(r,n,A(e).map(function(n,r){return H(t,n,r,e)})):J(e)?t.call(r,n,D(e).map(function(n,r){return H(t,n,r,e)})):e}function Y(t){return Array.isArray(t)?A(t).map(Y).toList():J(t)?D(t).map(Y).toMap():t}function J(t){return t&&(t.constructor===Object||void 0===t.constructor)}function K(t,e){if(t===e||t!==t&&e!==e)return!0
if(!t||!e)return!1
if("function"==typeof t.valueOf&&"function"==typeof e.valueOf){if(t=t.valueOf(),e=e.valueOf(),t===e||t!==t&&e!==e)return!0
if(!t||!e)return!1}return!("function"!=typeof t.equals||"function"!=typeof e.equals||!t.equals(e))}function G(t,e){if(t===e)return!0
if(!o(e)||void 0!==t.size&&void 0!==e.size&&t.size!==e.size||void 0!==t.__hash&&void 0!==e.__hash&&t.__hash!==e.__hash||a(t)!==a(e)||s(t)!==s(e)||c(t)!==c(e))return!1
if(0===t.size&&0===e.size)return!0
var n=!u(t)
if(c(t)){var r=t.entries()
return e.every(function(t,e){var i=r.next().value
return i&&K(i[1],t)&&(n||K(i[0],e))})&&r.next().done}var i=!1
if(void 0===t.size)if(void 0===e.size)"function"==typeof t.cacheResult&&t.cacheResult()
else{i=!0
var l=t
t=e,e=l}var f=!0,d=e.__iterate(function(e,r){return(n?t.has(e):i?K(e,t.get(r,mn)):K(t.get(r,mn),e))?void 0:(f=!1,!1)})
return f&&t.size===d}function X(t,e){if(!(this instanceof X))return new X(t,e)
if(this._value=t,this.size=void 0===e?1/0:Math.max(0,e),0===this.size){if(jn)return jn
jn=this}}function Z(t,e){if(!t)throw Error(e)}function Q(t,e,n){if(!(this instanceof Q))return new Q(t,e,n)
if(Z(0!==n,"Cannot step a Range by 0"),t=t||0,void 0===e&&(e=1/0),n=void 0===n?1:Math.abs(n),t>e&&(n=-n),this._start=t,this._end=e,this._step=n,this.size=Math.max(0,Math.ceil((e-t)/n-1)+1),0===this.size){if(Pn)return Pn
Pn=this}}function tt(){throw TypeError("Abstract")}function et(){}function nt(){}function rt(){}function it(t){return t>>>1&1073741824|3221225471&t}function ot(t){if(!1===t||null===t||void 0===t)return 0
if("function"==typeof t.valueOf&&(!1===(t=t.valueOf())||null===t||void 0===t))return 0
if(!0===t)return 1
var e=typeof t
if("number"===e){if(t!==t||t===1/0)return 0
var n=0|t
for(n!==t&&(n^=4294967295*t);t>4294967295;)t/=4294967295,n^=t
return it(n)}if("string"===e)return t.length>Ln?at(t):st(t)
if("function"==typeof t.hashCode)return t.hashCode()
if("object"===e)return ut(t)
if("function"==typeof t.toString)return st(""+t)
throw Error("Value type "+e+" cannot be hashed.")}function at(t){var e=qn[t]
return void 0===e&&(e=st(t),Bn===zn&&(Bn=0,qn={}),Bn++,qn[t]=e),e}function st(t){for(var e=0,n=0;t.length>n;n++)e=31*e+t.charCodeAt(n)|0
return it(e)}function ut(t){var e
if(Nn&&void 0!==(e=Dn.get(t)))return e
if(void 0!==(e=t[Mn]))return e
if(!Cn){if(void 0!==(e=t.propertyIsEnumerable&&t.propertyIsEnumerable[Mn]))return e
if(void 0!==(e=ct(t)))return e}if(e=++Rn,1073741824&Rn&&(Rn=0),Nn)Dn.set(t,e)
else{if(void 0!==Tn&&!1===Tn(t))throw Error("Non-extensible objects are not allowed as keys.")
if(Cn)Object.defineProperty(t,Mn,{enumerable:!1,configurable:!1,writable:!1,value:e})
else if(void 0!==t.propertyIsEnumerable&&t.propertyIsEnumerable===t.constructor.prototype.propertyIsEnumerable)t.propertyIsEnumerable=function(){return this.constructor.prototype.propertyIsEnumerable.apply(this,arguments)},t.propertyIsEnumerable[Mn]=e
else{if(void 0===t.nodeType)throw Error("Unable to set a non-enumerable property on object.")
t[Mn]=e}}return e}function ct(t){if(t&&t.nodeType>0)switch(t.nodeType){case 1:return t.uniqueID
case 9:return t.documentElement&&t.documentElement.uniqueID}}function lt(t){Z(t!==1/0,"Cannot perform this action with an infinite size.")}function ft(t){return null===t||void 0===t?xt():dt(t)&&!c(t)?t:xt().withMutations(function(e){var r=n(t)
lt(r.size),r.forEach(function(t,n){return e.set(n,t)})})}function dt(t){return!(!t||!t[Fn])}function pt(t,e){this.ownerID=t,this.entries=e}function ht(t,e,n){this.ownerID=t,this.bitmap=e,this.nodes=n}function vt(t,e,n){this.ownerID=t,this.count=e,this.nodes=n}function yt(t,e,n){this.ownerID=t,this.keyHash=e,this.entries=n}function mt(t,e,n){this.ownerID=t,this.keyHash=e,this.entry=n}function bt(t,e,n){this._type=e,this._reverse=n,this._stack=t._root&&wt(t._root)}function gt(t,e){return x(t,e[0],e[1])}function wt(t,e){return{node:t,index:0,__prev:e}}function _t(t,e,n,r){var i=Object.create(Vn)
return i.size=t,i._root=e,i.__ownerID=n,i.__hash=r,i.__altered=!1,i}function xt(){return Un||(Un=_t(0))}function St(t,e,n){var r,i
if(t._root){var o=l(bn),a=l(gn)
if(r=It(t._root,t.__ownerID,0,void 0,e,n,o,a),!a.value)return t
i=t.size+(o.value?n===mn?-1:1:0)}else{if(n===mn)return t
i=1,r=new pt(t.__ownerID,[[e,n]])}return t.__ownerID?(t.size=i,t._root=r,t.__hash=void 0,t.__altered=!0,t):r?_t(i,r):xt()}function It(t,e,n,r,i,o,a,s){return t?t.update(e,n,r,i,o,a,s):o===mn?t:(f(s),f(a),new mt(e,r,[i,o]))}function Ot(t){return t.constructor===mt||t.constructor===yt}function kt(t,e,n,r,i){if(t.keyHash===r)return new yt(e,r,[t.entry,i])
var o,a=(0===n?t.keyHash:t.keyHash>>>n)&yn,s=(0===n?r:r>>>n)&yn
return new ht(e,1<<a|1<<s,a===s?[kt(t,e,n+hn,r,i)]:(o=new mt(e,r,i),s>a?[t,o]:[o,t]))}function Et(t,e,n,r){t||(t=new d)
for(var i=new mt(t,ot(n),[n,r]),o=0;e.length>o;o++){var a=e[o]
i=i.update(t,0,void 0,a[0],a[1])}return i}function jt(t,e,n,r){for(var i=0,o=0,a=Array(n),s=0,u=1,c=e.length;c>s;s++,u<<=1){var l=e[s]
void 0!==l&&s!==r&&(i|=u,a[o++]=l)}return new ht(t,i,a)}function Pt(t,e,n,r,i){for(var o=0,a=Array(vn),s=0;0!==n;s++,n>>>=1)a[s]=1&n?e[o++]:void 0
return a[r]=i,new vt(t,o+1,a)}function Dt(t,e,r){for(var i=[],a=0;r.length>a;a++){var s=r[a],u=n(s)
o(s)||(u=u.map(function(t){return $(t)})),i.push(u)}return Ct(t,e,i)}function At(t,e,n){return t&&t.mergeDeep&&o(e)?t.mergeDeep(e):K(t,e)?t:e}function Tt(t){return function(e,n,r){if(e&&e.mergeDeepWith&&o(n))return e.mergeDeepWith(t,n)
var i=t(e,n,r)
return K(e,i)?e:i}}function Ct(t,e,n){return n=n.filter(function(t){return 0!==t.size}),0===n.length?t:0!==t.size||t.__ownerID||1!==n.length?t.withMutations(function(t){for(var r=e?function(n,r){t.update(r,mn,function(t){return t===mn?n:e(t,n,r)})}:function(e,n){t.set(n,e)},i=0;n.length>i;i++)n[i].forEach(r)}):t.constructor(n[0])}function Nt(t,e,n,r){var i=t===mn,o=e.next()
if(o.done){var a=i?n:t,s=r(a)
return s===a?t:s}Z(i||t&&t.set,"invalid keyPath")
var u=o.value,c=i?mn:t.get(u,mn),l=Nt(c,e,n,r)
return l===c?t:l===mn?t.remove(u):(i?xt():t).set(u,l)}function Rt(t){return t-=t>>1&1431655765,t=(858993459&t)+(t>>2&858993459),t=t+(t>>4)&252645135,t+=t>>8,127&(t+=t>>16)}function Mt(t,e,n,r){var i=r?t:p(t)
return i[e]=n,i}function Lt(t,e,n,r){var i=t.length+1
if(r&&e+1===i)return t[e]=n,t
for(var o=Array(i),a=0,s=0;i>s;s++)s===e?(o[s]=n,a=-1):o[s]=t[s+a]
return o}function zt(t,e,n){var r=t.length-1
if(n&&e===r)return t.pop(),t
for(var i=Array(r),o=0,a=0;r>a;a++)a===e&&(o=1),i[a]=t[a+o]
return i}function Bt(t){var e=Wt()
if(null===t||void 0===t)return e
if(qt(t))return t
var n=r(t),i=n.size
return 0===i?e:(lt(i),i>0&&vn>i?Ut(0,i,hn,null,new Ft(n.toArray())):e.withMutations(function(t){t.setSize(i),n.forEach(function(e,n){return t.set(n,e)})}))}function qt(t){return!(!t||!t[Yn])}function Ft(t,e){this.array=t,this.ownerID=e}function Vt(t,e){function n(t,e,n){return 0===e?r(t,n):i(t,e,n)}function r(t,n){var r=n===s?u&&u.array:t&&t.array,i=n>o?0:o-n,c=a-n
return c>vn&&(c=vn),function(){if(i===c)return Gn
var t=e?--c:i++
return r&&r[t]}}function i(t,r,i){var s,u=t&&t.array,c=i>o?0:o-i>>r,l=1+(a-i>>r)
return l>vn&&(l=vn),function(){for(;;){if(s){var t=s()
if(t!==Gn)return t
s=null}if(c===l)return Gn
var o=e?--l:c++
s=n(u&&u[o],r-hn,i+(o<<r))}}}var o=t._origin,a=t._capacity,s=Xt(a),u=t._tail
return n(t._root,t._level,0)}function Ut(t,e,n,r,i,o,a){var s=Object.create(Jn)
return s.size=e-t,s._origin=t,s._capacity=e,s._level=n,s._root=r,s._tail=i,s.__ownerID=o,s.__hash=a,s.__altered=!1,s}function Wt(){return Kn||(Kn=Ut(0,0,hn))}function $t(t,e,n){if((e=v(t,e))!==e)return t
if(e>=t.size||0>e)return t.withMutations(function(t){0>e?Kt(t,e).set(0,n):Kt(t,0,e+1).set(e,n)})
e+=t._origin
var r=t._tail,i=t._root,o=l(gn)
return e>=Xt(t._capacity)?r=Ht(r,t.__ownerID,0,e,n,o):i=Ht(i,t.__ownerID,t._level,e,n,o),o.value?t.__ownerID?(t._root=i,t._tail=r,t.__hash=void 0,t.__altered=!0,t):Ut(t._origin,t._capacity,t._level,i,r):t}function Ht(t,e,n,r,i,o){var a=r>>>n&yn,s=t&&t.array.length>a
if(!s&&void 0===i)return t
var u
if(n>0){var c=t&&t.array[a],l=Ht(c,e,n-hn,r,i,o)
return l===c?t:(u=Yt(t,e),u.array[a]=l,u)}return s&&t.array[a]===i?t:(f(o),u=Yt(t,e),void 0===i&&a===u.array.length-1?u.array.pop():u.array[a]=i,u)}function Yt(t,e){return e&&t&&e===t.ownerID?t:new Ft(t?t.array.slice():[],e)}function Jt(t,e){if(e>=Xt(t._capacity))return t._tail
if(1<<t._level+hn>e){for(var n=t._root,r=t._level;n&&r>0;)n=n.array[e>>>r&yn],r-=hn
return n}}function Kt(t,e,n){void 0!==e&&(e|=0),void 0!==n&&(n|=0)
var r=t.__ownerID||new d,i=t._origin,o=t._capacity,a=i+e,s=void 0===n?o:0>n?o+n:i+n
if(a===i&&s===o)return t
if(a>=s)return t.clear()
for(var u=t._level,c=t._root,l=0;0>a+l;)c=new Ft(c&&c.array.length?[void 0,c]:[],r),u+=hn,l+=1<<u
l&&(a+=l,i+=l,s+=l,o+=l)
for(var f=Xt(o),p=Xt(s);p>=1<<u+hn;)c=new Ft(c&&c.array.length?[c]:[],r),u+=hn
var h=t._tail,v=f>p?Jt(t,s-1):p>f?new Ft([],r):h
if(h&&p>f&&o>a&&h.array.length){c=Yt(c,r)
for(var y=c,m=u;m>hn;m-=hn){var b=f>>>m&yn
y=y.array[b]=Yt(y.array[b],r)}y.array[f>>>hn&yn]=h}if(o>s&&(v=v&&v.removeAfter(r,0,s)),a>=p)a-=p,s-=p,u=hn,c=null,v=v&&v.removeBefore(r,0,a)
else if(a>i||f>p){for(l=0;c;){var g=a>>>u&yn
if(g!==p>>>u&yn)break
g&&(l+=(1<<u)*g),u-=hn,c=c.array[g]}c&&a>i&&(c=c.removeBefore(r,u,a-l)),c&&f>p&&(c=c.removeAfter(r,u,p-l)),l&&(a-=l,s-=l)}return t.__ownerID?(t.size=s-a,t._origin=a,t._capacity=s,t._level=u,t._root=c,t._tail=v,t.__hash=void 0,t.__altered=!0,t):Ut(a,s,u,c,v)}function Gt(t,e,n){for(var i=[],a=0,s=0;n.length>s;s++){var u=n[s],c=r(u)
c.size>a&&(a=c.size),o(u)||(c=c.map(function(t){return $(t)})),i.push(c)}return a>t.size&&(t=t.setSize(a)),Ct(t,e,i)}function Xt(t){return vn>t?0:t-1>>>hn<<hn}function Zt(t){return null===t||void 0===t?ee():Qt(t)?t:ee().withMutations(function(e){var r=n(t)
lt(r.size),r.forEach(function(t,n){return e.set(n,t)})})}function Qt(t){return dt(t)&&c(t)}function te(t,e,n,r){var i=Object.create(Zt.prototype)
return i.size=t?t.size:0,i._map=t,i._list=e,i.__ownerID=n,i.__hash=r,i}function ee(){return Xn||(Xn=te(xt(),Wt()))}function ne(t,e,n){var r,i,o=t._map,a=t._list,s=o.get(e),u=void 0!==s
if(n===mn){if(!u)return t
a.size>=vn&&a.size>=2*o.size?(i=a.filter(function(t,e){return void 0!==t&&s!==e}),r=i.toKeyedSeq().map(function(t){return t[0]}).flip().toMap(),t.__ownerID&&(r.__ownerID=i.__ownerID=t.__ownerID)):(r=o.remove(e),i=s===a.size-1?a.pop():a.set(s,void 0))}else if(u){if(n===a.get(s)[1])return t
r=o,i=a.set(s,[e,n])}else r=o.set(e,a.size),i=a.set(a.size,[e,n])
return t.__ownerID?(t.size=r.size,t._map=r,t._list=i,t.__hash=void 0,t):te(r,i)}function re(t,e){this._iter=t,this._useKeys=e,this.size=t.size}function ie(t){this._iter=t,this.size=t.size}function oe(t){this._iter=t,this.size=t.size}function ae(t){this._iter=t,this.size=t.size}function se(t){var e=je(t)
return e._iter=t,e.size=t.size,e.flip=function(){return t},e.reverse=function(){var e=t.reverse.apply(this)
return e.flip=function(){return t.reverse()},e},e.has=function(e){return t.includes(e)},e.includes=function(e){return t.has(e)},e.cacheResult=Pe,e.__iterateUncached=function(e,n){var r=this
return t.__iterate(function(t,n){return!1!==e(n,t,r)},n)},e.__iteratorUncached=function(e,n){if(e===xn){var r=t.__iterator(e,n)
return new _(function(){var t=r.next()
if(!t.done){var e=t.value[0]
t.value[0]=t.value[1],t.value[1]=e}return t})}return t.__iterator(e===_n?wn:_n,n)},e}function ue(t,e,n){var r=je(t)
return r.size=t.size,r.has=function(e){return t.has(e)},r.get=function(r,i){var o=t.get(r,mn)
return o===mn?i:e.call(n,o,r,t)},r.__iterateUncached=function(r,i){var o=this
return t.__iterate(function(t,i,a){return!1!==r(e.call(n,t,i,a),i,o)},i)},r.__iteratorUncached=function(r,i){var o=t.__iterator(xn,i)
return new _(function(){var i=o.next()
if(i.done)return i
var a=i.value,s=a[0]
return x(r,s,e.call(n,a[1],s,t),i)})},r}function ce(t,e){var n=je(t)
return n._iter=t,n.size=t.size,n.reverse=function(){return t},t.flip&&(n.flip=function(){var e=se(t)
return e.reverse=function(){return t.flip()},e}),n.get=function(n,r){return t.get(e?n:-1-n,r)},n.has=function(n){return t.has(e?n:-1-n)},n.includes=function(e){return t.includes(e)},n.cacheResult=Pe,n.__iterate=function(e,n){var r=this
return t.__iterate(function(t,n){return e(t,n,r)},!n)},n.__iterator=function(e,n){return t.__iterator(e,!n)},n}function le(t,e,n,r){var i=je(t)
return r&&(i.has=function(r){var i=t.get(r,mn)
return i!==mn&&!!e.call(n,i,r,t)},i.get=function(r,i){var o=t.get(r,mn)
return o!==mn&&e.call(n,o,r,t)?o:i}),i.__iterateUncached=function(i,o){var a=this,s=0
return t.__iterate(function(t,o,u){return e.call(n,t,o,u)?(s++,i(t,r?o:s-1,a)):void 0},o),s},i.__iteratorUncached=function(i,o){var a=t.__iterator(xn,o),s=0
return new _(function(){for(;;){var o=a.next()
if(o.done)return o
var u=o.value,c=u[0],l=u[1]
if(e.call(n,l,c,t))return x(i,r?c:s++,l,o)}})},i}function fe(t,e,n){var r=ft().asMutable()
return t.__iterate(function(i,o){r.update(e.call(n,i,o,t),0,function(t){return t+1})}),r.asImmutable()}function de(t,e,n){var r=a(t),i=(c(t)?Zt():ft()).asMutable()
t.__iterate(function(o,a){i.update(e.call(n,o,a,t),function(t){return t=t||[],t.push(r?[a,o]:o),t})})
var o=Ee(t)
return i.map(function(e){return Ie(t,o(e))})}function pe(t,e,n,r){var i=t.size
if(void 0!==e&&(e|=0),void 0!==n&&(n=n===1/0?i:0|n),m(e,n,i))return t
var o=b(e,i),a=g(n,i)
if(o!==o||a!==a)return pe(t.toSeq().cacheResult(),e,n,r)
var s,u=a-o
u===u&&(s=0>u?0:u)
var c=je(t)
return c.size=0===s?s:t.size&&s||void 0,!r&&L(t)&&s>=0&&(c.get=function(e,n){return e=v(this,e),e>=0&&s>e?t.get(e+o,n):n}),c.__iterateUncached=function(e,n){var i=this
if(0===s)return 0
if(n)return this.cacheResult().__iterate(e,n)
var a=0,u=!0,c=0
return t.__iterate(function(t,n){return u&&(u=a++<o)?void 0:(c++,!1!==e(t,r?n:c-1,i)&&c!==s)}),c},c.__iteratorUncached=function(e,n){if(0!==s&&n)return this.cacheResult().__iterator(e,n)
var i=0!==s&&t.__iterator(e,n),a=0,u=0
return new _(function(){for(;a++<o;)i.next()
if(++u>s)return S()
var t=i.next()
return r||e===_n?t:e===wn?x(e,u-1,void 0,t):x(e,u-1,t.value[1],t)})},c}function he(t,e,n){var r=je(t)
return r.__iterateUncached=function(r,i){var o=this
if(i)return this.cacheResult().__iterate(r,i)
var a=0
return t.__iterate(function(t,i,s){return e.call(n,t,i,s)&&++a&&r(t,i,o)}),a},r.__iteratorUncached=function(r,i){var o=this
if(i)return this.cacheResult().__iterator(r,i)
var a=t.__iterator(xn,i),s=!0
return new _(function(){if(!s)return S()
var t=a.next()
if(t.done)return t
var i=t.value,u=i[0],c=i[1]
return e.call(n,c,u,o)?r===xn?t:x(r,u,c,t):(s=!1,S())})},r}function ve(t,e,n,r){var i=je(t)
return i.__iterateUncached=function(i,o){var a=this
if(o)return this.cacheResult().__iterate(i,o)
var s=!0,u=0
return t.__iterate(function(t,o,c){return s&&(s=e.call(n,t,o,c))?void 0:(u++,i(t,r?o:u-1,a))}),u},i.__iteratorUncached=function(i,o){var a=this
if(o)return this.cacheResult().__iterator(i,o)
var s=t.__iterator(xn,o),u=!0,c=0
return new _(function(){var t,o,l
do{if(t=s.next(),t.done)return r||i===_n?t:i===wn?x(i,c++,void 0,t):x(i,c++,t.value[1],t)
var f=t.value
o=f[0],l=f[1],u&&(u=e.call(n,l,o,a))}while(u)
return i===xn?t:x(i,o,l,t)})},i}function ye(t,e){var r=a(t),i=[t].concat(e).map(function(t){return o(t)?r&&(t=n(t)):t=r?B(t):q(Array.isArray(t)?t:[t]),t}).filter(function(t){return 0!==t.size})
if(0===i.length)return t
if(1===i.length){var u=i[0]
if(u===t||r&&a(u)||s(t)&&s(u))return u}var c=new C(i)
return r?c=c.toKeyedSeq():s(t)||(c=c.toSetSeq()),c=c.flatten(!0),c.size=i.reduce(function(t,e){if(void 0!==t){var n=e.size
if(void 0!==n)return t+n}},0),c}function me(t,e,n){var r=je(t)
return r.__iterateUncached=function(r,i){function a(t,c){var l=this
t.__iterate(function(t,i){return(!e||e>c)&&o(t)?a(t,c+1):!1===r(t,n?i:s++,l)&&(u=!0),!u},i)}var s=0,u=!1
return a(t,0),s},r.__iteratorUncached=function(r,i){var a=t.__iterator(r,i),s=[],u=0
return new _(function(){for(;a;){var t=a.next()
if(!1===t.done){var c=t.value
if(r===xn&&(c=c[1]),e&&!(e>s.length)||!o(c))return n?t:x(r,u++,c,t)
s.push(a),a=c.__iterator(r,i)}else a=s.pop()}return S()})},r}function be(t,e,n){var r=Ee(t)
return t.toSeq().map(function(i,o){return r(e.call(n,i,o,t))}).flatten(!0)}function ge(t,e){var n=je(t)
return n.size=t.size&&2*t.size-1,n.__iterateUncached=function(n,r){var i=this,o=0
return t.__iterate(function(t,r){return(!o||!1!==n(e,o++,i))&&!1!==n(t,o++,i)},r),o},n.__iteratorUncached=function(n,r){var i,o=t.__iterator(_n,r),a=0
return new _(function(){return(!i||a%2)&&(i=o.next(),i.done)?i:a%2?x(n,a++,e):x(n,a++,i.value,i)})},n}function we(t,e,n){e||(e=De)
var r=a(t),i=0,o=t.toSeq().map(function(e,r){return[r,e,i++,n?n(e,r,t):e]}).toArray()
return o.sort(function(t,n){return e(t[3],n[3])||t[2]-n[2]}).forEach(r?function(t,e){o[e].length=2}:function(t,e){o[e]=t[1]}),r?D(o):s(t)?A(o):T(o)}function _e(t,e,n){if(e||(e=De),n){var r=t.toSeq().map(function(e,r){return[e,n(e,r,t)]}).reduce(function(t,n){return xe(e,t[1],n[1])?n:t})
return r&&r[0]}return t.reduce(function(t,n){return xe(e,t,n)?n:t})}function xe(t,e,n){var r=t(n,e)
return 0===r&&n!==e&&(void 0===n||null===n||n!==n)||r>0}function Se(t,n,r){var i=je(t)
return i.size=new C(r).map(function(t){return t.size}).min(),i.__iterate=function(t,e){for(var n,r=this.__iterator(_n,e),i=0;!(n=r.next()).done&&!1!==t(n.value,i++,this););return i},i.__iteratorUncached=function(t,i){var o=r.map(function(t){return t=e(t),k(i?t.reverse():t)}),a=0,s=!1
return new _(function(){var e
return s||(e=o.map(function(t){return t.next()}),s=e.some(function(t){return t.done})),s?S():x(t,a++,n.apply(null,e.map(function(t){return t.value})))})},i}function Ie(t,e){return L(t)?e:t.constructor(e)}function Oe(t){if(t!==Object(t))throw new TypeError("Expected [K, V] tuple: "+t)}function ke(t){return lt(t.size),h(t)}function Ee(t){return a(t)?n:s(t)?r:i}function je(t){return Object.create((a(t)?D:s(t)?A:T).prototype)}function Pe(){return this._iter.cacheResult?(this._iter.cacheResult(),this.size=this._iter.size,this):P.prototype.cacheResult.call(this)}function De(t,e){return t>e?1:e>t?-1:0}function Ae(t){var n=k(t)
if(!n){if(!j(t))throw new TypeError("Expected iterable or array-like: "+t)
n=k(e(t))}return n}function Te(t,e){var n,r=function(o){if(o instanceof r)return o
if(!(this instanceof r))return new r(o)
if(!n){n=!0
var a=Object.keys(t)
Re(i,a),i.size=a.length,i._name=e,i._keys=a,i._defaultValues=t}this._map=ft(o)},i=r.prototype=Object.create(Zn)
return i.constructor=r,r}function Ce(t,e,n){var r=Object.create(Object.getPrototypeOf(t))
return r._map=e,r.__ownerID=n,r}function Ne(t){return t._name||t.constructor.name||"Record"}function Re(t,e){try{e.forEach(Me.bind(void 0,t))}catch(t){}}function Me(t,e){Object.defineProperty(t,e,{get:function(){return this.get(e)},set:function(t){Z(this.__ownerID,"Cannot set on an immutable record."),this.set(e,t)}})}function Le(t){return null===t||void 0===t?Fe():ze(t)&&!c(t)?t:Fe().withMutations(function(e){var n=i(t)
lt(n.size),n.forEach(function(t){return e.add(t)})})}function ze(t){return!(!t||!t[Qn])}function Be(t,e){return t.__ownerID?(t.size=e.size,t._map=e,t):e===t._map?t:0===e.size?t.__empty():t.__make(e)}function qe(t,e){var n=Object.create(tr)
return n.size=t?t.size:0,n._map=t,n.__ownerID=e,n}function Fe(){return er||(er=qe(xt()))}function Ve(t){return null===t||void 0===t?$e():Ue(t)?t:$e().withMutations(function(e){var n=i(t)
lt(n.size),n.forEach(function(t){return e.add(t)})})}function Ue(t){return ze(t)&&c(t)}function We(t,e){var n=Object.create(nr)
return n.size=t?t.size:0,n._map=t,n.__ownerID=e,n}function $e(){return rr||(rr=We(ee()))}function He(t){return null===t||void 0===t?Ke():Ye(t)?t:Ke().unshiftAll(t)}function Ye(t){return!(!t||!t[ir])}function Je(t,e,n,r){var i=Object.create(or)
return i.size=t,i._head=e,i.__ownerID=n,i.__hash=r,i.__altered=!1,i}function Ke(){return ar||(ar=Je(0))}function Ge(t,e){var n=function(n){t.prototype[n]=e[n]}
return Object.keys(e).forEach(n),Object.getOwnPropertySymbols&&Object.getOwnPropertySymbols(e).forEach(n),t}function Xe(t,e){return e}function Ze(t,e){return[e,t]}function Qe(t){return function(){return!t.apply(this,arguments)}}function tn(t){return function(){return-t.apply(this,arguments)}}function en(t){return"string"==typeof t?JSON.stringify(t):t+""}function nn(){return p(arguments)}function rn(t,e){return e>t?1:t>e?-1:0}function on(t){if(t.size===1/0)return 0
var e=c(t),n=a(t),r=e?1:0
return an(t.__iterate(n?e?function(t,e){r=31*r+sn(ot(t),ot(e))|0}:function(t,e){r=r+sn(ot(t),ot(e))|0}:e?function(t){r=31*r+ot(t)|0}:function(t){r=r+ot(t)|0}),r)}function an(t,e){return e=An(e,3432918353),e=An(e<<15|e>>>-15,461845907),e=An(e<<13|e>>>-13,5),e=(e+3864292196|0)^t,e=An(e^e>>>16,2246822507),e=An(e^e>>>13,3266489909),e=it(e^e>>>16)}function sn(t,e){return t^e+2654435769+(t<<6)+(t>>2)|0}var un=Array.prototype.slice
t(n,e),t(r,e),t(i,e),e.isIterable=o,e.isKeyed=a,e.isIndexed=s,e.isAssociative=u,e.isOrdered=c,e.Keyed=n,e.Indexed=r,e.Set=i
var cn="@@__IMMUTABLE_ITERABLE__@@",ln="@@__IMMUTABLE_KEYED__@@",fn="@@__IMMUTABLE_INDEXED__@@",dn="@@__IMMUTABLE_ORDERED__@@",pn="delete",hn=5,vn=1<<hn,yn=vn-1,mn={},bn={value:!1},gn={value:!1},wn=0,_n=1,xn=2,Sn="function"==typeof Symbol&&Symbol.iterator,In="@@iterator",On=Sn||In
_.prototype.toString=function(){return"[Iterator]"},_.KEYS=wn,_.VALUES=_n,_.ENTRIES=xn,_.prototype.inspect=_.prototype.toSource=function(){return""+this},_.prototype[On]=function(){return this},t(P,e),P.of=function(){return P(arguments)},P.prototype.toSeq=function(){return this},P.prototype.toString=function(){return this.__toString("Seq {","}")},P.prototype.cacheResult=function(){return!this._cache&&this.__iterateUncached&&(this._cache=this.entrySeq().toArray(),this.size=this._cache.length),this},P.prototype.__iterate=function(t,e){return U(this,t,e,!0)},P.prototype.__iterator=function(t,e){return W(this,t,e,!0)},t(D,P),D.prototype.toKeyedSeq=function(){return this},t(A,P),A.of=function(){return A(arguments)},A.prototype.toIndexedSeq=function(){return this},A.prototype.toString=function(){return this.__toString("Seq [","]")},A.prototype.__iterate=function(t,e){return U(this,t,e,!1)},A.prototype.__iterator=function(t,e){return W(this,t,e,!1)},t(T,P),T.of=function(){return T(arguments)},T.prototype.toSetSeq=function(){return this},P.isSeq=L,P.Keyed=D,P.Set=T,P.Indexed=A
var kn="@@__IMMUTABLE_SEQ__@@"
P.prototype[kn]=!0,t(C,A),C.prototype.get=function(t,e){return this.has(t)?this._array[v(this,t)]:e},C.prototype.__iterate=function(t,e){for(var n=this._array,r=n.length-1,i=0;r>=i;i++)if(!1===t(n[e?r-i:i],i,this))return i+1
return i},C.prototype.__iterator=function(t,e){var n=this._array,r=n.length-1,i=0
return new _(function(){return i>r?S():x(t,i,n[e?r-i++:i++])})},t(N,D),N.prototype.get=function(t,e){return void 0===e||this.has(t)?this._object[t]:e},N.prototype.has=function(t){return this._object.hasOwnProperty(t)},N.prototype.__iterate=function(t,e){for(var n=this._object,r=this._keys,i=r.length-1,o=0;i>=o;o++){var a=r[e?i-o:o]
if(!1===t(n[a],a,this))return o+1}return o},N.prototype.__iterator=function(t,e){var n=this._object,r=this._keys,i=r.length-1,o=0
return new _(function(){var a=r[e?i-o:o]
return o++>i?S():x(t,a,n[a])})},N.prototype[dn]=!0,t(R,A),R.prototype.__iterateUncached=function(t,e){if(e)return this.cacheResult().__iterate(t,e)
var n=this._iterable,r=k(n),i=0
if(O(r))for(var o;!(o=r.next()).done&&!1!==t(o.value,i++,this););return i},R.prototype.__iteratorUncached=function(t,e){if(e)return this.cacheResult().__iterator(t,e)
var n=this._iterable,r=k(n)
if(!O(r))return new _(S)
var i=0
return new _(function(){var e=r.next()
return e.done?e:x(t,i++,e.value)})},t(M,A),M.prototype.__iterateUncached=function(t,e){if(e)return this.cacheResult().__iterate(t,e)
for(var n=this._iterator,r=this._iteratorCache,i=0;r.length>i;)if(!1===t(r[i],i++,this))return i
for(var o;!(o=n.next()).done;){var a=o.value
if(r[i]=a,!1===t(a,i++,this))break}return i},M.prototype.__iteratorUncached=function(t,e){if(e)return this.cacheResult().__iterator(t,e)
var n=this._iterator,r=this._iteratorCache,i=0
return new _(function(){if(i>=r.length){var e=n.next()
if(e.done)return e
r[i]=e.value}return x(t,i,r[i++])})}
var En
t(X,A),X.prototype.toString=function(){return 0===this.size?"Repeat []":"Repeat [ "+this._value+" "+this.size+" times ]"},X.prototype.get=function(t,e){return this.has(t)?this._value:e},X.prototype.includes=function(t){return K(this._value,t)},X.prototype.slice=function(t,e){var n=this.size
return m(t,e,n)?this:new X(this._value,g(e,n)-b(t,n))},X.prototype.reverse=function(){return this},X.prototype.indexOf=function(t){return K(this._value,t)?0:-1},X.prototype.lastIndexOf=function(t){return K(this._value,t)?this.size:-1},X.prototype.__iterate=function(t,e){for(var n=0;this.size>n;n++)if(!1===t(this._value,n,this))return n+1
return n},X.prototype.__iterator=function(t,e){var n=this,r=0
return new _(function(){return n.size>r?x(t,r++,n._value):S()})},X.prototype.equals=function(t){return t instanceof X?K(this._value,t._value):G(t)}
var jn
t(Q,A),Q.prototype.toString=function(){return 0===this.size?"Range []":"Range [ "+this._start+"..."+this._end+(1!==this._step?" by "+this._step:"")+" ]"},Q.prototype.get=function(t,e){return this.has(t)?this._start+v(this,t)*this._step:e},Q.prototype.includes=function(t){var e=(t-this._start)/this._step
return e>=0&&this.size>e&&e===Math.floor(e)},Q.prototype.slice=function(t,e){return m(t,e,this.size)?this:(t=b(t,this.size),e=g(e,this.size),t>=e?new Q(0,0):new Q(this.get(t,this._end),this.get(e,this._end),this._step))},Q.prototype.indexOf=function(t){var e=t-this._start
if(e%this._step==0){var n=e/this._step
if(n>=0&&this.size>n)return n}return-1},Q.prototype.lastIndexOf=function(t){return this.indexOf(t)},Q.prototype.__iterate=function(t,e){for(var n=this.size-1,r=this._step,i=e?this._start+n*r:this._start,o=0;n>=o;o++){if(!1===t(i,o,this))return o+1
i+=e?-r:r}return o},Q.prototype.__iterator=function(t,e){var n=this.size-1,r=this._step,i=e?this._start+n*r:this._start,o=0
return new _(function(){var a=i
return i+=e?-r:r,o>n?S():x(t,o++,a)})},Q.prototype.equals=function(t){return t instanceof Q?this._start===t._start&&this._end===t._end&&this._step===t._step:G(this,t)}
var Pn
t(tt,e),t(et,tt),t(nt,tt),t(rt,tt),tt.Keyed=et,tt.Indexed=nt,tt.Set=rt
var Dn,An="function"==typeof Math.imul&&-2===Math.imul(4294967295,2)?Math.imul:function(t,e){t|=0,e|=0
var n=65535&t,r=65535&e
return n*r+((t>>>16)*r+n*(e>>>16)<<16>>>0)|0},Tn=Object.isExtensible,Cn=function(){try{return Object.defineProperty({},"@",{}),!0}catch(t){return!1}}(),Nn="function"==typeof WeakMap
Nn&&(Dn=new WeakMap)
var Rn=0,Mn="__immutablehash__"
"function"==typeof Symbol&&(Mn=Symbol(Mn))
var Ln=16,zn=255,Bn=0,qn={}
t(ft,et),ft.of=function(){var t=un.call(arguments,0)
return xt().withMutations(function(e){for(var n=0;t.length>n;n+=2){if(n+1>=t.length)throw Error("Missing value for key: "+t[n])
e.set(t[n],t[n+1])}})},ft.prototype.toString=function(){return this.__toString("Map {","}")},ft.prototype.get=function(t,e){return this._root?this._root.get(0,void 0,t,e):e},ft.prototype.set=function(t,e){return St(this,t,e)},ft.prototype.setIn=function(t,e){return this.updateIn(t,mn,function(){return e})},ft.prototype.remove=function(t){return St(this,t,mn)},ft.prototype.deleteIn=function(t){return this.updateIn(t,function(){return mn})},ft.prototype.update=function(t,e,n){return 1===arguments.length?t(this):this.updateIn([t],e,n)},ft.prototype.updateIn=function(t,e,n){n||(n=e,e=void 0)
var r=Nt(this,Ae(t),e,n)
return r===mn?void 0:r},ft.prototype.clear=function(){return 0===this.size?this:this.__ownerID?(this.size=0,this._root=null,this.__hash=void 0,this.__altered=!0,this):xt()},ft.prototype.merge=function(){return Dt(this,void 0,arguments)},ft.prototype.mergeWith=function(t){return Dt(this,t,un.call(arguments,1))},ft.prototype.mergeIn=function(t){var e=un.call(arguments,1)
return this.updateIn(t,xt(),function(t){return"function"==typeof t.merge?t.merge.apply(t,e):e[e.length-1]})},ft.prototype.mergeDeep=function(){return Dt(this,At,arguments)},ft.prototype.mergeDeepWith=function(t){var e=un.call(arguments,1)
return Dt(this,Tt(t),e)},ft.prototype.mergeDeepIn=function(t){var e=un.call(arguments,1)
return this.updateIn(t,xt(),function(t){return"function"==typeof t.mergeDeep?t.mergeDeep.apply(t,e):e[e.length-1]})},ft.prototype.sort=function(t){return Zt(we(this,t))},ft.prototype.sortBy=function(t,e){return Zt(we(this,e,t))},ft.prototype.withMutations=function(t){var e=this.asMutable()
return t(e),e.wasAltered()?e.__ensureOwner(this.__ownerID):this},ft.prototype.asMutable=function(){return this.__ownerID?this:this.__ensureOwner(new d)},ft.prototype.asImmutable=function(){return this.__ensureOwner()},ft.prototype.wasAltered=function(){return this.__altered},ft.prototype.__iterator=function(t,e){return new bt(this,t,e)},ft.prototype.__iterate=function(t,e){var n=this,r=0
return this._root&&this._root.iterate(function(e){return r++,t(e[1],e[0],n)},e),r},ft.prototype.__ensureOwner=function(t){return t===this.__ownerID?this:t?_t(this.size,this._root,t,this.__hash):(this.__ownerID=t,this.__altered=!1,this)},ft.isMap=dt
var Fn="@@__IMMUTABLE_MAP__@@",Vn=ft.prototype
Vn[Fn]=!0,Vn[pn]=Vn.remove,Vn.removeIn=Vn.deleteIn,pt.prototype.get=function(t,e,n,r){for(var i=this.entries,o=0,a=i.length;a>o;o++)if(K(n,i[o][0]))return i[o][1]
return r},pt.prototype.update=function(t,e,n,r,i,o,a){for(var s=i===mn,u=this.entries,c=0,l=u.length;l>c&&!K(r,u[c][0]);c++);var d=l>c
if(d?u[c][1]===i:s)return this
if(f(a),(s||!d)&&f(o),!s||1!==u.length){if(!d&&!s&&u.length>=Wn)return Et(t,u,r,i)
var h=t&&t===this.ownerID,v=h?u:p(u)
return d?s?c===l-1?v.pop():v[c]=v.pop():v[c]=[r,i]:v.push([r,i]),h?(this.entries=v,this):new pt(t,v)}},ht.prototype.get=function(t,e,n,r){void 0===e&&(e=ot(n))
var i=1<<((0===t?e:e>>>t)&yn),o=this.bitmap
return 0==(o&i)?r:this.nodes[Rt(o&i-1)].get(t+hn,e,n,r)},ht.prototype.update=function(t,e,n,r,i,o,a){void 0===n&&(n=ot(r))
var s=(0===e?n:n>>>e)&yn,u=1<<s,c=this.bitmap,l=0!=(c&u)
if(!l&&i===mn)return this
var f=Rt(c&u-1),d=this.nodes,p=l?d[f]:void 0,h=It(p,t,e+hn,n,r,i,o,a)
if(h===p)return this
if(!l&&h&&d.length>=$n)return Pt(t,d,c,s,h)
if(l&&!h&&2===d.length&&Ot(d[1^f]))return d[1^f]
if(l&&h&&1===d.length&&Ot(h))return h
var v=t&&t===this.ownerID,y=l?h?c:c^u:c|u,m=l?h?Mt(d,f,h,v):zt(d,f,v):Lt(d,f,h,v)
return v?(this.bitmap=y,this.nodes=m,this):new ht(t,y,m)},vt.prototype.get=function(t,e,n,r){void 0===e&&(e=ot(n))
var i=(0===t?e:e>>>t)&yn,o=this.nodes[i]
return o?o.get(t+hn,e,n,r):r},vt.prototype.update=function(t,e,n,r,i,o,a){void 0===n&&(n=ot(r))
var s=(0===e?n:n>>>e)&yn,u=i===mn,c=this.nodes,l=c[s]
if(u&&!l)return this
var f=It(l,t,e+hn,n,r,i,o,a)
if(f===l)return this
var d=this.count
if(l){if(!f&&(d--,Hn>d))return jt(t,c,d,s)}else d++
var p=t&&t===this.ownerID,h=Mt(c,s,f,p)
return p?(this.count=d,this.nodes=h,this):new vt(t,d,h)},yt.prototype.get=function(t,e,n,r){for(var i=this.entries,o=0,a=i.length;a>o;o++)if(K(n,i[o][0]))return i[o][1]
return r},yt.prototype.update=function(t,e,n,r,i,o,a){void 0===n&&(n=ot(r))
var s=i===mn
if(n!==this.keyHash)return s?this:(f(a),f(o),kt(this,t,e,n,[r,i]))
for(var u=this.entries,c=0,l=u.length;l>c&&!K(r,u[c][0]);c++);var d=l>c
if(d?u[c][1]===i:s)return this
if(f(a),(s||!d)&&f(o),s&&2===l)return new mt(t,this.keyHash,u[1^c])
var h=t&&t===this.ownerID,v=h?u:p(u)
return d?s?c===l-1?v.pop():v[c]=v.pop():v[c]=[r,i]:v.push([r,i]),h?(this.entries=v,this):new yt(t,this.keyHash,v)},mt.prototype.get=function(t,e,n,r){return K(n,this.entry[0])?this.entry[1]:r},mt.prototype.update=function(t,e,n,r,i,o,a){var s=i===mn,u=K(r,this.entry[0])
return(u?i===this.entry[1]:s)?this:(f(a),s?void f(o):u?t&&t===this.ownerID?(this.entry[1]=i,this):new mt(t,this.keyHash,[r,i]):(f(o),kt(this,t,e,ot(r),[r,i])))},pt.prototype.iterate=yt.prototype.iterate=function(t,e){for(var n=this.entries,r=0,i=n.length-1;i>=r;r++)if(!1===t(n[e?i-r:r]))return!1},ht.prototype.iterate=vt.prototype.iterate=function(t,e){for(var n=this.nodes,r=0,i=n.length-1;i>=r;r++){var o=n[e?i-r:r]
if(o&&!1===o.iterate(t,e))return!1}},mt.prototype.iterate=function(t,e){return t(this.entry)},t(bt,_),bt.prototype.next=function(){for(var t=this._type,e=this._stack;e;){var n,r=e.node,i=e.index++
if(r.entry){if(0===i)return gt(t,r.entry)}else if(r.entries){if((n=r.entries.length-1)>=i)return gt(t,r.entries[this._reverse?n-i:i])}else if((n=r.nodes.length-1)>=i){var o=r.nodes[this._reverse?n-i:i]
if(o){if(o.entry)return gt(t,o.entry)
e=this._stack=wt(o,e)}continue}e=this._stack=this._stack.__prev}return S()}
var Un,Wn=vn/4,$n=vn/2,Hn=vn/4
t(Bt,nt),Bt.of=function(){return this(arguments)},Bt.prototype.toString=function(){return this.__toString("List [","]")},Bt.prototype.get=function(t,e){if((t=v(this,t))>=0&&this.size>t){t+=this._origin
var n=Jt(this,t)
return n&&n.array[t&yn]}return e},Bt.prototype.set=function(t,e){return $t(this,t,e)},Bt.prototype.remove=function(t){return this.has(t)?0===t?this.shift():t===this.size-1?this.pop():this.splice(t,1):this},Bt.prototype.insert=function(t,e){return this.splice(t,0,e)},Bt.prototype.clear=function(){return 0===this.size?this:this.__ownerID?(this.size=this._origin=this._capacity=0,this._level=hn,this._root=this._tail=null,this.__hash=void 0,this.__altered=!0,this):Wt()},Bt.prototype.push=function(){var t=arguments,e=this.size
return this.withMutations(function(n){Kt(n,0,e+t.length)
for(var r=0;t.length>r;r++)n.set(e+r,t[r])})},Bt.prototype.pop=function(){return Kt(this,0,-1)},Bt.prototype.unshift=function(){var t=arguments
return this.withMutations(function(e){Kt(e,-t.length)
for(var n=0;t.length>n;n++)e.set(n,t[n])})},Bt.prototype.shift=function(){return Kt(this,1)},Bt.prototype.merge=function(){return Gt(this,void 0,arguments)},Bt.prototype.mergeWith=function(t){return Gt(this,t,un.call(arguments,1))},Bt.prototype.mergeDeep=function(){return Gt(this,At,arguments)},Bt.prototype.mergeDeepWith=function(t){var e=un.call(arguments,1)
return Gt(this,Tt(t),e)},Bt.prototype.setSize=function(t){return Kt(this,0,t)},Bt.prototype.slice=function(t,e){var n=this.size
return m(t,e,n)?this:Kt(this,b(t,n),g(e,n))},Bt.prototype.__iterator=function(t,e){var n=0,r=Vt(this,e)
return new _(function(){var e=r()
return e===Gn?S():x(t,n++,e)})},Bt.prototype.__iterate=function(t,e){for(var n,r=0,i=Vt(this,e);(n=i())!==Gn&&!1!==t(n,r++,this););return r},Bt.prototype.__ensureOwner=function(t){return t===this.__ownerID?this:t?Ut(this._origin,this._capacity,this._level,this._root,this._tail,t,this.__hash):(this.__ownerID=t,this)},Bt.isList=qt
var Yn="@@__IMMUTABLE_LIST__@@",Jn=Bt.prototype
Jn[Yn]=!0,Jn[pn]=Jn.remove,Jn.setIn=Vn.setIn,Jn.deleteIn=Jn.removeIn=Vn.removeIn,Jn.update=Vn.update,Jn.updateIn=Vn.updateIn,Jn.mergeIn=Vn.mergeIn,Jn.mergeDeepIn=Vn.mergeDeepIn,Jn.withMutations=Vn.withMutations,Jn.asMutable=Vn.asMutable,Jn.asImmutable=Vn.asImmutable,Jn.wasAltered=Vn.wasAltered,Ft.prototype.removeBefore=function(t,e,n){if(n===e?1<<e:0===this.array.length)return this
var r=n>>>e&yn
if(r>=this.array.length)return new Ft([],t)
var i,o=0===r
if(e>0){var a=this.array[r]
if((i=a&&a.removeBefore(t,e-hn,n))===a&&o)return this}if(o&&!i)return this
var s=Yt(this,t)
if(!o)for(var u=0;r>u;u++)s.array[u]=void 0
return i&&(s.array[r]=i),s},Ft.prototype.removeAfter=function(t,e,n){if(n===(e?1<<e:0)||0===this.array.length)return this
var r=n-1>>>e&yn
if(r>=this.array.length)return this
var i
if(e>0){var o=this.array[r]
if((i=o&&o.removeAfter(t,e-hn,n))===o&&r===this.array.length-1)return this}var a=Yt(this,t)
return a.array.splice(r+1),i&&(a.array[r]=i),a}
var Kn,Gn={}
t(Zt,ft),Zt.of=function(){return this(arguments)},Zt.prototype.toString=function(){return this.__toString("OrderedMap {","}")},Zt.prototype.get=function(t,e){var n=this._map.get(t)
return void 0!==n?this._list.get(n)[1]:e},Zt.prototype.clear=function(){return 0===this.size?this:this.__ownerID?(this.size=0,this._map.clear(),this._list.clear(),this):ee()},Zt.prototype.set=function(t,e){return ne(this,t,e)},Zt.prototype.remove=function(t){return ne(this,t,mn)},Zt.prototype.wasAltered=function(){return this._map.wasAltered()||this._list.wasAltered()},Zt.prototype.__iterate=function(t,e){var n=this
return this._list.__iterate(function(e){return e&&t(e[1],e[0],n)},e)},Zt.prototype.__iterator=function(t,e){return this._list.fromEntrySeq().__iterator(t,e)},Zt.prototype.__ensureOwner=function(t){if(t===this.__ownerID)return this
var e=this._map.__ensureOwner(t),n=this._list.__ensureOwner(t)
return t?te(e,n,t,this.__hash):(this.__ownerID=t,this._map=e,this._list=n,this)},Zt.isOrderedMap=Qt,Zt.prototype[dn]=!0,Zt.prototype[pn]=Zt.prototype.remove
var Xn
t(re,D),re.prototype.get=function(t,e){return this._iter.get(t,e)},re.prototype.has=function(t){return this._iter.has(t)},re.prototype.valueSeq=function(){return this._iter.valueSeq()},re.prototype.reverse=function(){var t=this,e=ce(this,!0)
return this._useKeys||(e.valueSeq=function(){return t._iter.toSeq().reverse()}),e},re.prototype.map=function(t,e){var n=this,r=ue(this,t,e)
return this._useKeys||(r.valueSeq=function(){return n._iter.toSeq().map(t,e)}),r},re.prototype.__iterate=function(t,e){var n,r=this
return this._iter.__iterate(this._useKeys?function(e,n){return t(e,n,r)}:(n=e?ke(this):0,function(i){return t(i,e?--n:n++,r)}),e)},re.prototype.__iterator=function(t,e){if(this._useKeys)return this._iter.__iterator(t,e)
var n=this._iter.__iterator(_n,e),r=e?ke(this):0
return new _(function(){var i=n.next()
return i.done?i:x(t,e?--r:r++,i.value,i)})},re.prototype[dn]=!0,t(ie,A),ie.prototype.includes=function(t){return this._iter.includes(t)},ie.prototype.__iterate=function(t,e){var n=this,r=0
return this._iter.__iterate(function(e){return t(e,r++,n)},e)},ie.prototype.__iterator=function(t,e){var n=this._iter.__iterator(_n,e),r=0
return new _(function(){var e=n.next()
return e.done?e:x(t,r++,e.value,e)})},t(oe,T),oe.prototype.has=function(t){return this._iter.includes(t)},oe.prototype.__iterate=function(t,e){var n=this
return this._iter.__iterate(function(e){return t(e,e,n)},e)},oe.prototype.__iterator=function(t,e){var n=this._iter.__iterator(_n,e)
return new _(function(){var e=n.next()
return e.done?e:x(t,e.value,e.value,e)})},t(ae,D),ae.prototype.entrySeq=function(){return this._iter.toSeq()},ae.prototype.__iterate=function(t,e){var n=this
return this._iter.__iterate(function(e){if(e){Oe(e)
var r=o(e)
return t(r?e.get(1):e[1],r?e.get(0):e[0],n)}},e)},ae.prototype.__iterator=function(t,e){var n=this._iter.__iterator(_n,e)
return new _(function(){for(;;){var e=n.next()
if(e.done)return e
var r=e.value
if(r){Oe(r)
var i=o(r)
return x(t,i?r.get(0):r[0],i?r.get(1):r[1],e)}}})},ie.prototype.cacheResult=re.prototype.cacheResult=oe.prototype.cacheResult=ae.prototype.cacheResult=Pe,t(Te,et),Te.prototype.toString=function(){return this.__toString(Ne(this)+" {","}")},Te.prototype.has=function(t){return this._defaultValues.hasOwnProperty(t)},Te.prototype.get=function(t,e){if(!this.has(t))return e
var n=this._defaultValues[t]
return this._map?this._map.get(t,n):n},Te.prototype.clear=function(){if(this.__ownerID)return this._map&&this._map.clear(),this
var t=this.constructor
return t._empty||(t._empty=Ce(this,xt()))},Te.prototype.set=function(t,e){if(!this.has(t))throw Error('Cannot set unknown key "'+t+'" on '+Ne(this))
if(this._map&&!this._map.has(t)){if(e===this._defaultValues[t])return this}var n=this._map&&this._map.set(t,e)
return this.__ownerID||n===this._map?this:Ce(this,n)},Te.prototype.remove=function(t){if(!this.has(t))return this
var e=this._map&&this._map.remove(t)
return this.__ownerID||e===this._map?this:Ce(this,e)},Te.prototype.wasAltered=function(){return this._map.wasAltered()},Te.prototype.__iterator=function(t,e){var r=this
return n(this._defaultValues).map(function(t,e){return r.get(e)}).__iterator(t,e)},Te.prototype.__iterate=function(t,e){var r=this
return n(this._defaultValues).map(function(t,e){return r.get(e)}).__iterate(t,e)},Te.prototype.__ensureOwner=function(t){if(t===this.__ownerID)return this
var e=this._map&&this._map.__ensureOwner(t)
return t?Ce(this,e,t):(this.__ownerID=t,this._map=e,this)}
var Zn=Te.prototype
Zn[pn]=Zn.remove,Zn.deleteIn=Zn.removeIn=Vn.removeIn,Zn.merge=Vn.merge,Zn.mergeWith=Vn.mergeWith,Zn.mergeIn=Vn.mergeIn,Zn.mergeDeep=Vn.mergeDeep,Zn.mergeDeepWith=Vn.mergeDeepWith,Zn.mergeDeepIn=Vn.mergeDeepIn,Zn.setIn=Vn.setIn,Zn.update=Vn.update,Zn.updateIn=Vn.updateIn,Zn.withMutations=Vn.withMutations,Zn.asMutable=Vn.asMutable,Zn.asImmutable=Vn.asImmutable,t(Le,rt),Le.of=function(){return this(arguments)},Le.fromKeys=function(t){return this(n(t).keySeq())},Le.prototype.toString=function(){return this.__toString("Set {","}")},Le.prototype.has=function(t){return this._map.has(t)},Le.prototype.add=function(t){return Be(this,this._map.set(t,!0))},Le.prototype.remove=function(t){return Be(this,this._map.remove(t))},Le.prototype.clear=function(){return Be(this,this._map.clear())},Le.prototype.union=function(){var t=un.call(arguments,0)
return t=t.filter(function(t){return 0!==t.size}),0===t.length?this:0!==this.size||this.__ownerID||1!==t.length?this.withMutations(function(e){for(var n=0;t.length>n;n++)i(t[n]).forEach(function(t){return e.add(t)})}):this.constructor(t[0])},Le.prototype.intersect=function(){var t=un.call(arguments,0)
if(0===t.length)return this
t=t.map(function(t){return i(t)})
var e=this
return this.withMutations(function(n){e.forEach(function(e){t.every(function(t){return t.includes(e)})||n.remove(e)})})},Le.prototype.subtract=function(){var t=un.call(arguments,0)
if(0===t.length)return this
t=t.map(function(t){return i(t)})
var e=this
return this.withMutations(function(n){e.forEach(function(e){t.some(function(t){return t.includes(e)})&&n.remove(e)})})},Le.prototype.merge=function(){return this.union.apply(this,arguments)},Le.prototype.mergeWith=function(t){var e=un.call(arguments,1)
return this.union.apply(this,e)},Le.prototype.sort=function(t){return Ve(we(this,t))},Le.prototype.sortBy=function(t,e){return Ve(we(this,e,t))},Le.prototype.wasAltered=function(){return this._map.wasAltered()},Le.prototype.__iterate=function(t,e){var n=this
return this._map.__iterate(function(e,r){return t(r,r,n)},e)},Le.prototype.__iterator=function(t,e){return this._map.map(function(t,e){return e}).__iterator(t,e)},Le.prototype.__ensureOwner=function(t){if(t===this.__ownerID)return this
var e=this._map.__ensureOwner(t)
return t?this.__make(e,t):(this.__ownerID=t,this._map=e,this)},Le.isSet=ze
var Qn="@@__IMMUTABLE_SET__@@",tr=Le.prototype
tr[Qn]=!0,tr[pn]=tr.remove,tr.mergeDeep=tr.merge,tr.mergeDeepWith=tr.mergeWith,tr.withMutations=Vn.withMutations,tr.asMutable=Vn.asMutable,tr.asImmutable=Vn.asImmutable,tr.__empty=Fe,tr.__make=qe
var er
t(Ve,Le),Ve.of=function(){return this(arguments)},Ve.fromKeys=function(t){return this(n(t).keySeq())},Ve.prototype.toString=function(){return this.__toString("OrderedSet {","}")},Ve.isOrderedSet=Ue
var nr=Ve.prototype
nr[dn]=!0,nr.__empty=$e,nr.__make=We
var rr
t(He,nt),He.of=function(){return this(arguments)},He.prototype.toString=function(){return this.__toString("Stack [","]")},He.prototype.get=function(t,e){var n=this._head
for(t=v(this,t);n&&t--;)n=n.next
return n?n.value:e},He.prototype.peek=function(){return this._head&&this._head.value},He.prototype.push=function(){if(0===arguments.length)return this
for(var t=this.size+arguments.length,e=this._head,n=arguments.length-1;n>=0;n--)e={value:arguments[n],next:e}
return this.__ownerID?(this.size=t,this._head=e,this.__hash=void 0,this.__altered=!0,this):Je(t,e)},He.prototype.pushAll=function(t){if(t=r(t),0===t.size)return this
lt(t.size)
var e=this.size,n=this._head
return t.reverse().forEach(function(t){e++,n={value:t,next:n}}),this.__ownerID?(this.size=e,this._head=n,this.__hash=void 0,this.__altered=!0,this):Je(e,n)},He.prototype.pop=function(){return this.slice(1)},He.prototype.unshift=function(){return this.push.apply(this,arguments)},He.prototype.unshiftAll=function(t){return this.pushAll(t)},He.prototype.shift=function(){return this.pop.apply(this,arguments)},He.prototype.clear=function(){return 0===this.size?this:this.__ownerID?(this.size=0,this._head=void 0,this.__hash=void 0,this.__altered=!0,this):Ke()},He.prototype.slice=function(t,e){if(m(t,e,this.size))return this
var n=b(t,this.size)
if(g(e,this.size)!==this.size)return nt.prototype.slice.call(this,t,e)
for(var r=this.size-n,i=this._head;n--;)i=i.next
return this.__ownerID?(this.size=r,this._head=i,this.__hash=void 0,this.__altered=!0,this):Je(r,i)},He.prototype.__ensureOwner=function(t){return t===this.__ownerID?this:t?Je(this.size,this._head,t,this.__hash):(this.__ownerID=t,this.__altered=!1,this)},He.prototype.__iterate=function(t,e){if(e)return this.reverse().__iterate(t)
for(var n=0,r=this._head;r&&!1!==t(r.value,n++,this);)r=r.next
return n},He.prototype.__iterator=function(t,e){if(e)return this.reverse().__iterator(t)
var n=0,r=this._head
return new _(function(){if(r){var e=r.value
return r=r.next,x(t,n++,e)}return S()})},He.isStack=Ye
var ir="@@__IMMUTABLE_STACK__@@",or=He.prototype
or[ir]=!0,or.withMutations=Vn.withMutations,or.asMutable=Vn.asMutable,or.asImmutable=Vn.asImmutable,or.wasAltered=Vn.wasAltered
var ar
e.Iterator=_,Ge(e,{toArray:function(){lt(this.size)
var t=Array(this.size||0)
return this.valueSeq().__iterate(function(e,n){t[n]=e}),t},toIndexedSeq:function(){return new ie(this)},toJS:function(){return this.toSeq().map(function(t){return t&&"function"==typeof t.toJS?t.toJS():t}).__toJS()},toJSON:function(){return this.toSeq().map(function(t){return t&&"function"==typeof t.toJSON?t.toJSON():t}).__toJS()},toKeyedSeq:function(){return new re(this,!0)},toMap:function(){return ft(this.toKeyedSeq())},toObject:function(){lt(this.size)
var t={}
return this.__iterate(function(e,n){t[n]=e}),t},toOrderedMap:function(){return Zt(this.toKeyedSeq())},toOrderedSet:function(){return Ve(a(this)?this.valueSeq():this)},toSet:function(){return Le(a(this)?this.valueSeq():this)},toSetSeq:function(){return new oe(this)},toSeq:function(){return s(this)?this.toIndexedSeq():a(this)?this.toKeyedSeq():this.toSetSeq()},toStack:function(){return He(a(this)?this.valueSeq():this)},toList:function(){return Bt(a(this)?this.valueSeq():this)},toString:function(){return"[Iterable]"},__toString:function(t,e){return 0===this.size?t+e:t+" "+this.toSeq().map(this.__toStringMapper).join(", ")+" "+e},concat:function(){return Ie(this,ye(this,un.call(arguments,0)))},includes:function(t){return this.some(function(e){return K(e,t)})},entries:function(){return this.__iterator(xn)},every:function(t,e){lt(this.size)
var n=!0
return this.__iterate(function(r,i,o){return t.call(e,r,i,o)?void 0:(n=!1,!1)}),n},filter:function(t,e){return Ie(this,le(this,t,e,!0))},find:function(t,e,n){var r=this.findEntry(t,e)
return r?r[1]:n},forEach:function(t,e){return lt(this.size),this.__iterate(e?t.bind(e):t)},join:function(t){lt(this.size),t=void 0!==t?""+t:","
var e="",n=!0
return this.__iterate(function(r){n?n=!1:e+=t,e+=null!==r&&void 0!==r?""+r:""}),e},keys:function(){return this.__iterator(wn)},map:function(t,e){return Ie(this,ue(this,t,e))},reduce:function(t,e,n){lt(this.size)
var r,i
return arguments.length<2?i=!0:r=e,this.__iterate(function(e,o,a){i?(i=!1,r=e):r=t.call(n,r,e,o,a)}),r},reduceRight:function(t,e,n){var r=this.toKeyedSeq().reverse()
return r.reduce.apply(r,arguments)},reverse:function(){return Ie(this,ce(this,!0))},slice:function(t,e){return Ie(this,pe(this,t,e,!0))},some:function(t,e){return!this.every(Qe(t),e)},sort:function(t){return Ie(this,we(this,t))},values:function(){return this.__iterator(_n)},butLast:function(){return this.slice(0,-1)},isEmpty:function(){return void 0!==this.size?0===this.size:!this.some(function(){return!0})},count:function(t,e){return h(t?this.toSeq().filter(t,e):this)},countBy:function(t,e){return fe(this,t,e)},equals:function(t){return G(this,t)},entrySeq:function(){var t=this
if(t._cache)return new C(t._cache)
var e=t.toSeq().map(Ze).toIndexedSeq()
return e.fromEntrySeq=function(){return t.toSeq()},e},filterNot:function(t,e){return this.filter(Qe(t),e)},findEntry:function(t,e,n){var r=n
return this.__iterate(function(n,i,o){return t.call(e,n,i,o)?(r=[i,n],!1):void 0}),r},findKey:function(t,e){var n=this.findEntry(t,e)
return n&&n[0]},findLast:function(t,e,n){return this.toKeyedSeq().reverse().find(t,e,n)},findLastEntry:function(t,e,n){return this.toKeyedSeq().reverse().findEntry(t,e,n)},findLastKey:function(t,e){return this.toKeyedSeq().reverse().findKey(t,e)},first:function(){return this.find(y)},flatMap:function(t,e){return Ie(this,be(this,t,e))},flatten:function(t){return Ie(this,me(this,t,!0))},fromEntrySeq:function(){return new ae(this)},get:function(t,e){return this.find(function(e,n){return K(n,t)},void 0,e)},getIn:function(t,e){for(var n,r=this,i=Ae(t);!(n=i.next()).done;){var o=n.value
if((r=r&&r.get?r.get(o,mn):mn)===mn)return e}return r},groupBy:function(t,e){return de(this,t,e)},has:function(t){return this.get(t,mn)!==mn},hasIn:function(t){return this.getIn(t,mn)!==mn},isSubset:function(t){return t="function"==typeof t.includes?t:e(t),this.every(function(e){return t.includes(e)})},isSuperset:function(t){return t="function"==typeof t.isSubset?t:e(t),t.isSubset(this)},keyOf:function(t){return this.findKey(function(e){return K(e,t)})},keySeq:function(){return this.toSeq().map(Xe).toIndexedSeq()},last:function(){return this.toSeq().reverse().first()},lastKeyOf:function(t){return this.toKeyedSeq().reverse().keyOf(t)},max:function(t){return _e(this,t)},maxBy:function(t,e){return _e(this,e,t)},min:function(t){return _e(this,t?tn(t):rn)},minBy:function(t,e){return _e(this,e?tn(e):rn,t)},rest:function(){return this.slice(1)},skip:function(t){return this.slice(Math.max(0,t))},skipLast:function(t){return Ie(this,this.toSeq().reverse().skip(t).reverse())},skipWhile:function(t,e){return Ie(this,ve(this,t,e,!0))},skipUntil:function(t,e){return this.skipWhile(Qe(t),e)},sortBy:function(t,e){return Ie(this,we(this,e,t))},take:function(t){return this.slice(0,Math.max(0,t))},takeLast:function(t){return Ie(this,this.toSeq().reverse().take(t).reverse())},takeWhile:function(t,e){return Ie(this,he(this,t,e))},takeUntil:function(t,e){return this.takeWhile(Qe(t),e)},valueSeq:function(){return this.toIndexedSeq()},hashCode:function(){return this.__hash||(this.__hash=on(this))}})
var sr=e.prototype
sr[cn]=!0,sr[On]=sr.values,sr.__toJS=sr.toArray,sr.__toStringMapper=en,sr.inspect=sr.toSource=function(){return""+this},sr.chain=sr.flatMap,sr.contains=sr.includes,Ge(n,{flip:function(){return Ie(this,se(this))},mapEntries:function(t,e){var n=this,r=0
return Ie(this,this.toSeq().map(function(i,o){return t.call(e,[o,i],r++,n)}).fromEntrySeq())},mapKeys:function(t,e){var n=this
return Ie(this,this.toSeq().flip().map(function(r,i){return t.call(e,r,i,n)}).flip())}})
var ur=n.prototype
return ur[ln]=!0,ur[On]=sr.entries,ur.__toJS=sr.toObject,ur.__toStringMapper=function(t,e){return JSON.stringify(e)+": "+en(t)},Ge(r,{toKeyedSeq:function(){return new re(this,!1)},filter:function(t,e){return Ie(this,le(this,t,e,!1))},findIndex:function(t,e){var n=this.findEntry(t,e)
return n?n[0]:-1},indexOf:function(t){var e=this.keyOf(t)
return void 0===e?-1:e},lastIndexOf:function(t){var e=this.lastKeyOf(t)
return void 0===e?-1:e},reverse:function(){return Ie(this,ce(this,!1))},slice:function(t,e){return Ie(this,pe(this,t,e,!1))},splice:function(t,e){var n=arguments.length
if(e=Math.max(0|e,0),0===n||2===n&&!e)return this
t=b(t,0>t?this.count():this.size)
var r=this.slice(0,t)
return Ie(this,1===n?r:r.concat(p(arguments,2),this.slice(t+e)))},findLastIndex:function(t,e){var n=this.findLastEntry(t,e)
return n?n[0]:-1},first:function(){return this.get(0)},flatten:function(t){return Ie(this,me(this,t,!1))},get:function(t,e){return t=v(this,t),0>t||this.size===1/0||void 0!==this.size&&t>this.size?e:this.find(function(e,n){return n===t},void 0,e)},has:function(t){return(t=v(this,t))>=0&&(void 0!==this.size?this.size===1/0||this.size>t:-1!==this.indexOf(t))},interpose:function(t){return Ie(this,ge(this,t))},interleave:function(){var t=[this].concat(p(arguments)),e=Se(this.toSeq(),A.of,t),n=e.flatten(!0)
return e.size&&(n.size=e.size*t.length),Ie(this,n)},keySeq:function(){return Q(0,this.size)},last:function(){return this.get(-1)},skipWhile:function(t,e){return Ie(this,ve(this,t,e,!1))},zip:function(){return Ie(this,Se(this,nn,[this].concat(p(arguments))))},zipWith:function(t){var e=p(arguments)
return e[0]=this,Ie(this,Se(this,t,e))}}),r.prototype[fn]=!0,r.prototype[dn]=!0,Ge(i,{get:function(t,e){return this.has(t)?t:e},includes:function(t){return this.has(t)},keySeq:function(){return this.valueSeq()}}),i.prototype.has=sr.includes,i.prototype.contains=i.prototype.includes,Ge(D,n.prototype),Ge(A,r.prototype),Ge(T,i.prototype),Ge(et,n.prototype),Ge(nt,r.prototype),Ge(rt,i.prototype),{Iterable:e,Seq:P,Collection:tt,Map:ft,OrderedMap:Zt,List:Bt,Stack:He,Set:Le,OrderedSet:Ve,Record:Te,Range:Q,Repeat:X,is:K,fromJS:$}})},function(t,e){},,,,,,,,,,,,,,,function(t,e,n){function r(t,e){this._id=t,this._clearFn=e}var i=Function.prototype.apply
e.setTimeout=function(){return new r(i.call(setTimeout,window,arguments),clearTimeout)},e.setInterval=function(){return new r(i.call(setInterval,window,arguments),clearInterval)},e.clearTimeout=e.clearInterval=function(t){t&&t.close()},r.prototype.unref=r.prototype.ref=function(){},r.prototype.close=function(){this._clearFn.call(window,this._id)},e.enroll=function(t,e){clearTimeout(t._idleTimeoutId),t._idleTimeout=e},e.unenroll=function(t){clearTimeout(t._idleTimeoutId),t._idleTimeout=-1},e._unrefActive=e.active=function(t){clearTimeout(t._idleTimeoutId)
var e=t._idleTimeout
e>=0&&(t._idleTimeoutId=setTimeout(function(){t._onTimeout&&t._onTimeout()},e))},n(328),e.setImmediate=setImmediate,e.clearImmediate=clearImmediate},function(t,e,n){"use strict"
var r=n(240),i=function(){return function(t){return window.location.href.indexOf(t)>=0}("t3.com")&&!1}
e.a=i()?r:Object.assign.apply(Object,[{}].concat(Object.keys(r).map(function(t){var e
return e={},e[t]=function(t){},e})))},,function(t,e,n){"use strict"
var r=n(2),i=function(){function t(t,e,n){this.kind=t,this.value=e,this.error=n,this.hasValue="N"===t}return t.prototype.observe=function(t){switch(this.kind){case"N":return t.next&&t.next(this.value)
case"E":return t.error&&t.error(this.error)
case"C":return t.complete&&t.complete()}},t.prototype.do=function(t,e,n){switch(this.kind){case"N":return t&&t(this.value)
case"E":return e&&e(this.error)
case"C":return n&&n()}},t.prototype.accept=function(t,e,n){return t&&"function"==typeof t.next?this.observe(t):this.do(t,e,n)},t.prototype.toObservable=function(){switch(this.kind){case"N":return r.Observable.of(this.value)
case"E":return r.Observable.throw(this.error)
case"C":return r.Observable.empty()}throw new Error("unexpected notification kind value")},t.createNext=function(e){return void 0!==e?new t("N",e):this.undefinedValueNotification},t.createError=function(e){return new t("E",void 0,e)},t.createComplete=function(){return this.completeNotification},t.completeNotification=new t("C"),t.undefinedValueNotification=new t("N",void 0),t}()
e.Notification=i},function(t,e,n){"use strict"
function r(t,e){return t.raw=e,t}function i(t,e){var n={}
for(var r in t)e.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(t,r)&&(n[r]=t[r])
return n}function o(t){if(_[t])return _[t]
throw Object.keys(_).indexOf(t)>=0?new Error("Format key for '"+t+"' exists but is undefined -probably a bug in the formats mapping or the format module for "+t+" itself"):new Error("No format found that matches '"+t+"' - options are: "+Object.keys(_).join(", "))}var a=n(51),s=n.n(a),u=n(229),c=n(234),l=n(233),f=n(231),d=n(232),p=n(230),h=n(236),v=n(235),y=n(8),m=(n.n(y),n(73))
n.d(e,"a",function(){return w})
var b=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},g=r(["\n            Affinity "," does not exist in layout ",", affinities: ",".\n            Format is ","\n            "],["\n            Affinity "," does not exist in layout ",", affinities: ",".\n            Format is ","\n            "]),w=h.a,_={impact:u.a,nFormat:c.a,mobile:l.a,mobileArticle:f.a,mobileGallery:d.a,leaderboardSkin:p.a,none:v.a},x=function(t){return void 0===t||null===t},S=function(t,e){function n(n){this.name=e.name,this.message=n,this.format=t,this.stack=e.stack}return console.log("format: creating MyError",t,e),n.prototype=e,n}
e.b=function(t){return function(e){return function(r){return function(a){var u=w(t)(e)
if(!u)throw new Error("No ad format found for parameters: "+JSON.stringify(e,null,2))
var c=o(n.i(m.a)(u))
try{var l=a.affinity$,f=i(a,["affinity$"])
return c(e)(b({affinity$:y.map.call(l,function(t){return function(e){var n=!(arguments.length>1&&void 0!==arguments[1])||arguments[1]
if(!x(t[e]))return t[e]
if(n){var i=new Error(s()(g,e,r,JSON.stringify(t,null,2),e))
throw i.layout=r,i.format=c,i}return-1}})},f))}catch(t){var d=S(u,t)
throw new d("(format is "+u+") "+t.name+": "+t.message)}}}}}},function(t,e,n){"use strict"
var r=n(243)
e.a=function(t){return n.i(r.a)(t.document,"position",["-webkit-sticky","sticky"])}},function(t,e,n){"use strict"
var r=window.feat=window.feat||new Promise(function(t){window.resolveFEAT=t})
e.a=r},function(t,e,n){"use strict"
var r=n(247),i=n(248),o=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t}
e.a=function(){var t=n.i(r.a)(),e=n.i(i.a)()
return o({},window.adParameters,{device:t,locale:e})}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i})
var i=function(t,e){var i,o=arguments.length>2&&void 0!==arguments[2]&&arguments[2],a=n.i(r.k)(),s=n.i(r.l)([500,1e3,1/0],t,e,a),u=(s[0],s[1]),c=s[2],l={type:"INLINE_RIGHT",margin:"5px "+(o?"-325px":"0px")+" 10px 25px"},f=!1,d=function(){return f=!f,l},p=function(){return d()},h=!1,v=window.pageYOffset,y=3e3,m=(i=[]).concat.apply(i,c.filter(function(t){return t.element.getBoundingClientRect().top+v>y}).map(function(t,e){return[{slotify:{name:"double-height-"+e+"-"+t.amountOfCharacters,specifyInline:p,hook:t.element,type:"INLINE",position:"before",align:"center",width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}].concat(h&&n.i(r.q)(a,t.element,function(t){return"P"===t.nodeName&&t.textContent.length},!1)>300&&t.element.getBoundingClientRect().top+v>y?[{slotify:{name:"mid-leaderboard-"+t.amountOfCharacters,hook:t.element,specifyInline:p,type:"BLOCK",position:"after",align:"center",width:970,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}]:[])})),b=!1,g=u.filter(function(t){return t.element.getBoundingClientRect().top+v>y}).map(function(t,e,n){return b&&e===n.length-1&&t.element.getBoundingClientRect().top+v>y?{slotify:{name:"final-leaderboard",hook:t.element,type:r.b,position:r.c,align:r.d,width:970,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}:{slotify:{name:"single-height-"+e+"-"+t.amountOfCharacters,hook:t.element,specifyInline:p,type:"INLINE",position:r.c,align:r.d,width:r.e,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}})
return[].concat(g,m)}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i})
var i=function(t,e){var i=n.i(r.k)(),o=n.i(r.l)([500,1e3,1/0],t,e,i),a=(o[0],o[1]),s=o[2],u=a.map(function(t,e){return{slotify:{name:"single-height-"+e+"-"+t.amountOfCharacters,hook:t.element,type:r.b,position:r.j,align:r.d,width:r.e,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px"}}}),c=s.map(function(t,e){return{slotify:{name:"double-height-"+e+"-"+t.amountOfCharacters,hook:t.element,type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px"}}})
return[].concat(u,c)}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i}),n.d(e,"b",function(){return o})
var i={slotify:{name:"mpu1",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#article-body > p:not(:empty):not(.bordeaux-image-check)","#article-body"),backgroundColor:r.i,boilerplate:!0,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}},o={slotify:{name:"mpu2",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#this-will-be-used-for-mpu-2"),backgroundColor:r.i,boilerplate:!0,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=function(t){return["t3","creativebloq","gamesradar","musicradar","techradar"].indexOf(t)>=0}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i})
var i=function(t,e){var i,o=n.i(r.k)(),a=n.i(r.l)([500,1e3,1/0],t,e,o),s=(a[0],a[1]),u=a[2],c=!1,l=function(){return c=!c,{type:"INLINE_RIGHT",margin:"5px 0px 10px 30px"}},f=function(){return l()},d=(i=[]).concat.apply(i,u.map(function(t,e){return[{slotify:{name:"double-height-"+e+"-"+t.amountOfCharacters,specifyInline:f,hook:t.element,type:"INLINE",position:"before",align:"center",width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}].concat((n.i(r.q)(o,t.element,function(t){return"P"===t.nodeName&&t.textContent.length},!1)>300&&(t.element.getBoundingClientRect().top,window.pageYOffset),[]))})),p=!1,h=s.map(function(t,e,n){return p&&e===n.length-1&&t.element.getBoundingClientRect().top+window.pageYOffset>3500?{slotify:{name:"final-leaderboard",hook:t.element,type:r.b,position:r.c,align:r.d,width:970,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}:{slotify:{name:"single-height-"+e+"-"+t.amountOfCharacters,hook:t.element,specifyInline:f,type:"INLINE",position:r.c,align:r.d,width:r.e,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}})
return[].concat(h,d)}},function(t,e,n){"use strict"
function r(t,e){return t.raw=e,t}var i=n(51)
n.n(i),r(["\n      Style '","' attempted to be set to '","', but ended up being '","'.\n      It was originally '","'\n      "],["\n      Style '","' attempted to be set to '","', but ended up being '","'.\n      It was originally '","'\n      "])
e.a=function(t,e,n){t.style[e]=n}},function(t,e,n){"use strict"
e.a=function(t){return Array.prototype.slice.call(t)}},function(t,e,n){"use strict"
var r=!1
try{var i=Object.defineProperty({},"passive",{get:function(){r=!0}})
window.addEventListener("test",null,i)}catch(t){}e.a=r},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=function(t){return Date.now()-t.performance.timing.domLoading}},function(t,e,n){"use strict"
e.a=function(t){return Object.keys(t).map(function(e){return t[e]})}},function(t,e,n){"use strict"
function r(t){var e=document.createElement("div")
return e.dataset.name=t.name,e.className="slotify-slot",Object.assign(e.style,y.a),"BLOCK"===t.type&&"center"===t.align&&(e.style.marginLeft="auto",e.style.marginRight="auto"),e}function i(t){return Promise.all(t.map(function(t){return new Promise(function(e,n){var i=t.hook
if(!i)return void n("No hook for "+t.name)
var o=r(t)
if(!(i instanceof HTMLElement))return void n("Hook must be HTMLElement for "+t.name)
if("BLOCK"===t.type)switch(t.position){case"before":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i)
break
case"prepend":i.insertBefore(o,i.firstElementChild)
break
case"append":i.appendChild(o)
break
case"after":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i.nextSibling)
break
default:return void n("Invalid hook position "+t.position+" for "+t.name)}else{if("INLINE_LEFT"!==t.type&&"INLINE_RIGHT"!==t.type&&"INLINE"!==t.type)return void n("Invalid slot type: "+t.type+" for "+t.name)
switch(t.position){case"before":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i)
break
case"prepend":i.insertBefore(o,i.firstElementChild)
break
case"append":i.appendChild(o)
break
default:if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i.nextSibling)}}if(!o)return void n("no element found for "+t.name)
e({el:o,state:t})})})).then(function(t){return new Promise(function(e,n){var r=function(){e(t.map(function(t){var e=t.el,n=t.state,r=e.getBoundingClientRect(),i=r.left,o=r.top,a=r.right,s=r.bottom,u=0|window.pageXOffset,c=0|window.pageYOffset
o=(0|o)+c,s=(0|s)+c,i=(0|i)+u,a=(0|a)+u
var l=m.length
return m.push({el:e}),{coordinates:{left:i,top:o,right:a,bottom:s},id:l,element:e,slot:n}}))}
window.document.hidden?r():window.requestAnimationFrame(r)})})}function o(t,e,n,i){return new Promise(function(e,n){var i=t.hook
if(!i)return void n("No hook for "+t.name)
var o=r(t)
if(!(i instanceof HTMLElement))return void n("Hook must be HTMLElement for "+t.name)
if("BLOCK"===t.type)switch(t.position){case"before":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i)
break
case"prepend":i.insertBefore(o,i.firstElementChild)
break
case"append":i.appendChild(o)
break
case"after":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i.nextSibling)
break
default:return void n("Invalid hook position "+t.position+" for "+t.name)}else{if("INLINE_LEFT"!==t.type&&"INLINE_RIGHT"!==t.type&&"INLINE"!==t.type)return void n("Invalid slot type: "+t.type+" for "+t.name)
switch(t.position){case"before":if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i)
break
case"prepend":i.insertBefore(o,i.firstElementChild)
break
case"append":i.appendChild(o)
break
default:if(!i.parentNode)return void n("No parent node of hook for "+t.name)
i.parentNode.insertBefore(o,i.nextSibling)}}if(!o)return void n("no element found for "+t.name)
var a=o.getBoundingClientRect(),s=a.left,u=a.top,c=a.right,l=a.bottom,f=0|window.pageXOffset,d=0|window.pageYOffset
u=(0|u)+d,l=(0|l)+d,s=(0|s)+f,c=(0|c)+f
var p=m.length
m.push({el:o}),e({coordinates:{left:s,top:u,right:c,bottom:l},id:p,element:o})})}function a(t,e,r){var i=0|window.pageXOffset,o=0|window.pageYOffset,a=(window.innerWidth,o+window.innerHeight|0),s=(o+a)/2,u=t.slots.filter(function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},e=(t.coordinates,t.tile),n=t.anticipated,r=t.status
t.id
return e>=0&&n&&(r===v.a.NEARLY_VISIBLE||r===v.a.VISIBLE)}).sort(function(t,e){var n=(t.coordinates.top+t.coordinates.bottom)/2,r=(e.coordinates.top+e.coordinates.bottom)/2
return Math.abs(s-n)-Math.abs(s-r)}),l=t.tiles.map(function(t){return u.find(function(e){return e.tile===t.id})})
t.slots.forEach(function(t,n){var r=m[t.element]
r.tracked||c(r,t,e)}),b.length=t.tiles.count(),t.slots.forEach(function(r,i){if(!r.anticipated){var o=null
if(r.tile>=0){o=b[r.tile]||(b[r.tile]={})
var a=t.tiles.get(r.tile)
n.i(p.a)(m[r.element],r,o,a,!1,e)}else n.i(h.a)(m[r.element],r,e)}}),t.slots.forEach(function(r,i){if(r.anticipated){var o=l.includes(r),a=null
if(r.tile>=0&&(a=b[r.tile]||(b[r.tile]={})),r.tile>=0){var s=t.tiles.get(r.tile)
n.i(p.a)(m[r.element],r,a,s,o,e)}else n.i(h.a)(m[r.element],r,e)}}),x=t}function s(){try{if(null!==_&&null!==w&&w!==g){var t=g
g=w,a(w,_,t)}}catch(t){throw console.log("exception thrown in slot-driver",t),t}window.requestAnimationFrame(s)}function u(t){if(w=t.getState(),_=t,window.document.hidden&&null!==_&&null!==w&&w!==g){var e=g
g=w,a(w,_,e)}}function c(t,e,n){var r=t.el
f.b.then(function(t){return t.add("virtual-slots",r,function(t,r){return I.next(l.i(e.id,r),n)},S,function(t,r){return I.next(l.j(e.id,r),n)},function(t,r){return I.next(l.k(e.id,r),n)})}).catch(function(t){throw console.log("e",t),t}),t.tracked=!0}var l=n(74),f=n(122),d=n(64),p=(n.n(d),n(285)),h=n(287),v=n(124),y=n(345)
e.a=i,e.b=o,e.c=u
var m=[],b=[],g=null,w=null,_=null,x=void 0
window.requestAnimationFrame(s)
var S=500,I={next:function(t,e){switch(this.store=e,t.type){case"VIEW_SLOT":this.views.push(t)
break
case"IN_VIEW":this.inViews.push(t)
break
case"OUT_OF_VIEW":this.outOfViews.push(t)}},clear:function(){this.views=[],this.outOfViews=[],this.inViews=[]},store:null,views:[],outOfViews:[],inViews:[]}
setInterval(function(){(I.inViews.length>0||I.views.length>0||I.outOfViews.length>0)&&(I.views.forEach(function(t,e){var n=t.id,r=I.views.findIndex(function(t,e){var r=t.oID
return n===r})
r>=0&&e!==r&&console.error("DUPLICATES IN UPDATES.VIEWS, ",n,":",e,"vs",r)}),I.store.dispatch(l.h(I.inViews,I.views,I.outOfViews)),I.clear())},16)},function(t,e,n){"use strict"
function r(t,e,n,r,i,a){var s=arguments.length>6&&void 0!==arguments[6]?arguments[6]:o,u=arguments.length>7&&void 0!==arguments[7]?arguments[7]:o,c=arguments.length>8&&void 0!==arguments[8]?arguments[8]:o,l=arguments.length>9&&void 0!==arguments[9]&&arguments[9],f=t.el
if(t.type!==a){t.type
t.type=a,l||(t.active=!0,n.domSlot=t),f.firstElementChild&&f.removeChild(f.firstElementChild)
var d=document.createElement("div")
d.className=a,f.appendChild(d),s(d,t,e,n,r,i),l||(u(d,t,e,n,r,i),c(d,t,e,n,r,i))}else{if(l)return
n.domSlot!==t&&(t.active=!0,n.domSlot=t,u(f.querySelector("."+a),t,e,n,r,i)),c(f.querySelector("."+a),t,e,n,r,i)}}function i(t,e,n,r){var i=arguments.length>4&&void 0!==arguments[4]?arguments[4]:o,a=arguments.length>5&&void 0!==arguments[5]?arguments[5]:o,s=arguments.length>6&&void 0!==arguments[6]?arguments[6]:o,u=t.el
if(t.type!==r){t.type=r,t.active=!0,u.firstElementChild&&u.removeChild(u.firstElementChild)
var c=document.createElement("div")
c.className=r,u.appendChild(c),i(c,t,e,n),a(c,t,e,n),s(c,t,e,n)}else t.active||(t.active=!0,a(u.querySelector("."+r),t,e,n)),s(u.querySelector("."+r),t,e,n)}e.c=r,e.b=i,n.d(e,"a",function(){return s})
var o=function(){},a=!1,s=a?function(t,e,n,r){var i=t.style
i.border="solid 3px rgba("+e+", "+n+", "+r+", 0.8)",i.backgroundColor="rgba("+e+", "+n+", "+r+", 0.2)"}:o},function(t,e,n){"use strict"
function r(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null
t?i(t):(console.warn("Slotify is fetching its own feat implementation"),new Promise(function(t){return n.e(2).then(function(){return t(n(201))}.bind(null,n)).catch(n.oe)}).then(i))}n.d(e,"b",function(){return o}),e.a=r
var i=null,o=new Promise(function(t){i=t})},function(t,e,n){"use strict"
function r(t,e){return e.coordinates?t.withMutations(function(t){e.coordinates.forEach(function(e){if(void 0!==e.left&&void 0!==e.top&&void 0!==e.right&&void 0!==e.bottom){var n=t.get(e.id)
l()(void 0!==n,"currentSlot must not be undefined - "+e.id),l()(Number.isInteger(n.coordinates.top)&&Number.isInteger(e.top),"current slot coordinates top ("+n.coordinates.top+") or coords top ("+e.top+") are not integers"),n.coordinates.top===e.top&&n.coordinates.bottom===e.bottom&&n.coordinates.left===e.left&&n.coordinates.right===e.right||t.set(e.id,n.set("coordinates",{left:e.left,top:e.top,right:e.right,bottom:e.bottom}))}})}):t}var i=n(340),o=n(288),a=n(289),s=n(120),u=n(86),c=(n.n(u),n(32)),l=n.n(c),f=!1,d=void 0
try{d=void 0}catch(t){console.error("Error in showDiffs",t)}var p=n.i(u.Record)({slots:new u.List,tiles:new u.List,descendingSlotsById:new u.List}),h=n.i(i.a)(function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:new p,e=arguments[1],i=r(t.slots,e),s=i!==t.slots||t.descendingSlotsById.count()!==i.count()?i.sort(function(t,e){return t.coordinates.top-e.coordinates.top}).map(function(t){return t.id}):t.descendingSlotsById
i=n.i(o.a)(i,e,t.tiles,s)
var u=n.i(a.a)(t.tiles,e,i)
i!==t.slots||t.tiles
var c=t.set("slots",i).set("tiles",u).set("descendingSlotsById",s)
return f&&d.then(function(e){var n=e.diff(t.toJS(),c.toJS())
void 0===n||console.log("diff:",JSON.stringify(n),"but state === newState",t===c)}).catch(function(t){return console.warn("Error with show diffs:",t)}),c})
h.subscribe(function(t){n.i(s.c)(h)}),window.slotifyDebug=function(){console.log(JSON.stringify(h.getState(),0,4))},e.a=h},function(t,e,n){"use strict"
var r=n(32),i=n.n(r),o={OFF_SCREEN:"OFF_SCREEN",NEARLY_VISIBLE:"NEARLY_VISIBLE",VISIBLE:"VISIBLE"}
e.a=window.Proxy?new Proxy(o,{get:function(t,e){if(t.hasOwnProperty(e))return t[e]
i()(!1,"Trying to access an enum that does not exist: "+e+" in "+t)}}):o},function(t,e,n){"use strict"
e.empty={closed:!0,next:function(t){},error:function(t){throw t},complete:function(){}}},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(31),o=function(t){function e(e,n){t.call(this),this.subject=e,this.subscriber=n,this.closed=!1}return r(e,t),e.prototype.unsubscribe=function(){if(!this.closed){this.closed=!0
var t=this.subject,e=t.observers
if(this.subject=null,e&&0!==e.length&&!t.isStopped&&!t.closed){var n=e.indexOf(this.subscriber);-1!==n&&e.splice(n,1)}}},e}(i.Subscription)
e.SubjectSubscription=o},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n=null
return"function"==typeof t[t.length-1]&&(n=t.pop()),1===t.length&&a.isArray(t[0])&&(t=t[0].slice()),t.unshift(this),this.lift.call(new o.ArrayObservable(t),new l(n))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(25),a=n(45),s=n(21),u=n(22),c={}
e.combineLatest=r
var l=function(){function t(t){this.project=t}return t.prototype.call=function(t,e){return e.subscribe(new f(t,this.project))},t}()
e.CombineLatestOperator=l
var f=function(t){function e(e,n){t.call(this,e),this.project=n,this.active=0,this.values=[],this.observables=[]}return i(e,t),e.prototype._next=function(t){this.values.push(c),this.observables.push(t)},e.prototype._complete=function(){var t=this.observables,e=t.length
if(0===e)this.destination.complete()
else{this.active=e,this.toRespond=e
for(var n=0;n<e;n++){var r=t[n]
this.add(u.subscribeToResult(this,r,r,n))}}},e.prototype.notifyComplete=function(t){0==(this.active-=1)&&this.destination.complete()},e.prototype.notifyNext=function(t,e,n,r,i){var o=this.values,a=o[n],s=this.toRespond?a===c?--this.toRespond:this.toRespond:0
o[n]=e,0===s&&(this.project?this._tryProject(o):this.destination.next(o.slice()))},e.prototype._tryProject=function(t){var e
try{e=this.project.apply(this,t)}catch(t){return void this.destination.error(t)}this.destination.next(e)},e}(s.OuterSubscriber)
e.CombineLatestSubscriber=f},function(t,e,n){"use strict"
function r(t){return t?o.multicast.call(this,function(){return new i.Subject},t):o.multicast.call(this,new i.Subject)}var i=n(16),o=n(80)
e.publish=r},function(t,e,n){"use strict"
function r(t){return this.lift(new a(t))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.skipWhile=r
var a=function(){function t(t){this.predicate=t}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.predicate))},t}(),s=function(t){function e(e,n){t.call(this,e),this.predicate=n,this.skipping=!0,this.index=0}return i(e,t),e.prototype._next=function(t){var e=this.destination
this.skipping&&this.tryCallPredicate(t),this.skipping||e.next(t)},e.prototype.tryCallPredicate=function(t){try{var e=this.predicate(t,this.index++)
this.skipping=Boolean(e)}catch(t){this.destination.error(t)}},e}(o.Subscriber)},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=function(t){function e(){var e=t.call(this,"no elements in sequence")
this.name=e.name="EmptyError",this.stack=e.stack,this.message=e.message}return r(e,t),e}(Error)
e.EmptyError=i},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=function(t){function e(){var e=t.call(this,"object unsubscribed")
this.name=e.name="ObjectUnsubscribedError",this.stack=e.stack,this.message=e.message}return r(e,t),e}(Error)
e.ObjectUnsubscribedError=i},function(t,e,n){"use strict"
e.isArrayLike=function(t){return t&&"number"==typeof t.length}},function(t,e,n){"use strict"
function r(t){return t instanceof Date&&!isNaN(+t)}e.isDate=r},function(t,e,n){"use strict"
function r(t){return"function"==typeof t}e.isFunction=r},function(t,e,n){"use strict"
function r(t){return null!=t&&"object"==typeof t}e.isObject=r},function(t,e,n){"use strict"
function r(t){return t&&"function"!=typeof t.subscribe&&"function"==typeof t.then}e.isPromise=r},function(t,e,n){"use strict"
function r(){try{return o.apply(this,arguments)}catch(t){return a.errorObject.e=t,a.errorObject}}function i(t){return o=t,r}var o,a=n(85)
e.tryCatch=i},function(t,e,n){"use strict"
var r=n(335),i=r.a.Symbol
e.a=i},function(t,e,n){"use strict"
function r(t){if(!n.i(a.a)(t)||n.i(i.a)(t)!=s)return!1
var e=n.i(o.a)(t)
if(null===e)return!0
var r=f.call(e,"constructor")&&e.constructor
return"function"==typeof r&&r instanceof r&&l.call(r)==d}var i=n(329),o=n(331),a=n(336),s="[object Object]",u=Function.prototype,c=Object.prototype,l=u.toString,f=c.hasOwnProperty,d=l.call(Object)
e.a=r},function(t,e,n){"use strict"
function r(){for(var t=arguments.length,e=Array(t),n=0;n<t;n++)e[n]=arguments[n]
if(0===e.length)return function(t){return t}
if(1===e.length)return e[0]
var r=e[e.length-1],i=e.slice(0,-1)
return function(){return i.reduceRight(function(t,e){return e(t)},r.apply(void 0,arguments))}}e.a=r},function(t,e,n){"use strict"
function r(t,e,o){function u(){b===m&&(b=m.slice())}function c(){return y}function l(t){if("function"!=typeof t)throw new Error("Expected listener to be a function.")
var e=!0
return u(),b.push(t),function(){if(e){e=!1,u()
var n=b.indexOf(t)
b.splice(n,1)}}}function f(t){if(!n.i(i.a)(t))throw new Error("Actions must be plain objects. Use custom middleware for async actions.")
if(void 0===t.type)throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?')
if(g)throw new Error("Reducers may not dispatch actions.")
try{g=!0,y=v(y,t)}finally{g=!1}for(var e=m=b,r=0;r<e.length;r++)e[r]()
return t}function d(t){if("function"!=typeof t)throw new Error("Expected the nextReducer to be a function.")
v=t,f({type:s.INIT})}function p(){var t,e=l
return t={subscribe:function(t){function n(){t.next&&t.next(c())}if("object"!=typeof t)throw new TypeError("Expected the observer to be an object.")
return n(),{unsubscribe:e(n)}}},t[a.a]=function(){return this},t}var h
if("function"==typeof e&&void 0===o&&(o=e,e=void 0),void 0!==o){if("function"!=typeof o)throw new Error("Expected the enhancer to be a function.")
return o(r)(t,e)}if("function"!=typeof t)throw new Error("Expected the reducer to be a function.")
var v=t,y=e,m=[],b=m,g=!1
return f({type:s.INIT}),h={dispatch:f,subscribe:l,getState:c,replaceReducer:d},h[a.a]=p,h}var i=n(139),o=n(341),a=n.n(o)
n.d(e,"b",function(){return s}),e.a=r
var s={INIT:"@@redux/INIT"}},function(t,e,n){"use strict"},function(t,e,n){"use strict"
Object.defineProperty(e,"__esModule",{value:!0})
var r=n(108),i=n(238)
n.i(i.a)(r.a)},function(t,e){Array.prototype.findIndex||(Array.prototype.findIndex=function(t){"use strict"
if(null==this)throw new TypeError("Array.prototype.findIndex called on null or undefined")
if("function"!=typeof t)throw new TypeError("predicate must be a function")
for(var e,n=Object(this),r=n.length>>>0,i=arguments[1],o=0;o<r;o++)if(e=n[o],t.call(i,e,o,n))return o
return-1}),"function"!=typeof Object.assign&&function(){Object.assign=function(t){"use strict"
if(void 0===t||null===t)throw new TypeError("Cannot convert undefined or null to object")
for(var e=Object(t),n=1;n<arguments.length;n++){var r=arguments[n]
if(void 0!==r&&null!==r)for(var i in r)r.hasOwnProperty(i)&&(e[i]=r[i])}return e}}(),Array.prototype.includes||Object.defineProperty(Array.prototype,"includes",{value:function(t,e){if(null==this)throw new TypeError('"this" is null or not defined')
var n=Object(this),r=n.length>>>0
if(0===r)return!1
for(var i=0|e,o=Math.max(i>=0?i:r-Math.abs(i),0);o<r;){if(n[o]===t)return!0
o++}return!1}})},function(t,e){t.exports=function(t){return t.webpackPolyfill||(t.deprecate=function(){},t.paths=[],t.children||(t.children=[]),Object.defineProperty(t,"loaded",{enumerable:!0,get:function(){return t.l}}),Object.defineProperty(t,"id",{enumerable:!0,get:function(){return t.i}}),t.webpackPolyfill=1),t}},,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,function(t,e,n){"use strict"
function r(t,e){var n=e.offsetHeight,r=t.getComputedStyle(e)
return n+=parseInt(r.marginTop,10)+parseInt(r.marginBottom,10)}var i=n(117),o=n(107),a=n(280),s=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t}
e.a=function(t){var e=n.i(o.a)(t)
if(e&&n.i(a.a)())t.init_background_skin=function(n,r,i,o){var a=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{},u="scroll"===o,c=t.document.body.getBoundingClientRect().height,l=t.document.querySelector("#main")
l.style.isolation="isolate"
var f=l.getBoundingClientRect().height,d=250,p=40,h=document.createElement("div"),v=function(t,e){return Math.min(t+d+p,e)+"px"}
Object.assign(h.style,{width:"100%",height:v(f,c),position:"absolute",backgroundColor:r,contain:"strict"})
var y=document.createElement("div")
Object.assign(y.style,s({width:"100%",height:u?"100%":"120vh",position:u?"absolute":e,top:"0px",willChange:"transform",backgroundColor:r,backgroundImage:"url("+n+")",cursor:"pointer",backgroundRepeat:"no-repeat",contain:"strict",backgroundPosition:"50% 0"},a)),y.addEventListener("click",function(){t.open(i,"_blank")}),h.appendChild(y)
var m=t.document.querySelector(".dfp-leaderboard-container")
m.parentElement.insertBefore(h,m.nextElementSibling),t.setInterval(function(){t.document.hidden||t.requestAnimationFrame(function(){var e=l.getBoundingClientRect().height,n=t.document.body.getBoundingClientRect().height
h.style.height=v(e,n)})},5e3)}
else{var u=t.document.body,c=!1,l=0,f=void 0,d=void 0,p=void 0
Math.log10=Math.log10||function(t){return Math.log(t)*Math.LOG10E}
var h=1e5*Math.random()|0,v="gpt-skin-styles-"+h,y=void 0,m={},b=function(e){m=s({},m,e)
var n=m,r=n.transform,i=n.transition,o=n.position,a=n.top,u=n.backgroundColor,c=n.backgroundImage,l=n.backgroundRepeat,f=void 0===l?"no-repeat":l,d="\n      body::before{\n      content: '';\n        contain: strict;\n        position: "+o+";\n        height: 200%;\n        width: 100%;\n        top: "+a+";\n        will-change: transform, top;\n        left: 0;\n        background-color: "+u+";\n        background-image: url("+c+");\n        background-repeat: "+f+";\n        background-position: 50% 0;\n        transform: "+r+";\n        transition: "+i+";\n        cursor: default;\n        z-index: -1;\n      }\n      "
if(y)y.innerHTML=d
else{y=t.document.createElement("style"),y.id=v,y.innerHTML=d,t.document.body.appendChild(y)
var p=t.document.createElement("style")
p.innerHTML="body.instant-fixed-background::before{\n          position: fixed;\n          top: 0px;\n          transform: translateY(0px);\n          transition: none;\n        }",t.document.body.appendChild(p)}},g=null,w=16,_=1024,x=0,S=0,I=w,O=!1,k=!0,E=function(){var e=k
k=!1
var n=t.performance.now(),r=n-x
if(x=n,c){var i=t.scrollY
I=w+Math.min(2,Math.log10(1+Math.max(0,(i-l)/l)))/2*(_-w)|0
var o=i-S,a=16/r*Math.abs(o)
if(S=i,i+.5*a>=l){if(!0===g)return
var s=t.innerHeight,u=t.document.body.getBoundingClientRect().top+l
Math.abs(Math.max(i+.5*a-l))<75||Math.abs(Math.max(i-l))<75?(t.document.body.classList.add("instant-fixed-background"),g=!0):(1e3/r*Math.abs(o)<900||O)&&(b(i>=s?{position:"fixed",top:"0px",transform:"translateY("+-2*s+"px)",transition:"none"}:{position:"fixed",top:"0px",transform:"translateY("+u+"px)",transition:"none"}),t.requestAnimationFrame(function(){b(i>=s?{position:"fixed",top:"0px",transform:"translateY(0px)",transition:"transform ease-out 600ms"}:{position:"fixed",top:"0px",transform:"translateY(0px)",transition:"transform ease-out 300ms"})}),g=!0)}else{if(!1===g)return
var f=-t.document.body.getBoundingClientRect().top
if(t.document.body.classList.remove("instant-fixed-background"),Math.abs(Math.max(i+.5*a-l))<75||Math.abs(Math.max(i-l))<75)b({position:"absolute",top:"0px",transform:"translateY("+l+"px)",transition:"none"}),g=!1
else{var d={position:"absolute",top:"0px",transform:"translateY("+f+"px)",transition:"none"},p={position:"absolute",top:"0px",transform:"translateY("+l+"px)",transition:"transform ease-in-out 300ms"}
b(e?p:d),e||t.requestAnimationFrame(function(){b({position:"absolute",top:"0px",transform:"translateY("+l+"px)",transition:"transform ease-in-out 300ms"})}),g=!1}}}}
t.init_background_skin=function(e,n,o,a){var h=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{}
try{if(n||(n="none"),a||(a="scroll"),c=!0,l=r(t,t.document.getElementsByClassName("primary-nav")[0]),e&&(u.classList.add("has-takeover"),b(s({backgroundColor:n,backgroundImage:e,position:"fixed"},h)),"fixed"===a)){f&&t.removeEventListener("scroll",f)
var v=!0,y=!1,m=function(){v&&(v=!1,O=!0,t.requestAnimationFrame(w))},g=function(){v=!0,y&&(y=!1,setTimeout(m,16))},w=function(){try{E(),O=!1}catch(t){console.error("Error in skin recalc",t)}setTimeout(g,I)}
f=function(){v?(v=!1,t.requestAnimationFrame(w)):y=!0},t.addEventListener("scroll",f,!!i.a&&{passive:!0}),f()}o&&(p&&u.removeEventListener("mouseover",p),p=function(t){"BODY"===t.target.tagName?u.style.cursor="pointer":u.style.cursor="default"},u.addEventListener("mouseover",p),d&&u.removeEventListener("click",d),d=function(e){"BODY"===e.target.tagName&&t.open(o,"_blank")},u.addEventListener("click",d))}catch(t){console.error("Error in gpt-skin",t)}}}}},function(t,e,n){"use strict"
e.a=function(t){var e,n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Number.POSITIVE_INFINITY,r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:""
return(e=[]).concat.apply(e,t.map(function(t){if(Number.isInteger(t[0])){if(Array.isArray(t[1])){var e=t[0],i=t.slice(1)
return e<=n?i:[]}return t[1]<=n?[t]:[]}throw new Error("Invalid sizes for advert",r)}))}},function(t,e,n){"use strict"
function r(t){return t?(t^16*Math.random()>>t/4).toString(16):([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g,r)}e.a=r},,function(t,e,n){"use strict"
var r=n(2),i=n(309)
r.Observable.prototype.do=i._do,r.Observable.prototype._do=i._do},function(t,e,n){"use strict"
function r(t){var e=this
if(t||(i.root.Rx&&i.root.Rx.config&&i.root.Rx.config.Promise?t=i.root.Rx.config.Promise:i.root.Promise&&(t=i.root.Promise)),!t)throw new Error("no Promise impl found")
return new t(function(t,n){var r
e.subscribe(function(t){return r=t},function(t){return n(t)},function(){return t(r)})})}var i=n(11)
e.toPromise=r},,function(t,e,n){"use strict"
var r=n(72)
n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a}),n.d(e,"c",function(){return s})
var i=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=n.i(r.a)("loaded")(function(t){var e=t.width,n=t.height,r=t.id,o=t.info,a=t.eventID
return function(t){var s
return i({},t,(s={},s[r]=i({},t[r],{info:o,status:"loaded",width:e,height:n,eventID:a}),s))}}),a=n.i(r.a)("undelivered")(function(t){return function(e){var n
return i({},e,(n={},n[t.id]=i({},e[t.id],{status:"undelivered",eventID:t.eventID}),n))}}),s=n.i(r.a)("configured")(function(t){return function(e){var n
return i({},e,(n={},n[t.id]=i({},e[t.id],{status:"configured",eventID:t.eventID}),n))}})},function(t,e,n){"use strict"
function r(){return this}e.a=r},function(t,e,n){"use strict"
var r=n(6),i=n(66),o=(n.n(i),n(81)),a=(n.n(o),Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t})
e.a=function(t){var e
return(e=(e=r.a.call(t,"feature"),i.scan).call(e,function(t,e){var n=t.findIndex(function(t){return t.name===e.name})
if(n>=0){var r=[].concat(t)
return r[n]=a({},r[n],e),r}return[].concat(t,[e])},[]),o.publishReplay).call(e)}},function(t,e,n){"use strict"
function r(t,e){return t.raw=e,t}function i(t,e){var n={}
for(var r in t)e.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(t,r)&&(n[r]=t[r])
return n}function o(t){var e
return n.i(p.merge)(y.filter.call(this,function(t){var e=t.type
return-1===W.indexOf(e)}),(e=y.filter.call(this,function(t){var e=t.type
return-1!==W.indexOf(e)}),I.withLatestFrom).call(e,t,function(t,e){if(e[t.id])return V({},t,{advert:e[t.id]})
throw new Error("Fortification failed because the ad ID "+t.id+" was not found inside ads:\n          "+Object.keys(e).join(", "))}))}function a(t){var e=t.incremental$,n=i(t,["incremental$"]),r=1e7*Math.random()|0
return V({incremental$:m.map.call(e,function(t,e){return V({},t,{id:r+"increment"+e})})},n)}var s=n(51),u=n.n(s),c=n(24),l=(n.n(c),n(16)),f=(n.n(l),n(53)),d=(n.n(f),n(13)),p=(n.n(d),n(23)),h=(n.n(p),n(79)),v=(n.n(h),n(307)),y=(n.n(v),n(7)),m=(n.n(y),n(8)),b=(n.n(m),n(66)),g=(n.n(b),n(17)),w=(n.n(g),n(55)),_=(n.n(w),n(129)),x=(n.n(_),n(81)),S=(n.n(x),n(313)),I=(n.n(S),n(27)),O=(n.n(I),n(14)),k=(n.n(O),n(44)),E=(n.n(k),n(106)),j=n(3),P=n(6),D=n(29),A=n(72),T=n(209),C=n(216),N=n(205),R=n(213),M=n(211),L=n(207),z=n(212),B=n(210),q=n(215),F=n(214),V=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},U=r(["\n        Event has no property called id, ids or ads, which is probably a bug:\n        ","\n        "],["\n        Event has no property called id, ids or ads, which is probably a bug:\n        ","\n        "]),W=["viewed","creative-loaded"],$=function(t){return function(e){return Object.keys(e).reduce(function(n,r){return n[r]=t(e[r]),n},{})}},H=function(t){return function(e){return Object.keys(e).filter(function(n){return t(e[n])}).reduce(function(t,n){return t[n]=e[n],t},{})}}
e.a=function(t){return function(e){return function(r){return function(i){return function(s){return function(W){return function(Y){var J,K=Y.adverts,G=Y.legacyAds,X=Y.gallery,Z=new l.Subject,Q={advert$:o.call(K,Z),legacyAd$:G,galleryAction$:X,affinity$:(J=(J=(J=P.a.call(K,"slots-added"),g.first).call(J),m.map).call(J,function(t){var e=t.slots
return $(function(t){return t.id})(H(Boolean)(s(e)))}),S.share).call(J)},tt=a(n.i(E.b)(e)(r)(i)(Q)),et=tt.incremental$,nt=tt.preemptive$,rt=tt.slot$,it=tt.feature$,ot=void 0===it?n.i(d.never)():it,at=tt.collapse$,st=void 0===at?n.i(d.never)():at,ut=tt.refresh$,ct=void 0===ut?n.i(d.never)():ut,lt=n.i(T.a)(v.defaultIfEmpty.call(nt,null),K),ft=(J=y.filter.call(ot,function(t){return t.url}),m.map).call(J,function(t){var e=t.url
return n.i(D.a)(e)}),dt=(J=y.filter.call(ot,function(t){return t.script}),m.map).call(J,function(t){var e=t.script
return n.i(D.b)(e)}),pt=n.i(p.merge)(ft,dt),ht=(J=(J=n.i(p.merge)(lt,et),P.a).call(J,"create"),m.map).call(J,function(t){return function(e){var n
if(e[t.id])throw new Error("Adverts cannot share an ID: new advert "+t.name+"("+t.id+")\n         vs "+e[t.id].name+"("+e[t.id].id+")")
return V({},e,(n={},n[t.id]=V({},t,{status:"pending",eventID:t.eventID}),n))}}),vt=(J=P.a.call(K,"mount"),m.map).call(J,function(t){return function(e){var n
if(!e[t.id])throw new Error("Mounted advert ("+JSON.stringify(t,null,2)+") has no id inside state ("+Object.keys(e).join(", ")+") - possibly a hot/cold stream issue resulting in the same ad with a different ids. Event: "+JSON.stringify(t,0,2))
return V({},e,(n={},n[t.id]=V({},e[t.id],{status:"mounted",eventID:t.eventID}),n))}}),yt=(J=P.a.call(K,"shrinkwrap"),m.map).call(J,function(t){return function(e){var n
if(!e[t.id])throw new Error("Shrinkwrapped advert ("+JSON.stringify(t,null,2)+") has no id inside state ("+Object.keys(e).join(", ")+") - possibly a hot/cold stream issue resulting in the same ad with a different ids. Event: "+JSON.stringify(t,0,2))
return V({},e,(n={},n[t.id]=V({},e[t.id],{shrinkwrap:!0,stickyCandidate:!1,eventID:t.eventID}),n))}}),mt=(J=P.a.call(K,"shrinkwrap"),m.map).call(J,function(t){var e=t.id
return n.i(D.c)(!0)(e)}),bt=(J=P.a.call(K,"non-sticky"),m.map).call(J,function(t){return function(e){var n
if(!e[t.id])throw new Error("Nonsticky advert ("+JSON.stringify(t,null,2)+") has no id inside state ("+Object.keys(e).join(", ")+") - possibly a hot/cold stream issue resulting in the same ad with a different ids. Event: "+JSON.stringify(t,0,2))
return V({},e,(n={},n[t.id]=V({},e[t.id],{stickyCandidate:!1,eventID:t.eventID}),n))}}),gt=(J=(J=P.a.call(K,"shrinkwrap"),y.filter).call(J,function(t){return"interscroller"===t.adType}),m.map).call(J,function(t){var e=t.id,r=t.eventID
return n.i(D.d)(e,0,r)}),wt=n.i(N.a)(K),_t=n.i(A.a)("new-size")(function(t){var e=t.width,n=t.height,r=t.id,i=t.eventID
return function(t){var o
return V({},t,(o={},o[r]=V({},t[r],{width:e,height:n,eventID:i}),o))}})(K),xt=n.i(N.b)(K),St=n.i(N.c)(K),It=n.i(C.a)(K),Ot=n.i(C.b)(K),kt=n.i(C.c)(K),Et=(J=(J=(J=P.a.call(K,D.e),m.map).call(J,function(t){return function(e){var n
return V({},e,(n={},n[t.id]=t,n))}}),b.scan).call(J,function(t,e){return e(t)},{}),x.publishReplay).call(J,1),jt=(J=P.a.call(K,"migrate"),O.mergeMap).call(J,function(t){var e,n=t.slotID,r=t.id,i=t.eventID
return(e=(e=_.skipWhile.call(Et,function(t){return void 0===t[n]}),g.first).call(e),m.map).call(e,function(t){var e=t[n]
return{slotWidth:e.slotWidth,slotHeight:e.slotHeight,id:r,eventID:i,slotID:n}})}),Pt=m.map.call(jt,function(t){var e=t.id,n=t.slotWidth,r=t.slotHeight,i=t.slotID
return function(t){var o
return V({},t,(o={},o[e]=V({},t[e],{slotWidth:n,slotHeight:r,slotID:i}),o))}}),Dt=n.i(F.a)(t)({advert$:K,migrateToSlot$:jt,state$:Z}),At=(J=(J=n.i(p.merge)(ht,vt,wt,xt,St,_t,It,Ot,kt,Pt,bt,yt),b.scan).call(J,function(t,e){return e(t)},{}),x.publishReplay).call(J,1)
At.subscribe(Z,function(t){return console.error("Error in ad$ to state$ subscription",t)},function(){return console.warn("ads$ to state$ subscription completed")})
var Tt=n.i(R.a)(t?n.i(d.never)():Z),Ct=(J=(J=(J=P.a.call(K,"mount"),I.withLatestFrom).call(J,b.scan.call(et,function(t,e){var n
return V({},t,(n={},n[e.id]=e,n))},{}),At,function(t,e,n){return e[t.id]?n[t.id]:null}),y.filter).call(J,function(t){return t}),m.map).call(J,function(t){return{eventID:n.i(j.a)(),type:"fetch",ads:[t]}}),Nt=n.i(q.a)(Z)(K),Rt=function(t){var e
return"mobile"===r.device?n.i(f.empty)():(e=(e=P.a.call(K,t),y.filter).call(e,function(t){var e=t.name
return"undertone"===e||"inskin"===e}),I.withLatestFrom).call(e,At,function(t,e){return{eventID:t,ad:Object.keys(e).map(function(t){return e[t]}).find(function(t){return"leaderboard"===t.name})}})},Mt=function(t,e){var r
return(r=I.withLatestFrom.call(t,Et,function(t,e){var n=t.ad.slotID
return{slot:e[n].slot,slotID:n}}),m.map).call(r,function(t){var r=t.slot.preallocated,i=t.slotID
return{eventID:n.i(j.a)(),type:e,preallocated:r,slotID:i}})},Lt=Rt("third-party-skin"),zt=Rt("passback"),Bt=Mt(Lt,"collapse-slot"),qt=Mt(zt,"inflate-slot"),Ft=n.i(p.merge)(qt,Bt,st),Vt=n.i(p.merge)(n.i(z.a)(Z)(K),n.i(z.b)(Z)(jt),n.i(z.c)(Z)(K)),Ut=(J=(J=P.a.call(K,"loaded"),I.withLatestFrom).call(J,Z,function(t,e){var r=t.id,i=t.width,o=t.height,a=t.name,s=t.eventID,u=e[r],c=u.fluid,l=u.mode
return n.i(h.from)([{eventID:n.i(j.a)(),eventDeps:[s],type:"ack-loaded",name:a,id:r,width:i,height:o,fluid:c,mode:l}].concat("slotify"!==l?[]:[n.i(D.f)(r,i,o,s)]))}),k.mergeAll).call(J),Wt=n.i(p.merge)(n.i(B.a)({advert$:K,state$:Z}),gt),$t=n.i(p.merge)(ct,n.i(M.a)(At)(G)),Ht=n.i(L.a)(n.i(p.merge)(K,m.map.call(ot,function(t){var e=t.name,r=t.brief,i=t.description,o=t.status
return{type:"feature",eventID:n.i(j.a)(),name:e,brief:r,description:i,status:o}}),(J=P.a.call(K,"third-party-skin"),m.map).call(J,function(t){var e=t.name
return{type:"feature",eventID:n.i(j.a)(),brief:"third party skin",name:e,status:"active"}})))
At.connect(),lt.connect(),Et.connect(),Ht.connect()
var Yt=10,Jt=new c.ReplaySubject(Yt),Kt=function(t){if(!t.id&&!t.ids&&!t.ads)throw new Error(u()(U,JSON.stringify(t,null,2)))}
return{adverts:n.i(p.merge)(Ft,n.i(p.merge)(lt,et,Ct,Vt,Ut,$t,Wt,mt,Tt,Nt,Dt).do(function(t){Array.isArray(t)?t.forEach(Kt):Kt(t)})).catch(function(t){return Jt.next(t),n.i(f.empty)()}),error$:Jt,slot$:n.i(p.merge)(rt,(J=(J=P.a.call(K,"init"),g.first).call(J),w.mapTo).call(J,V({eventID:n.i(j.a)()},W))),scripts:pt,features:Ht,advertsDebug:At}}}}}}}}},function(t,e,n){"use strict"
function r(t,e){var r,x=w.a.call(e,"init"),S=w.a.call(e,"add-tile"),I=w.a.call(e,"mount"),O=w.a.call(e,"no-mount")
return(r=(r=v.concatMap.call(x,function(e){var r,p=1e7*Math.random()|0,v=a.map.call(t,function(t,e){return null!==t?_({},t,{id:p+"preempt"+e}):t}),w=(r=(r=(r=n.i(y.combineLatest)((r=(r=n.i(m.merge)((r=(r=o.filter.call(v,function(t){return null!==t}),o.filter).call(r,function(t){return"slotify"===t.mode}),a.map).call(r,function(t){var e=t.id
return function(t){var n
return _({},t,(n={},n[e]=!1,n))}}),a.map.call(S,function(t){var e=t.id,n=t.tileID
return function(t){var r
return!1===t[e]?_({},t,(r={},r[e]=n,r)):t}})),s.scan).call(r,function(t,e){return e(t)},{}),i.startWith).call(r,{}),c.last.call(v),function(t){return t}),f.skipWhile).call(r,function(t){return Object.keys(t).map(function(e){return t[e]}).some(function(t){return!1===t})}),u.first).call(r),g.a).call(r,l.timeout,1e4),x=(r=(r=o.filter.call(v,function(t){return null!==t}),s.scan).call(r,function(t,e){var n
return _({},t,(n={},n[e.id]=e,n))},{}),d.publishReplay).call(r,1)
x.connect()
var k=!1,E=null,j=(r=(r=(r=n.i(y.combineLatest)((r=(r=n.i(m.merge)((r=o.filter.call(v,function(t){return null!==t}),a.map).call(r,function(t){return function(e){var n
return _({},e,(n={},n[t.id]=k,n))}}),a.map.call(I,function(t){var e=t.id,n=t.eventID
return function(t){var r
return t[e]===k?_({},t,(r={},r[e]=n,r)):t}}),a.map.call(O,function(t){var e=t.id
return function(t){var n
return t[e]===k?_({},t,(n={},n[e]=E,n)):t}})),s.scan).call(r,function(t,e){return e(t)},{}),i.startWith).call(r,{}),c.last.call(v),function(t){return t}),f.skipWhile).call(r,function(t){return Object.keys(t).map(function(e){return t[e]}).some(function(t){return t===k})}),u.first).call(r),g.a).call(r,l.timeout,1e4)
return n.i(m.merge)(v,a.map.call(w,function(t){return{type:"place",eventID:n.i(b.a)(),ids:Object.keys(t).map(function(e){return t[e]})}}),h.withLatestFrom.call(j,x,function(t,e){return{type:"fetch",eventID:n.i(b.a)(),ads:Object.keys(t).filter(function(e){return t[e]!==E}).map(function(t){return e[t]}),eventDeps:Object.keys(t).filter(function(e){return t[e]!==E}).map(function(e){return t[e]})}}))}),o.filter).call(r,function(t){return null!==t}),p.publish).call(r)}var i=n(69),o=(n.n(i),n(7)),a=(n.n(o),n(8)),s=(n.n(a),n(66)),u=(n.n(s),n(17)),c=(n.n(u),n(310)),l=(n.n(c),n(315)),f=(n.n(l),n(129)),d=(n.n(f),n(81)),p=(n.n(d),n(128)),h=(n.n(p),n(27)),v=(n.n(h),n(306)),y=(n.n(v),n(68)),m=(n.n(y),n(23)),b=(n.n(m),n(3)),g=n(206),w=n(6)
e.a=r
var _=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t}},function(t,e,n){"use strict"
var r=n(23),i=(n.n(r),n(8)),o=(n.n(i),n(7)),a=(n.n(o),n(27)),s=(n.n(a),n(6)),u=n(29)
e.a=function(t){var e,c=t.advert$,l=t.state$
return n.i(r.merge)((e=s.a.call(c,"loaded"),i.map).call(e,function(t){var e=t.id,r=t.eventID
return n.i(u.d)(e,.98,r)}),(e=(e=(e=s.a.call(c,"viewed"),a.withLatestFrom).call(e,l,function(t,e){var n=t.id
return{id:n,eventID:t.eventID,mode:e[n].mode}}),o.filter).call(e,function(t){return"slotify"===t.mode}),i.map).call(e,function(t){var e=t.id,r=t.eventID
return n.i(u.d)(e,0,r)}))}},function(t,e,n){"use strict"
var r=n(7),i=(n.n(r),n(8)),o=(n.n(i),n(314)),a=(n.n(o),n(27)),s=(n.n(a),n(119)),u=n(3)
e.a=function(t){return function(e){var c
return(c=(c=(c=r.filter.call(e,function(t){return"REFRESH"===t.payload.type}),a.withLatestFrom).call(c,t,function(t,e){return n.i(s.a)(e)}),o.throttleTime).call(c,1e3),i.map).call(c,function(t){return{type:"refresh",eventID:n.i(u.a)(),ads:t}})}}},function(t,e,n){"use strict"
var r=n(3),i=n(6),o=n(8),a=(n.n(o),n(27))
n.n(a)
n.d(e,"a",function(){return s}),n.d(e,"b",function(){return u}),n.d(e,"c",function(){return c})
var s=function(t){return function(e){var s
return(s=(s=i.a.call(e,"loaded"),a.withLatestFrom).call(s,t,function(t,e){var n=t.id,r=t.width,i=t.height,o=t.eventID
return{id:n,width:r,height:i,fluid:e[n].fluid,shrinkwrap:e[n].shrinkwrap,slotID:e[n].slotID,eventID:o,mode:e[n].mode}}),o.map).call(s,function(t){return{eventID:n.i(r.a)(),type:"resize",id:t.id,slotID:t.slotID,description:"loaded",eventDeps:[t.eventID],innerWidth:t.width,innerHeight:t.height,fluid:t.fluid,shrinkwrap:t.shrinkwrap,mode:t.mode}})}},u=function(t){return function(e){var i
return(i=a.withLatestFrom.call(e,t,function(t,e){var n=t.id,r=t.slotWidth,i=t.slotHeight,o=t.eventID
return{id:n,slotWidth:r,slotHeight:i,fluid:e[n].fluid,shrinkwrap:e[n].shrinkwrap,slotID:e[n].slotID,eventID:o,width:e[n].width,height:e[n].height,mode:e[n].mode}}),o.map).call(i,function(t){return{eventID:n.i(r.a)(),type:"resize",id:t.id,slotID:t.slotID,description:"migrate",eventDeps:[t.eventID],width:t.slotWidth,height:t.slotHeight,innerWidth:t.width,innerHeight:t.height,fluid:t.fluid,shrinkwrap:t.shrinkwrap,mode:t.mode}})}},c=function(t){return function(e){var s
return(s=(s=i.a.call(e,"new-size"),a.withLatestFrom).call(s,t,function(t,e){var n=t.id,r=t.width,i=t.height,o=t.eventID
return{id:n,width:r,height:i,fluid:e[n].fluid,shrinkwrap:e[n].shrinkwrap,slotID:e[n].slotID,eventID:o,mode:e[n].mode}}),o.map).call(s,function(t){return{eventID:n.i(r.a)(),type:"resize",id:t.id,slotID:t.slotID,description:"new-size",eventDeps:[t.eventID],innerWidth:t.width,innerHeight:t.height,fluid:t.fluid,shrinkwrap:t.shrinkwrap,mode:t.mode}})}}},function(t,e,n){"use strict"
var r=n(3),i=n(119),o=n(8),a=(n.n(o),n(308))
n.n(a)
e.a=function(t){var e
return(e=(e=o.map.call(t,function(t){return n.i(i.a)(t).filter(function(t){return t.visible&&("configured"===t.status||"viewed"===t.status)&&t.slotWidth&&t.slotHeight&&!1!==t.stickyCandidate})}),o.map).call(e,function(t){return{eventID:n.i(r.a)(),type:"sliding",ads:t.map(function(t){return{id:t.id,width:t.width,height:t.height,slotWidth:t.slotWidth,slotHeight:t.slotHeight,verticallyCentered:t.verticallyCentered,name:t.name}})}}),a.distinctUntilChanged).call(e,function(t,e){if(t.ads.length!==e.ads.length)return!1
for(var n=0;n<t.ads.length;n++){var r=t.ads[n],i=e.ads[n]
if(r.id!==i.id||r.width!==i.width||r.height!==i.height||r.slotWidth!==i.slotWidth||r.slotHeight!==i.slotHeight||r.verticallyCentered!==i.verticallyCentered||r.name!==i.name)return!1}return!0})}},function(t,e,n){"use strict"
var r=n(68),i=(n.n(r),n(13)),o=(n.n(i),n(23)),a=(n.n(o),n(7)),s=(n.n(a),n(8)),u=(n.n(s),n(27)),c=(n.n(u),n(14)),l=(n.n(c),n(56)),f=(n.n(l),n(69)),d=(n.n(f),n(6)),p=n(29),h=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t}
e.a=function(t){return function(e){var v,y=e.advert$,m=e.migrateToSlot$,b=e.state$
return t?(v=d.a.call(y,"add-tile"),c.mergeMap).call(v,function(t){var e,i=t.tileID,c=t.id
return n.i(r.combineLatest)(n.i(o.merge)((e=d.a.call(y,p.e),a.filter).call(e,function(t){return t.tileID===i}),(e=a.filter.call(m,function(t){return t.id===c}),l.switchMap).call(e,function(t){var e
return(e=(e=(e=d.a.call(y,p.g),a.filter).call(e,function(t){return t.tileID===i}),s.map).call(e,function(t){return{slotHeight:t.height}}),f.startWith).call(e,t)})),(e=(e=n.i(o.merge)((e=d.a.call(y,"loaded"),a.filter).call(e,function(t){return t.id===c}),(e=d.a.call(y,"new-size"),a.filter).call(e,function(t){return t.id===c})),u.withLatestFrom).call(e,b,function(t,e){var n=e[t.id]
if(n)return h({},t,{mode:n.mode,stickyCandidate:n.stickyCandidate,verticallyCentered:n.verticallyCentered})
throw new Error("Sticky failed because the ad ID "+t.id+" was not found inside ads:\n            "+Object.keys(e).join(", "))}),a.filter).call(e,function(t){return"slotify"===t.mode}),function(t,e){var r=t.slotHeight,i=e.height,o=e.id,a=e.verticallyCentered,s=e.stickyCandidate,u=void 0===s||s,c=a?(r-i)/2:0,l=i<r
return n.i(p.h)(o,c,l&&u)})}):n.i(i.never)()}}},function(t,e,n){"use strict"
var r=n(3),i=n(8),o=(n.n(i),n(27)),a=(n.n(o),n(6)),s=n(7)
n.n(s)
e.a=function(t){return function(e){var u
return(u=(u=(u=a.a.call(e,"loaded"),o.withLatestFrom).call(u,t,function(t,e){var n=t.id
return{id:n,width:t.width,height:t.height,legacySponsoredPost:e[n].legacySponsoredPost}}),s.filter).call(u,function(t){return t.legacySponsoredPost}),i.map).call(u,function(t){return{eventID:n.i(r.a)(),type:"sync-neighbour",id:t.id}})}}},function(t,e,n){"use strict"
var r=n(72)
n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a}),n.d(e,"c",function(){return s})
var i=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=n.i(r.a)("viewed")(function(t){return function(e){var n
return i({},e,(n={},n[t.id]=i({},e[t.id],{status:"viewed",eventID:t.eventID}),n))}}),a=n.i(r.a)("viewport-enter")(function(t){return function(e){var n
return i({},e,(n={},n[t.id]=i({},e[t.id],{visible:!0,eventID:t.eventID}),n))}}),s=n.i(r.a)("viewport-leave")(function(t){return function(e){var n
return i({},e,(n={},n[t.id]=i({},e[t.id],{visible:!1,eventID:t.eventID}),n))}})},function(t,e,n){"use strict"
var r=n(49),i=n(16),o=(n.n(i),new i.Subject)
n.i(r.a)(function(t){return"dfp"===t.type&&o.next(t)}),e.a=o},function(t,e,n){"use strict"
function r(t,e){function n(t){return s(t).replace(/[#",*()=+<>\[\]]/g,function(t){return"%"+t.charCodeAt(0).toString(16)})}function r(t){return"string"==typeof t?n(t):Array.isArray(t)?u(t):t}e.pubads().enableAsyncRendering(),e.pubads().collapseEmptyDivs(),e.pubads().enableSingleRequest(),e.pubads().disableInitialLoad(),e.pubads().setCentering(!0)
var i=function(t){return function(e){return e.indexOf(t)>-1?e.substr(0,e.indexOf(t)):e}},o=i("@"),a=i("%40"),s=function(t){return a(o(t))},u=function(t){return t.map(n)}
Object.keys(t).map(function(e){return{key:e,value:r(t[e])}}).forEach(function(t){var n=t.key,r=t.value
e.pubads().setTargeting(n,r)}),e.enableServices(),e.pubads().addEventListener("slotRenderEnded",function(t){try{(0,k.get(t.slot).loaded)(t)}catch(t){console.error("Error thrown in GPT API's slotRenderEnded event listener - not really sure how to handle this sensibly yet! Maybe with streams? Error:",t)}}),e.pubads().addEventListener("slotOnload",function(t){try{(0,k.get(t.slot).slotOnload)(t)}catch(t){console.error("Error thrown in GPT API's slotRenderEnded event listener - not really sure how to handle this sensibly yet! Maybe with streams? Error:",t)}}),e.pubads().addEventListener("impressionViewable",function(t){try{(0,k.get(t.slot).viewed)(t)}catch(t){console.error("Error thrown in GPT API's impressionViewable event listener - not really sure how to handle this sensibly yet! Maybe with streams? Error:",t)}})}function i(t,e){return I&&e.next({type:"feature",eventID:n.i(f.a)(),name:"index-exchange",status:"pending"}),O.then(function(t){setTimeout(function(){e.next({type:"feature",eventID:n.i(f.a)(),name:"index-exchange",status:t?"active":"present"})},10)}),E(function(e){r(t,e)})}function o(t,e,n,r,i){return new Promise(function(t,e){t()})}function a(t,e,r,i,o){if("oop"===t.mode)return console.log("GPT:: define out of page slot",t.name),o.defineOutOfPageSlot(e,r).setTargeting("oop",t.dfp.targeting.oop)
var a=n.i(g.a)(t.dfp.sizes,i,t.name)
return console.log("GPT:: define slot",t.name,"with sizes",a.map(function(t){return t[0]+"x"+t[1]}).join(", ")),o.defineSlot(e,a,r)}function s(t,e,r,i,o,s,u,c,l){var h=t.map(function(t){var e=i(t.id)
b()(e,"Fetched advert "+t.id+" must not be undefined in driver Map")
var n=e.innerBox
return b()(n.id,"InnerBox element for advert "+t.name+" has no id"),{advert:t,id:n.id+"-wrapper"}})
h.forEach(function(t){var e=t.advert,d=t.id,h=i(e.id),v=h.innerBox,y=h.innerBoxHeight,m=h.boxHeight,b=h.wrapper,g=window.performance.now()
if(!b){var w=document.createElement("div")
w.id=d,v.appendChild(w),b=w,o(e.id,{wrapper:b})}var x=a(e,u,d,Math.min(void 0===y?Number.POSITIVE_INFINITY:y,void 0===m?Number.POSITIVE_INFINITY:m),l)
if(!x)throw new Error("Invalid slot definition - advert: "+e.name+", "+JSON.stringify(e)+", unit: "+u+", id: "+d)
x.setTargeting("pos",e.dfp.targeting.pos).setTargeting("placement",e.dfp.targeting.placement).setTargeting("format",e.dfp.targeting.format).setTargeting("bordeauxID",e.id).addService(l.pubads())
var I=g
k.set(e.id,x),k.set(x,{viewed:function(){Number.isInteger(e.gaPosition)&&p.a.viewed(e.gaPosition),r({id:e.id})},slotOnload:function(t){var r=window.performance&&window.performance.timing?(new Date).getTime()-window.performance.timing.navigationStart:0
if(console.log("::slot onload",e.name,"time taken from DFP response",window.performance.now()-I|0,"time taken from DFP request",window.performance.now()-g|0,"perceived load time from navigation",r),S){console.log("Invoking recursive console silencer")
var i=n.i(_.a)(b)
console.log("Silenced",i,"iframe"+(1===i?"":"s"))}s.next({type:"creative-loaded",eventID:n.i(f.a)(),name:e.name,id:e.id,eventDeps:[c]})},loaded:function(t){if(console.log("::loaded",e.name,"occupied",!t.isEmpty,"lineItemId",t.lineItemId,"agnostic lineItemId",t.sourceAgnosticLineItemId,"creativeId",t.creativeId,"agnostic creativeId",t.sourceAgnosticCreativeId,"size",t.size,"time to response",window.performance.now()-g|0),I=window.performance.now(),S){console.log("Invoking recursive console silencer")
var r=n.i(_.a)(b)
console.log("Silenced",r,"iframe"+(1===r?"":"s"))}if(t.isEmpty)s.next({type:"undelivered",eventID:n.i(f.a)(),id:e.id,name:e.name,eventDeps:[c]})
else{var i={isEmpty:t.isEmpty,size:t.size,lineItem:t.lineItemId,creative:t.creativeId,loadTime:window.performance.now()-g}
Number.isInteger(e.gaPosition)&&p.a.loaded(Object.assign({},{name:e.name},i),Date.now(),e.gaPosition),s.next({type:"loaded",eventID:n.i(f.a)(),width:t.size[0],height:t.size[1],name:e.name,id:e.id,info:i,eventDeps:[c]})}}})}),h.forEach(function(t){var e=t.advert,n=t.id
console.log("GPT:: display "+e.name+", unit: "+u+", placement:",e.dfp.targeting.placement,"pos:",e.dfp.targeting.pos,"format:",e.dfp.targeting.format,"id:",n),l.display(n)}),Promise.resolve(window.reliablePageLoad).then(function(){var e=n.i(d.a)(window)
console.log("GPT:: request time taken",e,"in this order",t.map(function(t){return t.name}).join(", ")),E(function(e){e.refresh(t.map(function(t){var e=t.id
return k.get(e)}),{changeCorrelator:!1})})})}function u(t){return E(function(e){e.destroySlots(t.map(function(t){var e=t.id
return k.get(e)}))})}function c(t,e,n,r,i,o,a){return u(t,r).then(function(){l(t,e,n,r,i,o,a)})}function l(t,e,n,r,i,o,a,u){return E(function(c){s(t,e,n,r,i,o,a,u,c)})}Object.defineProperty(e,"__esModule",{value:!0})
var f=n(3),d=n(118),p=n(103),h=n(15),v=n(42),y=n(198),m=n(76),b=n.n(m),g=n(199),w=n(220),_=n(221)
n.d(e,"QUIET_ADS",function(){return S}),e.init=i,e.resize=o,e.destroy=u,e.refresh=c,e.fetch=l,n.i(w.a)(window),n.i(y.a)(window),window.googletag=window.googletag||{},window.googletag.cmd=window.googletag.cmd||[]
var x=function(t){return window.location.search.indexOf(t)>=0},S=x("quiet_ads"),I=!h.k,O=Promise.resolve(window.reliablePageLoad).then(function(){return new Promise(function(t,e){window.googletag.cmd.push(function(){if(I)try{void 0===window.headertag||!0!==window.headertag.apiReady?(window.headertag=window.googletag,t(!1)):t(!0)}catch(t){e(t)}else t(!1)})})}),k=n.i(v.a)(),E=function(t){return O.then(function(e){return new Promise(function(n,r){window.googletag.cmd.push(function(){try{var i=window.googletag,o=e?window.headertag:window.googletag
t({display:function(){o.display.apply(o,arguments)},refresh:function(){var t;(t=o.pubads()).refresh.apply(t,arguments)},destroySlots:function(){i.destroySlots.apply(i,arguments)},pubads:function(){return i.pubads()},defineOutOfPageSlot:function(){return i.defineOutOfPageSlot.apply(i,arguments)},defineSlot:function(){return i.defineSlot.apply(i,arguments)},enableServices:function(){i.enableServices.apply(i,arguments)}}),n()}catch(t){r(t)}})})})}},function(t,e,n){"use strict"
var r=n(49),i=n(16),o=(n.n(i),new i.Subject)
n.i(r.a)(function(t){return"sponsored-post"===t.type&&o.next(t)}),e.a=o},function(t,e,n){"use strict"
var r=n(17),i=(n.n(r),n(203)),o=(n.n(i),n(7)),a=(n.n(o),n(219))
e.a=function(t){var e,n=(e=(e=o.filter.call(a.a,function(t){return"sponsored-post"===t.type}),r.first).call(e),i.toPromise).call(e)
t.renderSponsoredPost=function(){for(var t=arguments.length,e=Array(t),r=0;r<t;r++)e[r]=arguments[r]
n.then(function(t){var n=t.payload
return n.callback.apply(n,e)})}}},function(t,e,n){"use strict"
var r=n(116),i=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=function t(e,o){var a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0
return a>=o?0:n.i(r.a)(e.querySelectorAll("iframe")).reduce(function(e,n){try{var r=n.contentWindow
return r.consoleSilenced?e:(r.realConsole=r.console,r.console=Object.keys(r.realConsole).reduce(function(t,e){var n
return i({},t,(n={},n[e]=function(){},n))},{}),r.consoleSilenced=!0,e+1+t(r.document,o,a))}catch(t){return e}},0)}
e.a=o},function(t,e,n){"use strict"
function r(t,e){var n={}
for(var r in t)e.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(t,r)&&(n[r]=t[r])
return n}var i=n(294),o=n.n(i),a=n(24),s=(n.n(a),n(16)),u=(n.n(s),n(53)),c=(n.n(u),n(2)),l=(n.n(c),n(42)),f=n(283),d=n(312),p=(n.n(d),n(127)),h=(n.n(p),n(242)),v=n(76),y=n.n(v),m=n(3),b=n(115),g=n(279),w=n(117),_=n(245),x=n(200),S=n(218),I=n(15),O=n(109),k=n(224),E=n(29),j=n(49),P=n(73),D=n(223),A="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},T=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},C="#EDEDED",N=n.i(O.a)(),R=function(){if(I.g){var t=new Promise(function(t){return n.e(1).then(function(){return t(n(197))}.bind(null,n)).catch(n.oe)}).catch(function(t){throw console.error("import('./api/mock/index')",t),t})
return{init:function(){for(var e=arguments.length,n=Array(e),r=0;r<e;r++)n[r]=arguments[r]
return t.then(function(t){return t.init.apply(t,n)})},fetch:function(){for(var e=arguments.length,n=Array(e),r=0;r<e;r++)n[r]=arguments[r]
return t.then(function(t){return t.fetch.apply(t,n)})},resize:function(){for(var e=arguments.length,n=Array(e),r=0;r<e;r++)n[r]=arguments[r]
return t.then(function(t){return t.resize.apply(t,n)})},refresh:function(){for(var e=arguments.length,n=Array(e),r=0;r<e;r++)n[r]=arguments[r]
return t.then(function(t){return t.refresh.apply(t,n)})}}}return S}(),M=function(t){return"slotify"===t.mode},L=function(t){return"sticky"===t.mode},z=function(t){return"interscroller"===t.mode},B=function(t){return"oop"===t.mode}
e.a=function(t){return function(e,i,v,S,I){return function(O){function q(t){return R.refresh(t.ads,v,function(t){st.next({type:"viewed",id:t.id,eventID:n.i(m.a)()})},it,ot,st,I)}function F(t){var e=t.selector,n=r(t,["selector"]),i=window.document.querySelector(e)
return V([T({},n,{slotify:T({},n.slotify,{hook:i})})])}function V(t){var r=(window.performance.now(),t.map(function(t){var e=void 0,r=new Promise(function(t){e=t})
return[e,t,T({},t.slotify,{onResize:function(t,e,i){r.then(function(r){st.next(n.i(E.j)({width:t,height:e,id:r,tileID:i.id}))})},onOccupy:t.boilerplate?function(e,i,o,a){var s=window.document.createElement("div")
return s.textContent="Advertisement",e.style.backgroundColor=C,s.style.fontSize="12px",s.style.width="100%",n.i(b.a)(s,"height","30px"),s.style.display="flex",s.style.flexFlow="column nowrap",s.style.alignItems="center",s.style.justifyContent="center",e.insertBefore(s,e.firstChild),e.style.paddingBottom="10px",t.preallocated||void 0===t.style||null===t.style||Object.assign(e.style,n.i(f.a)(t.style,window)),r.then(function(e){st.next(n.i(E.k)({slot:t,slotWidth:t.slotify.width,slotHeight:Math.min(t.slotify.height-40,a),tileWidth:i.width,tileHeight:i.height,tileID:i.id,preallocated:t.preallocated,id:e}))}),Math.min(t.slotify.height-40,a)}:function(e,i,o,a){return t.preallocated||void 0===t.style||null===t.style||Object.assign(e.style,n.i(f.a)(t.style,window)),r.then(function(e){st.next(n.i(E.k)({slot:t,slotWidth:t.slotify.width,slotHeight:t.slotify.height,tileWidth:i.width,tileHeight:i.height,tileID:i.id,preallocated:t.preallocated,id:e}))}),a}})]}))
return e.addSlots(r.map(function(t){return t[2]})).then(function(t){return t.map(function(t,e){var n=t.id,i=t.element
return r[e][0](n),{id:n,element:i,data:r[e][1]}})}).then(function(t){window.performance.now()
t.forEach(function(t){var e=t.id,n=t.element,r=t.data
return rt.set(e,{data:r,element:n})}),st.next({eventID:n.i(m.a)(),type:"slots-added",slots:t})})}function U(t){var r=t.id,i=1
if(void 0!==t.score&&null!==t.score&&(i=t.score),y()(t.mode,"Advert must have a mode: "+JSON.stringify(t,null,2)),L(t))n.i(g.a)(function(){var e=window.document.createElement("div")
Object.assign(e.style,{position:"fixed",bottom:"0",width:"100%",height:"auto",zIndex:"9999",backgroundColor:"transparent",display:"flex",justifyContent:"center",alignItems:"center"})
var i=window.document.createElement("div"),o={},a=window.document.createElement("div"),s={width:"320px",height:"50px",backgroundColor:C,display:"none"}
a.id="div-sticky-ad-"+r,Object.assign(i.style,o),Object.assign(a.style,s),i.appendChild(a),e.appendChild(i),window.document.body.appendChild(e),at(r,{box:i,innerBox:a,boxWidth:t.width,boxHeight:t.height,actions:{resize:function(t,e){i.style.width=t,i.style.height=e}},mode:t.mode}),st.next({eventID:n.i(m.a)(),type:"mount",name:t.name,id:r})})
else if(z(t))n.i(g.a)(function(){var e=window.document.createElement("div")
Object.assign(e.style,{marginTop:"16px",marginBottom:"16px"}),e.id="interscroller-box"
var i=window.document.createElement("div")
i.id="interscroller-inner-box"
var o=window.document.querySelectorAll("#article-body p:not(.bordeaux-image-check)")
if(o.length>=8){e.appendChild(i)
var a=o[5]
a.parentElement.insertBefore(e,a.nextSibling),at(r,{box:e,innerBox:i,boxWidth:t.width,boxHeight:t.height,actions:{resize:function(t,e){}},mode:t.mode}),st.next({eventID:n.i(m.a)(),type:"mount",name:t.name,id:r})}else st.next({eventID:n.i(m.a)(),type:"no-mount",name:t.name,id:r})})
else if(B(t))n.i(g.a)(function(){var e=window.document.createElement("div")
e.style.display="none",e.id="div-oop-"+r,at(r,{innerBox:e,actions:{resize:function(){}},mode:t.mode}),window.document.body.appendChild(e),st.next({eventID:n.i(m.a)(),type:"mount",name:t.name,id:r})})
else{if(!M(t))return Promise.reject(new Error("mode "+t.mode+" not recognised in driver.create\n        \n"+JSON.stringify(t,null,2)))
var o=t.domID,a=e.addTile({category:t.category||"advert",name:t.name,width:t.width,height:t.collapsed?0:t.height,hybrid:!0,floating:!0,proactive:!0,fluid:t.fluid,score:t.fluid?0:i,affinities:t.affinities,onMount:function(e,i){var o=void 0
e.style.zIndex=505,ot(r,{element:e,actions:i,unfetched:o,mode:t.mode}),st.next({eventID:n.i(m.a)(),name:t.name,type:"mount",id:r}),v.then(function(t){t.add("Ads",e,function(t,e){},1,function(t){st.next({eventID:n.i(m.a)(),type:"viewport-enter",id:r})},function(t){st.next({eventID:n.i(m.a)(),type:"viewport-leave",id:r})})})},onActivate:function(t,e,i,o){ot(r,{slot:e,slotID:t}),st.next({eventID:n.i(m.a)(),type:"migrate",slotID:t,slotWidth:i,slotHeight:o,id:r})}})
at(r,{tileID:a,domID:o}),setTimeout(function(t){return st.next({eventID:n.i(m.a)(),type:"add-tile",tileID:a,id:r})},0)}return Promise.resolve()}function W(t){return t.ads.forEach(function(t){if(M(t)){var r=it(t.id),i=r.element,o=r.unfetched,a=r.tileID,s=r.domID
o&&o.parentElement.removeChild(o)
var u=window.document.createElement("div"),c=t.width,l=t.height
u.id="bordeaux-outer-box-"+n.i(x.a)(),Object.assign(u.style,{display:"flex",flexFlow:"row nowrap",justifyContent:"center",zIndex:510,contain:t.fluid?"style layout":"style layout size",pointerEvents:"none"}),t.fluid?(n.i(b.a)(u,"width","100%"),n.i(b.a)(u,"height","auto")):(n.i(b.a)(u,"width",c+"px"),n.i(b.a)(u,"height",l+"px"))
var f=window.document.createElement("div")
f.id="bordeaux-intermediate-box-"+n.i(x.a)(),Object.assign(f.style,{zIndex:515})
var d=window.document.createElement("div"),p="bordeaux-inner-box-"+n.i(x.a)()
d.className=p,d.id=s||p,Object.assign(d.style,{position:"relative",zIndex:515,contain:t.fluid?"content":"size layout style"}),u.appendChild(f),f.appendChild(d),i.appendChild(u),ot(t.id,{box:u,interBox:f,boxWidth:c,boxHeight:l,innerBox:d,unfetched:void 0})
e.setScore(a,0)}}),Promise.resolve(window.reliablePageLoad).then(function(){return R.fetch(t.ads,v,function(e){st.next({type:"viewed",id:e.id,eventID:n.i(m.a)(),eventDeps:[t.eventID]})},it,ot,st,I,t.eventID)})}function $(t){var e=it(t.id),r=e.box,i=r.parentElement.parentElement.parentElement,o=i.parentElement,a=r.querySelector("iframe"),s=setInterval(n.i(_.a)(a,n.i(_.b)(o)),500)
return setTimeout(clearInterval,5e3,s),Promise.resolve()}function H(t){var e=it(t.id),r=e.box,i=e.innerBox,o=e.actions,a=t.innerWidth,s=t.innerHeight
if(r&&!t.fluid&&"interscroller"!==t.mode)if(void 0!==a&&n.i(b.a)(i,"width",a+"px"),void 0!==s&&n.i(b.a)(i,"height",s+"px"),t.shrinkwrap){if(void 0!==t.slotID){var u=rt.get(t.slotID),c=u.data.preallocated&&u.element.parentElement
c&&(console.log("value:",u,u.data.boilerplate?40:0,u.data.boilerplate),n.i(b.a)(c,"height",s+(u.data.boilerplate?40:0)+"px")),o.resize(a,s)}void 0!==a&&n.i(b.a)(r,"width",a+"px"),void 0!==s&&n.i(b.a)(r,"height",s+"px")}else void 0!==t.width&&n.i(b.a)(r,"width",t.width+"px"),void 0!==t.height&&n.i(b.a)(r,"height",t.height+"px")
return t.innerWidth&&o.resize(a,s),R.resize(t,v,it,ot,st)}function Y(e){function r(){z(e)||(Object.assign(a.style,{boxSizing:"border-box",display:"flex",flexFlow:"row wrap",justifyContent:"center",alignItems:"center"}),"absolute"!==a.style.position&&"fixed"!==a.style.position&&a.style.position!==t&&"relative"!==a.style.position&&(a.style.position="relative"),e.fluid?(n.i(b.a)(a,"width","100%"),n.i(b.a)(a,"height","auto")):(n.i(b.a)(a,"width",s+"px"),n.i(b.a)(a,"height",u+"px"))),o?o.style.pointerEvents="auto":a.style.display="none",n.i(g.a)(function(){return st.next({type:"configured",id:e.id,eventID:n.i(m.a)()})}),ot(e.id,{box:o,innerBox:a,innerBoxWidth:s,innerBoxHeight:u})}var i=it(e.id),o=i.box,a=i.innerBox,s=e.width,u=e.height
return r(),Promise.resolve()}function J(t){return ht.next(t.ads),Promise.resolve()}function K(t){var n=it(t.id),r=n.tileID
return void 0!==r&&e.setScore(r,t.priority),Promise.resolve()}function G(t){var n=it(t.id),r=n.tileID
return void 0!==r&&e.setShrinkwrapped(r,t.value),Promise.resolve()}function X(t,e){if(!o()(t.slotID)){var r=rt.get(t.slotID),i=r.data.preallocated?r.element.parentElement:r.element
return new Promise(function(t,r){switch(e){case"collapse-slot":n.i(b.a)(i,"display","none"),t()
break
case"inflate-slot":n.i(b.a)(i,"display","block"),t()
break
default:r(new Error("Action required to collapse or display an ad"))}})}if(!o()(t.tileID)){var a=nt.get(t.tileID)
return new Promise(function(t,r){switch(e){case"collapse-slot":n.i(b.a)(a.box,"display","none"),t()
break
case"inflate-slot":n.i(b.a)(a.box,"display","block"),t()
break
default:r(new Error("Action required to collapse or display an ad"))}})}return Promise.reject(new Error("Event contained neither valid slotID or tileID"))}function Z(t){var e=document.querySelector(t.selector)
return Object.keys(t.style).forEach(function(r){n.i(b.a)(e,r,t.style[r])}),Promise.resolve()}function Q(t){return t.function(window),Promise.resolve()}function tt(t){var e=window.document.createElement("script")
return e.src=t.url,e.async=!0,e.defer=!0,window.document.body.appendChild(e),Promise.resolve()}var et,nt=n.i(l.a)(),rt=n.i(l.a)(),it=function(t){return nt.get(t)},ot=function(t,e){if(!nt.has(t))throw new Error("No id ("+t+") in DOMAdverts")
nt.set(t,T({},nt.get(t),e))},at=function(t,e){return nt.set(t,e)},st=new a.ReplaySubject(1)
i.then(function(){st.next({type:"init",eventID:n.i(m.a)(),parameters:N})})
var ut=new s.Subject
ut.subscribe(function(t){var e=t.payload,n=e.id,r=e.height,i=window.document.querySelector("."+n)
window.innerWidth<700&&(i.width=window.innerWidth),i.height=Math.min(r,380)}),n.i(j.a)(function(t){return"sponsored-post-dimensions"===t.type&&ut.next(t)})
var ct=function(t){var e=it(t.id),r=e.wrapper
return n.i(D.a)(r,t.width,t.height,function(e,r){st.next({eventID:n.i(m.a)(),type:"new-size",id:t.id,width:e,height:r})}),Promise.resolve()},lt=new a.ReplaySubject(10),ft=function(t){return function(e){return console.warn(t,"passing error on",void 0===e?"undefined":A(e),e),lt.next(e),n.i(u.empty)()}},dt=n.i(k.a)(it,ot),pt=n.i(k.b)(it,ot),ht=new s.Subject;(et=(et=c.Observable.create(function(t){setInterval(function(){t.next()},1e3),window.addEventListener("scroll",function(){t.next()},!!w.a&&{passive:!0})}),d.sample).call(et,c.Observable.create(function(t){var e=function e(){t.next(),window.requestAnimationFrame(e)}
window.requestAnimationFrame(e)})),p.combineLatest).call(et,h.a.call(ht,function(t,e){return{next:e,previous:t.filter(function(t){return-1===e.findIndex(function(e){return e.id===t.id})})}}),function(t,e){return e}).subscribe(function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{previous:[],next:[]}
try{t.next.forEach(dt),t.previous.forEach(pt)}catch(t){ft(t)}},function(t){return console.error("Error in sliding ads",t)},function(){return console.warn("Sliding ads stream completed")}),R.init(S,st).catch(ft("thrown by api.init"))
var vt=function(e){var n=it(e.id),r=n.innerBox,i=n.interBox,o=n.sticky,a=n.margin,s=function(t,e){Object.assign(t.style,e)},u=function(t,e){Object.assign(t.style,{marginTop:e+"px"})}
return e.sticky?(e.margin&&u(i,e.margin),s(r,{position:t,top:"10px",willChange:"transform"}),ot(e.id,{sticky:e.sticky,margin:e.margin})):o&&(s(r,{position:"relative",top:"0px",willChange:"auto"}),a&&s(i,{margin:0}),ot(e.id,{sticky:e.sticky,margin:0})),Promise.resolve()},yt=function(t){switch(t.type){case"place":return e.place(t.ids,window.pageXOffset,window.pageYOffset-250),Promise.resolve()
case"create":return U(t)
case"create-slot":return F(t.data)
case"create-slot-with-hooks":return V(t.data)
case"refresh":return q(t)
case"fetch":return W(t)
case"resize":return H(t)
case"sync-neighbour":return $(t)
case"sliding":return J(t)
case"ack-loaded":return Y(t)
case"priority":return K(t)
case E.l:return G(t)
case E.m:return ct(t)
case"collapse-slot":return X(t,"collapse-slot")
case"inflate-slot":return X(t,"inflate-slot")
case"style":return Z(t)
case E.n:return Q(t)
case E.o:return tt(t)
case"sticky":return vt(t)
default:throw console.error("message received that driver did not recognise ("+t.type+"):",t),new Error("message received that driver did not recognise ("+t.type+"):\n        \n{"+JSON.stringify(t,null,2)+"}")}}
return window.dfp={deliveringCreativeTemplate:function(t,e,r,i){st.next({eventID:n.i(m.a)(),type:"creative-template",creativeID:t,lineItemID:e,orderID:r,name:i})},applying:function(t,e,r){console.log("window.dfp.applying",t,"width",e,"height",r),st.next({type:"third-party-skin",eventID:n.i(m.a)(),name:t,width:e,height:r})},passback:function(t){console.log("window.dfp.passback",t),st.next({type:"passback",eventID:n.i(m.a)(),name:t})},nonSticky:function(t){var e=t.bordeauxID,r=t.creativeID
console.warn("nonsticky",e,r),st.next({type:"non-sticky",eventID:n.i(m.a)(),id:e})},shrinkwrap:function(t){var e=t.bordeauxID,r=t.creativeID,i=t.adType
console.warn("shrinkwrap",e,r,i),st.next({type:"shrinkwrap",eventID:n.i(m.a)(),id:e,adType:i})}},window.addEventListener("message",function(t){var e=t.data
if("creative-template"===e.message){var r=window.dfp[n.i(P.a)(e.type)]
r&&r(e)}},!1),O.subscribe(function(t){try{(Array.isArray(t)?Promise.all(t.map(yt)):yt(t)).catch(function(e){"string"==typeof e?ft("thrown in driver asynchronous")(new Error("(Event is "+JSON.stringify(t,null,2)+") "+e)):(e.message="(Event is "+JSON.stringify(t,null,2)+") "+e.message,ft("thrown in driver asynchronous")(e))})}catch(e){e.message="(Event is "+JSON.stringify(t,null,2)+") "+e.message,ft("thrown in driver synchronous")(e)}},function(t){ft("caught in driver subscribe")(t)},function(){console.error("Driver: stream complete! (this should not happen)")}),{sink:st,error$:lt}}}}},function(t,e,n){"use strict"
var r=n(42),i=n.i(r.a)()
e.a=function(t,e,n,r){console.log("POLLING WRAPPER",t,"specified width, height",e,n)
var o=2e3
i.has(t)&&window.clearInterval(i.get(t))
var a=window.setInterval(function(){var i=t.getBoundingClientRect(),o=i.width,a=i.height;(o!==e||a!==n)&&a>=10&&(e=o,n=a,r(o,a))},o)
i.set(t,a),window.setTimeout(function(){window.clearInterval(a),i.delete(t)},6e4)}},function(t,e,n){"use strict"
var r=n(115),i=n(225)
n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a})
var o=function(t,e){return function(o){var a=t(o.id),s=a.box,u=a.innerBox,c=a.mode,l=a.lastWidth,f=a.lastHeight
if(o.height!==o.slotHeight){var d=o.width,p=o.height,h=o.slotWidth,v=o.slotHeight,y=s.getBoundingClientRect(),m=10,b=c,g=o.verticallyCentered?-(v/2-p/2):0,w=g+(m-y.top)
if((b=w>0?w>g+(v-p)?i.a.BOTTOM:i.a.MIDDLE:i.a.TOP)!==c||(0|o.width)!=(0|l)||(0|o.height)!=(0|f)){switch(e(o.id,{lastWidth:o.width,lastHeight:o.height}),"transform"!==u.style.willChange&&(u.style.willChange="transform"),u.dataset.bordeauxPreviousSlideMode=(c||void 0).toString(),u.dataset.bordeauxSlideMode=b.toString(),b){case i.a.TOP:u.style.position="relative",u.style.top=o.verticallyCentered?-g+"px":"auto",u.style.bottom="auto",u.style.transform="none",u.style.willChange="auto",s.style.justifyContent="center"
break
case i.a.MIDDLE:u.style.position="fixed",n.i(r.a)(u,"top",m+"px"),u.style.bottom="auto",n.i(r.a)(u,"transform","translateX("+(h-d)/2+"px)"),s.style.justifyContent="flex-start"
break
case i.a.BOTTOM:u.style.position="absolute",u.style.top="auto",u.style.bottom="0px",n.i(r.a)(u,"transform","translateX("+(h-d)/2+"px)"),s.style.justifyContent="flex-start"}e(o.id,{mode:b})}}else c!==i.a.NOOP&&(u.dataset.bordeauxPreviousSlideMode=u.dataset.bordeauxSlideMode,u.dataset.bordeauxSlideMode=i.a.NOOP.toString(),u.style.position="relative",u.style.top="auto",u.style.bottom="auto",u.style.transform="none",u.style.willChange="auto",e(o.id,{mode:i.a.NOOP}))}},a=function(t,e){return function(o){var a=t(o.id),s=a.box,u=a.innerBox,c=a.mode,l=o.height,f=o.slotHeight
if(o.height!==o.slotHeight){var d=10,p=s.getBoundingClientRect(),h=d-p.top,v=0|Math.min(f-l,Math.max(0,h))
u.style.position="relative",u.style.top="auto",u.style.bottom="auto",u.style.transform="none",s.style.justifyContent="center",n.i(r.a)(u,"transform","translate(0px, "+v+"px)"),e(o.id,{mode:i.a.DEFAULT}),u.dataset.bordeauxPreviousSlideMode=u.dataset.bordeauxSlideMode,u.dataset.bordeauxSlideMode=i.a.DEFAULT.toString()}else c!==i.a.NOOP&&(u.style.position="relative",u.style.top="auto",u.style.bottom="auto",u.style.transform="none",e(o.id,{mode:i.a.NOOP}),u.dataset.bordeauxPreviousSlideMode=u.dataset.bordeauxSlideMode,u.dataset.bordeauxSlideMode=i.a.NOOP.toString())}}},function(t,e,n){"use strict"
var r={DEFAULT:"DEFAULT",TOP:"TOP",MIDDLE:"MIDDLE",BOTTOM:"BOTTOM",NOOP:"NOOP"}
e.a=r},function(t,e,n){"use strict"
var r=n(3),i=n(227)
n.d(e,"a",function(){return a})
var o=function(t){return{creativebloq:"fe138b7b",t3:"e2d4691a",pcgamer:"9bb7c687",gamesradar:"7ce9642f",techradar:"5fe4e2e6",musicradar:"d1b8ec5e"}[t]},a=function(t){return{name:"Gumgum",brief:"Gumgum implementation",description:"GumGum",script:n.i(i.a)(o(t)),eventID:n.i(r.a)()}}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=function(t){return function(e){var n,r=t,i="https://g2.gumgum.com/javascripts/ggv2.js",o=e.top,a="script",s=o.document,u=s.getElementsByTagName(a)[0],c=o.XMLHttpRequest||o.XDomainRequest,l=function(t){var e=s.createElement(a)
e.src=t,e.async=!0,u.parentNode.insertBefore(e,u)},f=function(){o.clearTimeout(n)}
return o.ggv2id=r,c?(c=new c,c.open("GET",i),c.onload=function(){f()
try{(o.execScript||function(t){o.eval.call(o,t)})(c.responseText)}catch(t){}},n=o.setTimeout(function(){c.abort()},3e3),void c.send()):l(i)}}},function(t,e,n){"use strict"
function r(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[]
if(null!==t){var e=t[0],r=void 0===e?{}:e,s=r.adTags,u=void 0===s?{}:s,c=r.hawkTags,l=void 0===c?{}:c,f={articleName:n.i(i.a)(a.articleName,r.articleName),articleType:n.i(i.a)(a.articleType,r.articleType),strategy:n.i(i.a)(a.strategy,r.strategy),nullified:n.i(i.a)(a.nullified,r.nullified),timestamp:n.i(i.a)(a.timestamp,r.timestamp)}
return u&&Object.assign(f,{primaryProduct:n.i(i.a)(a.primaryProduct,u.primaryProduct),secondaryProducts:n.i(i.a)(a.secondaryProducts,u.secondaryProducts),category:n.i(i.a)(a.category,o(u.category)),groups:n.i(i.a)(a.groups,u.groups),primaryCompany:n.i(i.a)(a.primaryCompany,u.primaryCompany),companies:n.i(i.a)(a.companies,u.companies),primaryCategory:n.i(i.a)(a.primaryCategory,o(u.primaryCategory)),secondaryCategories:n.i(i.a)(a.secondaryCategories,u.secondaryCategories),tertiaryCategories:n.i(i.a)(a.tertiaryCategories,u.thirdCategories)}),l&&Object.assign(f,{hawk:{primaryProduct:n.i(i.a)(a.hawk.primaryProduct,l.primaryProduct),secondaryProducts:n.i(i.a)(a.hawk.secondaryProducts,l.secondaryProducts),companies:n.i(i.a)(a.hawk.companies,l.companies),groups:n.i(i.a)(a.hawk.groups,l.groups),category:n.i(i.a)(a.hawk.category,o(l.category))}}),f.kwMunge=[f.primaryProduct,f.secondaryProducts,f.companies,f.category].reduce(function(t,e){return t.concat(e)},[]).filter(function(t,e,n){return void 0!==t&&""!==t&&n.indexOf(t)===e}),f}return a}var i=n(244)
e.a=r
var o=function(t){return[].concat(t)[0]},a={articleName:"",articleType:"",strategy:"",nullified:!1,timestamp:0,category:"",groups:[],primaryCompany:"",companies:[],primaryProduct:"",secondaryProducts:[],primaryCategory:"",secondaryCategories:[],tertiaryCategories:[],hawk:{primaryProduct:"",secondaryProducts:[],companies:[],groups:[],category:""},kwMunge:[]}},function(t,e,n){"use strict"
var r=n(3),i=n(26),o=(n.n(i),n(54)),a=(n.n(o),n(14)),s=(n.n(a),n(28)),u=(n.n(s),n(6)),c=n(13),l=(n.n(c),n(15)),f=n(47),d=n(46),p=n(48),h=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t}
e.a=function(t){var e=t.site,v=t.device
return function(t){var y,m=t.advert$,b=t.affinity$,g="tablet"===v,w=o.letProto.call(m,n.i(d.a)(n.i(s.of)(n.i(f.a)(e))))
return{preemptive$:a.mergeMap.call(b,function(t){return s.of.apply(void 0,[h({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"lightbox1",category:"leaderboard",preempt:!0},g?{width:728,height:90}:{width:970,height:250},{verticallyCentered:!0,gaPosition:0,affinities:[{id:t("lightbox1"),pinned:!0}],dfp:{sizes:g?[[90,[728,90],[728,91]]]:[[90,[728,90],[728,91],[970,90],[970,91]],[250,[970,250],[970,251]]],targeting:{pos:1,placement:"dfp_lightbox1",format:"roadblock"}}}),h({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"lightbox2",category:"leaderboard",preempt:!0},g?{width:728,height:90}:{width:970,height:250},{verticallyCentered:!0,gaPosition:1,affinities:[{id:t("lightbox2"),pinned:!0}],dfp:{sizes:g?[[90,[728,90],[728,92]]]:[[90,[728,90],[728,92],[970,90],[970,92]],[250,[970,250],[970,252]]],targeting:{pos:2,placement:"dfp_lightbox2",format:"roadblock"}}}),h({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"lightbox3",category:"leaderboard",preempt:!0},g?{width:728,height:90}:{width:970,height:250},{verticallyCentered:!0,gaPosition:2,affinities:[{id:t("lightbox3"),pinned:!0}],dfp:{sizes:g?[[90,[728,90],[728,93]]]:[[90,[728,90],[728,93],[970,90],[970,93]],[250,[970,250],[970,253]]],targeting:{pos:3,placement:"dfp_lightbox3",format:"roadblock"}}}),{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"overlay",preempt:!0,dfp:{targeting:{placement:"dfp_rs_"+v+"_overlay_oop_1",oop:"overlay"}}}].concat(n.i(p.a)(t,v),"desktop"===v?[{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"skin",preempt:!0,dfp:{targeting:{placement:"dfp_rs_desktop_skin_oop_1",format:"roadblock",oop:"skin"}}}]:[]))}),incremental$:l.f?(y=(y=u.a.call(m,"viewed"),i.delay).call(y,500),a.mergeMap).call(y,function(t,e){return n.i(s.of)({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-mpu"+e,width:300,height:250,score:.4,dfp:{sizes:[[250,[300,250],[300,251]]],targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-dbl-mpu"+e,width:300,height:600,score:.7,dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2",format:"roadblock"}}})}):n.i(c.never)(),slot$:n.i(c.never)(),feature$:w}}}},function(t,e,n){"use strict"
var r=n(3),i=n(14),o=(n.n(i),n(79)),a=(n.n(o),n(13)),s=(n.n(a),Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t})
e.a=function(t){var e=t.device
return function(t){var u=t.affinity$,c="tablet"===e
return{preemptive$:i.mergeMap.call(u,function(t){return n.i(o.from)([s({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"leaderboard",category:"leaderboard",preempt:!0},c?{width:728,height:90}:{width:970,height:250},{verticallyCentered:!0,gaPosition:0,affinities:[{id:t("leaderboard"),pinned:!0}],dfp:{sizes:c?[[728,90],[728,91]]:[[728,90],[970,250],[970,90]],targeting:{pos:1,placement:"dfp_rs_"+e+"_leaderboard_1",format:"roadblock"}}})].concat("desktop"===e?[{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"skin",preempt:!0,dfp:{targeting:{placement:"dfp_rs_desktop_skin_oop_1",format:"roadblock",oop:"skin"}}}]:[]))}),incremental$:n.i(a.never)(),slot$:n.i(a.never)()}}}},function(t,e,n){"use strict"
var r=n(3),i=n(17),o=(n.n(i),n(26)),a=(n.n(o),n(7)),s=(n.n(a),n(55)),u=(n.n(s),n(54)),c=(n.n(u),n(14)),l=(n.n(c),n(56)),f=(n.n(l),n(28)),d=(n.n(f),n(13)),p=(n.n(d),n(15)),h=n(6),v=n(47),y=n(46),m=n(48),b=n(29)
e.a=function(t){var e=t.site,g=t.device
return function(t){var w,_=t.advert$,x=t.affinity$,S=u.letProto.call(_,n.i(y.a)(n.i(f.of)(n.i(v.a)(e)))),I=(w=h.a.call(_,"mount"),a.filter).call(w,function(t){return"sticky"===t.name}),O=(w=h.a.call(_,"undelivered"),a.filter).call(w,function(t){return"sticky"===t.name}),k=l.switchMap.call(I,function(t){var e,r=t.id
return(e=i.first.call(O),s.mapTo).call(e,n.i(b.i)({tileID:r}))})
return{preemptive$:c.mergeMap.call(x,function(t){return f.of.apply(void 0,[{eventID:n.i(r.a)(),type:"create",mode:"sticky",name:"sticky",preempt:!0,width:320,height:50,dfp:{sizes:[[320,50],[300,50]],targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"interscroller",name:"interscroller",preempt:!0,width:10,height:10,dfp:{sizes:[[10,10]],targeting:{pos:1,placement:"dfp_rs_mobile_interscroller_1",format:["mobile","interscroller"]}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu1",preempt:!0,width:300,height:600,affinities:[{id:t("mpu1"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu2",preempt:!0,width:300,height:600,affinities:[{id:t("mpu2"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,252]],[600,[300,600],[300,602]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}}].concat(n.i(m.a)(t,g),[{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"overlay",preempt:!0,dfp:{targeting:{placement:"dfp_rs_mobile_overlay_oop_1",oop:"overlay"}}}]))}),incremental$:p.f?(w=(w=h.a.call(_,"viewed"),o.delay).call(w,500),c.mergeMap).call(w,function(t,e){return n.i(f.of)({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-mpu"+e,width:300,height:250,score:.5,dfp:{sizes:[[300,250],[300,251]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-dbl-mpu"+e,width:300,height:600,score:.8,dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}})}):n.i(d.never)(),slot$:n.i(d.never)(),feature$:S,collapse$:k}}}},function(t,e,n){"use strict"
var r=n(3),i=n(7),o=(n.n(i),n(8)),a=(n.n(o),n(55)),s=(n.n(a),n(17)),u=(n.n(s),n(128)),c=(n.n(u),n(26)),l=(n.n(c),n(14)),f=(n.n(l),n(56)),d=(n.n(f),n(28)),p=(n.n(d),n(6))
e.a=function(t){return function(t){var e,h=t.advert$,v=t.galleryAction$,y=t.affinity$,m="sticky",b=l.mergeMap.call(y,function(t){return d.of.apply(void 0,[{eventID:n.i(r.a)(),type:"create",mode:"sticky",name:m,preempt:!0,width:320,height:50,dfp:{sizes:[[320,50],[300,50]],targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu1",preempt:!0,width:300,height:600,affinities:[{id:t("mpu1"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"overlay",preempt:!0,dfp:{targeting:{placement:"dfp_rs_mobile_overlay_oop_1",oop:"overlay"}}}])}),g=(e=i.filter.call(v,function(t){return"gallery"===t.type}),u.publish).call(e),w=(e=p.a.call(h,"viewed"),i.filter).call(e,function(t){return t.advert.name===m}),_=(e=(e=f.switchMap.call(w,function(t){var e,n=t.advert
return(e=s.first.call(g),a.mapTo).call(e,n)}),c.delay).call(e,500),o.map).call(e,function(t){return{type:"refresh",eventID:n.i(r.a)(),ads:[t]}})
return g.connect(),{preemptive$:b,incremental$:(e=(e=(e=p.a.call(h,"viewed"),i.filter).call(e,function(t){return"slotify"===t.advert.mode}),c.delay).call(e,250),l.mergeMap).call(e,function(t,e){return n.i(d.of)({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-mpu"+e,width:300,height:250,score:.5,dfp:{sizes:[[250,[300,250],[300,251]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-dbl-mpu"+e,width:300,height:600,score:.8,dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}})}),slot$:(e=i.filter.call(g,function(t){return!1===t.payload.reachedEnd}),o.map).call(e,function(t,e){return{eventID:n.i(r.a)(),type:"create-slot",data:{selector:"#gallery-body .last-visible",slotify:{name:"incremental-gallery-ad-"+e,type:"BLOCK",position:"before",align:"center",width:300,height:640,preactivated:!1},boilerplate:!0,backgroundColor:"EDEDED",style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}}}}),refresh$:_}}}},function(t,e,n){"use strict"
var r=n(3),i=n(17),o=(n.n(i),n(26)),a=(n.n(o),n(7)),s=(n.n(a),n(55)),u=(n.n(s),n(54)),c=(n.n(u),n(14)),l=(n.n(c),n(56)),f=(n.n(l),n(28)),d=(n.n(f),n(13)),p=(n.n(d),n(15)),h=n(6),v=n(47),y=n(46),m=n(48),b=n(29)
e.a=function(t){var e=t.site,g=t.device
return function(t){var w,_=t.advert$,x=t.affinity$,S=u.letProto.call(_,n.i(y.a)(n.i(f.of)(n.i(v.a)(e)))),I=(w=h.a.call(_,"mount"),a.filter).call(w,function(t){return"sticky"===t.name}),O=(w=h.a.call(_,"undelivered"),a.filter).call(w,function(t){return"sticky"===t.name}),k=l.switchMap.call(I,function(t){var e,r=t.id
return(e=i.first.call(O),s.mapTo).call(e,n.i(b.i)({tileID:r}))})
return{preemptive$:c.mergeMap.call(x,function(t){return f.of.apply(void 0,[{eventID:n.i(r.a)(),type:"create",mode:"sticky",name:"sticky",preempt:!0,width:320,height:50,dfp:{sizes:[[320,50],[300,50]],targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu1",preempt:!0,width:300,height:600,affinities:[{id:t("mpu1"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1",format:["mobile","roadblock"]}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu2",preempt:!0,width:300,height:600,affinities:[{id:t("mpu2"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,252]],[600,[300,600],[300,602]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}}].concat(n.i(m.a)(t,g),[{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"overlay",preempt:!0,dfp:{targeting:{placement:"dfp_rs_mobile_overlay_oop_1",oop:"overlay"}}}]))}),incremental$:p.f?(w=(w=h.a.call(_,"viewed"),o.delay).call(w,500),c.mergeMap).call(w,function(t,e){return n.i(f.of)({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-mpu"+e,width:300,height:250,score:.5,dfp:{sizes:[[300,250],[300,251]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-dbl-mpu"+e,width:300,height:600,score:.8,dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2",format:"roadblock"}}})}):n.i(d.never)(),slot$:n.i(d.never)(),feature$:S,collapse$:k}}}},function(t,e,n){"use strict"
var r=n(3),i=n(26),o=(n.n(i),n(54)),a=(n.n(o),n(14)),s=(n.n(a),n(79)),u=(n.n(s),n(28)),c=(n.n(u),n(23)),l=(n.n(c),n(13)),f=(n.n(l),n(15)),d=n(48),p=n(47),h=n(226),v=n(46),y=n(6),m=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},b=["GB","US","CA","AU","NZ"]
e.a=function(t){var e=t.device,g=t.site,w=t.type,_=t.locale
return function(t){var x,S=t.advert$,I=t.affinity$,O="gallery"===w,k="tablet"===e,E="standard"===w||"review"===w,j=O||k||b.includes(_)?n.i(u.of)(n.i(p.a)(g)):n.i(u.of)(n.i(p.a)(g),n.i(p.b)(g)),P="techradar"!==g||-1===window.location.href.indexOf("/phone-and-communications/mobile-phones/"),D=E&&P?n.i(u.of)(n.i(h.a)(g)):n.i(l.never)(),A=c.merge.apply(void 0,[j,D].map(function(t){return o.letProto.call(S,n.i(v.a)(t))}))
return{preemptive$:a.mergeMap.call(I,function(t){return n.i(s.from)([m({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"leaderboard",category:"leaderboard",preempt:!0},k?{width:728,height:90}:{width:970,height:250},{verticallyCentered:!0,gaPosition:0,affinities:[{id:t("leaderboard"),pinned:!0}],dfp:{sizes:k?[[728,90],[728,91]]:[[728,90],[970,250],[970,90]],targeting:{pos:1,placement:"dfp_rs_"+e+"_leaderboard_1",format:"roadblock"}}}),{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu1",preempt:!0,width:300,height:600,gaPosition:1,affinities:[{id:t("topOfSidebar"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:1,placement:"dfp_rs_"+e+"_mpu_1",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu2",preempt:!0,width:300,height:600,gaPosition:2,affinities:[{id:t("beforePopularBox"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,252]],[600,[300,600],[300,602]]],targeting:{pos:2,placement:"dfp_rs_"+e+"_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"mpu3",preempt:!0,width:300,height:600,gaPosition:3,affinities:[{id:t("afterPopularBox"),sticky:!0}],dfp:{sizes:[[250,[300,250],[300,253]],[600,[300,600],[300,603]]],targeting:{pos:3,placement:"dfp_rs_"+e+"_mpu_3",format:"adx"}}},{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"overlay",preempt:!0,dfp:{targeting:{placement:"dfp_rs_"+e+"_overlay_oop_1",oop:"overlay"}}}].concat(n.i(d.b)(t,e),n.i(d.a)(t,e),"desktop"===e?[{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"skin",preempt:!0,dfp:{targeting:{placement:"dfp_rs_desktop_skin_oop_1",format:"roadblock",oop:"skin"}}},{eventID:n.i(r.a)(),type:"create",mode:"oop",name:"outstream",preempt:!0,dfp:{targeting:{placement:"dfp_rs_desktop_outstream_oop_1",format:"roadblock",oop:"outstream"}}}]:[]))}),incremental$:f.f?(x=(x=y.a.call(S,"viewed"),i.delay).call(x,500),a.mergeMap).call(x,function(t,e){return n.i(u.of)({eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-mpu"+e,width:300,height:250,score:.4,dfp:{sizes:[[250,[300,250],[300,251]]],targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2",format:"roadblock"}}},{eventID:n.i(r.a)(),type:"create",mode:"slotify",name:"incr-dbl-mpu"+e,width:300,height:600,score:.7,dfp:{sizes:[[250,[300,250],[300,251]],[600,[300,600],[300,601]]],targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2",format:"roadblock"}}})}):n.i(l.never)(),slot$:n.i(l.never)(),feature$:A}}}},function(t,e,n){"use strict"
var r=n(13),i=(n.n(r),n(53))
n.n(i)
e.a=function(t){return function(){return{preemptive$:n.i(i.empty)(),incremental$:n.i(r.never)(),slot$:n.i(r.never)()}}}},function(t,e,n){"use strict";(function(t){var r=n(41),i=function(e){e._dfpConfig,e._vanAdsConfig
return function(e){var n=e.type,r=e.content,i=e.site,o=e.device
if(n=t.env.MACRO_TYPE||n,r=t.env.MACRO_CONTENT||r,i=t.env.MACRO_SITE||i,"no-inbody-ads"===n){if("deals"===r)return"none"
switch(o){case"desktop":case"tablet":return"n-format"
case"mobile":return"mobile"}}if("listing"===n){if("deals"===r)return"none"
if("unknown"===r||"hub"===r||"cheats"===r||"pro"===r)switch(o){case"desktop":case"tablet":return"n-format"
case"mobile":return"mobile"}}if("no-sidebar"===n){if("deals"===r)return"none"
if("unknown"===r)switch(o){case"desktop":case"tablet":return"leaderboard-skin"
case"mobile":return"mobile"}}if("standard"===n||"review"===n){if("deals"===r)return"none"
if("unknown"===r)switch(o){case"desktop":case"tablet":return"n-format"
case"mobile":return"mobile-article"}}if("gallery"===n){if("deals"===r)return"none"
switch(o){case"desktop":case"tablet":return"n-format"
case"mobile":return"mobile-gallery"}}if("homepage"===n&&"unknown"===r)switch(o){case"desktop":case"tablet":return"t3"===i||"musicradar"===i?"n-format":"impact"
case"mobile":return"mobile"}}}
e.a=function(t){return function(e){return r.d||i(t)(e)}}}).call(e,n(19))},function(t,e,n){"use strict"
var r=n(49),i=n(2)
n.n(i)
e.a=i.Observable.create(function(t){n.i(r.a)(t,"gallery")})},function(t,e,n){"use strict"
var r=n(15),i=n(239),o=void 0
window.bordeauxAds=new Promise(function(t){o=t}),e.a=function(t){function e(){var e={STATIC:"STATIC",BORDEAUX:"BORDEAUX"},o=e.STATIC
switch(r.a&&(o=e.BORDEAUX),o){case e.BORDEAUX:return n.i(i.a)(t)
default:return Promise.resolve(!1)}}e().catch(function(t){return console.error("Exception thrown attempting Bordeaux - not falling back to fixed ads layout:","\nname:",t.name,"\nmessage:",t.message,"\nError:\n",t),t.stack?console.error("Stack trace:\n",t.stack):console.error("No stack trace"),!0}).then(o)}},function(t,e,n){"use strict"
function r(t,e){return t.raw=e,t}function i(t){A.a.checkLocalStorage()
var e=n.i(C.a)(window),r=function(){return document.querySelector("article.review-article")?document.querySelector("article.review-article").textContent.length:document.querySelector("article.news-article")?document.querySelector("article.news-article").textContent.length:0},i=void 0
i=r()>11e3?"hopscotch-long":"hopscotch-short",window.indexExchangeDeviceType=R.device,"mobile"===R.device&&(i="sticky-mobile")
var o=new x.ReplaySubject(1),a=t.catch(function(){}).then(m.a),c=function(){return"/"===window.dfp_config.ad_unit.substring(window.dfp_config.ad_unit.length-1)?(console.warn("DFP issue: missing ad unit. Replacing with default: /article "),window.dfp_config.ad_unit+"article"):window.dfp_config.ad_unit}()
A.a.request(c,Date.now(),i),t.then(function(t){window.addEventListener("unload",function(){A.a.sendData(A.a.formatForGA(t.getPageViewed()),i)})})
var b=function(t,e,n){for(var r=arguments.length,i=Array(r>3?r-3:0),o=3;o<r;o++)i[o-3]=arguments[o]
try{var a=n.apply(void 0,i)
window.setTimeout(t,0,a)}catch(t){e(t)}},D=function(t){for(var e=arguments.length,n=Array(e>1?e-1:0),r=1;r<e;r++)n[r-1]=arguments[r]
return new Promise(function(e,r){var i;(i=window).setTimeout.apply(i,[b,0,e,r,t].concat(n))})},M=function(t){return function(e){return new Promise(function(n,r){window.setTimeout(b,0,n,r,t,e)})}},L=D(s.a,window.dfp_config,i,window.location.hostname),z=function(){return t.then(function(t){return A.a.finishMetrics(function(){return A.a.formatForGA(t.getPageViewed())},i)})},B=Promise.all([w.b.then(function(){return new Promise(function(t){return n.e(0).then(function(){return t(n(196))}.bind(null,n)).catch(n.oe)})}).catch(function(t){throw console.error("import('./debug/setup.jsx')",t),t}),L]).then(function(t){var e=t[0],n=t[1]
return e.default(R,c,w.c,n,z)})
return B.then(function(t){return t.layout(n.i(p.a)(R))}),B.then(function(t){return t.format(n.i(T.a)({dfpConfig:window.dfp_config,vanAdsConfig:window.vanAdsConfig})(R))}),Promise.all([L,Promise.all([a,n.i(p.b)(R)])]).then(function(r){var i,a=r[0],s=r[1],f=s[0],d=s[1],p=d.slots,m=d.getAffinities,b=d.name,_=void 0,x=new Promise(function(t){_=t}),S={type:"create-slot-with-hooks",data:p},I=w.d?function(){return O.delay.call(this,w.c)}:function(){return this}
g()(void 0!==p&&null!==p,"Slots must not be undefined or null: "+p)
var k=n.i(h.a)(e)(f,x,t,a,c)((i=I.call(o),E.observeOn).call(i,j.asap))
return D(function(){var t,r=n.i(u.a)(e)({dfpConfig:window.dfp_config,vanAdsConfig:window.vanAdsConfig})(R)(b)(m)(S)({adverts:(t=(t=k.sink,I).call(t),E.observeOn).call(t,j.asap),legacyAds:(t=I.call(v.a),E.observeOn).call(t,j.asap),gallery:(t=I.call(y.a),E.observeOn).call(t,j.asap)})
return r.error$.subscribe(function(t){return console.error(l()(N,t.name,t.message,t.stack))},function(t){return console.error("Error in appSinks.error$ stream",t)},function(){return console.warn("appSinks.error$ stream completed")}),k.error$.subscribe(function(t){return console.error("::Bordeaux driver error:",t)},function(t){return console.error("Error in driverSinks.error$ stream",t)},function(){return console.warn("driverSinks.error$ stream completed")}),{appSinks:r,initResolve:_,driverSinks:k}})}).then(M(function(t){var e,r=t.appSinks,i=t.driverSinks,a=t.initResolve
return n.i(P.merge)(r.adverts,r.slot$,r.scripts).subscribe(o,function(t){return console.error("Error in appSink to proxy stream",t)},function(){return console.warn("appSinks to proxy stream completed")}),window.advertsDebugFilter=function(t){var e
return(e=(e=r.advertsDebug,I.filter).call(e,t),k.first).call(e)},window.advertsDebug=(e=r.advertsDebug,k.first).call(e),window.resolveBordeauxDone(),B.then(function(t){var e
return t.success(o,r.advertsDebug,i.sink,n.i(P.merge)((e=_.of.apply(void 0,window.preallocatorErrors&&window.preallocatorErrors.length>=0?window.preallocatorErrors:[new Error("no window.preallocatorErrors!")]),S.map).call(e,function(t){return{label:"Preallocator",error:t}}),(e=i.error$,S.map).call(e,function(t){return{label:"From driver",error:t}}),window.preallocatorFallback?n.i(_.of)({label:"Preallocator",error:new Error("Fallback used")}):n.i(d.empty)()),A.a.state$()||n.i(f.never)(),r.features)}).catch(function(t){return console.error("Exception when setting up debug UI",t)}),a(),!0})).catch(function(t){throw B.then(function(e){return e.error(t)}),t})}var o=n(297),a=(n.n(o),n(202)),s=(n.n(a),n(241)),u=n(208),c=n(51),l=n.n(c),f=n(13),d=(n.n(f),n(53)),p=(n.n(d),n(259)),h=n(222),v=n(217),y=n(237),m=n(281),b=n(76),g=n.n(b),w=n(15),_=n(28),x=(n.n(_),n(24)),S=(n.n(x),n(8)),I=(n.n(S),n(7)),O=(n.n(I),n(26)),k=(n.n(O),n(17)),E=(n.n(k),n(65)),j=(n.n(E),n(321)),P=(n.n(j),n(23)),D=(n.n(P),n(109)),A=n(103),T=n(106),C=n(107)
e.a=i
var N=r(["\n          ::Bordeaux app error:\n          Name: ","\n          Message: ","\n          Stack: ","\n          "],["\n          ::Bordeaux app error:\n          Name: ","\n          Message: ","\n          Stack: ","\n          "]),R=n.i(D.a)()},function(t,e,n){"use strict"
function r(t){b=t,x.next(b)}function i(t){m=t,S.next(m)}function o(t,e,n){if(console.log("loaded index",n),!m[n]){var r={"Ad Name":t.name,AdDescription:t.size[0]+"x"+t.size[1],LineItemID:t.lineItem,CreativeID:t.creative,AdLoadTime:e-g,AdTimeOnScreen:0,AdViewed:0,DFPViewed:0},o=[].concat(m)
o[n]=r,i(o),_++}}function a(t,e,i){var o=function(t){var e=""+document.cookie,n=e.split(t+"=")
return 2===n.length?n.pop().split("").shift():null}
g=e,r({Mode:i,AdTestName:"",ArticleID:"",GACookieID:o("_ga"),DFPKeywords:"",DFPAdUnit:t,NumberAds:"",PageViewed:0,TimeOnPage:0,SincePageLoad:n.i(p.a)(window)})
var a=window.setInterval(function(){var t=Object.assign({},b)
window.analytics_ga_data&&window.analytics_ga_data.dimension5?t.ArticleID=window.analytics_ga_data.dimension5:t.ArticleID="",r(t)},1e3)
window.setTimeout(function(t){window.clearInterval(a)},5e3)}function s(t){console.log("viewed index",t)
var e=[].concat(m)
e[t].DFPViewed=1,i(e)}function u(t,e,n){if(m[n]){var r=[].concat(m)
e.coverage>=.5&&(r[n].AdTimeOnScreen+=e.interval),r[n].AdViewed=Math.max(e.coverage,r[n].AdViewed),S.next(r)}}function c(t){var e=Object.assign({},b),n=null
window.performance&&window.performance.timing&&window.performance.timing.navigationStart&&(n=Date.now()-window.performance.timing.navigationStart),e.NumberAds=""+_,e.TimeOnPage=n,e.PageViewed=Math.min(100,Math.floor(100*t)),r(e)
var i=["dimension68","dimension71","dimension77","dimension78","dimension79"],o=["dimension69","dimension80","dimension81","dimension82","dimension83"],a=["dimension70","dimension84","dimension85","dimension86","dimension87"],s=["metric2","metric3","metric4","metric5","metric6"],u=["metric7","metric8","metric9","metric10","metric11"],c=["metric12","metric13","metric14","metric15","metric16"],l=["metric19","metric20","metric21","metric22","metric23"],f={dimension88:e.Mode,dimension89:e.AdTestName,dimension5:e.ArticleID,dimension59:e.GACookieID,dimension34:e.DFPKeywords,dimension4:e.DFPAdUnit,dimension64:e.NumberAds,metric17:e.PageViewed,metric18:e.TimeOnPage,metric1:e.SincePageLoad},d={}
return i.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=""+m[e].AdDescription)}),o.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=""+m[e].LineItemID)}),a.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=""+m[e].CreativeID)}),s.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=m[e].AdLoadTime)}),u.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=m[e].AdTimeOnScreen)}),c.forEach(function(t,e){if(void 0!==m[e]){if(m[e].AdViewed>1)throw new Error("Ad Viewed metric over 1.0!")
d[t]=100*(m[e].AdViewed||0)|0}}),l.forEach(function(t,e){void 0!==m[e]&&null!==m[e]&&(d[t]=0|m[e].DFPViewed)}),Object.assign(d,f),d}function l(t,e){try{if(window.navigator.sendBeacon)window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: Sending ad metrics to GA using transport: beacon",JSON.stringify(t)),window.ga("send","event","Ad","Detail",e,Object.assign({},t,{transport:"beacon",nonInteraction:!0}))
else{window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: transport: beacon not supported, storing ad metrics in local storage",JSON.stringify(t))
var n={timestamp:Date.now(),mode:e}
window.localStorage.setItem(w,JSON.stringify({data:t,metadata:n}))}}catch(t){console.log("Exception when sending ad metrics to GA",t)}}function f(){try{var t=3,e=Date.now()-24*t*60*60*1e3,n=JSON.parse(window.localStorage.getItem(w))
n&&n.metadata.timestamp>e?(window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: Sending ad metrics from local storage",n),window.ga("send","event","Ad","Detail",n.metadata.mode,Object.assign({},n.data,{nonInteraction:!0})),window.localStorage.removeItem(w)):window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: No ad metrics from local storage to send")}catch(t){console.log("Exception when checking local storage for ad metrics",t)}}function d(t){var e=t()
I.next(e)}Object.defineProperty(e,"__esModule",{value:!0})
var p=n(118),h=n(24),v=(n.n(h),n(68)),y=(n.n(v),n(69))
n.n(y)
n.d(e,"state$",function(){return k}),e.setGeneral=r,e.setMetrics=i,e.loaded=o,e.request=a,e.viewed=s,e.view=u,e.formatForGA=c,e.sendData=l,e.checkLocalStorage=f,e.finishMetrics=d
var m=[],b={},g=Date.now(),w="ad-metrics",_=0,x=new h.ReplaySubject(1),S=new h.ReplaySubject(1),I=new h.ReplaySubject(1),O=n.i(v.combineLatest)(y.startWith.call(x,void 0),y.startWith.call(S,void 0),y.startWith.call(I,void 0),function(t,e,n){return{general:t,metrics:e,debugMetrics:n}}).catch(function(t){return console.log("Error Debugging Metrics",t)}),k=function(){return O}},function(t,e,n){"use strict"
function r(t){if(void 0===t)throw new Error("Width should not be undefined")
var e={small:{min:0,max:1279},large:{min:1280,max:12e3}},n=t,r="small"
if(!e)return r
for(var i in e)if(e.hasOwnProperty(i)&&n>=e[i].min&&n<=e[i].max)return i
return r}function i(t){if("object"===(void 0===t?"undefined":d(t))){var e=[]
for(var n in t)if(t.hasOwnProperty(n)){var r=t[n]
r=r.replace(/[#*()+\-='",<>\{\}\[\]\\\/]/gi,""),e.push(r)}return e}return t.replace(/[#*()+\-='",<>\{\}\[\]\\\/]/gi,"")}function o(t){var e={fepPrimaryProduct:t.primaryProduct,fepSecondaryProducts:t.secondaryProducts,fepCompanies:t.companies,fepCategory:t.category,fepGroups:t.groups,fepPrimaryCompany:t.primaryCompany,primaryCategory:t.primaryCategory,secondaryCategories:t.secondaryCategories,tertiaryCategories:t.tertiaryCategories}
return Object.keys(e).reduce(function(t,n){var r=i(e[n])
return r.length>0&&(t[n]=r),t},{})}function a(t,e){return{pageskin_yes:Math.min(t,e)>=375?"true":"false"}}function s(t){var e=t.getItem("highImpact")||!1
return e||n.i(f.a)(t)("highImpact",!0),{highImpact:e?"true":"false"}}function u(){try{return window.Krux||((window.Krux=function(){Krux.q.push(arguments)}).q=[]),function(){function t(t){var e,n="kx"+t
return window.localStorage?window.localStorage[n]||"":navigator.cookieEnabled?(e=document.cookie.match(n+"=([^;]*)"))&&unescape(e[1])||"":""}Krux.user=t("user"),Krux.segments=t("segs")?t("segs").split(","):[]
var e=[]
Krux.user&&(e.push("khost="+encodeURIComponent(location.hostname)),e.push("kuid="+Krux.user))
for(var n=0;n<Krux.segments.length;n++)e.push("ksg="+Krux.segments[n])
Krux.dfppKeyValues=e.length?e.join(";")+";":""}(),{kuid:Krux.user}}catch(t){console.error(t)}return{}}function c(t,e,i){var c=t.keywords.split(","),f=t.vertical.split(",")
return Object.assign({url:window.location.href,test:Math.random()>=.5?"A":"B",screen:r(window.screen.width),kw:c,brand:t.brand,genre:t.genre,games:t.games,platform:t.platform,articleid:t.article_id,manu:t.product_brand,pagetype:t.page_type?t.page_type.replace(",","-"):"",vertical:f,provertical:t.provertical,highImpact:s?"true":"false",hopscotch:"true",sitePlatform:"vanilla",hostname:i,mode:e},a(window.screen.width,window.screen.height),s(window.sessionStorage),o(n.i(l.a)(window.FEP_object)),u())}var l=n(228),f=n(282)
e.a=c
var d="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t}},function(t,e,n){"use strict"
function r(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function i(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function o(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e)
t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}function a(t){return this.lift(new c(t))}var s=n(1)
n.n(s)
e.a=a
var u=function(t){function e(n){var o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:function(t,e){return[t,e]}
r(this,e)
var a=i(this,t.call(this,n))
return a.hasPrev=!1,a.selector=o,a}return o(e,t),e.prototype._next=function(t){this.hasPrev?this.destination.next(this.selector(this.prev,t)):this.hasPrev=!0,this.prev=t},e}(s.Subscriber),c=function(){function t(e){r(this,t),this.selector=e}return t.prototype.call=function(t,e){return e._subscribe(new u(t,this.selector))},t}()},function(t,e,n){"use strict"
function r(t,e,n){for(var r=e+":",i=t.createElement("test"),o=i.style,a=0;a<n.length;a++)o.cssText=r+n.join(";"+r)+";"
return o[e]}e.a=r},function(t,e,n){"use strict"
e.a=function(t,e){return void 0===e||null===e?t:e}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i})
var r=function(t,e){return function(){var n=e()
t.width=0|n.width,t.height=(0|n.height)-2}},i=function(t){return function(){if(null!==t.nextElementSibling&&void 0!==t.nextElementSibling){if(t.nextElementSibling.className.indexOf("listingResult")>-1)return t.nextElementSibling.getBoundingClientRect()
if(-1===t.nextElementSibling.className.indexOf("listingResult"))for(var e=0;e<5;e++)if(t=t.nextElementSibling,t.nextElementSibling&&t.nextElementSibling.className.indexOf("listingResult")>=0)return t.nextElementSibling.getBoundingClientRect()}if(null!==t.previousElementSibling&&void 0!==t.previousElementSibling)return t.previousElementSibling.getBoundingClientRect()
throw new Error("No element to get bounds on")}}},function(t,e,n){"use strict"
var r=n(26),i=(n.n(r),n(7)),o=(n.n(i),n(17)),a=(n.n(o),n(6))
e.a=function(t){return function(e){return function(n){return function(s){var u
return(u=(u=(u=a.a.call(s,t),i.filter).call(u,e),o.first).call(u),r.delay).call(u,n)}}}}},function(t,e,n){"use strict"
var r=1e3,i=function(t){return/(iphone|ipod|ipad).* os 9_/.test(t.navigator.userAgent.toLowerCase())}
e.a=function(){var t=i(window)?window.document.documentElement.clientWidth:window.innerWidth,e="mobile"
return t>=700&&t<r?e="tablet":t>=r&&(e="desktop"),e}},function(t,e,n){"use strict"
var r=n(41)
e.a=function(){return(r.f||(window.document.querySelector("meta[name=geo_locale]")||{content:""}).content||"GB").toUpperCase()}},function(t,e,n){"use strict"
var r=n(0),i=n(18),o=n(12)
n.d(e,"a",function(){return s})
var a=function(){return[i.a,i.b,i.c,i.d]},s=function(t){return{slots:[].concat(n.i(r.a)(a()),n.i(o.a)()),getAffinities:function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,sponsored1:o.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:o.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:o.find(function(t){return"sponsored3"===t.data.slotify.name})}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(18),o=n(110),a=n(12)
n.d(e,"a",function(){return c})
var s=function(){return[i.a,i.b,i.c,i.d]},u=["GB","US","CA","AU","NZ"],c=function(t){var e=t.site,c=t.locale,l=[].concat(n.i(r.a)(s()),n.i(o.a)(e,"#article-body p",u.includes(c)),n.i(a.a)())
return n.i(i.e)(window),window.document.querySelector("#content-after-image section")&&(window.document.querySelector("#content-after-image section").style.overflow="visible"),document.querySelector("article.news-article section")&&(window.document.querySelector("article.news-article section").style.overflow="visible"),{slots:l,getAffinities:function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,sponsored1:o.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:o.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:o.find(function(t){return"sponsored3"===t.data.slotify.name})}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(18),o=n(110)
n.d(e,"a",function(){return u})
var a=function(){return[i.a,i.b,i.c,i.d]},s=["GB","US","CA","AU","NZ"],u=function(t){var e=t.site,u=t.locale
return n.i(i.e)(window),{slots:[].concat(n.i(r.a)(a()),n.i(o.a)(e,".cheatcategory p",s.includes(u))),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(18)
n.d(e,"a",function(){return a})
var o=function(){return[i.a,i.b,i.c,i.d]},a=function(){return{slots:[].concat(n.i(r.a)(o())),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(18),o=n(30)
n.d(e,"a",function(){return s})
var a=function(){return[i.a,i.b,i.c,i.d]},s=function(){var t=n.i(o.a)(window.document,".listingResult")[1],e=function(){return{type:"JUST_INLINE",margin:"0px 0px 0px 0px"}},i=[{slotify:{name:"ukSponsored",hook:t,whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1},{slotify:{name:"ukSponsored2",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1},{slotify:{name:"ukSponsored3",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1}]
return{slots:[].concat(n.i(r.a)(a()),i),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3],ukSponsored1:t[4],ukSponsored2:t[5],ukSponsored3:t[6]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(258),o=n(12)
n.d(e,"a",function(){return s})
var a=function(){return[i.a,i.b,i.c]},s=function(){return{slots:[].concat(n.i(r.a)(a()),n.i(o.a)()),getAffinities:function(t){return{lightbox1:t[0],lightbox2:t[1],lightbox3:t[2],sponsored1:t[3],sponsored2:t[4],sponsored3:t[5]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(30),o=n(18),a=n(12),s=n(113)
n.d(e,"a",function(){return c})
var u=function(){return[o.a,o.b,o.c,o.d]},c=function(t){var e=t.site,o={slotify:{name:"ukSponsored",hook:n.i(i.a)(window.document,".listingResult")[1],whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0},boilerplate:!1},c={slotify:{name:"ukSponsored2",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0},boilerplate:!1},l=[o,c].filter(function(t){return t.slotify.hook}),f=n.i(s.a)(e)
return{slots:[].concat(n.i(r.a)(u()),f?l:n.i(a.a)()),getAffinities:function(t){return t?function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3],ukSponsored1:t[4],ukSponsored2:t[5]}}:function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,sponsored1:o.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:o.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:o.find(function(t){return"sponsored3"===t.data.slotify.name})}}}(f)}}},function(t,e,n){"use strict"
var r=n(0),i=n(18)
n.d(e,"a",function(){return a})
var o=function(){return[i.a,i.b,i.c,i.d]},a=function(t){return{slots:[].concat(n.i(r.a)(o())),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(18)
n.d(e,"a",function(){return a})
var o=function(){return[i.a]},a=function(t){return{slots:[].concat(n.i(r.a)(o())),getAffinities:function(t){return{leaderboard:t[0]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i}),n.d(e,"b",function(){return o}),n.d(e,"c",function(){return a})
var i={slotify:{name:"lightbox1",type:r.b,position:r.j,align:r.d,width:r.s,height:r.t,fixed:!0,preactivated:!0},hook:n.i(r.h)(".dfp-leaderboard-container"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}},o={slotify:{name:"lightbox2",type:r.b,position:r.j,align:r.d,width:r.s,height:r.t,fixed:!0,preactivated:!0},hook:n.i(r.h)(".impact .lightbox2"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px",marginLeft:"-24px"}},a={slotify:{name:"lightbox3",type:r.b,position:r.c,align:r.d,width:r.s,height:r.t,fixed:!0,preactivated:!0},hook:n.i(r.h)(".impact .lightbox3"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px",marginLeft:"-24px"}}},function(t,e,n){"use strict"
function r(t){if(T[t])return T[t]
throw Object.keys(T).indexOf(t)>=0?new Error("Layout key for '"+t+"' exists but is undefined- probably a bug in the layouts mapping or the layout module for "+t+" itself"):new Error("No layout found that matches '"+t+"', options are:"+Object.keys(T).join(", "))}function i(t,e){function n(n){this.name=e.name,this.message=n,this.layout=t,this.stack=e.stack}return console.log("layout: creating MyError",t,e),n.prototype=e,n}var o=n(254),a=n(253),s=n(250),u=n(249),c=n(255),l=n(252),f=n(257),d=n(251),p=n(256),h=n(274),v=n(273),y=n(270),m=n(275),b=n(272),g=n(277),w=n(271),_=n(276),x=n(263),S=n(260),I=n(264),O=n(262),k=n(261),E=n(265),j=n(267),P=n(73),D=n(268)
n.d(e,"a",function(){return A}),n.d(e,"b",function(){return N})
var A=D.a,T={none:j.a,desktopImpact:o.a,desktopHomepage:a.a,desktopArticle:s.a,desktopArticleNix:u.a,desktopListing:c.a,desktopGallery:l.a,desktopNoSidebar:f.a,desktopCheats:d.a,desktopNoInbody:p.a,tabletImpact:h.a,tabletHomepage:v.a,tabletArticle:y.a,tabletListing:m.a,tabletGallery:b.a,tabletNoSidebar:g.a,tabletCheats:w.a,tabletNoInbody:_.a,mobileHomepage:x.a,mobileArticle:S.a,mobileListing:I.a,mobileGallery:O.a,mobileCheats:k.a,mobileNoInbody:E.a},C=function(t,e,i){var o=r(n.i(P.a)(t))(e),a=o.slots,s=o.getAffinities
a.forEach(function(t){if(void 0===t.slotify)throw new Error("Slot "+JSON.stringify(t)+" has no 'slotify' key}")
if(void 0===t.slotify.hook)throw new Error("Slot "+t.slotify.name+" has no hook, "+JSON.stringify(t))}),i({slots:a,getAffinities:s,name:t})},N=function(t){return Promise.resolve(window.reliableDOMContentLoaded).then(function(){return new Promise(function(e,n){var r=A(t)
if(!r)throw new Error("No layout found for parameters: "+JSON.stringify(t,null,2))
window.requestAnimationFrame(function(){try{C(r,t,e)}catch(t){var o=i(r,t)
n(new o("(layout is "+r+") "+t.name+": "+t.message))}})})})}},function(t,e,n){"use strict"
var r=n(0),i=n(112),o=n(12),a=n(111)
n.d(e,"a",function(){return u})
var s=function(){return[i.a,i.b]},u=function(t){return{slots:[].concat(n.i(r.a)(s()),n.i(a.a)(t,"#article-body p"),n.i(o.a)()),getAffinities:function(t){var e=t[0],n=t[1],r=t.slice(2)
return{mpu1:e,mpu2:n,sponsored1:r.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:r.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:r.find(function(t){return"sponsored3"===t.data.slotify.name})}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(111)
n.d(e,"a",function(){return a})
var o=function(){return[{slotify:{name:"mpu1",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)(".cheatcategory"),backgroundColor:r.i,boilerplate:!0,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}},{slotify:{name:"mpu2",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#content"),backgroundColor:r.i,boilerplate:!0,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}}]},a=function(t){return{slots:[].concat(n.i(r.a)(o()),n.i(i.a)(t,".cheatcategory p")),getAffinities:function(t){return{mpu1:t[0],mpu2:t[1]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return o})
var i=function(){return[{slotify:{name:"mpu1",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#gallery-body p:not(:empty)"),backgroundColor:r.i,boilerplate:!0,style:{"@media (max-width: 340px)":{marginLeft:"-10px",marginRight:"-10px"},marginBottom:"20px",clear:"both"}}]},o=function(){return{slots:[].concat(n.i(r.a)(i())),getAffinities:function(t){return{mpu1:t[0]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(266),o=n(12)
n.d(e,"a",function(){return s})
var a=function(){return[i.a]},s=function(t){var e=t.site,i=function(t){return"t3"===t||"pcgamer"===t||"musicradar"===t?{mpu2:{hook:document.querySelector(".list-bottom-links"),position:r.j}}:{mpu2:{hook:document.querySelector(".impact .listingResultsWrapper:nth-of-type(2)"),position:r.c}}}(e),s={slotify:{name:"mpu2",type:r.b,hook:i.mpu2.hook,position:i.mpu2.position,align:r.d,width:r.e,height:r.f+r.g,preactivated:!0},boilerplate:!0,style:{marginTop:"10px"}}
return{slots:[].concat(n.i(r.a)(a()),[s],n.i(o.a)()),getAffinities:function(t){return{mpu1:t[0],mpu2:t[1],sponsored1:t[2],sponsored2:t[3],sponsored3:t[4]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(12)
n.d(e,"a",function(){return a})
var o=function(){return[{slotify:{name:"mpu1",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)(".listingResult.small.result3"),backgroundColor:r.i,boilerplate:!0,style:{marginTop:"20px"}},{slotify:{name:"mpu2",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:function(){return window.document.querySelectorAll(".listingResult")[8]},backgroundColor:r.i,boilerplate:!0,style:{marginTop:"20px"}}]},a=function(){return{slots:[].concat(n.i(r.a)(o()),n.i(i.a)()),getAffinities:function(t){var e=t[0],n=t[1],r=t.slice(2)
return{mpu1:e,mpu2:n,sponsored1:r.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:r.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:r.find(function(t){return"sponsored3"===t.data.slotify.name})}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(112)
n.d(e,"a",function(){return a})
var o=function(){return[i.a,i.b]},a=function(t){return{slots:[].concat(n.i(r.a)(o())),getAffinities:function(t){return{mpu1:t[0],mpu2:t[1]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i})
var i={slotify:{name:"mpu1",type:r.b,position:r.j,align:r.d,width:r.e,height:r.f+r.g,preactivated:!0},hook:n.i(r.h)(".feature-block"),boilerplate:!0,style:{marginBottom:"20px"}}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=function(){return{slots:[],getAffinities:function(){return{}}}}},function(t,e,n){"use strict"
var r=n(41),i=n(269)
e.a=function(t){return r.e||n.i(i.a)(t)}},function(t,e,n){"use strict";(function(t){function n(e){var n=e.type,r=e.content,i=e.device,o=e.site
if(n=t.env.MACRO_TYPE||n,r=t.env.MACRO_CONTENT||r,"t3baby"===(o=t.env.MACRO_SITE||o))return"none"
if(("cheats"!==r||"listing"===n&&"gamesradar"===o)&&("deals"!==r||"standard"===n||"review"===n||"no-sidebar"===n)&&("pro"!==r||"listing"===n&&"techradar"===o)){if("no-inbody-ads"===n){if("deals"===r)return"none"
switch(i){case"desktop":return"desktop-no-inbody"
case"tablet":return"tablet-no-inbody"
case"mobile":return"mobile-no-inbody"}}if("listing"===n){if("deals"===r)return"none"
if("unknown"===r||"hub"===r||"pro"===r)switch(i){case"desktop":return"desktop-listing"
case"tablet":return"tablet-listing"
case"mobile":return"mobile-listing"}else if("gamesradar"===o&&"cheats"===r)switch(i){case"desktop":return"desktop-cheats"
case"tablet":return"tablet-cheats"
case"mobile":return"mobile-cheats"}}if("no-sidebar"===n){if("deals"===r)return"none"
if("unknown"===r)switch(i){case"desktop":return"desktop-no-sidebar"
case"tablet":return"tablet-no-sidebar"
case"mobile":return"mobile-article"}}if("standard"===n||"review"===n){if("deals"===r)return"none"
if("unknown"===r)switch(i){case"desktop":return"t3"===o?"desktop-article-nix":"desktop-article"
case"tablet":return"tablet-article"
case"mobile":return"mobile-article"}}if("gallery"===n){if("deals"===r)return"none"
switch(i){case"desktop":return"desktop-gallery"
case"tablet":return"tablet-gallery"
case"mobile":return"mobile-gallery"}}if("homepage"===n&&"unknown"===r)switch(i){case"desktop":return"t3"===o||"musicradar"===o?"desktop-homepage":"desktop-impact"
case"tablet":return"t3"===o||"musicradar"===o?"tablet-homepage":"tablet-impact"
case"mobile":return"mobile-homepage"}}}e.a=n}).call(e,n(19))},function(t,e,n){"use strict"
var r=n(0),i=n(36),o=n(114),a=n(12)
n.d(e,"a",function(){return u})
var s=function(){return[i.a,i.b,i.c,i.d]},u=function(t){var e=t.site,u=[].concat(n.i(r.a)(s()),n.i(o.a)(e,"#article-body p"),n.i(a.a)())
return n.i(i.e)(window),window.document.querySelector("#content-after-image section")&&(window.document.querySelector("#content-after-image section").style.overflow="visible"),document.querySelector("article.news-article section")&&(window.document.querySelector("article.news-article section").style.overflow="visible"),{slots:u,getAffinities:function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,sponsored1:o.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:o.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:o.find(function(t){return"sponsored3"===t.data.slotify.name})}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(36),o=n(114)
n.d(e,"a",function(){return s})
var a=function(){return[i.a,i.b,i.c,i.d]},s=function(t){var e=t.site,s=[].concat(n.i(r.a)(a()),n.i(o.a)(e,".cheatcategory p"))
return n.i(i.e)(window),{slots:s,getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return o})
var i=function(){return[{slotify:{name:"leaderboard",type:r.b,position:r.c,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)("#main"),boilerplate:!1},{slotify:{name:"top of sidebar",type:r.b,position:r.n,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar"),backgroundColor:r.i,boilerplate:!0},{slotify:{name:"before popular box",type:r.b,position:r.c,align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0},{slotify:{name:"after popular box",type:r.b,position:"after",align:r.d,width:r.e,height:r.f+r.g,fixed:!0,preactivated:!0},hook:n.i(r.h)("#sidebar .popular-box"),backgroundColor:r.i,boilerplate:!0}]},o=function(){var t=[].concat(n.i(r.a)(i()))
return window.document.querySelector("#sidebar")&&(window.document.querySelector("#sidebar").style.overflow="visible"),window.document.querySelector("#content-after-image section")&&(window.document.querySelector("#content-after-image section").style.overflow="visible"),document.querySelector("article.news-article section")&&(window.document.querySelector("article.news-article section").style.overflow="visible"),{slots:t,getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(30),o=n(36)
n.d(e,"a",function(){return s})
var a=function(){return[o.a,o.b,o.c,o.d]},s=function(){var t=n.i(i.a)(window.document,".listingResult")[1],e=function(){return{type:"JUST_INLINE",margin:"0px 0px 0px 0px"}},s=[{slotify:{name:"ukSponsored",hook:t,whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1},{slotify:{name:"ukSponsored2",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1},{slotify:{name:"ukSponsored3",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.b,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:e},boilerplate:!1}]
return n.i(o.e)(window),{slots:[].concat(n.i(r.a)(a()),s),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3],ukSponsored1:t[4],ukSponsored2:t[5],ukSponsored3:t[6]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(278),o=n(12)
n.d(e,"a",function(){return s})
var a=function(){return[i.a,i.b,i.c]},s=function(){return{slots:[].concat(n.i(r.a)(a()),n.i(o.a)()),getAffinities:function(t){return{lightbox1:t[0],lightbox2:t[1],lightbox3:t[2],sponsored1:t[3],sponsored2:t[4],sponsored3:t[5]}}}}},function(t,e,n){"use strict"
var r=n(0),i=n(12),o=n(113),a=n(30),s=n(36)
n.d(e,"a",function(){return c})
var u=function(){return[s.a]},c=function(t){var e=t.site,c=function(){return{type:"JUST_INLINE",margin:"0px 0px 0px 0px"}},l=n.i(a.a)(window.document,".listingResult")[3],f={slotify:{name:"ukSponsored",hook:l,whitelist:["sponsored-post"],type:r.r,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:c},boilerplate:!1},d={slotify:{name:"ukSponsored2",hook:document.querySelector(".listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),whitelist:["sponsored-post"],type:r.r,position:r.j,align:r.d,width:610,height:190,preactivated:!0,specifyInline:c},boilerplate:!1},p=[f,d].filter(function(t){return t.slotify.hook}),h=!1,v=function(){return h=!h,{type:"INLINE_RIGHT",margin:"0px 0px 0px 0px"}},y=function(){return v()},m=[{slotify:{name:"double-height-listingResult-small-result2",specifyInline:y,hook:document.querySelector(".listingResult.small.result2"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i},{slotify:{name:"double-height-listingResult-small-result6",specifyInline:y,hook:document.querySelector(".listingResult.small.result6"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i},{slotify:{name:"double-height-listingResult-small-result7",specifyInline:y,hook:document.querySelector(".listingResult.small.result7"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i},{slotify:{name:"double-height-listingResult-small-result8",specifyInline:y,hook:document.querySelector(".listingResult.small.result8"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i},{slotify:{name:"double-height-listingResult-small-result9",specifyInline:y,hook:document.querySelector(".listingResult.small.result9"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.m+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i},{slotify:{name:"double-height-listingResult-small-result10",specifyInline:y,hook:document.querySelector(".listingResult.small.result10"),type:r.r,position:r.c,align:r.d,width:r.e,height:r.f+r.g,preactivated:!1},boilerplate:!0,backgroundColor:r.i}]
n.i(s.e)(window)
var b=n.i(o.a)(e)
return{slots:[].concat(n.i(r.a)(u()),n.i(r.a)([s.b,s.c,s.d]),b?p:n.i(i.a)(),m),getAffinities:function(t){return t?function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,ukSponsored1:o.find(function(t){return"ukSponsored"===t.data.slotify.name}),ukSponsored2:o.find(function(t){return"ukSponsored2"===t.data.slotify.name})}}:function(t){var e=t[0],n=t[1],r=t[2],i=t[3],o=t.slice(4)
return{leaderboard:e,topOfSidebar:n,beforePopularBox:r,afterPopularBox:i,sponsored1:o.find(function(t){return"sponsored1"===t.data.slotify.name}),sponsored2:o.find(function(t){return"sponsored2"===t.data.slotify.name}),sponsored3:o.find(function(t){return"sponsored3"===t.data.slotify.name})}}}(b)}}},function(t,e,n){"use strict"
var r=n(0),i=n(36)
n.d(e,"a",function(){return a})
var o=function(){return[i.a,i.b,i.c,i.d]},a=function(t){return{slots:[].concat(n.i(r.a)(o())),getAffinities:function(t){return{leaderboard:t[0],topOfSidebar:t[1],beforePopularBox:t[2],afterPopularBox:t[3]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return o})
var i=function(){return[{slotify:{name:"leaderboard",type:r.b,position:r.c,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)("#main"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}}]},o=function(t){return{slots:[].concat(n.i(r.a)(i())),getAffinities:function(t){return{leaderboard:t[0]}}}}},function(t,e,n){"use strict"
var r=n(0)
n.d(e,"a",function(){return i}),n.d(e,"b",function(){return o}),n.d(e,"c",function(){return a})
var i={slotify:{name:"lightbox1",type:r.b,position:r.c,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)(".impact .lightbox1"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}},o={slotify:{name:"lightbox2",type:r.b,position:r.c,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)(".impact .lightbox2"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}},a={slotify:{name:"lightbox3",type:r.b,position:r.c,align:r.d,width:r.o,height:r.p,fixed:!0,preactivated:!0},hook:n.i(r.h)(".impact .lightbox3"),boilerplate:!1,style:{marginTop:"20px",marginBottom:"20px"}}},function(t,e,n){"use strict"
e.a=function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:64
window.document.hidden?setTimeout(t,e):window.requestAnimationFrame(t)}},function(t,e,n){"use strict"
function r(){var t=window.chrome,e=window.navigator,n=e.vendor,r=e.userAgent.indexOf("OPR")>-1,i=e.userAgent.indexOf("Edge")>-1
if(e.userAgent.match("CriOS"));else if(null!==t&&void 0!==t&&"Google Inc."===n&&!1===r&&!1===i)return!0
return!1}e.a=r},function(t,e,n){"use strict"
var r=n(290)
n(108).a.then(function(t){r.provideFeat(t)}),window.resolveSlotify&&window.resolveFEAT(r),window.slotify=Promise.resolve(r),e.a=function(){return Promise.resolve(r)}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r})
var r=function(t){return function(e,n){try{return t.setItem(e,n),!0}catch(t){return!1}}}},function(t,e,n){"use strict"
n.d(e,"a",function(){return a})
var r=/@media/g,i=7,o=function(t,e,n){var o
return e.match(r)?n.matchMedia(e.slice(i)).matches?a(t[e],n):{}:(o={},o[e]=t[e],o)},a=function(t,e){return Object.keys(t).reduce(function(n,r){return Object.assign({},n,o(t,r,e))},{})}},function(t,e,n){var r,i,o="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t}
!function(){function n(t){var e=void 0===t?"undefined":o(t)
if("object"==e){if(!t)return"null"
if(t instanceof Array)return"array"
if(t instanceof Object)return e
var n=Object.prototype.toString.call(t)
if("[object Window]"==n)return"object"
if("[object Array]"==n||"number"==typeof t.length&&void 0!==t.splice&&void 0!==t.propertyIsEnumerable&&!t.propertyIsEnumerable("splice"))return"array"
if("[object Function]"==n||void 0!==t.call&&void 0!==t.propertyIsEnumerable&&!t.propertyIsEnumerable("call"))return"function"}else if("function"==e&&void 0===t.call)return"object"
return e}function a(t){this.a=t}function s(t){this["@@transducer/reduced"]=!0,this["@@transducer/value"]=t}function u(t,e){this.b=t,this.a=e}function c(t,e){this.b=t,this.a=e}function l(t,e){this.b=t,this.a=e}function f(t,e){this.b=t,this.a=e}function d(t,e){this.b=-1,this.c=t,this.a=e}function p(t,e){this.b=t,this.a=e}function h(t,e){this.drop=!0,this.b=t,this.a=e}function v(t,e){this.j=t,this.b=e,this.a=[],this.c=w.NONE}function y(t,e){this.c=t,this.b=e,this.a=[]}function m(t,e){this.b=t,this.a=e}function b(t,e){this.b=-1,this.c=t,this.a=e}function g(t,e){this.b=t,this.a=e}var w={}
w.d="undefined"!=typeof Symbol?Symbol.iterator:"@@iterator",w.f=function(t){return"string"==typeof t},w.isArray=void 0!==Array.isArray?function(t){return Array.isArray(t)}:function(t){return"array"==n(t)},w.e=function(t){return"object"==n(t)},w.k=function(t){return t[w.d]||t.next},w.slice=function(t,e,n){return null==n?Array.prototype.slice.call(t,e):Array.prototype.slice.call(t,e,n)},w.complement=function(t){return function(e){return!t.apply(null,w.slice(arguments,0))}},a.prototype["@@transducer/init"]=function(){throw Error("init not implemented")},a.prototype["@@transducer/result"]=function(t){return t},a.prototype["@@transducer/step"]=function(t,e){return this.a(t,e)},w.wrap=function(t){return"function"==typeof t?new a(t):t},w.reduced=function(t){return new s(t)},w.isReduced=function(t){return t instanceof s||t&&t["@@transducer/reduced"]},w.ensureReduced=function(t){return w.isReduced(t)?t:w.reduced(t)},w.deref=function(t){return t["@@transducer/value"]},w.unreduced=function(t){return w.isReduced(t)?w.deref(t):t},w.identity=function(t){return t},w.comp=function(t){var e=arguments.length
if(2==e){var n=arguments[0],r=arguments[1]
return function(t){return n(r.apply(null,w.slice(arguments,0)))}}if(2<e)return w.reduce(w.comp,arguments[0],w.slice(arguments,1))},u.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},u.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},u.prototype["@@transducer/step"]=function(t,e){return this.a["@@transducer/step"](t,this.b(e))},w.map=function(t){return function(e){return new u(t,e)}},c.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},c.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},c.prototype["@@transducer/step"]=function(t,e){return this.b(e)?this.a["@@transducer/step"](t,e):t},w.filter=function(t){return function(e){return new c(t,e)}},w.remove=function(t){return w.filter(w.complement(t))},l.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},l.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},l.prototype["@@transducer/step"]=function(t,e){return t=0<this.b?this.a["@@transducer/step"](t,e):w.ensureReduced(t),this.b--,t},w.take=function(t){return function(e){return new l(t,e)}},f.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},f.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},f.prototype["@@transducer/step"]=function(t,e){return this.b(e)?this.a["@@transducer/step"](t,e):w.reduced(t)},w.takeWhile=function(t){return function(e){return new f(t,e)}},d.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},d.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},d.prototype["@@transducer/step"]=function(t,e){return this.b++,0==this.b%this.c?this.a["@@transducer/step"](t,e):t},w.takeNth=function(t){return function(e){return new d(t,e)}},p.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},p.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},p.prototype["@@transducer/step"]=function(t,e){return 0<this.b?(this.b--,t):this.a["@@transducer/step"](t,e)},w.drop=function(t){return function(e){return new p(t,e)}},h.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},h.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},h.prototype["@@transducer/step"]=function(t,e){return this.drop&&this.b(e)?t:(this.drop&&(this.drop=!1),this.a["@@transducer/step"](t,e))},w.dropWhile=function(t){return function(e){return new h(t,e)}},w.NONE={},v.prototype["@@transducer/init"]=function(){return this.b["@@transducer/init"]()},v.prototype["@@transducer/result"]=function(t){return 0<this.a.length&&(t=w.unreduced(this.b["@@transducer/step"](t,this.a)),this.a=[]),this.b["@@transducer/result"](t)},v.prototype["@@transducer/step"]=function(t,e){var n=this.c,r=this.j(e)
return this.c=r,n==w.NONE||n==r?(this.a.push(e),t):(n=this.b["@@transducer/step"](t,this.a),this.a=[],w.isReduced(n)||this.a.push(e),n)},w.partitionBy=function(t){return function(e){return new v(t,e)}},y.prototype["@@transducer/init"]=function(){return this.b["@@transducer/init"]()},y.prototype["@@transducer/result"]=function(t){return 0<this.a.length&&(t=w.unreduced(this.b["@@transducer/step"](t,this.a)),this.a=[]),this.b["@@transducer/result"](t)},y.prototype["@@transducer/step"]=function(t,e){if(this.a.push(e),this.c==this.a.length){var n=this.a
return this.a=[],this.b["@@transducer/step"](t,n)}return t},w.partitionAll=function(t){return function(e){return new y(t,e)}},m.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},m.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},m.prototype["@@transducer/step"]=function(t,e){return null==this.b(e)?t:this.a["@@transducer/step"](t,e)},w.keep=function(t){return function(e){return new m(t,e)}},b.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},b.prototype["@@transducer/result"]=function(t){return this.a["@@transducer/result"](t)},b.prototype["@@transducer/step"]=function(t,e){return this.b++,null==this.c(this.b,e)?t:this.a["@@transducer/step"](t,e)},w.keepIndexed=function(t){return function(e){return new b(t,e)}},w.n=function(t){return{"@@transducer/init":function(){return t["@@transducer/init"]()},"@@transducer/result":function(t){return t},"@@transducer/step":function(e,n){var r=t["@@transducer/step"](e,n)
return w.isReduced(r)?w.reduced(r):r}}},w.cat=function(t){var e=w.n(t)
return{"@@transducer/init":function(){return t["@@transducer/init"]()},"@@transducer/result":function(e){return t["@@transducer/result"](e)},"@@transducer/step":function(t,n){return w.reduce(e,t,n)}}},w.mapcat=function(t){return w.comp(w.map(t),w.cat)},w.p=function(t,e,n){for(var r=0;r<n.length;r++)if(e=t["@@transducer/step"](e,n.charAt(r)),w.isReduced(e)){e=w.deref(e)
break}return t["@@transducer/result"](e)},w.i=function(t,e,n){for(var r=0;r<n.length;r++)if(e=t["@@transducer/step"](e,n[r]),w.isReduced(e)){e=w.deref(e)
break}return t["@@transducer/result"](e)},w.m=function(t,e,n){for(var r in n)if(n.hasOwnProperty(r)&&(e=t["@@transducer/step"](e,[r,n[r]]),w.isReduced(e))){e=w.deref(e)
break}return t["@@transducer/result"](e)},w.l=function(t,e,n){n[w.d]&&(n=n[w.d]())
for(var r=n.next();!r.done;){if(e=t["@@transducer/step"](e,r.value),w.isReduced(e)){e=w.deref(e)
break}r=n.next()}return t["@@transducer/result"](e)},w.reduce=function(t,e,n){if(n){if(t="function"==typeof t?w.wrap(t):t,w.f(n))return w.p(t,e,n)
if(w.isArray(n))return w.i(t,e,n)
if(w.k(n))return w.l(t,e,n)
if(w.e(n))return w.m(t,e,n)
throw Error("Cannot reduce instance of "+n.constructor.name)}},w.transduce=function(t,e,n,r){if(3==arguments.length){if(r=n,"function"==typeof e)throw Error("If given only three arguments f must satisfy the ITransformer interface.")
n=e["@@transducer/init"]()}return e="function"==typeof e?w.wrap(e):e,t=t(e),w.reduce(t,n,r)},w.o=function(t,e){return t+e},w.h=function(t,e){return t.push(e),t},w.g=function(t,e){return t[e[0]]=e[1],t},w.into=function(t,e,n){return w.f(t)?w.transduce(e,w.o,t,n):w.isArray(t)?w.transduce(e,w.h,t,n):w.e(t)?w.transduce(e,w.g,t,n):void 0},g.prototype["@@transducer/init"]=function(){return this.a["@@transducer/init"]()},g.prototype["@@transducer/result"]=function(t){return this.b(t)},g.prototype["@@transducer/step"]=function(t,e){return this.a["@@transducer/step"](t,e)},w.completing=function(t,e){return t="function"==typeof t?w.wrap(t):t,e=e||w.identity,new g(e,t)},w.toFn=function(t,e){"function"==typeof e&&(e=w.wrap(e))
var n=t(e)
return n["@@transducer/step"].bind(n)},w.first=w.wrap(function(t,e){return w.reduced(e)}),w.q={},r=[],void 0!==(i=function(){return w}.apply(e,r))&&(t.exports=i)}()},function(t,e,n){"use strict"
function r(t,e,r,o,u,c){var l=t.el
e.anticipated?u?(a(t,e,r,o,c),n.i(s.a)(l,51,255,119)):e.proactive?a(t,e,r,o,c,!0):(n.i(s.a)(l,255,51,119),i(t,e,r,o,u,c)):i(t,e,r,o,u,c)}function i(t,e,n,r,i,o){if(i)throw new Error("no tiles should be invisible and active at the same time")
t.active&&(t.active=!1)}function o(t,e){return e>10?"polygon("+t+"px 0px, "+t+"px "+(e-.01)+"px, 0px "+(e-.01)+"px, 0px 0px)":null}function a(t,e,r,i,o){var a=arguments.length>5&&void 0!==arguments[5]&&arguments[5]
n.i(s.c)(t,e,r,i,o,"slotify-contents",v,y,m,a)}var s=n(121),u=n(74),c=n(50),l=n(286),f=n(32),d=n.n(f),p=n(344)
e.a=r
var h=!1,v=function(t,e,n,r,i,a){var s=e.el
Object.assign(s.style,p.a)
var l=void 0,f=void 0
if(d()(void 0!==n,"Slot must not be undefined"),d()(void 0!==n.type,"Slot "+n.name+" must not have an undefined type property"),"INLINE"===n.type){d()(n.specifyInline,"Slot "+n.name+" must have a property called specifyInline if type is INLINE")
var v=n.specifyInline(),y=v.type,m=v.margin
l=y,f=m,d()(void 0!==l,"Type property of result of slot function specifyInline must not be undefined"),d()(void 0!==f,"Margin property of result of slot function specifyInline must not be undefined")}else l=n.type,f=n.margin,d()(void 0!==l,"Type property of slot must not be undefined")
"INLINE_LEFT"===l||"INLINE_RIGHT"===l||"JUST_INLINE"===l?("INLINE_LEFT"!==l&&"INLINE_RIGHT"!==l||(s.style.float="INLINE_LEFT"===l?"left":"right"),s.style.margin=f,s.style.width=n.width+"px"):"INLINE"!==l&&(s.style.width="100%"),s.style.height="auto"
var b=t.style
if(Object.assign(t.style,p.b),n.fluid){b.width="100%",e.el.style.width="100%"
var g=n.onOccupy(s,i,n.width,n.height)
b.height="auto",e.height=g,e.width=n.width}else if(n.fixed){b.width=n.width+"px",e.el.style.width=n.width+"px"
var w=n.onOccupy(s,i,n.width,n.height)
b.height=w+"px",e.height=w,e.width=n.width}else{b.width=n.width+"px",e.el.style.width=n.width+"px"
var _=n.onOccupy(s,i,n.width,Math.min(i.height,n.height))
b.height=_+"px",e.height=_,e.width=n.width}if(c.a){var x=document.createElement("div")
x.innerHTML="\n    ?\n    ",x.className="slotify-debug",Object.assign(x.style,p.c),t.appendChild(x)}if(!r.mountPoint)if(i.hybrid){var S=document.createElement("div")
S.className="slotify-floatable",S.style.boxSizing="border-box",S.style.contain="style layout",S.style.pointerEvents="none"
var I=h&&o(e.width,e.height)
I&&(S.style.clipPath=I,S.style.webkitClipPath=I),t.appendChild(S),i.onMount(S,{resize:function(t,e){d()(void 0!=t&&void 0!=e,"Width and height of resize must not be null or undefined! Check onMount callback. width: "+t+", height: "+e),a.dispatch(u.l(i.id,t,e))}}),r.mountPoint=t,r.floatable=S}else i.floating},y=function(t,e,r,i,a,s){if(a.floating){var u=null
if(null===(u=a.hybrid?i.floatable:a.element())||void 0===u)throw new Error("TileEl is undefined or null",u)
if(u.style.position="relative",e.unsync=n.i(l.a)(t,u,i.mountPoint||null),i.floatable){var c=i.floatable,f=h&&o(e.width,e.height)
f&&(c.style.clipPath=f,c.style.webkitClipPath=f)}a.onActivate(r.id,e.el,r.width,r.height,{})}else t.appendChild(a.element())},m=function(t,e,n,r,i,o){if(i.shrinkwrapped&&(e.height||0)>i.height&&(t.style.height=i.height+"px",e.height=i.height,n.onResize(e.width,e.height,i)),(e.height||0)<i.height){var a=(i.width,i.height)
i.fluid||(t.style.height=a+"px"),e.height=a,n.onResize(e.width,e.height,i)}if(c.a){var s=t.querySelector(".slotify-debug")
e.debugListener&&s.removeEventListener("click",e.debugListener),e.debugListener=function(){console.log("Slot",JSON.stringify(n,null,4)),console.log("Reasons",JSON.stringify(n.acceptedReasons,null,4)),console.log("Tile",JSON.stringify(i,null,4)),console.log("DOMSlot",JSON.stringify(e,null,4)),console.log("DOMTile",JSON.stringify(r,null,4))},s.addEventListener("click",e.debugListener)}}},function(t,e,n){"use strict";(function(t){function t(){u.forEach(l)}function r(e,n){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,i=!0
if(void 0===n||null===n)throw new Error("synchrotron target is undefined")
if(void 0===e||null===e)throw new Error("synchrotron source is undefined")
if(u.has(n)){var o=u.get(n)
o.source,o.disable()}if(i){var a=function(t){u.has(n)&&u.get(n).source===e&&u.delete(n)}
return u.set(n,{source:e,target:n,mountPoint:r,posX:0,posY:0,disable:a,lastTime:0}),window.requestAnimationFrame(t),a}}var i=n(43),o=n.n(i),a=n(50),s=n(32)
n.n(s)
e.a=r
var u=o()(),c=3e3,l=function(t,e){var n=performance.now(),r=t.source,i=t.target,o=t.mountPoint,s=void 0===o?null:o,u=t.posX,l=t.posY,f=void 0===l?null:l,d=t.lastTime,p=void 0===d?0:d,h=r.getBoundingClientRect(),v=0|h.left,y=0|h.top,m=i.getBoundingClientRect(),b=0|m.left,g=0|m.top,w=s&&s.getBoundingClientRect()||m
if(v!==b||y!==g||n-p>c){var _=-(w.left+(s?0:u)),x=-(w.top+(s?0:f)),S=v,I=y,O=_+S|0,k=x+I-(w.height-h.height)/2|0,E=i.style
E.top=k+"px",E.left=O+"px",a.a,t.posX=-O,t.posY=-k,t.lastTime=n}},f=function(e){return window.requestAnimationFrame(t)}
window.setInterval(f,1e3),window.addEventListener("resize",f)}).call(e,n(19))},function(t,e,n){"use strict"
function r(t,e,r){if(e.anticipated){var s=t.el
a.a&&(i(t,e,r),n.i(o.a)(s,51,119,255))}}function i(t,e,r){n.i(o.b)(t,e,r,"slotify-reasons",u,c,l)}var o=n(121),a=n(50),s=n(346)
e.a=r
var u=function(t,e,n,r){var i=e.el
"inline"===n.type?i.style.width=n.width+"px":i.style.width="100%",Object.assign(i.style,s.a),Object.assign(t.style,s.b),t.style.width=n.width,t.style.height=n.height
var o=document.createElement("div")
Object.assign(o.style,s.c),o.className="debug-reasons",t.appendChild(o)},c=function(t){},l=function(t,e,n,r){var i="white"
n.rejectedReasons
var o=n.rejectedReasons||JSON.stringify(n.toJS(),null,2)
if(o!==e.reasons){e.reasons=o
var a='\n    <div style="font-size:1.0rem;color:white">\n      '+n.name+': empty\n    </div>\n    <div style="color:white">\n      '+n.width+"&times;"+n.height+'\n    </div>\n    <div\n      style="position:relative;top:0px;word-wrap:break-word;width: 260px;display: flex;flex-flow: column nowrap;color:'+i+';font-size:0.8rem;text-align:center;width:90%"\n    >\n      '+o+"\n    </div>\n    "
t.firstElementChild.innerHTML=a,t.firstElementChild.dataset.reasons=o}}},function(t,e,n){"use strict"
function r(t,e,n,r){var i=Math.abs(e-n),o=Math.abs(t-r)
return Math.min(i,o)}function i(t,e,n,i){return function(o,a){for(var s=n.indexOf(o.id),u=!1,c=0,l=0,f=0,d=s-1;d>=0;d--){l++,i()
var p=e.get(n.get(d))
if(p.tile===a.id){c++
if(r(p.coordinates.top,p.coordinates.bottom,o.coordinates.top,o.coordinates.bottom)<t){u=!0
break}u=!1
break}}if(!u)for(var h=n.count(),v=s+1;v<h;v++){f++,i()
var y=e.get(n.get(v))
if(y.tile===a.id){c++
var m=r(y.coordinates.top,y.coordinates.bottom,o.coordinates.top,o.coordinates.bottom)
if(m<t){u=!0
break}u=!1
break}}return!u}}function o(t,e,n,i,o){return function(a,s){for(var u=i.indexOf(a.id),c=!1,l=0,f=0,d=0,p=u-1;p>=0;p--){f++,o()
var h=i.get(p),v=e.get(h)
if(-1!==v.tile){if(n.get(v.tile).category===s.category){l++
if(r(v.coordinates.top,v.coordinates.bottom,a.coordinates.top,a.coordinates.bottom)<t){c=!0
break}c=!1
break}}}if(!c)for(var y=i.count(),m=u+1;m<y;m++){d++,o()
var b=e.get(i.get(m))
if(-1!==b.tile&&n.get(b.tile).category===s.category){l++
var g=r(b.coordinates.top,b.coordinates.bottom,a.coordinates.top,a.coordinates.bottom)
if(g<t){c=!0
break}c=!1
break}}return!c}}function a(t,e,n,r){return s(t,c(t,e,g.a),n,e,r)}function s(t,e,n,r,a){var s=(arguments.length>5&&void 0!==arguments[5]&&arguments[5],void 0)
g.a?(s=x(t),y.map):(s=S(t),y.filter)
var u=1.2*window.innerHeight,c=800,l=.4*window.innerHeight,f=350,d=0,p=function(t){return d++},h=g.a?e.map(s(i(Math.max(c,u),n,a,p),"far enough from self","too close to self")):e.filter(s(i(Math.max(c,u),n,a,p),"far enough from self","too close to self"))
return g.a?h.map(s(o(Math.max(f,l),n,r,a,p),"far enough from same category","too close to same category")):h.filter(s(o(Math.max(f,l),n,r,a,p),"far enough from same category","too close to same category"))}function u(t,e){return e.count(function(e){return e.tile===t.id||-1===e.tile&&U(F(e,t))})}function c(t,e){var r=void 0,i=void 0
g.a?(r=x(t),i=y.map):(r=S(t),i=y.filter)
var o=function(t,e){return t.push(e),t},a=n.i(y.comp)(i(r(D,"score higher than zero","score was equal or lower than zero")),i(r(P,"not fixed","fixed")),i(r(k,"large enough","too small")),i(r(E,"no/on whitelist","not on whitelist")),i(r(j,"not denied by a blacklist","denied by blacklist")))
return(new m.List).withMutations(function(t){return n.i(y.transduce)(a,o,t,e)})}function l(t,e){return t.set("anticipated",e.ratio>H)}function f(t,e){if(e.dirY<0)return t
if(t.preactivated||1===e.position&&e.ratio>H&&e.ratio<1){var n=t.timeViewed+e.interval
if(!t.preactivated){var r=0|Math.min(n,1e3)
return t.timeViewed!==r?t.set("timeViewed",r).set("anticipated",!0):t}return t.failed,t}return t}function d(t,e,n,r){var i=a(t,e,n,r,g.a),o=i.filter(function(t){return!(V(t).pinned||g.a&&0!==t.rejectedReasons.length)})
if(o.count()>0){var s=o.reduce(function(t,e){return V(e).lastViewed<V(t).lastViewed?e:t}),u=V(s),c=g.a?"tile accepted: "+s.acceptedReasons.join(" & "):""
return g.a?{tile:u,acceptedReasons:c,rejectedReasons:[]}:u}if(g.a){return{tile:null,rejectedReasons:"tiles rejected "+i.filter(function(t){return t.rejectedReasons.length>0}).map(function(t){return t.tile.id+": "+t.rejectedReasons.join(" & ")}).join(", "),acceptedReasons:[]}}return null}function p(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:new m.List,e=arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:new m.List,r=arguments[3]
if("VIEW_UPDATES"===e.type){return t.withMutations(function(t){(e.outOfView||[]).forEach(function(e){t.set(e.id,t.get(e.id).set("anticipated",!1).set("failed",!1))}),(e.inView||[]).forEach(function(e){t.set(e.id,t.get(e.id).set("anticipated",!0))})
var i=!1
if((e.view||[]).forEach(function(e,n){var r=t.get(e.id),o=X(v(r,e.event),e.event)
o!==r&&(t.set(e.id,o),i=!0)}),window.performance.now()-Z<3e3)return t
if(i&&t.find(function(e){return e.timeViewed>=Y&&e.status===b.a.NEARLY_VISIBLE&&-1===e.tile&&1===e.positionRelative&&U(d(e,n,t,r))})){var o=t.map(function(e){return e.timeViewed>=Y&&-1===e.tile&&1===e.positionRelative?{slot:e,choice:d(e,n,t,r)}:{slot:e,choice:g.a?{tile:null,rejectedReasons:"slot.timeViewed: "+e.timeViewed+", slot.tile: "+e.tile+", position: "+e.positionRelative}:null}})
o.forEach(function(e){!e||e.choice&&V(e.choice)||t.set(e.slot.id,e.slot.set("failed",!0).set("acceptedReasons",null).set("rejectedReasons","unsuccessfully picked: "+$(e.choice)).set("anticipated",!0))})
var a=o.filter(function(t){return t&&t.choice&&V(t.choice)}).map(function(e){return{score:V(e.choice).score/Number(u(V(e.choice),t)),slot:e.slot,choice:e.choice}}).sort(function(t,e){return t.score-e.score})
a.reduce(function(t,e){return e.score>=t.score&&(e.score>t.score?(t.pairings=[e],t.score=e.score,t):(t.pairings.push(e),t))||t},{score:0,pairings:[]}).pairings.sort(function(t,e){return r.indexOf(t.slot.id)-r.indexOf(e.slot.id)}).forEach(function(e,n,r){if(0===n){if(g.a){var i=r.slice(1).map(function(t){return V(t.choice).name+" to slot "+t.slot.name+" ("+t.score.toPrecision(4)+")"}).join(", "),o=r.slice(1).length>0?"it won over equally high scoring "+i:"there were no equally high scoring matches",s=a.slice(1).map(function(t){return V(t.choice).name+" to slot "+t.slot.name+" ("+t.score.toPrecision(4)+")"}).join(", "),u=a.slice(1).length>0?"and it won over the lower scoring "+s:"and there were no other lower scoring matches"
console.log("HOPSCOTCH: Successful valid slot choice: ",V(e.choice).name,"to slot",e.slot.name,"("+e.score.toPrecision(4)+")",o,u)}Z=window.performance.now(),t.set(e.slot.id,e.slot.set("tile",V(e.choice).id).set("width",V(e.choice).width).set("height",V(e.choice).height).set("anticipated",!0).set("acceptedReasons",W(e.choice)).set("rejectedReasons",null))}else t.set(e.slot.id,e.slot.set("anticipated",!0).set("rejectedReasons","rejected: unsuccessfully picked (same score)"))})}else(e.view||[]).length})}switch(e.type){case"ADD_SLOT":return t.push(new K(e.slot).set("tile",-1).set("timeViewed",0).set("id",e.id))
case"IN_VIEW":return t.set(e.id,t.get(e.id).set("anticipated",!0))
case"OUT_OF_VIEW":return t.set(e.id,t.get(e.id).set("anticipated",!1).set("failed",!1))
case"UPDATE_SLOT":break
case"VIEW_SLOT":var i=t.get(e.id),o=v(i,e.event,n,t,r)
return o!==i?t.set(e.id,o):t
case"FILL_PROACTIVE":return fill(t,n)
case"PLACE":var a=n.find(function(t){return t.id===e.id})
return _()(void 0!==a,"Tile must not be undefined in PLACE - is tile ID correct? "+e.id+" vs ["+n.toJS().map(function(t){return t.id}).join(", ")+"]"),h(t,a,e.left,e.top,r,n)}return t}function h(t,e,n,r,i,o){_()(void 0!==e,"Tile must not be undefined - maybe tile id is incorrect")
var a=(e.affinitiesMeta||[]).findIndex(function(t,e){return t.pinned})
if(a>=0){var u=t.get(e.affinities[a])
if(u){if(-1===u.tile){var c=u.set("tile",e.id).set("anticipated",!0).set("proactive",!0).set("rejectedReasons",null).set("acceptedReasons","filled by pinned affinity")
return g.a&&console.warn("::SLOTIFY_DEBUG: FOUND PINNED SLOT FOR TILE",e.name,"IN SLOT",c.name),t.set(c.id,c)}throw new Error(e.name+" was pinned to slot affinity "+e.affinities[a]+", "+u.name+" but it was already allocated: "+u.tile)}throw new Error(e.name+" was pinned to slot affinity "+e.affinities[a]+", but no slot with that ID was found")}var l=!1
if((e.affinitiesMeta||[]).forEach(function(n,r){if(n.sticky){var i=t.get(e.affinities[r])
if(-1===i.tile){g.a&&console.warn("::SLOTIFY_DEBUG: FOUND STICKY SLOT FOR TILE",e.name,"IN SLOT",i.name)
var o=i.set("tile",e.id).set("anticipated",!0).set("proactive",!0).set("rejectedReasons",null).set("acceptedReasons","filled by sticky affinity")
t=t.set(o.id,o),l=!0}}}),l)return t
var f=t.sort(function(t,e){return t.coordinates.top-e.coordinates.top}),d=function(){var n=!(arguments.length>0&&void 0!==arguments[0])||arguments[0]
return function(r){if(g.a&&console.warn("::SLOTIFY_DEBUG: VALIDATING SLOT",r.toJS(),"FOR TILE",e.toJS()),-1===r.tile){var a=F(r,e)
if(U(a)){if(!n||e.affinities.indexOf(r.id)>=0)return g.a&&(e.affinities.indexOf(r.id)>=0?console.warn("::SLOTIFY_DEBUG: TILE",e.toJS(),"HAS AFFINITY FOR SLOT",r.toJS(),"SO RETURNING TRUE"):console.warn("::SLOTIFY_DEBUG: DID NOT FIND TILE WHEN ENFORICNG INTERSLOT RULES - FOUND ONE WHEN RELAXING")),!0
var u=s(r,m.List.of(V(a)),t,o,i,!0).get(0)
return!!U(u)||(g.a&&console.log("::SLOTIFY_DEBUG: FAILED INTERSLOT RULES",$(u),"slot",r.toJS(),"tile",e.toJS()),!1)}return g.a&&console.log("::SLOTIFY_DEBUG: FAILED PER TILE RULES",$(a),"slot",r.toJS(),"tile",e.toJS()),!1}return g.a&&console.log("::SLOTIFY_DEBUG: FAILED - SLOT IS ALREADY ASSIGNED","slot",r.toJS(),"tile",e.toJS(),"SLOT ASSIGNED TO",o.get(r.tile).toJS()),!1}},p=f.skipWhile(function(t){return t.coordinates.top<r-0}).find(d(!0))||f.find(d(!1))
if(p){g.a&&console.log("::SLOTIFY_DEBUG: FOUND PLACE FOR TILE",e.toJS(),"AT SLOT",p.toJS())
var h=p.set("tile",e.id).set("anticipated",!0).set("proactive",!0).set("rejectedReasons",null).set("acceptedReasons","filled proactively")
return t.set(p.id,h)}throw g.a&&console.log("::SLOTIFY_DEBUG: SORTED",f.toJS(),"valid slot",p),new Error(e.name+" did not find valid slot in initial placement")}function v(t,e){return-1===t.tile?f(t,e):l(t,e)}var y=n(291),m=n(86),b=(n.n(m),n(124)),g=n(50),w=n(32),_=n.n(w)
e.a=p
var x=function(t){return function(e,n,r){return function(i){return e(t,i.tile||i)?{tile:i.tile||i,acceptedReasons:[].concat(i.acceptedReasons||[]).concat(n),rejectedReasons:i.rejectedReasons||[]}:{tile:i.tile||i,rejectedReasons:[].concat(i.rejectedReasons||[]).concat(r),acceptedReasons:i.acceptedReasons||[]}}}},S=function(t){return function(e){return function(n){return e(t,n)}}},I=function(t,e,n){return function(r,i){return t(r,i.tile||i)?{tile:i.tile||i,acceptedReasons:[].concat(i.acceptedReasons||[]).concat(e),rejectedReasons:i.rejectedReasons||[]}:{tile:i.tile||i,rejectedReasons:[].concat(i.rejectedReasons||[]).concat(n),acceptedReasons:i.acceptedReasons||[]}}},O=function(t){return function(e,n){return t(e,n)}},k=function(t,e){return 1===t.fluid&&1===e.fluid||e.width<=t.width&&e.height<=t.height},E=function(t,e){return!(t.whitelist.length>0)||t.whitelist.indexOf(e.category)>=0},j=function(t,e){return!(t.blacklist.length>0)||-1===t.blacklist.indexOf(e.category)},P=function(t,e){return!0},D=function(t,e){return e.score>0},A=g.a?I:O,T=A(D,"score higher than zero","score was equal or lower than zero"),C=A(P,"not fixed","fixed"),N=A(k,"large enough","too small"),R=A(E,"no/on whitelist","not on whitelist"),M=A(j,"not denied by a blacklist","denied by blacklist"),L=function(t){var e=t.length
return function(n,r){for(var i=0;i<e;i++)if(!t[i](n,r))return!1
return!0}},z=function(t){var e=t.length
return function(n,r){for(var i=r,o=0;o<e;o++)i=t[o](n,i)
return i}},B=g.a?z:L,q=B([T,C,N,R,M]),F=g.a?function(t,e){return q(t,e)}:function(t,e){return q(t,e)&&e},V=g.a?function(t){return t.tile}:function(t){return t},U=g.a?function(t){return t.acceptedReasons.length>0&&0===t.rejectedReasons.length}:function(t){return t},W=g.a?function(t){return t.acceptedReasons}:function(){},$=g.a?function(t){return t.rejectedReasons}:function(){},H=0,Y=200,J=function(){},K=n.i(m.Record)({id:-1,element:-1,name:"leaderboard slot",hook:document.querySelector("body div"),type:"BLOCK",position:"before",align:"center",width:-1,height:-1,fluid:!1,preactivated:!1,coordinates:{top:-1,left:-1,right:-1,bottom:-1},acceptedReasons:null,rejectedReasons:null,anticipated:!1,proactive:!1,tile:-1,timeViewed:0,mountPoint:!1,failed:!1,status:b.a.OFF_SCREEN,whitelist:[],blacklist:[],onOccupy:J,onResize:J,specifyInline:J,fixed:!1,positionRelative:null}),G=function(t){return t<.5?b.a.OFF_SCREEN:t<.99?b.a.NEARLY_VISIBLE:b.a.VISIBLE},X=function(t,e){var n=G(e.ratio)
return e.position!==t.positionRelative&&(t=t.set("positionRelative",e.position)),n!==t.status?t.set("status",n):t},Z=window.performance.now()},function(t,e,n){"use strict"
function r(t,e){return t.push(new d(e.tile).set("id",e.id))}function i(t,e,n){var r=n.get(e.id)
return r.tile>=0?t.set(r.tile,a(t.get(r.tile),r)):t}function o(t,e,n){var r=n.get(e.id)
return r.tile>=0?t.set(r.tile,t.get(r.tile).set("lastViewed",e.time)):t}function a(t,e){return t.hybrid&&t.mountPoint===f?t.set("mountPoint",e.id):t}function s(t,e){var n=e.filter(function(t){return t.tile>=0})
return t.map(function(t){var e=n.find(function(e){return e.tile===t.id})
return e?a(t,e):t})}function u(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:new c.List,e=arguments[1],n=arguments[2]
if("VIEW_UPDATES"===e.type)return t.withMutations(function(t){(e.outOfView||[]).forEach(function(e){return o(t,e,n)}),(e.inView||[]).forEach(function(t){}),(e.view||[]).forEach(function(e){return i(t,e,n)})})
switch(e.type){case"ADD_TILE":return r(t,e)
case"VIEW_SLOT":return i(t,e,n)
case"OUT_OF_VIEW":return o(t,e,n)
case"FILL_PROACTIVE":return s(t,n)
case"TILE_SIZE":return t.set(e.id,t.get(e.id).set("width",e.width).set("height",e.height))
case"SET_SCORE":return t.set(e.id,t.get(e.id).set("score",e.score))
case"SET_SHRINKWRAPPED":return t.set(e.id,t.get(e.id).set("shrinkwrapped",e.value))}return t}var c=n(86)
n.n(c)
e.a=u
var l=function(){},f=-1,d=n.i(c.Record)({id:-1,category:"generic",name:"Generic Tile",width:300,height:250,fluid:!1,shrinkwrapped:!1,floating:!0,element:l,hybrid:!1,onMount:l,onActivate:l,mountPoint:-1,proactive:!1,lastViewed:0,fixed:!1,nowFixed:!1,score:1,affinities:[],affinitiesMeta:[],pinned:!1})},function(t,e,n){"use strict"
function r(t,e){var n={}
for(var r in t)e.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(t,r)&&(n[r]=t[r])
return n}function i(t){return f.a(t).then(function(t){return t.map(function(t){var e=t.action,n=t.element,r=t.id
return d.a.dispatch(e),{id:r,element:n}})})}function o(t){return f.b(t).then(function(t){var e=t.action,n=t.element,r=t.id
return d.a.dispatch(e),{id:r,element:n}})}function a(t,e){d.a.dispatch(f.c(t,e))}function s(t,e){d.a.dispatch(f.d(t,e))}function u(t){var e=(t.affinities||[]).map(function(t){return"number"==typeof t?t:t.id}),n=(t.affinities||[]).map(function(t){if("number"==typeof t)return{}
var e=(t.id,r(t,["id"]))
return y({},e)}),i=y({},t,{affinities:e,affinitiesMeta:n,pinned:n.some(function(t){return t.pinned})})
return m++,d.a.dispatch(f.e(m-1,i)),m-1}function c(t,e,n){t.forEach(function(t){h()(Number.isInteger(t),"Expected an integer slot ID - this is not an integer: "+t),d.a.dispatch(f.f(t,e,n))})}function l(){d.a.dispatch(f.g())}Object.defineProperty(e,"__esModule",{value:!0})
var f=n(74),d=n(123),p=n(32),h=n.n(p),v=n(122)
n.d(e,"provideFeat",function(){return v.a}),e.addSlots=i,e.addSlot=o,e.setScore=a,e.setShrinkwrapped=s,e.addTile=u,e.place=c,e.assignTiles=l
var y=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]
for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},m=0
Number.isInteger=Number.isInteger||function(t){return"number"==typeof t&&isFinite(t)&&Math.floor(t)===t}},function(t,e,n){"use strict"
var r=n(284)
n.n(r)
n.o(r,"map")&&n.d(e,"map",function(){return r.map}),n.o(r,"filter")&&n.d(e,"filter",function(){return r.filter}),n.o(r,"comp")&&n.d(e,"comp",function(){return r.comp}),n.o(r,"transduce")&&n.d(e,"transduce",function(){return r.transduce})},function(t,e,n){var r=n(293)
t.exports=function(t){return function e(n){return 0===arguments.length||r(n)?e:t.apply(this,arguments)}}},function(t,e){t.exports=function(t){return null!=t&&"object"==typeof t&&!0===t["@@functional/placeholder"]}},function(t,e,n){var r=n(292)
t.exports=r(function(t){return null==t})},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(1),o=function(t){function e(e,n,r){t.call(this),this.parent=e,this.outerValue=n,this.outerIndex=r,this.index=0}return r(e,t),e.prototype._next=function(t){this.parent.notifyNext(this.outerValue,t,this.outerIndex,this.index++,this)},e.prototype._error=function(t){this.parent.notifyError(t,this),this.unsubscribe()},e.prototype._complete=function(){this.parent.notifyComplete(this),this.unsubscribe()},e}(i.Subscriber)
e.InnerSubscriber=o},function(t,e,n){"use strict"
var r=function(){function t(e,n){void 0===n&&(n=t.now),this.SchedulerAction=e,this.now=n}return t.prototype.schedule=function(t,e,n){return void 0===e&&(e=0),new this.SchedulerAction(this,t).schedule(n,e)},t.now=Date.now?Date.now:function(){return+new Date},t}()
e.Scheduler=r},function(t,e,n){"use strict"
var r=n(2),i=n(304)
r.Observable.prototype.catch=i._catch,r.Observable.prototype._catch=i._catch},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=n(78),a=n(52),s=function(t){function e(e,n){t.call(this),this.arrayLike=e,this.scheduler=n,n||1!==e.length||(this._isScalar=!0,this.value=e[0])}return r(e,t),e.create=function(t,n){var r=t.length
return 0===r?new a.EmptyObservable:1===r?new o.ScalarObservable(t[0],n):new e(t,n)},e.dispatch=function(t){var e=t.arrayLike,n=t.index,r=t.length,i=t.subscriber
if(!i.closed){if(n>=r)return void i.complete()
i.next(e[n]),t.index=n+1,this.schedule(t)}},e.prototype._subscribe=function(t){var n=this,r=n.arrayLike,i=n.scheduler,o=r.length
if(i)return i.schedule(e.dispatch,0,{arrayLike:r,index:0,length:o,subscriber:t})
for(var a=0;a<o&&!t.closed;a++)t.next(r[a])
t.complete()},e}(i.Observable)
e.ArrayLikeObservable=s},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(16),o=n(2),a=n(1),s=n(31),u=function(t){function e(e,n){t.call(this),this.source=e,this.subjectFactory=n,this._refCount=0}return r(e,t),e.prototype._subscribe=function(t){return this.getSubject().subscribe(t)},e.prototype.getSubject=function(){var t=this._subject
return t&&!t.isStopped||(this._subject=this.subjectFactory()),this._subject},e.prototype.connect=function(){var t=this._connection
return t||(t=this._connection=new s.Subscription,t.add(this.source.subscribe(new c(this.getSubject(),this))),t.closed?(this._connection=null,t=s.Subscription.EMPTY):this._connection=t),t},e.prototype.refCount=function(){return this.lift(new l(this))},e}(o.Observable)
e.ConnectableObservable=u,e.connectableObservableDescriptor={operator:{value:null},_refCount:{value:0,writable:!0},_subject:{value:null,writable:!0},_connection:{value:null,writable:!0},_subscribe:{value:u.prototype._subscribe},getSubject:{value:u.prototype.getSubject},connect:{value:u.prototype.connect},refCount:{value:u.prototype.refCount}}
var c=function(t){function e(e,n){t.call(this,e),this.connectable=n}return r(e,t),e.prototype._error=function(e){this._unsubscribe(),t.prototype._error.call(this,e)},e.prototype._complete=function(){this._unsubscribe(),t.prototype._complete.call(this)},e.prototype._unsubscribe=function(){var t=this.connectable
if(t){this.connectable=null
var e=t._connection
t._refCount=0,t._subject=null,t._connection=null,e&&e.unsubscribe()}},e}(i.SubjectSubscriber),l=function(){function t(t){this.connectable=t}return t.prototype.call=function(t,e){var n=this.connectable
n._refCount++
var r=new f(t,n),i=e.subscribe(r)
return r.closed||(r.connection=n.connect()),i},t}(),f=function(t){function e(e,n){t.call(this,e),this.connectable=n}return r(e,t),e.prototype._unsubscribe=function(){var t=this.connectable
if(!t)return void(this.connection=null)
this.connectable=null
var e=t._refCount
if(e<=0)return void(this.connection=null)
if(t._refCount=e-1,e>1)return void(this.connection=null)
var n=this.connection,r=t._connection
this.connection=null,!r||n&&r!==n||r.unsubscribe()},e}(a.Subscriber)},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(45),o=n(132),a=n(136),s=n(303),u=n(301),c=n(25),l=n(298),f=n(82),d=n(2),p=n(65),h=n(83),v=function(t){function e(e,n){t.call(this,null),this.ish=e,this.scheduler=n}return r(e,t),e.create=function(t,n){if(null!=t){if("function"==typeof t[h.observable])return t instanceof d.Observable&&!n?t:new e(t,n)
if(i.isArray(t))return new c.ArrayObservable(t,n)
if(a.isPromise(t))return new s.PromiseObservable(t,n)
if("function"==typeof t[f.iterator]||"string"==typeof t)return new u.IteratorObservable(t,n)
if(o.isArrayLike(t))return new l.ArrayLikeObservable(t,n)}throw new TypeError((null!==t&&typeof t||t)+" is not observable")},e.prototype._subscribe=function(t){var e=this.ish,n=this.scheduler
return null==n?e[h.observable]().subscribe(t):e[h.observable]().subscribe(new p.ObserveOnSubscriber(t,n,0))},e}(d.Observable)
e.FromObservable=v},function(t,e,n){"use strict"
function r(t){var e=t[l.iterator]
if(!e&&"string"==typeof t)return new d(t)
if(!e&&void 0!==t.length)return new p(t)
if(!e)throw new TypeError("object is not iterable")
return t[l.iterator]()}function i(t){var e=+t.length
return isNaN(e)?0:0!==e&&o(e)?(e=a(e)*Math.floor(Math.abs(e)),e<=0?0:e>h?h:e):e}function o(t){return"number"==typeof t&&u.root.isFinite(t)}function a(t){var e=+t
return 0===e?e:isNaN(e)?e:e<0?-1:1}var s=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},u=n(11),c=n(2),l=n(82),f=function(t){function e(e,n){if(t.call(this),this.scheduler=n,null==e)throw new Error("iterator cannot be null.")
this.iterator=r(e)}return s(e,t),e.create=function(t,n){return new e(t,n)},e.dispatch=function(t){var e=t.index,n=t.hasError,r=t.iterator,i=t.subscriber
if(n)return void i.error(t.error)
var o=r.next()
return o.done?void i.complete():(i.next(o.value),t.index=e+1,i.closed?void("function"==typeof r.return&&r.return()):void this.schedule(t))},e.prototype._subscribe=function(t){var n=this,r=n.iterator,i=n.scheduler
if(i)return i.schedule(e.dispatch,0,{index:0,iterator:r,subscriber:t})
for(;;){var o=r.next()
if(o.done){t.complete()
break}if(t.next(o.value),t.closed){"function"==typeof r.return&&r.return()
break}}},e}(c.Observable)
e.IteratorObservable=f
var d=function(){function t(t,e,n){void 0===e&&(e=0),void 0===n&&(n=t.length),this.str=t,this.idx=e,this.len=n}return t.prototype[l.iterator]=function(){return this},t.prototype.next=function(){return this.idx<this.len?{done:!1,value:this.str.charAt(this.idx++)}:{done:!0,value:void 0}},t}(),p=function(){function t(t,e,n){void 0===e&&(e=0),void 0===n&&(n=i(t)),this.arr=t,this.idx=e,this.len=n}return t.prototype[l.iterator]=function(){return this},t.prototype.next=function(){return this.idx<this.len?{done:!1,value:this.arr[this.idx++]}:{done:!0,value:void 0}},t}(),h=Math.pow(2,53)-1},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(2),o=n(326),a=function(t){function e(){t.call(this)}return r(e,t),e.create=function(){return new e},e.prototype._subscribe=function(t){o.noop()},e}(i.Observable)
e.NeverObservable=a},function(t,e,n){"use strict"
function r(t){var e=t.value,n=t.subscriber
n.closed||(n.next(e),n.complete())}function i(t){var e=t.err,n=t.subscriber
n.closed||n.error(e)}var o=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},a=n(11),s=n(2),u=function(t){function e(e,n){t.call(this),this.promise=e,this.scheduler=n}return o(e,t),e.create=function(t,n){return new e(t,n)},e.prototype._subscribe=function(t){var e=this,n=this.promise,o=this.scheduler
if(null==o)this._isScalar?t.closed||(t.next(this.value),t.complete()):n.then(function(n){e.value=n,e._isScalar=!0,t.closed||(t.next(n),t.complete())},function(e){t.closed||t.error(e)}).then(null,function(t){a.root.setTimeout(function(){throw t})})
else if(this._isScalar){if(!t.closed)return o.schedule(r,0,{value:this.value,subscriber:t})}else n.then(function(n){e.value=n,e._isScalar=!0,t.closed||t.add(o.schedule(r,0,{value:n,subscriber:t}))},function(e){t.closed||t.add(o.schedule(i,0,{err:e,subscriber:t}))}).then(null,function(t){a.root.setTimeout(function(){throw t})})},e}(s.Observable)
e.PromiseObservable=u},function(t,e,n){"use strict"
function r(t){var e=new s(t),n=this.lift(e)
return e.caught=n}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(21),a=n(22)
e._catch=r
var s=function(){function t(t){this.selector=t}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.selector,this.caught))},t}(),u=function(t){function e(e,n,r){t.call(this,e),this.selector=n,this.caught=r}return i(e,t),e.prototype.error=function(e){if(!this.isStopped){var n=void 0
try{n=this.selector(e,this.caught)}catch(e){return void t.prototype.error.call(this,e)}this._unsubscribeAndRecycle(),this.add(a.subscribeToResult(this,n))}},e}(o.OuterSubscriber)},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
return this.lift.call(i.apply(void 0,[this].concat(t)))}function i(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n=null,r=t
return a.isScheduler(r[t.length-1])&&(n=r.pop()),null===n&&1===t.length&&t[0]instanceof o.Observable?t[0]:new s.ArrayObservable(t,n).lift(new u.MergeAllOperator(1))}var o=n(2),a=n(37),s=n(25),u=n(44)
e.concat=r,e.concatStatic=i},function(t,e,n){"use strict"
function r(t,e){return this.lift(new i.MergeMapOperator(t,e,1))}var i=n(14)
e.concatMap=r},function(t,e,n){"use strict"
function r(t){return void 0===t&&(t=null),this.lift(new a(t))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e.defaultIfEmpty=r
var a=function(){function t(t){this.defaultValue=t}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.defaultValue))},t}(),s=function(t){function e(e,n){t.call(this,e),this.defaultValue=n,this.isEmpty=!0}return i(e,t),e.prototype._next=function(t){this.isEmpty=!1,this.destination.next(t)},e.prototype._complete=function(){this.isEmpty&&this.destination.next(this.defaultValue),this.destination.complete()},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(t,e){return this.lift(new u(t,e))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1),a=n(137),s=n(85)
e.distinctUntilChanged=r
var u=function(){function t(t,e){this.compare=t,this.keySelector=e}return t.prototype.call=function(t,e){return e.subscribe(new c(t,this.compare,this.keySelector))},t}(),c=function(t){function e(e,n,r){t.call(this,e),this.keySelector=r,this.hasKey=!1,"function"==typeof n&&(this.compare=n)}return i(e,t),e.prototype.compare=function(t,e){return t===e},e.prototype._next=function(t){var e=this.keySelector,n=t
if(e&&(n=a.tryCatch(this.keySelector)(t))===s.errorObject)return this.destination.error(s.errorObject.e)
var r=!1
if(this.hasKey){if((r=a.tryCatch(this.compare)(this.key,n))===s.errorObject)return this.destination.error(s.errorObject.e)}else this.hasKey=!0
!1===Boolean(r)&&(this.key=n,this.destination.next(t))},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(t,e,n){return this.lift(new a(t,e,n))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1)
e._do=r
var a=function(){function t(t,e,n){this.nextOrObserver=t,this.error=e,this.complete=n}return t.prototype.call=function(t,e){return e.subscribe(new s(t,this.nextOrObserver,this.error,this.complete))},t}(),s=function(t){function e(e,n,r,i){t.call(this,e)
var a=new o.Subscriber(n,r,i)
a.syncErrorThrowable=!0,this.add(a),this.safeSubscriber=a}return i(e,t),e.prototype._next=function(t){var e=this.safeSubscriber
e.next(t),e.syncErrorThrown?this.destination.error(e.syncErrorValue):this.destination.next(t)},e.prototype._error=function(t){var e=this.safeSubscriber
e.error(t),e.syncErrorThrown?this.destination.error(e.syncErrorValue):this.destination.error(t)},e.prototype._complete=function(){var t=this.safeSubscriber
t.complete(),t.syncErrorThrown?this.destination.error(t.syncErrorValue):this.destination.complete()},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(t,e,n){return this.lift(new s(t,e,n,this))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(1),a=n(130)
e.last=r
var s=function(){function t(t,e,n,r){this.predicate=t,this.resultSelector=e,this.defaultValue=n,this.source=r}return t.prototype.call=function(t,e){return e.subscribe(new u(t,this.predicate,this.resultSelector,this.defaultValue,this.source))},t}(),u=function(t){function e(e,n,r,i,o){t.call(this,e),this.predicate=n,this.resultSelector=r,this.defaultValue=i,this.source=o,this.hasValue=!1,this.index=0,void 0!==i&&(this.lastValue=i,this.hasValue=!0)}return i(e,t),e.prototype._next=function(t){var e=this.index++
if(this.predicate)this._tryPredicate(t,e)
else{if(this.resultSelector)return void this._tryResultSelector(t,e)
this.lastValue=t,this.hasValue=!0}},e.prototype._tryPredicate=function(t,e){var n
try{n=this.predicate(t,e,this.source)}catch(t){return void this.destination.error(t)}if(n){if(this.resultSelector)return void this._tryResultSelector(t,e)
this.lastValue=t,this.hasValue=!0}},e.prototype._tryResultSelector=function(t,e){var n
try{n=this.resultSelector(t,e)}catch(t){return void this.destination.error(t)}this.lastValue=n,this.hasValue=!0},e.prototype._complete=function(){var t=this.destination
this.hasValue?(t.next(this.lastValue),t.complete()):t.error(new a.EmptyError)},e}(o.Subscriber)},function(t,e,n){"use strict"
function r(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
return this.lift.call(i.apply(void 0,[this].concat(t)))}function i(){for(var t=[],e=0;e<arguments.length;e++)t[e-0]=arguments[e]
var n=Number.POSITIVE_INFINITY,r=null,i=t[t.length-1]
return u.isScheduler(i)?(r=t.pop(),t.length>1&&"number"==typeof t[t.length-1]&&(n=t.pop())):"number"==typeof i&&(n=t.pop()),null===r&&1===t.length&&t[0]instanceof o.Observable?t[0]:new a.ArrayObservable(t,r).lift(new s.MergeAllOperator(n))}var o=n(2),a=n(25),s=n(44),u=n(37)
e.merge=r,e.mergeStatic=i},function(t,e,n){"use strict"
function r(t){return this.lift(new s(t))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(21),a=n(22)
e.sample=r
var s=function(){function t(t){this.notifier=t}return t.prototype.call=function(t,e){var n=new u(t),r=e.subscribe(n)
return r.add(a.subscribeToResult(n,this.notifier)),r},t}(),u=function(t){function e(){t.apply(this,arguments),this.hasValue=!1}return i(e,t),e.prototype._next=function(t){this.value=t,this.hasValue=!0},e.prototype.notifyNext=function(t,e,n,r,i){this.emitValue()},e.prototype.notifyComplete=function(){this.emitValue()},e.prototype.emitValue=function(){this.hasValue&&(this.hasValue=!1,this.destination.next(this.value))},e}(o.OuterSubscriber)},function(t,e,n){"use strict"
function r(){return new a.Subject}function i(){return o.multicast.call(this,r).refCount()}var o=n(80),a=n(16)
e.share=i},function(t,e,n){"use strict"
function r(t,e){return void 0===e&&(e=s.async),this.lift(new u(t,e))}function i(t){t.subscriber.clearThrottle()}var o=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},a=n(1),s=n(67)
e.throttleTime=r
var u=function(){function t(t,e){this.duration=t,this.scheduler=e}return t.prototype.call=function(t,e){return e.subscribe(new c(t,this.duration,this.scheduler))},t}(),c=function(t){function e(e,n,r){t.call(this,e),this.duration=n,this.scheduler=r}return o(e,t),e.prototype._next=function(t){this.throttled||(this.add(this.throttled=this.scheduler.schedule(i,this.duration,{subscriber:this})),this.destination.next(t))},e.prototype.clearThrottle=function(){var t=this.throttled
t&&(t.unsubscribe(),this.remove(t),this.throttled=null)},e}(a.Subscriber)},function(t,e,n){"use strict"
function r(t,e){void 0===e&&(e=o.async)
var n=a.isDate(t),r=n?+t-e.now():Math.abs(t)
return this.lift(new c(r,n,e,new u.TimeoutError))}var i=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},o=n(67),a=n(133),s=n(1),u=n(324)
e.timeout=r
var c=function(){function t(t,e,n,r){this.waitFor=t,this.absoluteTimeout=e,this.scheduler=n,this.errorInstance=r}return t.prototype.call=function(t,e){return e.subscribe(new l(t,this.absoluteTimeout,this.waitFor,this.scheduler,this.errorInstance))},t}(),l=function(t){function e(e,n,r,i,o){t.call(this,e),this.absoluteTimeout=n,this.waitFor=r,this.scheduler=i,this.errorInstance=o,this.action=null,this.scheduleTimeout()}return i(e,t),e.dispatchTimeout=function(t){t.error(t.errorInstance)},e.prototype.scheduleTimeout=function(){var t=this.action
t?this.action=t.schedule(this,this.waitFor):this.add(this.action=this.scheduler.schedule(e.dispatchTimeout,this.waitFor,this))},e.prototype._next=function(e){this.absoluteTimeout||this.scheduleTimeout(),t.prototype._next.call(this,e)},e.prototype._unsubscribe=function(){this.action=null,this.scheduler=null,this.errorInstance=null},e}(s.Subscriber)},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(31),o=function(t){function e(e,n){t.call(this)}return r(e,t),e.prototype.schedule=function(t,e){return void 0===e&&(e=0),this},e}(i.Subscription)
e.Action=o},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(323),o=n(70),a=function(t){function e(e,n){t.call(this,e,n),this.scheduler=e,this.work=n}return r(e,t),e.prototype.requestAsyncId=function(e,n,r){return void 0===r&&(r=0),null!==r&&r>0?t.prototype.requestAsyncId.call(this,e,n,r):(e.actions.push(this),e.scheduled||(e.scheduled=i.Immediate.setImmediate(e.flush.bind(e,null))))},e.prototype.recycleAsyncId=function(e,n,r){if(void 0===r&&(r=0),null!==r&&r>0||null===r&&this.delay>0)return t.prototype.recycleAsyncId.call(this,e,n,r)
0===e.actions.length&&(i.Immediate.clearImmediate(n),e.scheduled=void 0)},e}(o.AsyncAction)
e.AsapAction=a},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(71),o=function(t){function e(){t.apply(this,arguments)}return r(e,t),e.prototype.flush=function(t){this.active=!0,this.scheduled=void 0
var e,n=this.actions,r=-1,i=n.length
t=t||n.shift()
do{if(e=t.execute(t.state,t.delay))break}while(++r<i&&(t=n.shift()))
if(this.active=!1,e){for(;++r<i&&(t=n.shift());)t.unsubscribe()
throw e}},e}(i.AsyncScheduler)
e.AsapScheduler=o},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(70),o=function(t){function e(e,n){t.call(this,e,n),this.scheduler=e,this.work=n}return r(e,t),e.prototype.schedule=function(e,n){return void 0===n&&(n=0),n>0?t.prototype.schedule.call(this,e,n):(this.delay=n,this.state=e,this.scheduler.flush(this),this)},e.prototype.execute=function(e,n){return n>0||this.closed?t.prototype.execute.call(this,e,n):this._execute(e,n)},e.prototype.requestAsyncId=function(e,n,r){return void 0===r&&(r=0),null!==r&&r>0||null===r&&this.delay>0?t.prototype.requestAsyncId.call(this,e,n,r):e.flush(this)},e}(i.AsyncAction)
e.QueueAction=o},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=n(71),o=function(t){function e(){t.apply(this,arguments)}return r(e,t),e}(i.AsyncScheduler)
e.QueueScheduler=o},function(t,e,n){"use strict"
var r=n(317),i=n(318)
e.asap=new i.AsapScheduler(r.AsapAction)},function(t,e,n){"use strict"
var r=n(319),i=n(320)
e.queue=new i.QueueScheduler(r.QueueAction)},function(t,e,n){"use strict";(function(t,r){var i=n(11),o=function(){function t(t){if(this.root=t,t.setImmediate&&"function"==typeof t.setImmediate)this.setImmediate=t.setImmediate.bind(t),this.clearImmediate=t.clearImmediate.bind(t)
else{this.nextHandle=1,this.tasksByHandle={},this.currentlyRunningATask=!1,this.canUseProcessNextTick()?this.setImmediate=this.createProcessNextTickSetImmediate():this.canUsePostMessage()?this.setImmediate=this.createPostMessageSetImmediate():this.canUseMessageChannel()?this.setImmediate=this.createMessageChannelSetImmediate():this.canUseReadyStateChange()?this.setImmediate=this.createReadyStateChangeSetImmediate():this.setImmediate=this.createSetTimeoutSetImmediate()
var e=function t(e){delete t.instance.tasksByHandle[e]}
e.instance=this,this.clearImmediate=e}}return t.prototype.identify=function(t){return this.root.Object.prototype.toString.call(t)},t.prototype.canUseProcessNextTick=function(){return"[object process]"===this.identify(this.root.process)},t.prototype.canUseMessageChannel=function(){return Boolean(this.root.MessageChannel)},t.prototype.canUseReadyStateChange=function(){var t=this.root.document
return Boolean(t&&"onreadystatechange"in t.createElement("script"))},t.prototype.canUsePostMessage=function(){var t=this.root
if(t.postMessage&&!t.importScripts){var e=!0,n=t.onmessage
return t.onmessage=function(){e=!1},t.postMessage("","*"),t.onmessage=n,e}return!1},t.prototype.partiallyApplied=function(t){for(var e=[],n=1;n<arguments.length;n++)e[n-1]=arguments[n]
var r=function t(){var e=t,n=e.handler,r=e.args
"function"==typeof n?n.apply(void 0,r):new Function(""+n)()}
return r.handler=t,r.args=e,r},t.prototype.addFromSetImmediateArguments=function(t){return this.tasksByHandle[this.nextHandle]=this.partiallyApplied.apply(void 0,t),this.nextHandle++},t.prototype.createProcessNextTickSetImmediate=function(){var t=function t(){var e=t.instance,n=e.addFromSetImmediateArguments(arguments)
return e.root.process.nextTick(e.partiallyApplied(e.runIfPresent,n)),n}
return t.instance=this,t},t.prototype.createPostMessageSetImmediate=function(){var t=this.root,e="setImmediate$"+t.Math.random()+"$",n=function n(r){var i=n.instance
r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&i.runIfPresent(+r.data.slice(e.length))}
n.instance=this,t.addEventListener("message",n,!1)
var r=function t(){var e=t,n=e.messagePrefix,r=e.instance,i=r.addFromSetImmediateArguments(arguments)
return r.root.postMessage(n+i,"*"),i}
return r.instance=this,r.messagePrefix=e,r},t.prototype.runIfPresent=function(t){if(this.currentlyRunningATask)this.root.setTimeout(this.partiallyApplied(this.runIfPresent,t),0)
else{var e=this.tasksByHandle[t]
if(e){this.currentlyRunningATask=!0
try{e()}finally{this.clearImmediate(t),this.currentlyRunningATask=!1}}}},t.prototype.createMessageChannelSetImmediate=function(){var t=this,e=new this.root.MessageChannel
e.port1.onmessage=function(e){var n=e.data
t.runIfPresent(n)}
var n=function t(){var e=t,n=e.channel,r=e.instance,i=r.addFromSetImmediateArguments(arguments)
return n.port2.postMessage(i),i}
return n.channel=e,n.instance=this,n},t.prototype.createReadyStateChangeSetImmediate=function(){var t=function t(){var e=t.instance,n=e.root,r=n.document,i=r.documentElement,o=e.addFromSetImmediateArguments(arguments),a=r.createElement("script")
return a.onreadystatechange=function(){e.runIfPresent(o),a.onreadystatechange=null,i.removeChild(a),a=null},i.appendChild(a),o}
return t.instance=this,t},t.prototype.createSetTimeoutSetImmediate=function(){var t=function t(){var e=t.instance,n=e.addFromSetImmediateArguments(arguments)
return e.root.setTimeout(e.partiallyApplied(e.runIfPresent,n),0),n}
return t.instance=this,t},t}()
e.ImmediateDefinition=o,e.Immediate=new o(i.root)}).call(e,n(102).clearImmediate,n(102).setImmediate)},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=function(t){function e(){var e=t.call(this,"Timeout has occurred")
this.name=e.name="TimeoutError",this.stack=e.stack,this.message=e.message}return r(e,t),e}(Error)
e.TimeoutError=i},function(t,e,n){"use strict"
var r=this&&this.__extends||function(t,e){function n(){this.constructor=t}for(var r in e)e.hasOwnProperty(r)&&(t[r]=e[r])
t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)},i=function(t){function e(e){t.call(this),this.errors=e
var n=Error.call(this,e?e.length+" errors occurred during unsubscription:\n  "+e.map(function(t,e){return e+1+") "+t.toString()}).join("\n  "):"")
this.name=n.name="UnsubscriptionError",this.stack=n.stack,this.message=n.message}return r(e,t),e}(Error)
e.UnsubscriptionError=i},function(t,e,n){"use strict"
function r(){}e.noop=r},function(t,e,n){"use strict"
function r(t,e,n){if(t){if(t instanceof i.Subscriber)return t
if(t[o.rxSubscriber])return t[o.rxSubscriber]()}return t||e||n?new i.Subscriber(t,e,n):new i.Subscriber(a.empty)}var i=n(1),o=n(84),a=n(125)
e.toSubscriber=r},function(t,e,n){(function(t,e){!function(t,n){"use strict"
function r(t){"function"!=typeof t&&(t=new Function(""+t))
for(var e=new Array(arguments.length-1),n=0;n<e.length;n++)e[n]=arguments[n+1]
var r={callback:t,args:e}
return v[h]=r,p(h),h++}function i(t){delete v[t]}function o(t){var e=t.callback,r=t.args
switch(r.length){case 0:e()
break
case 1:e(r[0])
break
case 2:e(r[0],r[1])
break
case 3:e(r[0],r[1],r[2])
break
default:e.apply(n,r)}}function a(t){if(y)setTimeout(a,0,t)
else{var e=v[t]
if(e){y=!0
try{o(e)}finally{i(t),y=!1}}}}function s(){p=function(t){e.nextTick(function(){a(t)})}}function u(){if(t.postMessage&&!t.importScripts){var e=!0,n=t.onmessage
return t.onmessage=function(){e=!1},t.postMessage("","*"),t.onmessage=n,e}}function c(){var e="setImmediate$"+Math.random()+"$",n=function(n){n.source===t&&"string"==typeof n.data&&0===n.data.indexOf(e)&&a(+n.data.slice(e.length))}
t.addEventListener?t.addEventListener("message",n,!1):t.attachEvent("onmessage",n),p=function(n){t.postMessage(e+n,"*")}}function l(){var t=new MessageChannel
t.port1.onmessage=function(t){a(t.data)},p=function(e){t.port2.postMessage(e)}}function f(){var t=m.documentElement
p=function(e){var n=m.createElement("script")
n.onreadystatechange=function(){a(e),n.onreadystatechange=null,t.removeChild(n),n=null},t.appendChild(n)}}function d(){p=function(t){setTimeout(a,0,t)}}if(!t.setImmediate){var p,h=1,v={},y=!1,m=t.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(t)
b=b&&b.setTimeout?b:t,"[object process]"==={}.toString.call(t.process)?s():u()?c():t.MessageChannel?l():m&&"onreadystatechange"in m.createElement("script")?f():d(),b.setImmediate=r,b.clearImmediate=i}}("undefined"==typeof self?void 0===t?this:t:self)}).call(e,n(9),n(19))},function(t,e,n){"use strict"
function r(t){return null==t?void 0===t?u:s:c&&c in Object(t)?n.i(o.a)(t):n.i(a.a)(t)}var i=n(138),o=n(332),a=n(333),s="[object Null]",u="[object Undefined]",c=i.a?i.a.toStringTag:void 0
e.a=r},function(t,e,n){"use strict";(function(t){var n="object"==typeof t&&t&&t.Object===Object&&t
e.a=n}).call(e,n(9))},function(t,e,n){"use strict"
var r=n(334),i=n.i(r.a)(Object.getPrototypeOf,Object)
e.a=i},function(t,e,n){"use strict"
function r(t){var e=a.call(t,u),n=t[u]
try{t[u]=void 0
var r=!0}catch(t){}var i=s.call(t)
return r&&(e?t[u]=n:delete t[u]),i}var i=n(138),o=Object.prototype,a=o.hasOwnProperty,s=o.toString,u=i.a?i.a.toStringTag:void 0
e.a=r},function(t,e,n){"use strict"
function r(t){return o.call(t)}var i=Object.prototype,o=i.toString
e.a=r},function(t,e,n){"use strict"
function r(t,e){return function(n){return t(e(n))}}e.a=r},function(t,e,n){"use strict"
var r=n(330),i="object"==typeof self&&self&&self.Object===Object&&self,o=r.a||i||Function("return this")()
e.a=o},function(t,e,n){"use strict"
function r(t){return null!=t&&"object"==typeof t}e.a=r},function(t,e,n){"use strict"
n(140),Object.assign},function(t,e,n){"use strict"},function(t,e,n){"use strict"
n(141),n(139),n(142)},function(t,e,n){"use strict"
var r=n(141)
n(339),n(338),n(337),n(140),n(142)
n.d(e,"a",function(){return r.a})},function(t,e,n){t.exports=n(342)},function(t,e,n){"use strict";(function(t,r){function i(t){return t&&t.__esModule?t:{default:t}}Object.defineProperty(e,"__esModule",{value:!0})
var o,a=n(343),s=i(a)
o="undefined"!=typeof self?self:"undefined"!=typeof window?window:void 0!==t?t:r
var u=(0,s.default)(o)
e.default=u}).call(e,n(9),n(145)(t))},function(t,e,n){"use strict"
function r(t){var e,n=t.Symbol
return"function"==typeof n?n.observable?e=n.observable:(e=n("observable"),n.observable=e):e="@@observable",e}Object.defineProperty(e,"__esModule",{value:!0}),e.default=r},function(t,e,n){"use strict"
n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i}),n.d(e,"c",function(){return o})
var r={marginBottom:"0px",position:"relative",WebkitTransform:"none",transform:"none",display:"block",contain:"layout"},i={display:"flex",WebkitBoxOrient:"horizontal",WebkitBoxDirection:"normal",msFlexFlow:"row nowrap",flexFlow:"row nowrap",WebkitBoxPack:"center",msFlexPack:"center",justifyContent:"center",WebkitBoxAlign:"center",msFlexAlign:"center",alignItems:"center",position:"relative"},o={display:"block",position:"absolute",left:"100%",top:"0%",backgroundColor:"red",color:"white",padding:"5px",cursor:"pointer",boxSizing:"border-box",width:"25px",height:"25px"}},function(t,e,n){"use strict"
e.a={position:"relative",boxSizing:"border-box",height:"0px",margin:"0px",textAlign:"center",display:"block"}},function(t,e,n){"use strict"
n.d(e,"a",function(){return r}),n.d(e,"b",function(){return i}),n.d(e,"c",function(){return o})
var r={height:"100px",marginBottom:"-100px",position:"relative",WebkitTransform:"translateY(-50px)",transform:"translateY(-50px)",display:"block"},i={background:["-webkit-linear-gradient(top,\n  rgba(0,0,0,0) 0%,\n  rgba(0,0,0,0) 48%,\n  rgba(125,185,232,1) 49%,\n  rgba(125,185,232,1) 51%,\n  rgba(0,0,0,0) 52%, rgba(0,0,0,0) 100%)","linear-gradient(to bottom,\n  rgba(0,0,0,0) 0%,\n  rgba(0,0,0,0) 48%,\n  rgba(125,185,232,1) 49%,\n  rgba(125,185,232,1) 51%,\n  rgba(0,0,0,0) 52%, rgba(0,0,0,0) 100%)"],display:"block"},o={fontSize:"1.8rem",color:"white",backgroundColor:"rgba(100,50,250,0.75)",fontFamily:"Inconsolata",width:"300px",height:"100px",display:"flex",WebkitBoxOrient:"vertical",WebkitBoxDirection:"normal",msFlexFlow:"column nowrap",flexFlow:"column nowrap",WebkitBoxPack:"center",msFlexPack:"center",justifyContent:"center",WebkitBoxAlign:"center",msFlexAlign:"center",alignItems:"center",position:"relative",margin:"0 auto"}},,function(t,e,n){"use strict"
Object.defineProperty(e,"__esModule",{value:!0})
var r=(n(38),n(39)),i=(n.n(r),n(144))
n.n(i)
n(143)}])

//# sourceMappingURL=header.js.map