(
    function(d){
        d.write('<span id="mag6919600"><img src="https://cm.g.doubleclick.net/pixel?google_nid=magnetic&amp;google_cm&amp;google_sc&amp;google_hm=fab6890e242d42b2a6a181c1b44690f7" width="1" height="1" style="display:none;"><img src="https://secure.adnxs.com/pxj?bidder=143&amp;seg=530156&amp;action=setuid(&quot;fab6890e242d42b2a6a181c1b44690f7&quot;)" width="1" height="1" style="display:none;"><img src="https://pixel.rubiconproject.com/tap.php?v=14256&amp;nid=2682&amp;expires=30&amp;put=fab6890e242d42b2a6a181c1b44690f7" width="1" height="1" style="display:none;"><img src="https://rtb.gumgum.com/usersync?b=mag&amp;i=fab6890e242d42b2a6a181c1b44690f7" width="1" height="1" style="display:none;"><img src="https://tapestry.tapad.com/tapestry/1?ta_partner_id=1032&amp;ta_partner_did=fab6890e242d42b2a6a181c1b44690f7&amp;ta_format=png" width="1" height="1" style="display:none;"></span>');
        if (d.getElementById('mag6919600')) {
            return;
        }
        var b=d.body||d.head;
        var i=function(u){var x=d.createElement('img');x.width=1;x.height=1;x.src=u;x.style.display='none';b.appendChild(x);};
        var s=function(u){var x=d.createElement('script');x.src=u;x.type='text/javascript';x.async=true;b.appendChild(x);};
        i("https://cm.g.doubleclick.net/pixel?google_nid=magnetic&google_cm&google_sc&google_hm=fab6890e242d42b2a6a181c1b44690f7");
i("https://secure.adnxs.com/pxj?bidder=143&seg=530156&action=setuid(\"fab6890e242d42b2a6a181c1b44690f7\")");
i("https://pixel.rubiconproject.com/tap.php?v=14256&nid=2682&expires=30&put=fab6890e242d42b2a6a181c1b44690f7");
i("https://rtb.gumgum.com/usersync?b=mag&i=fab6890e242d42b2a6a181c1b44690f7");
i("https://tapestry.tapad.com/tapestry/1?ta_partner_id=1032&ta_partner_did=fab6890e242d42b2a6a181c1b44690f7&ta_format=png");
    }
)(document);
