function FastClick(e,t){"use strict"
function n(e,t){return function(){return e.apply(t,arguments)}}var r
if(t=t||{},this.trackingClick=!1,this.trackingClickStart=0,this.targetElement=null,this.touchStartX=0,this.touchStartY=0,this.lastTouchIdentifier=0,this.touchBoundary=t.touchBoundary||10,this.layer=e,this.tapDelay=t.tapDelay||200,!FastClick.notNeeded(e)){for(var o=["onMouse","onClick","onTouchStart","onTouchMove","onTouchEnd","onTouchCancel"],i=this,a=0,s=o.length;s>a;a++)i[o[a]]=n(i[o[a]],i)
deviceIsAndroid&&(e.addEventListener("mouseover",this.onMouse,!0),e.addEventListener("mousedown",this.onMouse,!0),e.addEventListener("mouseup",this.onMouse,!0)),e.addEventListener("click",this.onClick,!0),e.addEventListener("touchstart",this.onTouchStart,!1),e.addEventListener("touchmove",this.onTouchMove,!1),e.addEventListener("touchend",this.onTouchEnd,!1),e.addEventListener("touchcancel",this.onTouchCancel,!1),Event.prototype.stopImmediatePropagation||(e.removeEventListener=function(t,n,r){var o=Node.prototype.removeEventListener
"click"===t?o.call(e,t,n.hijacked||n,r):o.call(e,t,n,r)},e.addEventListener=function(t,n,r){var o=Node.prototype.addEventListener
"click"===t?o.call(e,t,n.hijacked||(n.hijacked=function(e){e.propagationStopped||n(e)}),r):o.call(e,t,n,r)}),"function"==typeof e.onclick&&(r=e.onclick,e.addEventListener("click",function(e){r(e)},!1),e.onclick=null)}}function attr(e,t,n){if(e)try{for(var r in t)e.setAttribute(r,t[r])}catch(o){return e.hasAttribute(t)?e.getAttribute(t):n}}function attrClass(e,t){return e?attr(e,void 0===typeof t?"class":{"class":t}):void 0}function domCreate(e){return document.createElement(e)}(function(){"use strict"
function e(e){return"function"==typeof e||"object"==typeof e&&null!==e}function t(e){return"function"==typeof e}function n(e){return"object"==typeof e&&null!==e}function r(e,t){Q[H]=e,Q[H+1]=t,H+=2,2===H&&(F?F(u):W())}function o(e){F=e}function i(){var e=process.nextTick,t=process.versions.node.match(/^(?:(\d+)\.)?(?:(\d+)\.)?(\*|\d+)$/)
return Array.isArray(t)&&"0"===t[1]&&"10"===t[2]&&(e=setImmediate),function(){e(u)}}function a(){return function(){j(u)}}function s(){var e=0,t=new K(u),n=document.createTextNode("")
return t.observe(n,{characterData:!0}),function(){n.data=e=++e%2}}function l(){var e=new MessageChannel
return e.port1.onmessage=u,function(){e.port2.postMessage(0)}}function c(){return function(){setTimeout(u,1)}}function u(){for(var e=0;H>e;e+=2){var t=Q[e],n=Q[e+1]
t(n),Q[e]=void 0,Q[e+1]=void 0}H=0}function d(){try{var e=require,t=e("vertx")
return j=t.runOnLoop||t.runOnContext,a()}catch(n){return c()}}function p(){}function f(){return new TypeError("You cannot resolve a promise with itself")}function h(){return new TypeError("A promises callback cannot return that same promise.")}function m(e){try{return e.then}catch(t){return tt.error=t,tt}}function g(e,t,n,r){try{e.call(t,n,r)}catch(o){return o}}function v(e,t,n){Y(function(e){var r=!1,o=g(n,t,function(n){r||(r=!0,t!==n?w(e,n):E(e,n))},function(t){r||(r=!0,C(e,t))},"Settle: "+(e._label||" unknown promise"))
!r&&o&&(r=!0,C(e,o))},e)}function y(e,t){t._state===J?E(e,t._result):t._state===et?C(e,t._result):x(t,void 0,function(t){w(e,t)},function(t){C(e,t)})}function b(e,n){if(n.constructor===e.constructor)y(e,n)
else{var r=m(n)
r===tt?C(e,tt.error):void 0===r?E(e,n):t(r)?v(e,n,r):E(e,n)}}function w(t,n){t===n?C(t,f()):e(n)?b(t,n):E(t,n)}function _(e){e._onerror&&e._onerror(e._result),S(e)}function E(e,t){e._state===Z&&(e._result=t,e._state=J,0!==e._subscribers.length&&Y(S,e))}function C(e,t){e._state===Z&&(e._state=et,e._result=t,Y(_,e))}function x(e,t,n,r){var o=e._subscribers,i=o.length
e._onerror=null,o[i]=t,o[i+J]=n,o[i+et]=r,0===i&&e._state&&Y(S,e)}function S(e){var t=e._subscribers,n=e._state
if(0!==t.length){for(var r,o,i=e._result,a=0;a<t.length;a+=3)r=t[a],o=t[a+n],r?A(n,r,o,i):o(i)
e._subscribers.length=0}}function k(){this.error=null}function T(e,t){try{return e(t)}catch(n){return nt.error=n,nt}}function A(e,n,r,o){var i,a,s,l,c=t(r)
if(c){if(i=T(r,o),i===nt?(l=!0,a=i.error,i=null):s=!0,n===i)return void C(n,h())}else i=o,s=!0
n._state!==Z||(c&&s?w(n,i):l?C(n,a):e===J?E(n,i):e===et&&C(n,i))}function N(e,t){try{t(function(t){w(e,t)},function(t){C(e,t)})}catch(n){C(e,n)}}function M(e,t){var n=this
n._instanceConstructor=e,n.promise=new e(p),n._validateInput(t)?(n._input=t,n.length=t.length,n._remaining=t.length,n._init(),0===n.length?E(n.promise,n._result):(n.length=n.length||0,n._enumerate(),0===n._remaining&&E(n.promise,n._result))):C(n.promise,n._validationError())}function P(e){return new rt(this,e).promise}function D(e){function t(e){w(o,e)}function n(e){C(o,e)}var r=this,o=new r(p)
if(!z(e))return C(o,new TypeError("You must pass an array to race.")),o
for(var i=e.length,a=0;o._state===Z&&i>a;a++)x(r.resolve(e[a]),void 0,t,n)
return o}function I(e){var t=this
if(e&&"object"==typeof e&&e.constructor===t)return e
var n=new t(p)
return w(n,e),n}function R(e){var t=this,n=new t(p)
return C(n,e),n}function L(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function O(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function B(e){this._id=lt++,this._state=void 0,this._result=void 0,this._subscribers=[],p!==e&&(t(e)||L(),this instanceof B||O(),N(this,e))}function q(){var e
if("undefined"!=typeof global)e=global
else if("undefined"!=typeof self)e=self
else try{e=Function("return this")()}catch(t){throw new Error("polyfill failed because global object is unavailable in this environment")}var n=e.Promise;(!n||"[object Promise]"!==Object.prototype.toString.call(n.resolve())||n.cast)&&(e.Promise=ct)}var U
U=Array.isArray?Array.isArray:function(e){return"[object Array]"===Object.prototype.toString.call(e)}
var j,F,W,z=U,H=0,Y=({}.toString,r),V="undefined"!=typeof window?window:void 0,G=V||{},K=G.MutationObserver||G.WebKitMutationObserver,$="undefined"!=typeof process&&"[object process]"==={}.toString.call(process),X="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,Q=new Array(1e3)
W=$?i():K?s():X?l():void 0===V&&"function"==typeof require?d():c()
var Z=void 0,J=1,et=2,tt=new k,nt=new k
M.prototype._validateInput=function(e){return z(e)},M.prototype._validationError=function(){return new Error("Array Methods must be provided an Array")},M.prototype._init=function(){this._result=new Array(this.length)}
var rt=M
M.prototype._enumerate=function(){for(var e=this,t=e.length,n=e.promise,r=e._input,o=0;n._state===Z&&t>o;o++)e._eachEntry(r[o],o)},M.prototype._eachEntry=function(e,t){var r=this,o=r._instanceConstructor
n(e)?e.constructor===o&&e._state!==Z?(e._onerror=null,r._settledAt(e._state,t,e._result)):r._willSettleAt(o.resolve(e),t):(r._remaining--,r._result[t]=e)},M.prototype._settledAt=function(e,t,n){var r=this,o=r.promise
o._state===Z&&(r._remaining--,e===et?C(o,n):r._result[t]=n),0===r._remaining&&E(o,r._result)},M.prototype._willSettleAt=function(e,t){var n=this
x(e,void 0,function(e){n._settledAt(J,t,e)},function(e){n._settledAt(et,t,e)})}
var ot=P,it=D,at=I,st=R,lt=0,ct=B
B.all=ot,B.race=it,B.resolve=at,B.reject=st,B._setScheduler=o,B._asap=Y,B.prototype={constructor:B,then:function(e,t){var n=this,r=n._state
if(r===J&&!e||r===et&&!t)return this
var o=new this.constructor(p),i=n._result
if(r){var a=arguments[r-1]
Y(function(){A(r,o,a,i)})}else x(n,o,e,t)
return o},"catch":function(e){return this.then(null,e)}}
var ut=q,dt={Promise:ct,polyfill:ut}
"function"==typeof define&&define.amd?define("es6promise",[],function(){return dt}):"undefined"!=typeof module&&module.exports?module.exports=dt:"undefined"!=typeof this&&(this.ES6Promise=dt),ut()}).call(this)
var es6promise_init=!function(e,t){"function"==typeof define&&define.amd?define("es6promise_init",["es6promise"],t):t()}(this,function(e){e.polyfill()})
!function(e){"use strict"
function t(e){if("string"!=typeof e&&(e=String(e)),/[^a-z0-9\-#$%&'*+.\^_`|~]/i.test(e))throw new TypeError("Invalid character in header field name")
return e.toLowerCase()}function n(e){return"string"!=typeof e&&(e=String(e)),e}function r(e){this.map={},e instanceof r?e.forEach(function(e,t){this.append(t,e)},this):e&&Object.getOwnPropertyNames(e).forEach(function(t){this.append(t,e[t])},this)}function o(e){return e.bodyUsed?Promise.reject(new TypeError("Already read")):void(e.bodyUsed=!0)}function i(e){return new Promise(function(t,n){e.onload=function(){t(e.result)},e.onerror=function(){n(e.error)}})}function a(e){var t=new FileReader
return t.readAsArrayBuffer(e),i(t)}function s(e){var t=new FileReader
return t.readAsText(e),i(t)}function l(){return this.bodyUsed=!1,this._initBody=function(e){if(this._bodyInit=e,"string"==typeof e)this._bodyText=e
else if(h.blob&&Blob.prototype.isPrototypeOf(e))this._bodyBlob=e
else if(h.formData&&FormData.prototype.isPrototypeOf(e))this._bodyFormData=e
else if(e){if(!h.arrayBuffer||!ArrayBuffer.prototype.isPrototypeOf(e))throw new Error("unsupported BodyInit type")}else this._bodyText=""
this.headers.get("content-type")||("string"==typeof e?this.headers.set("content-type","text/plain;charset=UTF-8"):this._bodyBlob&&this._bodyBlob.type&&this.headers.set("content-type",this._bodyBlob.type))},h.blob?(this.blob=function(){var e=o(this)
if(e)return e
if(this._bodyBlob)return Promise.resolve(this._bodyBlob)
if(this._bodyFormData)throw new Error("could not read FormData body as blob")
return Promise.resolve(new Blob([this._bodyText]))},this.arrayBuffer=function(){return this.blob().then(a)},this.text=function(){var e=o(this)
if(e)return e
if(this._bodyBlob)return s(this._bodyBlob)
if(this._bodyFormData)throw new Error("could not read FormData body as text")
return Promise.resolve(this._bodyText)}):this.text=function(){var e=o(this)
return e?e:Promise.resolve(this._bodyText)},h.formData&&(this.formData=function(){return this.text().then(d)}),this.json=function(){return this.text().then(JSON.parse)},this}function c(e){var t=e.toUpperCase()
return m.indexOf(t)>-1?t:e}function u(e,t){t=t||{}
var n=t.body
if(u.prototype.isPrototypeOf(e)){if(e.bodyUsed)throw new TypeError("Already read")
this.url=e.url,this.credentials=e.credentials,t.headers||(this.headers=new r(e.headers)),this.method=e.method,this.mode=e.mode,n||(n=e._bodyInit,e.bodyUsed=!0)}else this.url=e
if(this.credentials=t.credentials||this.credentials||"omit",(t.headers||!this.headers)&&(this.headers=new r(t.headers)),this.method=c(t.method||this.method||"GET"),this.mode=t.mode||this.mode||null,this.referrer=null,("GET"===this.method||"HEAD"===this.method)&&n)throw new TypeError("Body not allowed for GET or HEAD requests")
this._initBody(n)}function d(e){var t=new FormData
return e.trim().split("&").forEach(function(e){if(e){var n=e.split("="),r=n.shift().replace(/\+/g," "),o=n.join("=").replace(/\+/g," ")
t.append(decodeURIComponent(r),decodeURIComponent(o))}}),t}function p(e){var t=new r,n=e.getAllResponseHeaders().trim().split("\n")
return n.forEach(function(e){var n=e.trim().split(":"),r=n.shift().trim(),o=n.join(":").trim()
t.append(r,o)}),t}function f(e,t){t||(t={}),this.type="default",this.status=t.status,this.ok=this.status>=200&&this.status<300,this.statusText=t.statusText,this.headers=t.headers instanceof r?t.headers:new r(t.headers),this.url=t.url||"",this._initBody(e)}if(!e.fetch){r.prototype.append=function(e,r){e=t(e),r=n(r)
var o=this.map[e]
o||(o=[],this.map[e]=o),o.push(r)},r.prototype.delete=function(e){delete this.map[t(e)]},r.prototype.get=function(e){var n=this.map[t(e)]
return n?n[0]:null},r.prototype.getAll=function(e){return this.map[t(e)]||[]},r.prototype.has=function(e){return this.map.hasOwnProperty(t(e))},r.prototype.set=function(e,r){this.map[t(e)]=[n(r)]},r.prototype.forEach=function(e,t){Object.getOwnPropertyNames(this.map).forEach(function(n){this.map[n].forEach(function(r){e.call(t,r,n,this)},this)},this)}
var h={blob:"FileReader"in e&&"Blob"in e&&function(){try{return new Blob,!0}catch(e){return!1}}(),formData:"FormData"in e,arrayBuffer:"ArrayBuffer"in e},m=["DELETE","GET","HEAD","OPTIONS","POST","PUT"]
u.prototype.clone=function(){return new u(this)},l.call(u.prototype),l.call(f.prototype),f.prototype.clone=function(){return new f(this._bodyInit,{status:this.status,statusText:this.statusText,headers:new r(this.headers),url:this.url})},f.error=function(){var e=new f(null,{status:0,statusText:""})
return e.type="error",e}
var g=[301,302,303,307,308]
f.redirect=function(e,t){if(-1===g.indexOf(t))throw new RangeError("Invalid status code")
return new f(null,{status:t,headers:{location:e}})},e.Headers=r,e.Request=u,e.Response=f,e.fetch=function(e,t){return new Promise(function(n,r){function o(){return"responseURL"in a?a.responseURL:/^X-Request-URL:/m.test(a.getAllResponseHeaders())?a.getResponseHeader("X-Request-URL"):void 0}var i
i=u.prototype.isPrototypeOf(e)&&!t?e:new u(e,t)
var a=new XMLHttpRequest
a.onload=function(){var e={status:a.status,statusText:a.statusText,headers:p(a),url:o()},t="response"in a?a.response:a.responseText
n(new f(t,e))},a.onerror=function(){r(new TypeError("Network request failed"))},a.open(i.method,i.url,!0),"include"===i.credentials&&(a.withCredentials=!0),"responseType"in a&&h.blob&&(a.responseType="blob"),i.headers.forEach(function(e,t){a.setRequestHeader(t,e)}),a.send("undefined"==typeof i._bodyInit?null:i._bodyInit)})},e.fetch.polyfill=!0}}("undefined"!=typeof self?self:this),define("fetch",function(){}),define("app/utils",[],function(){!function(){function e(e,t){t=t||{bubbles:!1,cancelable:!1,detail:void 0}
var n=document.createEvent("CustomEvent")
return n.initCustomEvent(e,t.bubbles,t.cancelable,t.detail),n}return"function"==typeof window.CustomEvent?!1:(e.prototype=window.Event.prototype,void(window.CustomEvent=e))}(),function(){var e=!1
try{var t=Object.defineProperty({},"passive",{get:function(){e=!0}})
window.addEventListener("test",null,t)}catch(n){}var r=function(t,n,r){var r=r||window,o=!1,i=function(){o||(o=!0,requestAnimationFrame(function(){r.dispatchEvent(new CustomEvent(n)),o=!1}))}
"scroll"===t?r.addEventListener("scroll",i,e?{passive:!0}:!1):r.addEventListener(t,i)}
r("scroll","optimizedScroll"),r("resize","optimizedResize")}()
var e={slugify:function(e){return e.replace(/[' ']/g,"-").toLowerCase()},namify:function(e){return e.replace(/[' '-]/g,"_").toLowerCase()},isTouchDevice:function(){return"ontouchstart"in window||navigator.MaxTouchPoints>0||navigator.msMaxTouchPoints>0},updateBodyClasses:function(){document.body.className+=this.isTouchDevice()?" touch":" no-touch"},toSentenceCase:function(e){return e.replace(/\w\S*/g,function(e){return e.charAt(0).toUpperCase()+e.substr(1).toLowerCase()})},inArray:function(e,t){for(var n=t.length,r=0;n>r;r++)if(t[r]==e)return!0
return!1},isHidden:function(e){return null===e.offsetParent},hasClass:function(e,t){if(void 0===e)throw new Error("invalid node")
return(" "+e.className+" ").indexOf(" "+t+" ")>-1},shuffle:function(e){for(var t,n,r=e.length;0!==r;)n=Math.floor(Math.random()*r),r-=1,t=e[r],e[r]=e[n],e[n]=t
return e},removeClass:function(e,t){e.className=e.className.replace(new RegExp("(?:^|\\s)"+t+"(?!\\S)"),"")},addClass:function(e,t){this.hasClass(e,t)||(e.className+=" "+t+" ")},isTouchDevice:function(){return window.hasOwnProperty("ontouchstart")&&void 0!==window.ontouchstart},windowScrollTop:function(){return document.documentElement.scrollTop||document.body.scrollTop||window.pageYOffset},findElementRuns:function(e,t){if(null==e)return[]
for(var n=[],r=e.children,o=!1,i=0;i<r.length;i++){var a=r[i]
"engagement-warning"==a.id||"engagement-block"==a.id||a.classList.length>0?o=!1:a.nodeName.toUpperCase()==t.toUpperCase()?(o?n[n.length-1].length++:n.push({index:i,length:1}),o=!0):o=!1}return n},scrollToTop:function(e){var t=e.getBoundingClientRect(),n=document.body.getBoundingClientRect()
window.scrollTo(0,t.top-n.top)},titleSuffix:"",setTitleSuffix:function(t){e.titleSuffix=t},setTitle:function(t){document.querySelector("head title").innerHTML=t+e.titleSuffix}}
return e}),function(e,t){"function"==typeof define&&define.amd?define("swipejs",[],function(){return e.Swipe=t()}):"object"==typeof exports?module.exports=t():e.Swipe=t()}(this,function(){function e(e,r){"use strict"
function o(){w=x.children,C=w.length,w.length<2&&(r.continuous=!1),b.transitions&&r.continuous&&w.length<3&&(x.appendChild(w[0].cloneNode(!0)),x.appendChild(x.children[1].cloneNode(!0)),w=x.children),_=new Array(w.length),E=e.getBoundingClientRect().width||e.offsetWidth,x.style.width=w.length*E+"px"
for(var t=w.length;t--;){var n=w[t]
n.style.width=E+"px",n.setAttribute("data-index",t),b.transitions&&(n.style.left=t*-E+"px",u(t,S>t?-E:t>S?E:0,0))}r.continuous&&b.transitions&&(u(s(S-1),-E,0),u(s(S+1),E,0)),b.transitions||(x.style.left=S*-E+"px"),e.style.visibility="visible"}function i(){r.continuous?c(S-1):S&&c(S-1)}function a(){r.continuous?c(S+1):S<w.length-1&&c(S+1)}function s(e){return(w.length+e%w.length)%w.length}function l(){var e=S
return e>=C&&(e-=C),e}function c(e,t){if(S!==e){if(b.transitions){var n=Math.abs(S-e)/(S-e)
if(r.continuous){var o=n
n=-_[s(e)]/E,n!==o&&(e=-n*w.length+e)}for(var i=Math.abs(S-e)-1;i--;)u(s((e>S?e:S)-i-1),E*n,0)
e=s(e),u(S,E*n,t||k),u(e,0,t||k),r.continuous&&u(s(e-n),-(E*n),0)}else e=s(e),p(S*-E,e*-E,t||k)
S=e,y(r.callback&&r.callback(l(),w[S]))}}function u(e,t,n){d(e,t,n),_[e]=t}function d(e,t,n){var r=w[e],o=r&&r.style
o&&(o.webkitTransitionDuration=o.MozTransitionDuration=o.msTransitionDuration=o.OTransitionDuration=o.transitionDuration=n+"ms",o.webkitTransform="translate("+t+"px,0)translateZ(0)",o.msTransform=o.MozTransform=o.OTransform="translateX("+t+"px)")}function p(e,t,n){if(!n)return void(x.style.left=t+"px")
var o=+new Date,i=setInterval(function(){var a=+new Date-o
return a>n?(x.style.left=t+"px",N&&f(),r.transitionEnd&&r.transitionEnd.call(event,l(),w[S]),void clearInterval(i)):void(x.style.left=(t-e)*(Math.floor(a/n*100)/100)+e+"px")},4)}function f(){T=setTimeout(a,N)}function h(){N=0,clearTimeout(T)}function m(){h(),N=r.auto||0,f()}function g(e){return/^mouse/.test(e.type)}var v=function(){},y=function(e){setTimeout(e||v,0)},b={addEventListener:!!t.addEventListener,touch:"ontouchstart"in t||t.DocumentTouch&&n instanceof DocumentTouch,transitions:function(e){var t=["transitionProperty","WebkitTransition","MozTransition","OTransition","msTransition"]
for(var n in t)if(void 0!==e.style[t[n]])return!0
return!1}(n.createElement("swipe"))}
if(e){var w,_,E,C,x=e.children[0]
r=r||{}
var S=parseInt(r.startSlide,10)||0,k=r.speed||300
r.continuous=void 0!==r.continuous?r.continuous:!0,r.autoRestart=void 0!==r.autoRestart?r.autoRestart:!0
var T,A,N=r.auto||0,M={},P={},D={handleEvent:function(e){switch(e.type){case"mousedown":case"touchstart":this.start(e)
break
case"mousemove":case"touchmove":this.move(e)
break
case"mouseup":case"mouseleave":case"touchend":y(this.end(e))
break
case"webkitTransitionEnd":case"msTransitionEnd":case"oTransitionEnd":case"otransitionend":case"transitionend":y(this.transitionEnd(e))
break
case"resize":y(o)}r.stopPropagation&&e.stopPropagation()},start:function(e){var t=g(e)?e:e.touches[0]
M={x:t.pageX,y:t.pageY,time:+new Date},A=void 0,P={},g(e)?(x.addEventListener("mousemove",this,!1),x.addEventListener("mouseup",this,!1),x.addEventListener("mouseleave",this,!1)):(x.addEventListener("touchmove",this,!1),x.addEventListener("touchend",this,!1))},move:function(e){var t
if(g(e))t=e
else{if(e.touches.length>1||e.scale&&1!==e.scale)return
r.disableScroll&&e.preventDefault(),t=e.touches[0]}P={x:t.pageX-M.x,y:t.pageY-M.y},"undefined"==typeof A&&(A=!!(A||Math.abs(P.x)<Math.abs(P.y))),A||(e.preventDefault(),h(),r.continuous?(d(s(S-1),P.x+_[s(S-1)],0),d(S,P.x+_[S],0),d(s(S+1),P.x+_[s(S+1)],0)):(P.x=P.x/(!S&&P.x>0||S===w.length-1&&P.x<0?Math.abs(P.x)/E+1:1),d(S-1,P.x+_[S-1],0),d(S,P.x+_[S],0),d(S+1,P.x+_[S+1],0)))},end:function(e){var t=+new Date-M.time,n=Number(t)<250&&Math.abs(P.x)>20||Math.abs(P.x)>E/2,o=!S&&P.x>0||S===w.length-1&&P.x<0
r.continuous&&(o=!1)
var i=P.x<0
A||(n&&!o?(i?(r.continuous?(u(s(S-1),-E,0),u(s(S+2),E,0)):u(S-1,-E,0),u(S,_[S]-E,k),u(s(S+1),_[s(S+1)]-E,k),S=s(S+1)):(r.continuous?(u(s(S+1),E,0),u(s(S-2),-E,0)):u(S+1,E,0),u(S,_[S]+E,k),u(s(S-1),_[s(S-1)]+E,k),S=s(S-1)),r.callback&&r.callback(l(),w[S])):r.continuous?(u(s(S-1),-E,k),u(S,0,k),u(s(S+1),E,k)):(u(S-1,-E,k),u(S,0,k),u(S+1,E,k))),g(e)?(x.removeEventListener("mousemove",D,!1),x.removeEventListener("mouseup",D,!1),x.removeEventListener("mouseleave",D,!1)):(x.removeEventListener("touchmove",D,!1),x.removeEventListener("touchend",D,!1))},transitionEnd:function(e){parseInt(e.target.getAttribute("data-index"),10)===S&&((N||r.autoRestart)&&m(),r.transitionEnd&&r.transitionEnd.call(e,l(),w[S]))}}
return o(),N&&f(),b.addEventListener?(b.touch&&x.addEventListener("touchstart",D,!1),r.draggable&&x.addEventListener("mousedown",D,!1),b.transitions&&(x.addEventListener("webkitTransitionEnd",D,!1),x.addEventListener("msTransitionEnd",D,!1),x.addEventListener("oTransitionEnd",D,!1),x.addEventListener("otransitionend",D,!1),x.addEventListener("transitionend",D,!1)),t.addEventListener("resize",D,!1)):t.onresize=function(){o()},{setup:function(){o()},slide:function(e,t){h(),c(e,t)},prev:function(){h(),i()},next:function(){h(),a()},restart:function(){m()},stop:function(){h()},getPos:function(){return l()},getNumSlides:function(){return C},kill:function(){h(),x.style.width="",x.style.left=""
for(var e=w.length;e--;){var n=w[e]
n.style.width="",n.style.left="",b.transitions&&d(e,0,0)}b.addEventListener?(x.removeEventListener("touchstart",D,!1),x.removeEventListener("mousedown",D,!1),x.removeEventListener("webkitTransitionEnd",D,!1),x.removeEventListener("msTransitionEnd",D,!1),x.removeEventListener("oTransitionEnd",D,!1),x.removeEventListener("otransitionend",D,!1),x.removeEventListener("transitionend",D,!1),t.removeEventListener("resize",D,!1)):t.onresize=null}}}}var t=this,n=t.document
return(t.jQuery||t.Zepto)&&!function(t){t.fn.Swipe=function(n){return this.each(function(){t(this).data("Swipe",new e(t(this)[0],n))})}}(t.jQuery||t.Zepto),e}),define("app/image-gallery",["swipejs"],function(e){var t={init:function(t){function n(e,t){var n=t.querySelectorAll("figcaption, .slide-title, .slide-description")
for(i=0;i<n.length;i++)n[i].style.display="block"
if(e>0)o=t.previousSibling,r(o)
else if(0==e){var o=document.querySelector(".inlinegallery-wrap").lastChild
r(o)}e+1!==s.length&&(o=t.nextSibling,r(o))}function r(e){prevNextSlideContents=e.querySelectorAll("figcaption, .slide-title, .slide-description"),o(prevNextSlideContents)}function o(e){for(i=0;i<e.length;i++)e[i].style.display="none"}if(null!=t){var i,a,s=t.querySelectorAll(".slidecount"),l=document.createElement("a"),c=document.createElement("a"),u=function(e){var t
for(t=0;a>t;t+=1)s[t].className=s[t].className.replace(" current","")
s[e].className+=" current"},d=e(t,{auto:0,autoRestart:!1,draggable:!0,transitionEnd:function(e,t){u(e),(-1!==window.location.host.indexOf("pcgamer")||-1!==window.location.host.indexOf("gamesradar"))&&n(e,t)}}),p=document.createElement("div")
if(p.setAttribute("class","counts"),s.length)for(a=s.length,s=Array.prototype.slice.call(s),i=0;a>i;i+=1)p.appendChild(s[i])
t.insertBefore(p,t.firstChild),u(0),l.setAttribute("class","inlinegallery-btn next"),l.innerHTML='<i class="icon icon-arrow-right"></i>',c.setAttribute("class","inlinegallery-btn prev"),c.innerHTML='<i class="icon icon-arrow-left"></i>',l.onclick=function(e){e.preventDefault(),d.next()},c.onclick=function(e){e.preventDefault(),d.prev()},t.appendChild(l),t.appendChild(c)}}},n=document.querySelectorAll(".inlinegallery")
if(n)for(i=0;i<n.length;i++)t.init(n[i])
return t}),define("app/mediainserts",["app/image-gallery"],function(e){"use strict"
var t={providers:{poll:{getId:function(){return this.el.attributes.src.value},build:function(){var e=document.createElement("p"),t=document.createElement("div")
e.setAttribute("class","polldaddy PD_superContainer"),t.setAttribute("class","PDS_Poll"),t.setAttribute("id","PDI_container"+this.getId()),e.appendChild(t),this.mediaNode=e},insert:function(e){this.el=e,this.id=this.getId(),this.build(),t.replace.bind(this)(),t.loadScript("http://static.polldaddy.com/p/"+this.id+".js")}},"insert-gallery":{getId:function(){return this.el.attributes.src.value},insert:function(n){this.el=n,this.id=this.getId()
var r=this,o=function(){if(4===i.readyState)if(200===i.status){var n=document.createElement("div")
n.innerHTML=i.responseText,r.mediaNode=n,t.replace.bind(r)(),e.init()}else console.log("Failed to load inline gallery id: "+r.id)},i=new XMLHttpRequest
i.onreadystatechange=o,i.open("GET","/panels/ssi/gallery/"+this.id),i.send()}},YouTube:{build:function(){var e=document.createElement("p"),t=document.createElement("iframe")
t.setAttribute("type","text/html"),t.setAttribute("src","http://www.youtube.com/embed/"+this.id),t.setAttribute("frameborder",0),t.setAttribute("allowfullscreen",!0),e.classList.add("youtube-video"),e.appendChild(t),this.mediaNode=e},getId:function(){var e=this.el.attributes.src.value,n="?"+e.split("?")[1]
return t.getParameterByName(n,"v")},insert:function(e){this.el=e,this.id=this.getId(),this.build(),t.replace.bind(this)()}},soundcloud:{build:function(){var e=document.createElement("iframe")
e.setAttribute("type","text/html"),e.setAttribute("src","https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/"+this.id+"&show_artwork=false&auto_play=false&color=0066cc"),e.setAttribute("frameborder",0),e.setAttribute("scrolling","no"),e.setAttribute("allowfullscreen",!0),e.setAttribute("height",450),e.setAttribute("width","100%"),this.mediaNode=e},getId:function(){var e=this.el.attributes.src.value,t=e.split("/")
return t[t.length-1]},insert:function(e){this.el=e,this.id=this.getId(),this.build(),t.replace.bind(this)()}},vimeo:{getId:function(){return this.el.attributes.src.value},build:function(){var e=document.createElement("p"),t=document.createElement("iframe")
t.setAttribute("frameborder",0),t.setAttribute("allowfullscreen",!0),t.setAttribute("src","https://player.vimeo.com/video/"+this.id),e.classList.add("youtube-video"),e.appendChild(t),this.mediaNode=e},insert:function(e){this.el=e,this.id=this.getId(),this.build(),t.replace.bind(this)()}}},getParameterByName:function(e,t){t=t.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]")
var n=new RegExp("[\\?&]"+t+"=([^&#]*)"),r=n.exec(e)
return null===r?"":decodeURIComponent(r[1].replace(/\+/g," "))},loadScript:function(e){var t=document.createElement("script")
t.setAttribute("type","text/javascript"),t.setAttribute("src",e),t.setAttribute("async","async"),document.head.appendChild(t)},replace:function(){this.mediaNode&&this.el.parentNode.replaceChild(this.mediaNode,this.el)}},n=function(e){[].forEach.call(e,function(e){var n=e.attributes.mediatype.value
if(t.providers[n]){var r=t.providers[n]
r.insert(e)}})}
n(document.querySelectorAll("[mediatype]"))}),!function(e,t,n){"use strict"
function r(e){return e.trim?e.trim():e.replace(/^\s+|\s+$/g,"")}function o(){var t
Y=!1,K=e.devicePixelRatio,V={},G={},t=(K||1)*N.xQuant,N.uT||(N.maxX=Math.max(1.3,N.maxX),t=Math.min(t,N.maxX),_.DPR=t),$.width=Math.max(e.innerWidth||0,T.clientWidth),$.height=Math.max(e.innerHeight||0,T.clientHeight),$.vw=$.width/100,$.vh=$.height/100,$.em=_.getEmValue(),$.rem=$.em,m=N.lazyFactor/2,m=m*t+m,v=.1*t,p=.5+.2*t,f=.5+.25*t,g=t+1.3,(h=$.width>$.height)||(m*=.9),L&&(m*=.9)}function i(e,t,n){var r=t*Math.pow(e,2)
return h||(r/=1.3),e+=r,e>n}function a(e){if(!e.getBoundingClientRect)return!0
var t,n,r,o,i=e.getBoundingClientRect()
return!!((t=i.bottom)>=-9&&(o=i.top)<=$.height+9&&(n=i.right)>=-9&&(r=i.left)<=$.height+9&&(t||n||r||o))}function s(e){var t,n=_.getSet(e),r=!1
"pending"!=n&&(r=!0,n&&(t=_.setRes(n),r=_.applySetCandidate(t,e))),e[_.ns].evaled=r}function l(e,t){return e.res-t.res}function c(e,t,n){var r
return!n&&t&&(n=e[_.ns].sets,n=n&&n[n.length-1]),r=u(t,n),r&&(t=_.makeUrl(t),e[_.ns].curSrc=t,e[_.ns].curCan=r,r.res||nt(r,r.set.sizes)),r}function u(e,t){var n,r,o
if(e&&t)for(o=_.parseSet(t),e=_.makeUrl(e),n=0;n<o.length;n++)if(e==_.makeUrl(o[n].url)){r=o[n]
break}return r}function d(e,t){var n,r,o,i,a=e.getElementsByTagName("source")
for(n=0,r=a.length;r>n;n++)o=a[n],o[_.ns]=!0,i=o.getAttribute("srcset"),i&&t.push({srcset:i,media:o.getAttribute("media"),type:o.getAttribute("type"),sizes:o.getAttribute("sizes")})}t.createElement("picture")
var p,f,h,m,g,v,y,b,w,_={},E=function(){},C=t.createElement("img"),x=C.getAttribute,S=C.setAttribute,k=C.removeAttribute,T=t.documentElement,A={},N={xQuant:1,lazyFactor:.4,maxX:2},M="data-risrc",P=M+"set",D="webkitBackfaceVisibility"in T.style,I=navigator.userAgent,R=/AppleWebKit/i.test(I),L=/rident/.test(I)||/ecko/.test(I)&&I.match(/rv\:(\d+)/)&&RegExp.$1>35,O=0,B="currentSrc",q=/\s+\+?\d+(e\d+)?w/,U=/(\([^)]+\))?\s*(.+)/,j=/^([\+eE\d\.]+)(w|x)$/,F=/\s*\d+h\s*/,W=e.respimgCFG,z=("https:"==location.protocol,"position:absolute;left:0;visibility:hidden;display:block;padding:0;border:none;font-size:1em;width:1em;overflow:hidden;clip:rect(0px, 0px, 0px, 0px)"),H="font-size:100%!important;",Y=!0,V={},G={},K=e.devicePixelRatio,$={px:1,"in":96},X=t.createElement("a"),Q=!1,Z=function(e,t,n,r){e.addEventListener?e.addEventListener(t,n,r||!1):e.attachEvent&&e.attachEvent("on"+t,n)},J=function(e,t,n,r){e.removeEventListener?e.removeEventListener(t,n,r||!1):e.detachEvent&&e.detachEvent("on"+t,n)},et=function(e){var t={}
return function(n){return n in t||(t[n]=e(n)),t[n]}},tt=function(){var e=/^([\d\.]+)(em|vw|px)$/,t=function(){for(var e=arguments,t=0,n=e[0];++t in e;)n=n.replace(e[t],e[++t])
return n},n=et(function(e){return"return "+t((e||"").toLowerCase(),/\band\b/g,"&&",/,/g,"||",/min-([a-z-\s]+):/g,"e.$1>=",/max-([a-z-\s]+):/g,"e.$1<=",/calc([^)]+)/g,"($1)",/(\d+[\.]*[\d]*)([a-z]+)/g,"($1 * e.$2)",/^(?!(e.[a-z]|[0-9\.&=|><\+\-\*\(\)\/])).*/gi,"")})
return function(t,r){var o
if(!(t in V))if(V[t]=!1,r&&(o=t.match(e)))V[t]=o[1]*$[o[2]]
else try{V[t]=new Function("e",n(t))($)}catch(i){}return V[t]}}(),nt=function(e,t){return e.w?(e.cWidth=_.calcListLength(t||"100vw"),e.res=e.w/e.cWidth):e.res=e.x,e},rt=function(e){var n,r,o,i=e||{}
if(i.elements&&1==i.elements.nodeType&&("IMG"==i.elements.nodeName.toUpperCase()?i.elements=[i.elements]:(i.context=i.elements,i.elements=null)),n=i.elements||_.qsa(i.context||t,i.reevaluate||i.reparse?_.sel:_.selShort),o=n.length){for(_.setupRun(i),Q=!0,r=0;o>r;r++)O++,6>O&&!n[r].complete&&O++,_.fillImg(n[r],i)
_.teardownRun(i),O++}},ot=function(){var e=function(){J(this,"load",e),J(this,"error",e),_.fillImgs({elements:[this]})}
return function(t){J(t,"load",e),J(t,"error",e),Z(t,"error",e),Z(t,"load",e)}}(),it=et(function(e){var t=[1,"x"],n=r(e||"")
return n&&(n=n.replace(F,""),t=n.match(j)?[1*RegExp.$1,RegExp.$2]:!1),t})
B in C||(B="src"),A["image/jpeg"]=!0,A["image/gif"]=!0,A["image/png"]=!0,A["image/svg+xml"]=t.implementation.hasFeature("http://wwwindow.w3.org/TR/SVG11/feature#Image","1.1"),_.ns=("ri"+(new Date).getTime()).substr(0,9),_.supSrcset="srcset"in C,_.supSizes="sizes"in C,_.selShort="picture>img,img[srcset]",_.sel=_.selShort,_.cfg=N,_.supSrcset&&(_.sel+=",img["+P+"]"),_.DPR=K||1,_.u=$,_.types=A,b=_.supSrcset&&!_.supSizes,_.setSize=E,_.makeUrl=et(function(e){return X.href=e,X.href}),_.qsa=function(e,t){return e.querySelectorAll(t)},_.matchesMedia=function(){return _.matchesMedia=e.matchMedia&&(matchMedia("(min-width: 0.1em)")||{}).matches?function(e){return!e||matchMedia(e).matches}:_.mMQ,_.matchesMedia.apply(this,arguments)},_.mMQ=function(e){return e?tt(e):!0},_.calcLength=function(e){var t=tt(e,!0)||!1
return 0>t&&(t=!1),t},_.supportsType=function(e){return e?A[e]:!0},_.parseSize=et(function(e){var t=(e||"").match(U)
return{media:t&&t[1],length:t&&t[2]}}),_.parseSet=function(e){if(!e.cands){var t,n,r,o,i,a,s=e.srcset
for(e.cands=[];s;)s=s.replace(/^\s+/g,""),t=s.search(/\s/g),r=null,-1!=t?(n=s.slice(0,t),o=n.charAt(n.length-1),","!=o&&n||(n=n.replace(/,+$/,""),r=""),s=s.slice(t+1),null==r&&(i=s.indexOf(","),-1!=i?(r=s.slice(0,i),s=s.slice(i+1)):(r=s,s=""))):(n=s,s=""),n&&(r=it(r))&&(a={url:n.replace(/^,+/,""),set:e},a[r[1]]=r[0],"x"==r[1]&&1==r[0]&&(e.has1x=!0),e.cands.push(a))}return e.cands},_.getEmValue=function(){var e
if(!y&&(e=t.body)){var n=t.createElement("div"),r=T.style.cssText,o=e.style.cssText
n.style.cssText=z,T.style.cssText=H,e.style.cssText=H,e.appendChild(n),y=n.offsetWidth,e.removeChild(n),y=parseFloat(y,10),T.style.cssText=r,e.style.cssText=o}return y||16},_.calcListLength=function(e){if(!(e in G)||N.uT){var t,n,o,i,a,s,l=r(e).split(/\s*,\s*/),c=!1
for(a=0,s=l.length;s>a&&(t=l[a],n=_.parseSize(t),o=n.length,i=n.media,!o||!_.matchesMedia(i)||(c=_.calcLength(o))===!1);a++);G[e]=c?c:$.width}return G[e]},_.setRes=function(e){var t
if(e){t=_.parseSet(e)
for(var n=0,r=t.length;r>n;n++)nt(t[n],e.sizes)}return t},_.setRes.res=nt,_.applySetCandidate=function(e,t){if(e.length){var n,r,o,s,u,d,h,y,b,w,E,C,S,k=t[_.ns],T=!0,A=m,N=v
if(y=k.curSrc||t[B],b=k.curCan||c(t,y,e[0].set),r=_.DPR,S=b&&b.res,!h&&y&&(C=L&&!t.complete&&b&&S>r,C||b&&!(g>S)||(b&&r>S&&S>p&&(f>S&&(A*=.87,N+=.04*r),b.res+=A*Math.pow(S-N,2)),w=!k.pic||b&&b.set==e[0].set,b&&w&&b.res>=r?h=b:R||t.complete||!x.call(t,"src")||t.lazyload||L&&!(4>O)||!w&&a(t)||(h=b,E=y,T="L",ot(t)))),!h)for(S&&(b.res=b.res-(b.res-S)/2),e.sort(l),d=e.length,h=e[d-1],o=0;d>o;o++)if(n=e[o],n.res>=r){s=o-1,h=e[s]&&(u=n.res-r)&&(C||y!=_.makeUrl(n.url))&&i(e[s].res,u,r)?e[s]:n
break}return S&&(b.res=S),h&&(E=_.makeUrl(h.url),k.curSrc=E,k.curCan=h,E!=y&&_.setSrc(t,h),_.setSize(t)),T}},_.setSrc=function(e,t){var n
e.src=t.url,D&&(n=e.style.zoom,e.style.zoom="0.999",e.style.zoom=n)},_.getSet=function(e){var t,n,r,o=!1,i=e[_.ns].sets
for(t=0;t<i.length&&!o;t++)if(n=i[t],n.srcset&&_.matchesMedia(n.media)&&(r=_.supportsType(n.type))){"pending"==r&&(n=r),o=n
break}return o},_.parseSets=function(e,t,r){var o,i,a,s,l="PICTURE"==t.nodeName.toUpperCase(),c=e[_.ns];(c.src===n||r.src)&&(c.src=x.call(e,"src"),c.src?S.call(e,M,c.src):k.call(e,M)),(c.srcset===n||!_.supSrcset||e.srcset||r.srcset)&&(o=x.call(e,"srcset"),c.srcset=o,s=!0),c.sets=[],l&&(c.pic=!0,d(t,c.sets)),c.srcset?(i={srcset:c.srcset,sizes:x.call(e,"sizes")},c.sets.push(i),a=(b||c.src)&&q.test(c.srcset||""),a||!c.src||u(c.src,i)||i.has1x||(i.srcset+=", "+c.src,i.cands.push({url:c.src,x:1,set:i}))):c.src&&c.sets.push({srcset:c.src,sizes:null}),c.curCan=null,c.curSrc=n,c.supported=!(l||i&&!_.supSrcset||a),s&&_.supSrcset&&!c.supported&&(o?(S.call(e,P,o),e.srcset=""):k.call(e,P)),c.supported&&!c.srcset&&(!c.src&&e.src||e.src!=_.makeUrl(c.src))&&(null==c.src?e.removeAttribute("src"):e.src=c.src),c.parsed=!0},_.fillImg=function(e,t){var n,r,o=t.reparse||t.reevaluate
if(e[_.ns]||(e[_.ns]={}),r=e[_.ns],"L"==r.evaled&&e.complete&&(r.evaled=!1),o||!r.evaled){if(!r.parsed||t.reparse){if(n=e.parentNode,!n)return
_.parseSets(e,n,t)}r.supported?r.evaled=!0:s(e)}},_.setupRun=function(e){(!Q||e.reevaluate||Y)&&(o(),e.elements||e.context||clearTimeout(w))},e.HTMLPictureElement?(rt=E,_.fillImg=E):!function(){var n,r=e.attachEvent?/d$|^c/:/d$|^c|^i/,o=function(){var e=t.readyState||""
s=setTimeout(o,"loading"==e?200:999),t.body&&(n=n||r.test(e),_.fillImgs(),n&&(O+=6,clearTimeout(s)))},i=function(){_.fillImgs({reevaluate:!0})},a=function(){clearTimeout(w),Y=!0,w=setTimeout(i,99)},s=setTimeout(o,t.body?9:99)
Z(e,"resize",a),Z(t,"readystatechange",o)}(),_.respimage=rt,_.fillImgs=rt,_.teardownRun=E,rt._=_,e.respimage=rt,e.respimgCFG={ri:_,push:function(e){var t=e.shift()
"function"==typeof _[t]?_[t].apply(_,e):(N[t]=e[0],Q&&_.fillImgs({reevaluate:!0}))}}
for(;W&&W.length;)e.respimgCFG.push(W.shift())}(window,document),define("respimage",function(){}),!function(e,t){e.lazySizes=t(e,e.document),"function"==typeof define&&define.amd&&define("lazysizes",e.lazySizes)}(window,function(e,t){"use strict"
if(t.getElementsByClassName){var n,r=t.documentElement,o=/^picture$/i,i=["load","error","lazyincluded","_lazyloaded"],a=function(e,t){var n=new RegExp("(\\s|^)"+t+"(\\s|$)")
return e.className.match(n)&&n},s=function(e,t){a(e,t)||(e.className+=" "+t)},l=function(e,t){var n;(n=a(e,t))&&(e.className=e.className.replace(n," "))},c=function(e,t,n){var r=n?"addEventListener":"removeEventListener"
n&&c(e,t),i.forEach(function(n){e[r](n,t)})},u=function(e,n,r){var o=t.createEvent("Event")
return o.initEvent(n,!0,!0),o.details=r||{},e.dispatchEvent(o),o},d=function(t,n){var r,o
e.HTMLPictureElement||(e.picturefill?picturefill({reevaluate:!0,reparse:!0,elements:[t]}):e.respimage?(n&&(o=n.srcset&&"srcset"||n.src&&"src")&&(r=t[respimage._.ns],r&&r[o]!=n[o]&&t.getAttribute(o)==n[o]&&(r[o]=void 0)),respimage({reparse:!0,elements:[t]})):n&&n.src&&(t.src=n.src))},p=function(e,t){return getComputedStyle(e,null)[t]},f=function(e,r){for(var o=e.offsetWidth;o<n.minSize&&r&&r!=t.body&&!e._lazysizesWidth;)o=r.offsetWidth,r=r.parentNode
return o},h=function(e){var n,r,o=function(){n&&(n=!1,e())},i=function(){clearInterval(r),t.hidden||(o(),r=setInterval(o,66))}
return t.addEventListener("visibilitychange",i),i(),function(e){n=!0,e===!0&&o()}},m=function(){var i,f,m,v,y,b,w,_,E,C,x,S,k=navigator.userAgent,T=e.HTMLPictureElement&&k.match(/hrome\/(\d+)/)&&40==RegExp.$1,A=/webkit/i.test(k),N=/^img$/i,M=/^iframe$/i,P=-2,D=P,I=P,R=P,L=!0,O=0,B=0,q=0,U=function(e){B--,e&&e.target&&c(e.target,U),(!e||0>B||!e.target)&&(B=0)},j=function(e,n){var o,i=e,a="hidden"!=p(e,"visibility")
for(E-=n,S+=n,C-=n,x+=n;a&&(i=i.offsetParent)&&i!=r&&i!=t.body;)a=v&&4>B||(p(i,"opacity")||1)>0,a&&"visible"!=p(i,"overflow")&&(o=i.getBoundingClientRect(),a=x>o.left-1&&C<o.right+1&&S>o.top-1&&E<o.bottom+1)
return a},F=function(){var e,t,r,o,a,s,l,c=i.length,u=Date.now(),d=q
if(L||V(),c){for(;c>d&&i[d];d++,q++)if((s=i[d].getAttribute("data-expand"))&&(o=1*s)||(o=R),!(B>6&&(!s||"src"in i[d])))if(B>3&&o>P&&(o=P),l!==o&&(w=innerWidth+o,_=innerHeight+o,a=-1*o,l=o),e=i[d].getBoundingClientRect(),(S=e.bottom)>=a&&(E=e.top)<=_&&(x=e.right)>=a&&(C=e.left)<=w&&(S||x||C||E)&&(v&&R==D&&3>B&&4>O&&!s||j(i[d],o)))q--,u+=2,Y(i[d]),r=!0
else{if(!b&&Date.now()-u>3)return q++,b=!0,void W()
!r&&v&&!t&&3>B&&4>O&&(f[0]||n.preloadAfterLoad)&&(f[0]||!s&&(S||x||C||E||"auto"!=i[d].getAttribute(n.sizesAttr)))&&(t=f[0]||i[d])}q=0,b=!1,O++,I>R&&2>B&&O>4?(R=I,O=0,W()):R!=D&&(R=D),t&&!r&&Y(t)}},W=h(F),z=function(e){s(e.target,n.loadedClass),l(e.target,n.loadingClass),c(e.target,z)},H=function(e,t){try{e.contentWindow.location.replace(t)}catch(n){e.setAttribute("src",t)}},Y=function(e,t){var r,i,p,f,h,m,b,w,_,E,C,x=e.currentSrc||e.src,S=N.test(e.nodeName),k=e.getAttribute(n.sizesAttr)||e.getAttribute("sizes"),P="auto"==k
if(!P&&(A||v)||!S||!x||e.complete||a(e,n.errorClass)){if(!(_=u(e,"lazybeforeunveil",{force:!!t})).defaultPrevented){if(k&&(P?g.updateElem(e,!0):e.setAttribute("sizes",k)),m=e.getAttribute(n.srcsetAttr),h=e.getAttribute(n.srcAttr),S&&(b=e.parentNode,w=o.test(b.nodeName||"")),E=_.details.firesLoad||"src"in e&&(m||h||w),E&&(B++,c(e,U,!0),clearTimeout(y),y=setTimeout(U,3e3)),w)for(r=b.getElementsByTagName("source"),i=0,p=r.length;p>i;i++)(C=n.customMedia[r[i].getAttribute("media")])&&r[i].setAttribute("media",C),f=r[i].getAttribute(n.srcsetAttr),f&&r[i].setAttribute("srcset",f)
m?(e.setAttribute("srcset",m),T&&k&&e.removeAttribute("src")):h&&(M.test(e.nodeName)?H(e,h):e.setAttribute("src",h)),n.addClasses&&(s(e,n.loadingClass),c(e,z,!0))}setTimeout(function(){"auto"==k&&s(e,n.autosizesClass),(m||w)&&d(e,{srcset:m,src:h}),l(e,n.lazyClass),(!E||e.complete&&x==(e.currentSrc||e.src))&&(E&&U(_),n.addClasses&&z(_)),e=null})}},V=function(){m&&!L&&(D=Math.max(Math.min(n.expand||n.threshold||120,300),9),I=4*D),L=!0},G=function(){m=!0,L=!1},K=function(){v=!0,G(),W(!0)},$=function(){i=t.getElementsByClassName(n.lazyClass),f=t.getElementsByClassName(n.lazyClass+" "+n.preloadClass),n.scroll&&addEventListener("scroll",W,!0),addEventListener("resize",function(){L=!1,W()}),e.MutationObserver?new MutationObserver(W).observe(r,{childList:!0,subtree:!0,attributes:!0}):(r.addEventListener("DOMNodeInserted",W,!0),r.addEventListener("DOMAttrModified",W,!0)),addEventListener("hashchange",W,!0),["transitionstart","transitionend","load","focus","mouseover","animationend","click"].forEach(function(e){t.addEventListener(e,W,!0)}),(v=/d$|^c/.test(t.readyState))||(addEventListener("load",K),t.addEventListener("DOMContentLoaded",W)),setTimeout(G,666),W()}
return{init:$,checkElems:W,unveil:Y}}(),g=function(){var e,r=function(e,t){var n,r,i,a,s,l=e.parentNode
if(l&&(n=f(e,l),s=u(e,"lazybeforesizes",{width:n,dataAttr:!!t}),!s.defaultPrevented&&(n=s.details.width,n&&n!==e._lazysizesWidth))){if(e._lazysizesWidth=n,n+="px",e.setAttribute("sizes",n),o.test(l.nodeName||""))for(r=l.getElementsByTagName("source"),i=0,a=r.length;a>i;i++)r[i].setAttribute("sizes",n)
s.details.dataAttr||d(e,s.details)}},i=function(){var t,n=e.length
if(n)for(t=0;n>t;t++)r(e[t])},a=h(i),s=function(){e=t.getElementsByClassName(n.autosizesClass),addEventListener("resize",a)}
return{init:s,checkElems:a,updateElem:r}}(),v=function(){v.i||(v.i=!0,g.init(),m.init())}
return function(){var t,r={lazyClass:"lazyload",loadedClass:"lazyloaded",loadingClass:"lazyloading",preloadClass:"lazypreload",scroll:!0,autosizesClass:"lazyautosizes",srcAttr:"data-src",srcsetAttr:"data-srcset",sizesAttr:"data-sizes",addClasses:!0,minSize:50,customMedia:{},init:!0}
n=e.lazySizesConfig||{}
for(t in r)t in n||(n[t]=r[t])
e.lazySizesConfig=n,r.init&&setTimeout(v)}(),{cfg:n,autoSizer:g,loader:m,init:v,updateAllSizes:g.updateElems,updateAllLazy:m.checkElems,unveilLazy:m.unveil,uS:g.updateElem,uP:d,aC:s,rC:l,hC:a,fire:u,gW:f}}})
var deviceIsAndroid=navigator.userAgent.indexOf("Android")>0,deviceIsIOS=/iP(ad|hone|od)/.test(navigator.userAgent),deviceIsIOS4=deviceIsIOS&&/OS 4_\d(_\d)?/.test(navigator.userAgent),deviceIsIOSWithBadTarget=deviceIsIOS&&/OS ([6-9]|\d{2})_\d/.test(navigator.userAgent),deviceIsBlackBerry10=navigator.userAgent.indexOf("BB10")>0
FastClick.prototype.needsClick=function(e){"use strict"
switch(e.nodeName.toLowerCase()){case"button":case"select":case"textarea":if(e.disabled)return!0
break
case"input":if(deviceIsIOS&&"file"===e.type||e.disabled)return!0
break
case"label":case"video":return!0}return/\bneedsclick\b/.test(e.className)},FastClick.prototype.needsFocus=function(e){"use strict"
switch(e.nodeName.toLowerCase()){case"textarea":return!0
case"select":return!deviceIsAndroid
case"input":switch(e.type){case"button":case"checkbox":case"file":case"image":case"radio":case"submit":return!1}return!e.disabled&&!e.readOnly
default:return/\bneedsfocus\b/.test(e.className)}},FastClick.prototype.sendClick=function(e,t){"use strict"
var n,r
document.activeElement&&document.activeElement!==e&&document.activeElement.blur(),r=t.changedTouches[0],n=document.createEvent("MouseEvents"),n.initMouseEvent(this.determineEventType(e),!0,!0,window,1,r.screenX,r.screenY,r.clientX,r.clientY,!1,!1,!1,!1,0,null),n.forwardedTouchEvent=!0,e.dispatchEvent(n)},FastClick.prototype.determineEventType=function(e){"use strict"
return deviceIsAndroid&&"select"===e.tagName.toLowerCase()?"mousedown":"click"},FastClick.prototype.focus=function(e){"use strict"
var t
deviceIsIOS&&e.setSelectionRange&&0!==e.type.indexOf("date")&&"time"!==e.type?(t=e.value.length,e.setSelectionRange(t,t)):e.focus()},FastClick.prototype.updateScrollParent=function(e){"use strict"
var t,n
if(t=e.fastClickScrollParent,!t||!t.contains(e)){n=e
do{if(n.scrollHeight>n.offsetHeight){t=n,e.fastClickScrollParent=n
break}n=n.parentElement}while(n)}t&&(t.fastClickLastScrollTop=t.scrollTop)},FastClick.prototype.getTargetElementFromEventTarget=function(e){"use strict"
return e.nodeType===Node.TEXT_NODE?e.parentNode:e},FastClick.prototype.onTouchStart=function(e){"use strict"
var t,n,r
if(e.targetTouches.length>1)return!0
if(t=this.getTargetElementFromEventTarget(e.target),n=e.targetTouches[0],deviceIsIOS){if(r=window.getSelection(),r.rangeCount&&!r.isCollapsed)return!0
if(!deviceIsIOS4){if(n.identifier&&n.identifier===this.lastTouchIdentifier)return e.preventDefault(),!1
this.lastTouchIdentifier=n.identifier,this.updateScrollParent(t)}}return this.trackingClick=!0,this.trackingClickStart=e.timeStamp,this.targetElement=t,this.touchStartX=n.pageX,this.touchStartY=n.pageY,e.timeStamp-this.lastClickTime<this.tapDelay&&e.preventDefault(),!0},FastClick.prototype.touchHasMoved=function(e){"use strict"
var t=e.changedTouches[0],n=this.touchBoundary
return Math.abs(t.pageX-this.touchStartX)>n||Math.abs(t.pageY-this.touchStartY)>n?!0:!1},FastClick.prototype.onTouchMove=function(e){"use strict"
return this.trackingClick?((this.targetElement!==this.getTargetElementFromEventTarget(e.target)||this.touchHasMoved(e))&&(this.trackingClick=!1,this.targetElement=null),!0):!0},FastClick.prototype.findControl=function(e){"use strict"
return void 0!==e.control?e.control:e.htmlFor?document.getElementById(e.htmlFor):e.querySelector("button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea")},FastClick.prototype.onTouchEnd=function(e){"use strict"
var t,n,r,o,i,a=this.targetElement
if(!this.trackingClick)return!0
if(e.timeStamp-this.lastClickTime<this.tapDelay)return this.cancelNextClick=!0,!0
if(this.cancelNextClick=!1,this.lastClickTime=e.timeStamp,n=this.trackingClickStart,this.trackingClick=!1,this.trackingClickStart=0,deviceIsIOSWithBadTarget&&(i=e.changedTouches[0],a=document.elementFromPoint(i.pageX-window.pageXOffset,i.pageY-window.pageYOffset)||a,a.fastClickScrollParent=this.targetElement.fastClickScrollParent),r=a.tagName.toLowerCase(),"label"===r){if(t=this.findControl(a)){if(this.focus(a),deviceIsAndroid)return!1
a=t}}else if(this.needsFocus(a))return e.timeStamp-n>100||deviceIsIOS&&window.top!==window&&"input"===r?(this.targetElement=null,!1):(this.focus(a),this.sendClick(a,e),deviceIsIOS&&"select"===r||(this.targetElement=null,e.preventDefault()),!1)
return deviceIsIOS&&!deviceIsIOS4&&(o=a.fastClickScrollParent,o&&o.fastClickLastScrollTop!==o.scrollTop)?!0:(this.needsClick(a)||(e.preventDefault(),this.sendClick(a,e)),!1)},FastClick.prototype.onTouchCancel=function(){"use strict"
this.trackingClick=!1,this.targetElement=null},FastClick.prototype.onMouse=function(e){"use strict"
return this.targetElement?e.forwardedTouchEvent?!0:!e.cancelable||this.needsClick(this.targetElement)&&!this.cancelNextClick?!0:(e.stopImmediatePropagation?e.stopImmediatePropagation():e.propagationStopped=!0,e.stopPropagation(),e.preventDefault(),!1):!0},FastClick.prototype.onClick=function(e){"use strict"
var t
return this.trackingClick?(this.targetElement=null,this.trackingClick=!1,!0):"submit"===e.target.type&&0===e.detail?!0:(t=this.onMouse(e),t||(this.targetElement=null),t)},FastClick.prototype.destroy=function(){"use strict"
var e=this.layer
deviceIsAndroid&&(e.removeEventListener("mouseover",this.onMouse,!0),e.removeEventListener("mousedown",this.onMouse,!0),e.removeEventListener("mouseup",this.onMouse,!0)),e.removeEventListener("click",this.onClick,!0),e.removeEventListener("touchstart",this.onTouchStart,!1),e.removeEventListener("touchmove",this.onTouchMove,!1),e.removeEventListener("touchend",this.onTouchEnd,!1),e.removeEventListener("touchcancel",this.onTouchCancel,!1)},FastClick.notNeeded=function(e){"use strict"
var t,n,r
if("undefined"==typeof window.ontouchstart)return!0
if(n=+(/Chrome\/([0-9]+)/.exec(navigator.userAgent)||[,0])[1]){if(!deviceIsAndroid)return!0
if(t=document.querySelector("meta[name=viewport]")){if(-1!==t.content.indexOf("user-scalable=no"))return!0
if(n>31&&document.documentElement.scrollWidth<=window.outerWidth)return!0}}if(deviceIsBlackBerry10&&(r=navigator.userAgent.match(/Version\/([0-9]*)\.([0-9]*)/),r[1]>=10&&r[2]>=3&&(t=document.querySelector("meta[name=viewport]")))){if(-1!==t.content.indexOf("user-scalable=no"))return!0
if(document.documentElement.scrollWidth<=window.outerWidth)return!0}return"none"===e.style.msTouchAction?!0:!1},FastClick.attach=function(e,t){"use strict"
return new FastClick(e,t)},"function"==typeof define&&"object"==typeof define.amd&&define.amd?define("fastclick",[],function(){"use strict"
return FastClick}):"undefined"!=typeof module&&module.exports?(module.exports=FastClick.attach,module.exports.FastClick=FastClick):window.FastClick=FastClick
var labels=document.getElementsByTagName("label"),i,triggerMouseClick=function(e){var t=document.createEvent("MouseEvents")
t.initEvent("click",!0,!0),e.dispatchEvent(t)}
for(i=0;i<labels.length;i+=1)labels[i].childNodes.length&&(labels[i].onclick=function(e){"undefined"!=typeof e&&"forwardedTouchEvent"in e&&e.forwardedTouchEvent&&"LABEL"!==e.target.nodeName&&triggerMouseClick(this)})
define("labelclick",function(){}),define("app/activenav",["app/activenav"],function(){for(var e=window.location.pathname,t=document.querySelectorAll(".menu-item"),n=t.length-1;n>=0;n--)t[n].childNodes[0].pathname===e&&t[n].classList.add("active")}),define("bordeaux",[],function(){return function(e){function t(r){if(n[r])return n[r].exports
var o=n[r]={i:r,l:!1,exports:{}}
return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={}
return t.m=e,t.c=n,t.i=function(e){return e},t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:r})},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e}
return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="media/js/header/",t(t.s=46)}([function(e,t,n){"use strict"
function r(e){return e.reduce(function(e,t){return e.concat(t instanceof c.UnsubscriptionError?t.errors:t)},[])}var o=n(41),i=n(42),a=n(11),s=n(44),l=n(10),c=n(40),u=function(){function e(e){this.closed=!1,this._parent=null,this._parents=null,this._subscriptions=null,e&&(this._unsubscribe=e)}return e.prototype.unsubscribe=function(){var e,t=!1
if(!this.closed){var n=this,u=n._parent,d=n._parents,p=n._unsubscribe,f=n._subscriptions
this.closed=!0,this._parent=null,this._parents=null,this._subscriptions=null
for(var h=-1,m=d?d.length:0;u;)u.remove(this),u=++h<m&&d[h]||null
if(a.isFunction(p)){var g=s.tryCatch(p).call(this)
g===l.errorObject&&(t=!0,e=e||(l.errorObject.e instanceof c.UnsubscriptionError?r(l.errorObject.e.errors):[l.errorObject.e]))}if(o.isArray(f))for(h=-1,m=f.length;++h<m;){var v=f[h]
if(i.isObject(v)){var g=s.tryCatch(v.unsubscribe).call(v)
if(g===l.errorObject){t=!0,e=e||[]
var y=l.errorObject.e
y instanceof c.UnsubscriptionError?e=e.concat(r(y.errors)):e.push(y)}}}if(t)throw new c.UnsubscriptionError(e)}},e.prototype.add=function(t){if(!t||t===e.EMPTY)return e.EMPTY
if(t===this)return this
var n=t
switch(typeof t){case"function":n=new e(t)
case"object":if(n.closed||"function"!=typeof n.unsubscribe)return n
if(this.closed)return n.unsubscribe(),n
if("function"!=typeof n._addParent){var r=n
n=new e,n._subscriptions=[r]}break
default:throw new Error("unrecognized teardown "+t+" added to Subscription.")}return(this._subscriptions||(this._subscriptions=[])).push(n),n._addParent(this),n},e.prototype.remove=function(e){var t=this._subscriptions
if(t){var n=t.indexOf(e);-1!==n&&t.splice(n,1)}},e.prototype._addParent=function(e){var t=this,n=t._parent,r=t._parents
n&&n!==e?r?-1===r.indexOf(e)&&r.push(e):this._parents=[e]:this._parent=e},e.EMPTY=function(e){return e.closed=!0,e}(new e),e}()
t.Subscription=u},function(e,t,n){"use strict";(function(e){if(t.root="object"==typeof window&&window.window===window&&window||"object"==typeof self&&self.self===self&&self||"object"==typeof e&&e.global===e&&e,!t.root)throw new Error("RxJS could not find any global context (window, self, global)")}).call(t,n(12))},function(e,t,n){"use strict"
var r=n(29)
n.n(r),n.d(t,"a",function(){return a})
var o=30,i=new r.ReplaySubject(o)
window._adsShimCommunication=window._adsShimCommunication||function(){return{send:function(e){arguments.length>1&&void 0!==arguments[1]&&arguments[1],i.next(e)},receive:function(e){arguments.length>1&&void 0!==arguments[1]&&arguments[1],i.subscribe(e)}}}()
var a=window._adsShimCommunication.send
window._adsShimCommunication.receive},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(11),i=n(0),a=n(7),s=n(4),l=function(e){function t(n,r,o){switch(e.call(this),this.syncErrorValue=null,this.syncErrorThrown=!1,this.syncErrorThrowable=!1,this.isStopped=!1,arguments.length){case 0:this.destination=a.empty
break
case 1:if(!n){this.destination=a.empty
break}if("object"==typeof n){n instanceof t?(this.destination=n,this.destination.add(this)):(this.syncErrorThrowable=!0,this.destination=new c(this,n))
break}default:this.syncErrorThrowable=!0,this.destination=new c(this,n,r,o)}}return r(t,e),t.prototype[s.rxSubscriber]=function(){return this},t.create=function(e,n,r){var o=new t(e,n,r)
return o.syncErrorThrowable=!1,o},t.prototype.next=function(e){this.isStopped||this._next(e)},t.prototype.error=function(e){this.isStopped||(this.isStopped=!0,this._error(e))},t.prototype.complete=function(){this.isStopped||(this.isStopped=!0,this._complete())},t.prototype.unsubscribe=function(){this.closed||(this.isStopped=!0,e.prototype.unsubscribe.call(this))},t.prototype._next=function(e){this.destination.next(e)},t.prototype._error=function(e){this.destination.error(e),this.unsubscribe()},t.prototype._complete=function(){this.destination.complete(),this.unsubscribe()},t.prototype._unsubscribeAndRecycle=function(){var e=this,t=e._parent,n=e._parents
return this._parent=null,this._parents=null,this.unsubscribe(),this.closed=!1,this.isStopped=!1,this._parent=t,this._parents=n,this},t}(i.Subscription)
t.Subscriber=l
var c=function(e){function t(t,n,r,i){e.call(this),this._parentSubscriber=t
var s,l=this
o.isFunction(n)?s=n:n&&(s=n.next,r=n.error,i=n.complete,n!==a.empty&&(l=Object.create(n),o.isFunction(l.unsubscribe)&&this.add(l.unsubscribe.bind(l)),l.unsubscribe=this.unsubscribe.bind(this))),this._context=l,this._next=s,this._error=r,this._complete=i}return r(t,e),t.prototype.next=function(e){if(!this.isStopped&&this._next){var t=this._parentSubscriber
t.syncErrorThrowable?this.__tryOrSetError(t,this._next,e)&&this.unsubscribe():this.__tryOrUnsub(this._next,e)}},t.prototype.error=function(e){if(!this.isStopped){var t=this._parentSubscriber
if(this._error)t.syncErrorThrowable?(this.__tryOrSetError(t,this._error,e),this.unsubscribe()):(this.__tryOrUnsub(this._error,e),this.unsubscribe())
else{if(!t.syncErrorThrowable)throw this.unsubscribe(),e
t.syncErrorValue=e,t.syncErrorThrown=!0,this.unsubscribe()}}},t.prototype.complete=function(){if(!this.isStopped){var e=this._parentSubscriber
this._complete?e.syncErrorThrowable?(this.__tryOrSetError(e,this._complete),this.unsubscribe()):(this.__tryOrUnsub(this._complete),this.unsubscribe()):this.unsubscribe()}},t.prototype.__tryOrUnsub=function(e,t){try{e.call(this._context,t)}catch(e){throw this.unsubscribe(),e}},t.prototype.__tryOrSetError=function(e,t,n){try{t.call(this._context,n)}catch(t){return e.syncErrorValue=t,e.syncErrorThrown=!0,!0}return!1},t.prototype._unsubscribe=function(){var e=this._parentSubscriber
this._context=null,this._parentSubscriber=null,e.unsubscribe()},t}(l)},function(e,t,n){"use strict"
var r=n(1),o=r.root.Symbol
t.rxSubscriber="function"==typeof o&&"function"==typeof o.for?o.for("rxSubscriber"):"@@rxSubscriber",t.$$rxSubscriber=t.rxSubscriber},function(e,t){"use strict"
var n=window.feat=window.feat||new Promise(function(e){window.resolveFEAT=e})
t.a=n},function(e,t,n){"use strict"
var r=n(1),o=n(43),i=n(39),a=function(){function e(e){this._isScalar=!1,e&&(this._subscribe=e)}return e.prototype.lift=function(t){var n=new e
return n.source=this,n.operator=t,n},e.prototype.subscribe=function(e,t,n){var r=this.operator,i=o.toSubscriber(e,t,n)
if(r?r.call(i,this.source):i.add(this._trySubscribe(i)),i.syncErrorThrowable&&(i.syncErrorThrowable=!1,i.syncErrorThrown))throw i.syncErrorValue
return i},e.prototype._trySubscribe=function(e){try{return this._subscribe(e)}catch(t){e.syncErrorThrown=!0,e.syncErrorValue=t,e.error(t)}},e.prototype.forEach=function(e,t){var n=this
if(t||(r.root.Rx&&r.root.Rx.config&&r.root.Rx.config.Promise?t=r.root.Rx.config.Promise:r.root.Promise&&(t=r.root.Promise)),!t)throw new Error("no Promise impl found")
return new t(function(e,t){var r
r=n.subscribe(function(e){if(r)try{n(e)}catch(n){t(n),r.unsubscribe()}else n(e)},t,e)})},e.prototype._subscribe=function(e){return this.source.subscribe(e)},e.prototype[i.observable]=function(){return this},e.create=function(t){return new e(t)},e}()
t.Observable=a},function(e,t){"use strict"
t.empty={closed:!0,next:function(){},error:function(e){throw e},complete:function(){}}},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(0),i=function(e){function t(t,n){e.call(this),this.subject=t,this.subscriber=n,this.closed=!1}return r(t,e),t.prototype.unsubscribe=function(){if(!this.closed){this.closed=!0
var e=this.subject,t=e.observers
if(this.subject=null,t&&0!==t.length&&!e.isStopped&&!e.closed){var n=t.indexOf(this.subscriber);-1!==n&&t.splice(n,1)}}},t}(o.Subscription)
t.SubjectSubscription=i},function(e,t){"use strict"
var n=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},r=function(e){function t(){var t=e.call(this,"object unsubscribed")
this.name=t.name="ObjectUnsubscribedError",this.stack=t.stack,this.message=t.message}return n(t,e),t}(Error)
t.ObjectUnsubscribedError=r},function(e,t){"use strict"
t.errorObject={e:{}}},function(e,t){"use strict"
function n(e){return"function"==typeof e}t.isFunction=n},function(e){var t
t=function(){return this}()
try{t=t||Function("return this")()||(0,eval)("this")}catch(e){"object"==typeof window&&(t=window)}e.exports=t},function(e,t,n){"use strict"
var r=n(23),o=n(22),i=n(5),a=function(){},s=function(e){var t={disqus:o.a,spot:r.a,"default":function(){console.log("Invalid or no comment system chosen nothing will happen",e)}}
return t[e]||t.default},l=function(e){e.style.display="none",s(e.getAttribute("data-comments"))()},c=function(e){return new Promise(function(t){e&&(e.onclick=t)})},u=function(e){return new Promise(function(t){if(e)if(window.IntersectionObserver){var n=0,r=new IntersectionObserver(function(e,r){e.forEach(function(e){e.intersectionRatio>n&&(t(),r.disconnect())})},{rootMargin:"200px 200px 200px 200px",threshold:n})
r.observe(e)}else i.a.then(function(n){n.add("comments",e,a,200,t,a)})})}
t.a=function(){var e=window.document.querySelector(".load-comments-hide")
Promise.race([c(e),window.innerWidth>700&&u(e)].filter(Boolean)).then(function(){return e}).then(l)}},function(e,t,n){"use strict"
function r(){n.i(s.a)({type:"dfp",payload:{type:"REFRESH"}})}function o(){}function i(e,t){n.i(s.a)({type:"dfp",payload:{type:"ADD_EVENT_LISTENER",name:e,callback:t}})}function a(e){n.i(s.a)({type:"dfp",payload:{type:"SET_KEYWORDS",keywords:e}})}Object.defineProperty(t,"__esModule",{value:!0})
var s=n(2)
t.refresh=r,t.getSlots=o,t.addEventListener=i,t.setKeywords=a},function(e,t,n){"use strict"
var r=n(26)
if(n.n(r)()(n.p)||(n.p=document.querySelector("#static-host-pattern").dataset.staticHost+n.p),!n.p)throw new Error("No __webpack_public_path__ - chunk loading will not work")},function(e,t,n){"use strict"
function r(){var e=arguments.length>0&&void 0!==arguments[0]&&arguments[0]
n.i(o.a)({type:"gallery",payload:{type:"UPDATE_MOBILE_ADS",reachedEnd:e}},"gallery")}Object.defineProperty(t,"__esModule",{value:!0})
var o=n(2)
t.updateMobileAds=r},function(e,t,n){"use strict"
var r=n(24),o=function(e){switch(e){case"high":return 0
case"medium":return 500
default:return 2e3}},i=function(e){if(!e.src&&e.dataset&&e.dataset.lazySrc){var t=e.dataset.lazyPriority||"low"
window.setTimeout(function(){e.dataset.lazyReport="lazily loaded with "+t+" priority and began "+n.i(r.a)(window)+"ms after DOM Loading event and "+n.i(r.b)(window)+"ms after Page Loaded event",e.src=e.dataset.lazySrc},o(t))}},a=function(){Array.prototype.slice.apply(window.document.querySelectorAll("iframe[data-lazy-src]")).forEach(i)}
Promise.resolve(window.reliablePageLoad).then(function(){return window.requestAnimationFrame(a)})},function(){Promise.resolve(window.reliablePageLoad).then(function(){var e=document.createElement("style")
e.innerHTML="\n  .portland-background{\n    will-change: transform;\n  }\n  #portland-optin{\n    contain: content;\n  }\n  ",document.body.appendChild(e)})},function(e,t,n){"use strict"
function r(e){n.i(i.a)({type:"sponsored-post",payload:{callback:e}},"sponsored-post")}function o(e,t){var r=t.width,o=t.height
n.i(i.a)({type:"sponsored-post-dimensions",payload:{id:e,width:r,height:o}},"sponsored-post")}Object.defineProperty(t,"__esModule",{value:!0})
var i=n(2)
t.sendRender=r,t.sendDimensions=o},function(e,t){"use strict"
var n="concealed",r="tag",o=function(e,t){return function(){[].slice.call(t).forEach(function(e){return e.classList.remove(n)}),e.parentElement.classList.add(n)}},i=function(e,t){null!==e&&void 0!==e&&e.addEventListener("click",o(e,t))}
t.a=function(){return i(document.querySelector("."+r+" .reveal"),document.querySelectorAll("."+r+"."+n))}},function(e,t,n){if(!window.Promise)try{n(25).polyfill()}catch(e){console.error("ERROR WHEN RUNNING PROMISE POLYFILL",e)}},function(e,t){"use strict"
t.a=function(){!function(){var e=document.createElement("script")
e.type="text/javascript",e.async=!0,e.src="//"+disqus_shortname+".disqus.com/embed.js",(document.getElementsByTagName("head")[0]||document.getElementsByTagName("body")[0]).appendChild(e)}()}},function(e,t){"use strict"
t.a=function(){!function(e,t,n){function r(e){var r=t.createElement("script")
r.type="text/javascript",r.async=!0,r.src=("https:"===t.location.protocol?"https":"http")+":"+n,(e||t.body||t.head).appendChild(r)}function o(){var e=t.getElementsByTagName("script")
return e[e.length-1].parentNode}var i=o()
e.spotId="sp_7xVAzh4B",e.parentElement=i,r(i)}(window.SPOTIM={options:{newsfeed:!1,enableMiniNewsfeed:!1}},document,"//www.spot.im/launcher/bundle.js")}},function(e,t,n){"use strict"
n.d(t,"a",function(){return r}),n.d(t,"b",function(){return o})
var r=function(e){return Date.now()-e.performance.timing.domLoading},o=function(e){return Date.now()-e.performance.timing.loadEventEnd}},function(e,t,n){(function(t,r){!function(t,n){e.exports=n()}(0,function(){"use strict"
function e(e){return"function"==typeof e||"object"==typeof e&&null!==e}function o(e){return"function"==typeof e}function i(e){$=e}function a(e){X=e}function s(){return function(){return t.nextTick(p)}}function l(){return void 0!==K?function(){K(p)}:d()}function c(){var e=0,t=new J(p),n=document.createTextNode("")
return t.observe(n,{characterData:!0}),function(){n.data=e=++e%2}}function u(){var e=new MessageChannel
return e.port1.onmessage=p,function(){return e.port2.postMessage(0)}}function d(){var e=setTimeout
return function(){return e(p,1)}}function p(){for(var e=0;G>e;e+=2)nt[e](nt[e+1]),nt[e]=void 0,nt[e+1]=void 0
G=0}function f(){try{var e=n(45)
return K=e.runOnLoop||e.runOnContext,l()}catch(e){return d()}}function h(e,t){var n=arguments,r=this,o=new this.constructor(g)
void 0===o[ot]&&L(o)
var i=r._state
return i?function(){var e=n[i-1]
X(function(){return D(i,o,e,r._result)})}():A(r,o,e,t),o}function m(e){var t=this
if(e&&"object"==typeof e&&e.constructor===t)return e
var n=new t(g)
return x(n,e),n}function g(){}function v(){return new TypeError("You cannot resolve a promise with itself")}function y(){return new TypeError("A promises callback cannot return that same promise.")}function b(e){try{return e.then}catch(e){return lt.error=e,lt}}function w(e,t,n,r){try{e.call(t,n,r)}catch(e){return e}}function _(e,t,n){X(function(e){var r=!1,o=w(n,t,function(n){r||(r=!0,t!==n?x(e,n):k(e,n))},function(t){r||(r=!0,T(e,t))},"Settle: "+(e._label||" unknown promise"))
!r&&o&&(r=!0,T(e,o))},e)}function E(e,t){t._state===at?k(e,t._result):t._state===st?T(e,t._result):A(t,void 0,function(t){return x(e,t)},function(t){return T(e,t)})}function C(e,t,n){t.constructor===e.constructor&&n===h&&t.constructor.resolve===m?E(e,t):n===lt?(T(e,lt.error),lt.error=null):void 0===n?k(e,t):o(n)?_(e,t,n):k(e,t)}function x(t,n){t===n?T(t,v()):e(n)?C(t,n,b(n)):k(t,n)}function S(e){e._onerror&&e._onerror(e._result),N(e)}function k(e,t){e._state===it&&(e._result=t,e._state=at,0!==e._subscribers.length&&X(N,e))}function T(e,t){e._state===it&&(e._state=st,e._result=t,X(S,e))}function A(e,t,n,r){var o=e._subscribers,i=o.length
e._onerror=null,o[i]=t,o[i+at]=n,o[i+st]=r,0===i&&e._state&&X(N,e)}function N(e){var t=e._subscribers,n=e._state
if(0!==t.length){for(var r=void 0,o=void 0,i=e._result,a=0;a<t.length;a+=3)r=t[a],o=t[a+n],r?D(n,r,o,i):o(i)
e._subscribers.length=0}}function M(){this.error=null}function P(e,t){try{return e(t)}catch(e){return ct.error=e,ct}}function D(e,t,n,r){var i=o(n),a=void 0,s=void 0,l=void 0,c=void 0
if(i){if(a=P(n,r),a===ct?(c=!0,s=a.error,a.error=null):l=!0,t===a)return void T(t,y())}else a=r,l=!0
t._state!==it||(i&&l?x(t,a):c?T(t,s):e===at?k(t,a):e===st&&T(t,a))}function I(e,t){try{t(function(t){x(e,t)},function(t){T(e,t)})}catch(t){T(e,t)}}function R(){return ut++}function L(e){e[ot]=ut++,e._state=void 0,e._result=void 0,e._subscribers=[]}function O(e,t){this._instanceConstructor=e,this.promise=new e(g),this.promise[ot]||L(this.promise),V(t)?(this._input=t,this.length=t.length,this._remaining=t.length,this._result=new Array(this.length),0===this.length?k(this.promise,this._result):(this.length=this.length||0,this._enumerate(),0===this._remaining&&k(this.promise,this._result))):T(this.promise,B())}function B(){return new Error("Array Methods must be provided an Array")}function q(e){return new O(this,e).promise}function U(e){var t=this
return new t(V(e)?function(n,r){for(var o=e.length,i=0;o>i;i++)t.resolve(e[i]).then(n,r)}:function(e,t){return t(new TypeError("You must pass an array to race."))})}function j(e){var t=this,n=new t(g)
return T(n,e),n}function F(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function W(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function z(e){this[ot]=R(),this._result=this._state=void 0,this._subscribers=[],g!==e&&("function"!=typeof e&&F(),this instanceof z?I(this,e):W())}function H(){var e=void 0
if(void 0!==r)e=r
else if("undefined"!=typeof self)e=self
else try{e=Function("return this")()}catch(e){throw new Error("polyfill failed because global object is unavailable in this environment")}var t=e.Promise
if(t){var n=null
try{n=Object.prototype.toString.call(t.resolve())}catch(e){}if("[object Promise]"===n&&!t.cast)return}e.Promise=z}var Y=void 0
Y=Array.isArray?Array.isArray:function(e){return"[object Array]"===Object.prototype.toString.call(e)}
var V=Y,G=0,K=void 0,$=void 0,X=function(e,t){nt[G]=e,nt[G+1]=t,2===(G+=2)&&($?$(p):rt())},Q="undefined"!=typeof window?window:void 0,Z=Q||{},J=Z.MutationObserver||Z.WebKitMutationObserver,et="undefined"==typeof self&&void 0!==t&&"[object process]"==={}.toString.call(t),tt="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,nt=new Array(1e3),rt=void 0
rt=et?s():J?c():tt?u():void 0===Q?f():d()
var ot=Math.random().toString(36).substring(16),it=void 0,at=1,st=2,lt=new M,ct=new M,ut=0
return O.prototype._enumerate=function(){for(var e=this.length,t=this._input,n=0;this._state===it&&e>n;n++)this._eachEntry(t[n],n)},O.prototype._eachEntry=function(e,t){var n=this._instanceConstructor,r=n.resolve
if(r===m){var o=b(e)
if(o===h&&e._state!==it)this._settledAt(e._state,t,e._result)
else if("function"!=typeof o)this._remaining--,this._result[t]=e
else if(n===z){var i=new n(g)
C(i,e,o),this._willSettleAt(i,t)}else this._willSettleAt(new n(function(t){return t(e)}),t)}else this._willSettleAt(r(e),t)},O.prototype._settledAt=function(e,t,n){var r=this.promise
r._state===it&&(this._remaining--,e===st?T(r,n):this._result[t]=n),0===this._remaining&&k(r,this._result)},O.prototype._willSettleAt=function(e,t){var n=this
A(e,void 0,function(e){return n._settledAt(at,t,e)},function(e){return n._settledAt(st,t,e)})},z.all=q,z.race=U,z.resolve=m,z.reject=j,z._setScheduler=i,z._setAsap=a,z._asap=X,z.prototype={constructor:z,then:h,"catch":function(e){return this.then(null,e)}},z.polyfill=H,z.Promise=z,z})}).call(t,n(27),n(12))},function(e){"use strict"
e.exports=function(e){if("string"!=typeof e)throw new TypeError("Expected a string")
return/^[a-z][a-z0-9+.-]*:/.test(e)}},function(e){function t(){throw new Error("setTimeout has not been defined")}function n(){throw new Error("clearTimeout has not been defined")}function r(e){if(c===setTimeout)return setTimeout(e,0)
if((c===t||!c)&&setTimeout)return c=setTimeout,setTimeout(e,0)
try{return c(e,0)}catch(n){try{return c.call(null,e,0)}catch(n){return c.call(this,e,0)}}}function o(e){if(u===clearTimeout)return clearTimeout(e)
if((u===n||!u)&&clearTimeout)return u=clearTimeout,clearTimeout(e)
try{return u(e)}catch(t){try{return u.call(null,e)}catch(t){return u.call(this,e)}}}function i(){h&&p&&(h=!1,p.length?f=p.concat(f):m=-1,f.length&&a())}function a(){if(!h){var e=r(i)
h=!0
for(var t=f.length;t;){for(p=f,f=[];++m<t;)p&&p[m].run()
m=-1,t=f.length}p=null,h=!1,o(e)}}function s(e,t){this.fun=e,this.array=t}function l(){}var c,u,d=e.exports={}
!function(){try{c="function"==typeof setTimeout?setTimeout:t}catch(e){c=t}try{u="function"==typeof clearTimeout?clearTimeout:n}catch(e){u=n}}()
var p,f=[],h=!1,m=-1
d.nextTick=function(e){var t=new Array(arguments.length-1)
if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n]
f.push(new s(e,t)),1!==f.length||h||r(a)},s.prototype.run=function(){this.fun.apply(null,this.array)},d.title="browser",d.browser=!0,d.env={},d.argv=[],d.version="",d.versions={},d.on=l,d.addListener=l,d.once=l,d.off=l,d.removeListener=l,d.removeAllListeners=l,d.emit=l,d.binding=function(){throw new Error("process.binding is not supported")},d.cwd=function(){return"/"},d.chdir=function(){throw new Error("process.chdir is not supported")},d.umask=function(){return 0}},function(e,t,n){"use strict"
var r=n(6),o=function(){function e(e,t,n){this.kind=e,this.value=t,this.error=n,this.hasValue="N"===e}return e.prototype.observe=function(e){switch(this.kind){case"N":return e.next&&e.next(this.value)
case"E":return e.error&&e.error(this.error)
case"C":return e.complete&&e.complete()}},e.prototype.do=function(e,t,n){switch(this.kind){case"N":return e&&e(this.value)
case"E":return t&&t(this.error)
case"C":return n&&n()}},e.prototype.accept=function(e,t,n){return e&&"function"==typeof e.next?this.observe(e):this.do(e,t,n)},e.prototype.toObservable=function(){switch(this.kind){case"N":return r.Observable.of(this.value)
case"E":return r.Observable.throw(this.error)
case"C":return r.Observable.empty()}throw new Error("unexpected notification kind value")},e.createNext=function(t){return void 0!==t?new e("N",t):this.undefinedValueNotification},e.createError=function(t){return new e("E",void 0,t)},e.createComplete=function(){return this.completeNotification},e.completeNotification=new e("C"),e.undefinedValueNotification=new e("N",void 0),e}()
t.Notification=o},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(31),i=n(38),a=n(0),s=n(32),l=n(9),c=n(8),u=function(e){function t(t,n,r){void 0===t&&(t=Number.POSITIVE_INFINITY),void 0===n&&(n=Number.POSITIVE_INFINITY),e.call(this),this.scheduler=r,this._events=[],this._bufferSize=1>t?1:t,this._windowTime=1>n?1:n}return r(t,e),t.prototype.next=function(t){var n=this._getNow()
this._events.push(new d(n,t)),this._trimBufferThenGetEvents(),e.prototype.next.call(this,t)},t.prototype._subscribe=function(e){var t,n=this._trimBufferThenGetEvents(),r=this.scheduler
if(this.closed)throw new l.ObjectUnsubscribedError
this.hasError?t=a.Subscription.EMPTY:this.isStopped?t=a.Subscription.EMPTY:(this.observers.push(e),t=new c.SubjectSubscription(this,e)),r&&e.add(e=new s.ObserveOnSubscriber(e,r))
for(var o=n.length,i=0;o>i&&!e.closed;i++)e.next(n[i].value)
return this.hasError?e.error(this.thrownError):this.isStopped&&e.complete(),t},t.prototype._getNow=function(){return(this.scheduler||i.queue).now()},t.prototype._trimBufferThenGetEvents=function(){for(var e=this._getNow(),t=this._bufferSize,n=this._windowTime,r=this._events,o=r.length,i=0;o>i&&!(e-r[i].time<n);)i++
return o>t&&(i=Math.max(i,o-t)),i>0&&r.splice(0,i),r},t}(o.Subject)
t.ReplaySubject=u
var d=function(){function e(e,t){this.time=e,this.value=t}return e}()},function(e,t){"use strict"
var n=function(){function e(t,n){void 0===n&&(n=e.now),this.SchedulerAction=t,this.now=n}return e.prototype.schedule=function(e,t,n){return void 0===t&&(t=0),new this.SchedulerAction(this,e).schedule(n,t)},e.now=Date.now?Date.now:function(){return+new Date},e}()
t.Scheduler=n},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(6),i=n(3),a=n(0),s=n(9),l=n(8),c=n(4),u=function(e){function t(t){e.call(this,t),this.destination=t}return r(t,e),t}(i.Subscriber)
t.SubjectSubscriber=u
var d=function(e){function t(){e.call(this),this.observers=[],this.closed=!1,this.isStopped=!1,this.hasError=!1,this.thrownError=null}return r(t,e),t.prototype[c.rxSubscriber]=function(){return new u(this)},t.prototype.lift=function(e){var t=new p(this,this)
return t.operator=e,t},t.prototype.next=function(e){if(this.closed)throw new s.ObjectUnsubscribedError
if(!this.isStopped)for(var t=this.observers,n=t.length,r=t.slice(),o=0;n>o;o++)r[o].next(e)},t.prototype.error=function(e){if(this.closed)throw new s.ObjectUnsubscribedError
this.hasError=!0,this.thrownError=e,this.isStopped=!0
for(var t=this.observers,n=t.length,r=t.slice(),o=0;n>o;o++)r[o].error(e)
this.observers.length=0},t.prototype.complete=function(){if(this.closed)throw new s.ObjectUnsubscribedError
this.isStopped=!0
for(var e=this.observers,t=e.length,n=e.slice(),r=0;t>r;r++)n[r].complete()
this.observers.length=0},t.prototype.unsubscribe=function(){this.isStopped=!0,this.closed=!0,this.observers=null},t.prototype._trySubscribe=function(t){if(this.closed)throw new s.ObjectUnsubscribedError
return e.prototype._trySubscribe.call(this,t)},t.prototype._subscribe=function(e){if(this.closed)throw new s.ObjectUnsubscribedError
return this.hasError?(e.error(this.thrownError),a.Subscription.EMPTY):this.isStopped?(e.complete(),a.Subscription.EMPTY):(this.observers.push(e),new l.SubjectSubscription(this,e))},t.prototype.asObservable=function(){var e=new o.Observable
return e.source=this,e},t.create=function(e,t){return new p(e,t)},t}(o.Observable)
t.Subject=d
var p=function(e){function t(t,n){e.call(this),this.destination=t,this.source=n}return r(t,e),t.prototype.next=function(e){var t=this.destination
t&&t.next&&t.next(e)},t.prototype.error=function(e){var t=this.destination
t&&t.error&&this.destination.error(e)},t.prototype.complete=function(){var e=this.destination
e&&e.complete&&this.destination.complete()},t.prototype._subscribe=function(e){return this.source?this.source.subscribe(e):a.Subscription.EMPTY},t}(d)
t.AnonymousSubject=p},function(e,t,n){"use strict"
function r(e,t){return void 0===t&&(t=0),this.lift(new s(e,t))}var o=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},i=n(3),a=n(28)
t.observeOn=r
var s=function(){function e(e,t){void 0===t&&(t=0),this.scheduler=e,this.delay=t}return e.prototype.call=function(e,t){return t.subscribe(new l(e,this.scheduler,this.delay))},e}()
t.ObserveOnOperator=s
var l=function(e){function t(t,n,r){void 0===r&&(r=0),e.call(this,t),this.scheduler=n,this.delay=r}return o(t,e),t.dispatch=function(e){var t=e.notification,n=e.destination
t.observe(n),this.unsubscribe()},t.prototype.scheduleMessage=function(e){this.add(this.scheduler.schedule(t.dispatch,this.delay,new c(e,this.destination)))},t.prototype._next=function(e){this.scheduleMessage(a.Notification.createNext(e))},t.prototype._error=function(e){this.scheduleMessage(a.Notification.createError(e))},t.prototype._complete=function(){this.scheduleMessage(a.Notification.createComplete())},t}(i.Subscriber)
t.ObserveOnSubscriber=l
var c=function(){function e(e,t){this.notification=e,this.destination=t}return e}()
t.ObserveOnMessage=c},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(0),i=function(e){function t(){e.call(this)}return r(t,e),t.prototype.schedule=function(e,t){return void 0===t&&(t=0),this},t}(o.Subscription)
t.Action=i},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(1),i=n(33),a=function(e){function t(t,n){e.call(this,t,n),this.scheduler=t,this.work=n,this.pending=!1}return r(t,e),t.prototype.schedule=function(e,t){if(void 0===t&&(t=0),this.closed)return this
this.state=e,this.pending=!0
var n=this.id,r=this.scheduler
return null!=n&&(this.id=this.recycleAsyncId(r,n,t)),this.delay=t,this.id=this.id||this.requestAsyncId(r,this.id,t),this},t.prototype.requestAsyncId=function(e,t,n){return void 0===n&&(n=0),o.root.setInterval(e.flush.bind(e,this),n)},t.prototype.recycleAsyncId=function(e,t,n){return void 0===n&&(n=0),null!==n&&this.delay===n?t:o.root.clearInterval(t)&&void 0||void 0},t.prototype.execute=function(e,t){if(this.closed)return new Error("executing a cancelled action")
this.pending=!1
var n=this._execute(e,t)
return n?n:void(!1===this.pending&&null!=this.id&&(this.id=this.recycleAsyncId(this.scheduler,this.id,null)))},t.prototype._execute=function(e){var t=!1,n=void 0
try{this.work(e)}catch(e){t=!0,n=!!e&&e||new Error(e)}return t?(this.unsubscribe(),n):void 0},t.prototype._unsubscribe=function(){var e=this.id,t=this.scheduler,n=t.actions,r=n.indexOf(this)
this.work=null,this.delay=null,this.state=null,this.pending=!1,this.scheduler=null,-1!==r&&n.splice(r,1),null!=e&&(this.id=this.recycleAsyncId(t,e,null))},t}(i.Action)
t.AsyncAction=a},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(30),i=function(e){function t(){e.apply(this,arguments),this.actions=[],this.active=!1,this.scheduled=void 0}return r(t,e),t.prototype.flush=function(e){var t=this.actions
if(this.active)return void t.push(e)
var n
this.active=!0
do if(n=e.execute(e.state,e.delay))break
while(e=t.shift())
if(this.active=!1,n){for(;e=t.shift();)e.unsubscribe()
throw n}},t}(o.Scheduler)
t.AsyncScheduler=i},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(34),i=function(e){function t(t,n){e.call(this,t,n),this.scheduler=t,this.work=n}return r(t,e),t.prototype.schedule=function(t,n){return void 0===n&&(n=0),n>0?e.prototype.schedule.call(this,t,n):(this.delay=n,this.state=t,this.scheduler.flush(this),this)},t.prototype.execute=function(t,n){return n>0||this.closed?e.prototype.execute.call(this,t,n):this._execute(t,n)},t.prototype.requestAsyncId=function(t,n,r){return void 0===r&&(r=0),null!==r&&r>0||null===r&&this.delay>0?e.prototype.requestAsyncId.call(this,t,n,r):t.flush(this)},t}(o.AsyncAction)
t.QueueAction=i},function(e,t,n){"use strict"
var r=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},o=n(35),i=function(e){function t(){e.apply(this,arguments)}return r(t,e),t}(o.AsyncScheduler)
t.QueueScheduler=i},function(e,t,n){"use strict"
var r=n(36),o=n(37)
t.queue=new o.QueueScheduler(r.QueueAction)},function(e,t,n){"use strict"
function r(e){var t,n=e.Symbol
return"function"==typeof n?n.observable?t=n.observable:(t=n("observable"),n.observable=t):t="@@observable",t}var o=n(1)
t.getSymbolObservable=r,t.observable=r(o.root),t.$$observable=t.observable},function(e,t){"use strict"
var n=this&&this.__extends||function(e,t){function n(){this.constructor=e}for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r])
e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)},r=function(e){function t(t){e.call(this),this.errors=t
var n=Error.call(this,t?t.length+" errors occurred during unsubscription:\n  "+t.map(function(e,t){return t+1+") "+e.toString()}).join("\n  "):"")
this.name=n.name="UnsubscriptionError",this.stack=n.stack,this.message=n.message}return n(t,e),t}(Error)
t.UnsubscriptionError=r},function(e,t){"use strict"
t.isArray=Array.isArray||function(e){return e&&"number"==typeof e.length}},function(e,t){"use strict"
function n(e){return null!=e&&"object"==typeof e}t.isObject=n},function(e,t,n){"use strict"
function r(e,t,n){if(e){if(e instanceof o.Subscriber)return e
if(e[i.rxSubscriber])return e[i.rxSubscriber]()}return e||t||n?new o.Subscriber(e,t,n):new o.Subscriber(a.empty)}var o=n(3),i=n(4),a=n(7)
t.toSubscriber=r},function(e,t,n){"use strict"
function r(){try{return i.apply(this,arguments)}catch(e){return a.errorObject.e=e,a.errorObject}}function o(e){return i=e,r}var i,a=n(10)
t.tryCatch=o},function(){},function(e,t,n){"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
var r=(n(15),n(21)),o=(n.n(r),n(17),n(18)),i=(n.n(o),n(5),n(13))
n.d(t,"comments",function(){return i.a})
var a=n(20)
n.d(t,"topics",function(){return a.a})
var s=n(14)
n.d(t,"dfpShim",function(){return s})
var l=n(16)
n.d(t,"galleryShim",function(){return l})
var c=n(19)
n.d(t,"sponsoredShim",function(){return c}),n.d(t,"ads",function(){return u})
var u=function(){return window.bordeauxAds||Promise.resolve(!1)}}])}),define("app/comments",["bordeaux"],function(e){e.comments()}),function(){"use strict"
var e=!1
!function(e,t){"function"==typeof define&&define.amd?define("dfp_legacy",[],t):t()}(this,function(){return function(){function t(){if(window.console){for(var e=0;e<arguments.length;e++)console.log(arguments[e])
return!0}return!1}function n(){if(window.console){for(var e=0;e<arguments.length;e++)console.warn(arguments[e])
return!0}return!1}function r(){if(window.console){for(var e=0;e<arguments.length;e++)console.error(arguments[e])
return!0}return!1}function o(e,t){if(window.performance=window.performance||window.mozPerformance||window.msPerformance||window.webkitPerformance||{},window.performance.mark&&window.performance.measure&&window.performance.getEntriesByName){var n=window.performance.timing||{navigationStart:0,responseStart:0,domLoading:0},r=n,o=(new Date).getTime(),i=(o-r.domLoading,0)
if(window.performance.mark("mark_"+e),t){window.performance.measure("measure_"+e+"_"+t,"mark_"+t,"mark_"+e)
var a=window.performance.getEntriesByName("measure_"+e+"_"+t),s={duration:0}
a.length>0&&(s=a[0]),i=Math.floor(s.duration)}}}function i(e,t){e.forEach(function(e,n,r){r[n]=h(!0,{},t,e)})}function a(e){return e&&e.nodeType&&1==e.nodeType}function s(e){this.isValid=function(){return e&&a(e.element)}
var t=null,n=null
this.isValid()&&(t=e.element,n=e.adjacency),this.clear=function(){for(var e;e=t.lastChild;)t.removeChild(e)},this.add=function(e){switch(n){case"prepend":t.insertBefore(e,t.firstElementChild)
break
case"before":t.parentElement.insertBefore(e,t)
break
case"after":t.parentElement.insertBefore(e,t.nextElementSibling)
break
default:t.appendChild(e)}}}function l(i,l){var c=null,u=new Array(20).join("~")+" Advert Code "
u+=new Array(20).join("~")+"\n",u+="~      slot name:	"+l.slotname+"\n",u+="~           unit:	"+l.unit+"\n",u+="~             id:	"+i+"\n",u+="~            oop:	"+l.oop.toString()+"\n",u+="~          sizes:	"+JSON.stringify(l.sizes)+"\n",u+="~      targeting:	"+JSON.stringify(l.targeting)+"\n",u+="~         format:	"+l.format+"\n",u+="~        addMode:	"+l.adjacency+"\n",u+="~ clearContainer:	"+l.clearContainer.toString()+"\n",u+="~  hideContainer:	"+l.hideContainer.toString()+"\n",u+=new Array(53).join("~")
var p=null,f=null
this.display=function(){e?this.displayMock():googletag.cmd.push(function(){googletag.display(i)})},this.displayMock=function(){console.log("DFP:: display mock",l.sizes[0])
var e=f
if(e&&e.style){var t=l.sizes[0]
e.style.width=t[0]+"px",e.style.height=t[1]+"px"
var n=[function(e){e.style.background="radial-gradient(circle at 100% 50%, transparent 20%, rgba(255,255,255,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent),radial-gradient(circle at 0% 50%, transparent 20%, rgba(255,255,255,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent) 0 -50px",e.style.backgroundSize="75px 100px",e.style.backgroundColor=Math.random()>.5?"#EC173A":"#173A88",e.style.color="#FFFFFF"},function(e){var t="#555",n="#444",r="#999"
Math.random()>.5?(t="#55A",n="#44A",r="#99a"):(t="#0A0",n="#080",r="#6a6"),e.style.backgroundColor=t,e.style.backgroundImage="linear-gradient(30deg, "+n+" 12%, transparent 12.5%, transparent 87%, "+n+" 87.5%, "+n+"),linear-gradient(150deg, "+n+" 12%, transparent 12.5%, transparent 87%, "+n+" 87.5%, "+n+"),linear-gradient(30deg, "+n+" 12%, transparent 12.5%, transparent 87%, "+n+" 87.5%, "+n+"),linear-gradient(150deg, "+n+" 12%, transparent 12.5%, transparent 87%, "+n+" 87.5%, "+n+"),linear-gradient(60deg, "+r+" 25%, transparent 25.5%, transparent 75%, "+r+" 75%, "+r+"),linear-gradient(60deg, "+r+" 25%, transparent 25.5%, transparent 75%, "+r+" 75%, "+r+")",e.style.backgroundSize="80px 140px",e.style.backgroundPosition="0 0, 0 0, 40px 70px, 40px 70px, 0 0, 40px 70px",e.style.color="#FFFFFF"},function(e){e.style.backgroundColor="background-color: hsl(34, 53%, 82%)",e.style.backgroundImage="repeating-linear-gradient(45deg, transparent 5px, hsla(197, 62%, 11%, 0.5) 5px, hsla(197, 62%, 11%, 0.5) 10px, hsla(5, 53%, 63%, 0) 10px, hsla(5, 53%, 63%, 0) 35px, hsla(5, 53%, 63%, 0.5) 35px, hsla(5, 53%, 63%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 50px, hsla(197, 62%, 11%, 0) 50px, hsla(197, 62%, 11%, 0) 60px, hsla(5, 53%, 63%, 0.5) 60px, hsla(5, 53%, 63%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 80px, hsla(35, 91%, 65%, 0) 80px, hsla(35, 91%, 65%, 0) 90px, hsla(5, 53%, 63%, 0.5) 90px, hsla(5, 53%, 63%, 0.5) 110px, hsla(5, 53%, 63%, 0) 110px, hsla(5, 53%, 63%, 0) 120px, hsla(197, 62%, 11%, 0.5) 120px, hsla(197, 62%, 11%, 0.5) 140px), repeating-linear-gradient(135deg, transparent 5px, hsla(197, 62%, 11%, 0.5) 5px, hsla(197, 62%, 11%, 0.5) 10px, hsla(5, 53%, 63%, 0) 10px, hsla(5, 53%, 63%, 0) 35px, hsla(5, 53%, 63%, 0.5) 35px, hsla(5, 53%, 63%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 40px, hsla(197, 62%, 11%, 0.5) 50px, hsla(197, 62%, 11%, 0) 50px, hsla(197, 62%, 11%, 0) 60px, hsla(5, 53%, 63%, 0.5) 60px, hsla(5, 53%, 63%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 70px, hsla(35, 91%, 65%, 0.5) 80px, hsla(35, 91%, 65%, 0) 80px, hsla(35, 91%, 65%, 0) 90px, hsla(5, 53%, 63%, 0.5) 90px, hsla(5, 53%, 63%, 0.5) 110px, hsla(5, 53%, 63%, 0) 110px, hsla(5, 53%, 63%, 0) 140px, hsla(197, 62%, 11%, 0.5) 140px, hsla(197, 62%, 11%, 0.5) 160px)",e.style.color="#000000"},function(e){var t=""
t=Math.random()>.5?"rgba(200,0,0,.5)":"rgba(160,150,0,.5)",e.style.backgroundColor="white",e.style.backgroundImage="linear-gradient(90deg, "+t+" 50%, transparent 50%), linear-gradient("+t+" 50%, transparent 50%)",e.style.backgroundSize="50px 50px",e.style.color="#00000"}]
n[Math.random()*n.length|0](e),e.style.margin="0 auto",e.style.display="flex",e.style.flexFlow="row wrap",e.style.alignItems="center",e.style.justifyContent="center",e.style.fontSize="3.5rem",e.innerHTML='<div><div style="font-size:1.25rem">'+l.slotname+"</div><div>"+t[0]+" ✕ "+t[1]+"</div></div>",l.loaded({isEmpty:!1,sizes:t},this)}},this.getSettings=function(){return l},this.loaded=function(e){l.loaded(e,this)},this.viewed=function(e){l.viewed(e,this)},this.getElement=function(){return f},this.refresh=function(){null!=p&&googletag.pubads().refresh([p])},this.define=function(){var e=this
googletag.cmd.push(function(){try{if(t(u),o("display_"+i,"create_"+i),p=l.oop?googletag.defineOutOfPageSlot(l.unit,i):googletag.defineSlot(l.unit,l.sizes,i),null===p)throw"declared advert is null"
var n=[]
if(""!==l.format&&n.push(l.format),n.length>0&&p.setTargeting("format",n),"object"==typeof l.targeting)for(var a in l.targeting)p.setTargeting(a,l.targeting[a])
p.addService(googletag.pubads()),e.display()}catch(s){r("exception when displaying ads: ",s)}})},this.hasSlot=function(e){return p===e},this.createContainer=function(){var e=l.hook||function(){return null}
d(e)&&(e=e()),a(e)&&(e={element:e}),e=h(!0,{element:l.element,adjacency:l.adjacency},e)
var t=new s(e),r="<!--"+u+"-->",o=document.createElement("div")
o.id=i+"-wrapper"
var p=""
return l.useDefaultClassName&&(p="dfp-plugin-advert "),o.className=p+l.cssClass,o.style.position="relative",l.hideContainer&&(o.style.display="none"),o.innerHTML=r,t.isValid()?(l.clearContainer&&t.clear(),c=document.createElement("div"),c.id=i,c.style.position="relative",o.appendChild(c),t.add(o),f=o,!0):(n("No hook for advert: ",l),!1)},this.hide=function(){t("Hiding",l.slotname),f&&(f.style.display="none")},this.show=function(){t("Showing",l.slotname),f&&(f.style.display="block")},this.remove=function(){null!=p&&googletag.pubads().clear([p])},this.destroy=function(){null!=p&&googletag.destroySlots([p])}}function c(){var e=(new Date).getTime()
return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(t){var n=(e+16*Math.random())%16|0
return e=Math.floor(e/16),("x"==t?n:3&n|8).toString(16)})}function u(e,t,n){return function(r){return Array.isArray(r)?e+r.join(t)+n:null}}window.googletag=window.googletag||{},googletag.cmd=googletag.cmd||[],o("dfp_init"),Array.isArray||(Array.isArray=function(e){return"[object Array]"===Object.prototype.toString.call(e)}),Array.prototype.filter||(Array.prototype.filter=function(e){if(void 0===this||null===this)throw new TypeError
var t=Object(this),n=t.length>>>0,r=[]
if("function"!=typeof e)throw new TypeError
for(var o=arguments.length>=2?arguments[1]:void 0,i=0;n>i;i++)if(i in t){var a=t[i]
e.call(o,a,i,t)&&r.push(a)}return r}),Array.prototype.forEach||(Array.prototype.forEach=function(e,t){var n,r
if(null===this)throw new TypeError(" this is null or not defined")
var o=Object(this),i=o.length>>>0
if("function"!=typeof e)throw new TypeError(e+" is not a function")
for(arguments.length>1&&(n=t),r=0;i>r;){var a
r in o&&(a=o[r],e.call(n,a,r,o)),r++}}),Array.prototype.map||(Array.prototype.map=function(e,t){var n,r,o
if(null===this)throw new TypeError(" this is null or not defined")
var i=Object(this),a=i.length>>>0
if("function"!=typeof e)throw new TypeError(e+" is not a function")
for(arguments.length>1&&(n=t),r=new Array(a),o=0;a>o;){var s,l
o in i&&(s=i[o],l=e.call(n,s,o,i),r[o]=l),o++}return r})
var d=function(e){return"function"==typeof e},p=function(e){return null!==e&&e===e.window},f=function(e){return"object"!=typeof e||e.nodeType||p(e)?!1:e.constructor&&e.constructor.prototype&&e.constructor.prototype.isPrototypeOf?!1:!0},h=function(){var e,t,n,r,o,i,a=arguments[0]||{},s=1,l=arguments.length,c=!1
for("boolean"==typeof a&&(c=a,a=arguments[s]||{},s++),"object"==typeof a||d(a)||(a={}),s===l&&(a=this,s--);l>s;s++)if(null!==(e=arguments[s]))for(t in e)n=a[t],r=e[t],a!==r&&(c&&r&&(f(r)||(o=Array.isArray(r)))?(o?(o=!1,i=n&&Array.isArray(n)?n:[]):i=n&&f(n)?n:{},a[t]=h(c,i,r)):void 0!==r&&(a[t]=r))
return a},m=function(){function a(e){return e.indexOf("@")>-1&&(e=e.substr(0,e.indexOf("@"))),e.indexOf("%40")>-1&&(e=e.substr(0,e.indexOf("%40"))),e.replace(/[#",*()=+<>\[\]]/g,function(e){return"%"+e.charCodeAt(0).toString(16)})}function s(e){for(var t=e.length,n=0;t>n;n++)e[n]=a(e[n])
return e}function u(e){return"string"==typeof e?a(e):Array.isArray(e)?s(e):void 0}function d(){var e,n
if("object"==typeof E){try{var o=""
o+=new Array(20).join("~")+" Global Advert Code ",o+=new Array(20).join("~")+"\n"
for(e in E)""!==n&&n!=[]&&(o+="~     "+e+":	"+JSON.stringify(E[e])+"\n")
o+=new Array(60).join("~"),t(o)}catch(i){r("Exception setting up globals comment:"),r(i)}for(e in E)n=E[e],""!==n&&n!=[]&&googletag.pubads().setTargeting(e,u(n))}}function p(){A=!0,b("advertsLoaded",k)}function f(e){try{for(var t=0;t<S.length;t++)S[t].hasSlot(e.slot)&&S[t].viewed(e)}catch(n){r("Caught exception on viewed:"),r(n)}}function m(e){try{o("slot_rendered","dfp_request"),k.push(e)
for(var t=0;t<S.length;t++)if(S[t].hasSlot(e.slot)){S[t].loaded(e),b("advertLoaded",{id:M,gaId:N,unit:C.unit,globalTargeting:E},e,{number:t.toString(),settings:S[t].getSettings()}),k.length===S.length&&p()
break}}catch(n){r("Caught exception on loaded:"),r(n)}}function g(){x||window.dfpSetup||(x=!0,"undefined"==typeof googletag&&(window.googletag={cmd:[]}),o("dfp_setup","dfp_create"),googletag.cmd.push(function(){try{o("gpt_dfp_setup","dfp_setup"),googletag.pubads().addEventListener("slotRenderEnded",m),googletag.pubads().addEventListener("impressionViewable",f),googletag.pubads().enableAsyncRendering(),googletag.pubads().collapseEmptyDivs(),_&&(googletag.pubads().enableSingleRequest(),googletag.pubads().disableInitialLoad()),googletag.pubads().setCentering(w),o("gpt_enable_services","gpt_dfp_setup"),googletag.enableServices()}catch(e){r(e)}}),window.dfpSetup=!0)}function v(e,t){var r=!1,o=!1,i=null
Array.isArray(e)||(e=[e])
for(var a=0;a<e.length;a++)if(r=e[a].minWidth||!1,o=e[a].maxWidth||!1,(t>=r||r===!1)&&(o>=t||o===!1)){i=e[a]
break}return i?(Array.isArray(i.sizes)&&(i.sizes=i.sizes.filter(function(e){return e[0]<=t})),i):(n("Settings not matched"),null)}function y(e){e()}function b(e){e=e.toLowerCase()
var t=T[e]||[],n=[].slice.call(arguments,1)
t.forEach(function(t){y(function(){try{t.apply(null,n)}catch(o){r('dfp.js dispatchEvent exception for event "'+e+'":',o)}})})}var w=!1,_=!0,E={},C={hook:null,element:null,adjacency:"append",slotname:"unnamed",clearContainer:!1,hideContainer:!1,cssClass:"",useDefaultClassName:!0,format:"",oop:!1,sizes:[],unit:"",targeting:{},loaded:function(){},viewed:function(){}},x=!1,S=[],k=[],T={},A=!1
this.config=function(e){_=e.singleRequest,C.unit=e.unit,w=e.centerAds},this.globalTargeting=function(e){E=h(!0,{},E,e)},this.setupGlobals=function(){googletag.cmd.push(function(){d()})},this.advert=function(e){if("undefined"==typeof e||null===e)return!1
var t=function(e){var t=e.navigator.userAgent.toLowerCase()
return/(iphone|ipod|ipad).* os 9_/.test(t)},n=window,r=window.document,a=r.documentElement,s=t(window)?a.clientWidth:n.innerWidth||a.clientWidth||r.getElementsByTagName("body")[0].clientWidth,c=(n.innerHeight||a.clientHeight||r.getElementsByTagName("body")[0].clientHeight,null)
if(Array.isArray(e)?(i(e,C),c=v(e,s)):(e=h(!0,{},C,e),e.settings?(Array.isArray(e.settings)||(e.settings=[e.settings]),i(e.settings,e),c=v(e.settings,s),c&&delete c.settings):c=v(e,s)),c){g()
var u="dfp_advert_"+S.length
o("create_"+u,"dfp_create")
var d=new l(u,c)
return d.createContainer()&&(d.define(),S.push(d)),d}return null},this.slot=function(e){this.advert(e)},this.passback=function(e,t){b("passback",{network:e,site:t})},this.cmd={push:function(e){e(this)}.bind(this)}
var N,M
this.refresh=function(){"undefined"!=typeof googletag&&(e?(console.log("dfp:: mocking...",S),S.forEach(function(){console.log("dfp:: mock slot",slot),slot.displayMock()})):(N||(N=document.cookie.replace(/(?:(?:^|.*;\s*)_ga\s*\=\s*([^;]*).*$)|^.*$/,"$1")),M||(M=c()),k=[],googletag.cmd.push(function(){try{o("dfp_request","dfp_create"),b("advertsRequested",{id:M,gaId:N,unit:C.unit,globalTargeting:E},S.map(function(e){return e.getSettings()})),googletag.pubads().refresh()}catch(e){r("dfp.refresh exception: ",e)}})))},this.addEventListener=function(e,t){e=e.toLowerCase()
var n=T[e]||[]
switch(n.push(t),T[e]=n,e){case"advertsloaded":A&&b("advertsLoaded",k)}},this.getAdverts=function(){return k},this.getSlots=function(){return S},this.display=function(){this.refresh()},o("dfp_create","dfp_init")},g=new m,v=[]
return window.dfp&&window.dfp.cmd&&(v=v.concat(window.dfp.cmd)),window.dfp=g,v.forEach(function(e){e(g)}),u("[","x","]"),g.addEventListener("advertsRequested",function(){t("dfp.js: advertsRequested")}),g.addEventListener("advertLoaded",function(){}),g}})}()
var amznhelper=!function(e,t){"function"==typeof define&&define.amd?define("amazon_direct_match_helper",[],t):t()}(this,function(){try{return window.Promise?new Promise(function(e){window.usingBordeauxAds?e("disabled"):require(["amazon_direct_match"],function(){amznads.getAdsCallback("3032",function(){amznads.setTargetingForGPTAsync(),e("loaded")})})}):!0}catch(e){window.location&&window.location.search&&logAmazon(e)}}),onscrollhelper=!function(e,t){"function"==typeof define&&define.amd?define("onscroll_helper",[],t):t()}(this,function(){var e=function(){function e(e){return window.location.href.indexOf(e)>=0}if(window.usingBordeauxAds)return!1
if(e("musicradar.com")||e("itproportal.com"))return!1
var t=["GB","US","AU","CA","NZ","IE"],n=document.getElementsByName("geo_locale")[0].content
return n?-1==t.indexOf(n):!1}(),t=dfp_config.onscroll||{mpu:"",refresh:""}
return{config:t,include:e,promise:new Promise(function(n){e?require([t.refresh],function(){setTimeout(function(){n("loaded")},50)}):n("disabled")})}}),xbidder=!function(e,t){"function"==typeof define&&define.amd?define("x_bidder_helper",[],t):t()}(this,function(){try{return window.Promise?new Promise(function(e){window.usingBordeauxAds?e("disabled"):require(["x_bidder"],function(){setTimeout(function(){e("loaded"),console.log("OpenX: loaded library")},50)})}):!0}catch(e){}})
!function(e,t){"function"==typeof define&&define.amd?define("feat_helper",[],t):t()}(this,function(){return window.feat?Promise.resolve(window.feat):new Promise(function(e){window.resolveFEAT=e})}),define("metrics",[],function(){function e(e){var t="; "+document.cookie,n=t.split("; "+e+"=")
return 2==n.length?n.pop().split(";").shift():void 0}"function"!=typeof Object.assign&&!function(){Object.assign=function(e){"use strict"
if(void 0===e||null===e)throw new TypeError("Cannot convert undefined or null to object")
for(var t=Object(e),n=1;n<arguments.length;n++){var r=arguments[n]
if(void 0!==r&&null!==r)for(var o in r)r.hasOwnProperty(o)&&(t[o]=r[o])}return t}}()
var t=[],n={},r=Date.now(),o="ad-metrics",i=0,a={loaded:function(e,n,o){console.log("Ad Loaded:",e)
var a={AdDescription:e.size[0]+"x"+e.size[1],LineItemID:e.lineItemId,CreativeID:e.creativeId,AdLoadTime:n-r,AdTimeOnScreen:0,AdViewed:0,DFPViewed:0}
t[o]=a,i++},request:function(t,o,i,a){r=i,n={Mode:a,AdTestName:"",ArticleID:"",GACookieID:e("_ga"),DFPKeywords:"",DFPAdUnit:t,NumberAds:"",PageViewed:0,TimeOnPage:0,SincePageLoad:o}
var s=window.setInterval(function(){n.ArticleID=analytics_ga_data&&analytics_ga_data.dimension5?analytics_ga_data.dimension5:""},1e3)
window.setTimeout(function(){window.clearInterval(s)},5e3)},viewed:function(e){t[e]?t[e].DFPViewed=1:console.warn("DFP metrics viewed",e," but it had not been added to metrics yet (loaded)")},view:function(e,n,r){n.coverage>=.5&&(t[r].AdTimeOnScreen+=n.interval),t[r].AdViewed=Math.max(n.coverage,t[r].AdViewed)},formatForGA:function(e){var r=Object.assign({},n),o=null
window.performance&&window.performance.timing&&window.performance.timing.navigationStart&&(o=Date.now()-window.performance.timing.navigationStart),r.NumberAds=""+i,r.TimeOnPage=o,r.PageViewed=Math.min(100,Math.floor(100*e))
var a=["dimension68","dimension71","dimension77","dimension78","dimension79"],s=["dimension69","dimension80","dimension81","dimension82","dimension83"],l=["dimension70","dimension84","dimension85","dimension86","dimension87"],c=["metric2","metric3","metric4","metric5","metric6"],u=["metric7","metric8","metric9","metric10","metric11"],d=["metric12","metric13","metric14","metric15","metric16"],p=["metric19","metric20","metric21","metric22","metric23"],f={dimension88:r.Mode,dimension89:r.AdTestName,dimension5:r.ArticleID,dimension59:r.GACookieID,dimension34:r.DFPKeywords,dimension4:r.DFPAdUnit,dimension64:r.NumberAds,metric17:r.PageViewed,metric18:r.TimeOnPage,metric1:r.SincePageLoad},h={}
return a.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=""+t[n].AdDescription)}),s.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=""+t[n].LineItemID)}),l.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=""+t[n].CreativeID)}),c.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=t[n].AdLoadTime)}),u.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=t[n].AdTimeOnScreen)}),d.forEach(function(e,n){if("undefined"!=typeof t[n]){if(t[n].AdViewed>1)throw new Error("Ad Viewed metric over 1.0!")
h[e]=100*(t[n].AdViewed||0)|0}}),p.forEach(function(e,n){"undefined"!=typeof t[n]&&null!==t[n]&&(h[e]=0|t[n].DFPViewed)}),Object.assign(h,f),h},sendData:function(e,t){try{if(window.navigator.sendBeacon)window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: Sending ad metrics to GA using transport: beacon",JSON.stringify(e)),ga("send","event","Ad","Detail",t,Object.assign({},e,{transport:"beacon",nonInteraction:!0}))
else{window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: transport: beacon not supported, storing ad metrics in local storage",JSON.stringify(e))
var n={timestamp:Date.now(),mode:t}
window.localStorage.setItem(o,JSON.stringify({data:e,metadata:n}))}}catch(r){console.log("Exception when sending ad metrics to GA",r)}},checkLocalStorage:function(){try{var e=3,t=Date.now()-24*e*60*60*1e3,n=JSON.parse(window.localStorage.getItem(o))
n&&n.metadata.timestamp>t?(window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: Sending ad metrics from local storage",n),ga("send","event","Ad","Detail",n.metadata.mode,Object.assign({},n.data,{nonInteraction:!0})),window.localStorage.removeItem(o)):window.location.href.indexOf("debug_ad_metrics")>=0&&console.log("debug_ad_metrics: No ad metrics from local storage to send")}catch(r){console.log("Exception when checking local storage for ad metrics",r)}}}
return a}),define("hoist_mobile_mpu",[],function(){var e,t,n=new Promise(function(t){e=t})
exposeMPU2=new Promise(function(e){t=e})
var r={slotMPU1:e,slotMPU2:t,exposeMPU1:n,exposeMPU2:exposeMPU2}
return r}),define("dfp_skin",["app/utils"],function(){return function(){function e(){if(n)if(window.scrollY>=r){if(o===!0)return
t.style.backgroundAttachment="fixed",t.style.backgroundPosition="50% 0",o=!0}else t.style.backgroundAttachment="scroll",t.style.backgroundPosition="50% "+r+"px",o=!1}console.warn("Running legacy dfp_skin")
var t=document.body,n=!1,r=0,o=null
return window.init_background_skin=function(o,i,a,s){function l(e){var t=e.offsetHeight,n=getComputedStyle(e)
return t+=parseInt(n.marginTop)+parseInt(n.marginBottom)}i||(i="none"),s||(s="scroll"),n=!0,r=l(document.getElementsByClassName("primary-nav")[0]),o&&(t.classList.add("has-takeover"),t.style.backgroundColor=i,t.style.backgroundImage="url("+o+")",t.style.backgroundRepeat="no-repeat",t.style.backgroundAttachment="scroll",t.style.backgroundPosition="50% "+r+"px","fixed"===s&&window.addEventListener("optimizedScroll",e)),a&&(t.addEventListener("mouseover",function(e){t.style.cursor="BODY"===e.target.tagName?"pointer":"default"}),t.addEventListener("click",function(e){"BODY"===e.target.tagName&&window.open(a,"_blank")}))},{recalcSkin:e}}}),define("sponsoredPost",["bordeaux"],function(e){var t=1,n=[],r=function(r,o,i,a,s,l,c,u,d){function p(){var t=o.getBoundingClientRect(),n=t.width,r=t.height;(n!==N||r!==M)&&(e.sponsoredShim.sendDimensions(A,{width:n,height:r}),N=n,M=r)}null==u&&(u=""),null==c&&(c="")
try{var f=function(){for(var e=window.document.querySelectorAll(".font-style"),t=0,n=0;n<e.length;n++)-1!==v.site.requiredFonts.internal.indexOf(e[n].id)&&(o.appendChild(window.document.importNode(e[n],!0)),t++)
t!==v.site.requiredFonts.internal.length?(r.WebFontConfig={google:{families:v.site.requiredFonts.external}},function(){var e=r.document.createElement("script")
e.src="https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js",e.type="text/javascript",e.async="true"
var t=r.document.getElementsByTagName("script")[0]
t.parentNode.insertBefore(e,t)}(),console.debug("sponsored-post:","loaded fonts from google")):console.debug("sponsored-post:","loaded fonts from page")},h=function(e){var n=function(){var e=C.querySelector("h3"),n=C.querySelector("a"),o=C.querySelector("img"),p=C.querySelector("figure"),f=C.querySelector("article"),h=C.querySelector(".synopsis"),m=C.querySelector(".category-link")
if(_.querySelector("h3"))var g=window.getComputedStyle(_.querySelector("h3"))
if(m||(m=r.document.createElement("a"),m.className="category-link",C.appendChild(m)),r.document.body.style.backgroundColor="rgb(255,255,255)",C.setAttribute("data-index",t),C.style.backgroundColor="rgb(237,237,237)",n.href=s,n.target="same window"===l.toLowerCase().valueOf()?"_top":"_blank",n.style.display="block",n.style.textDecoration="none",n.addEventListener("mouseover",function(){e.style.color=v.site.labelStyles.backgroundColor}),n.addEventListener("mouseout",function(){e.style.color="black"}),e.textContent=i,e.style.fontFamily=g.fontFamily,e.style.fontSize=g.fontSize,e.style.lineHeight=g.lineHeight,e.style.margin=0,e.style.textDecoration="none",e.style.color="#333333",C.querySelector("span.rating")&&(C.querySelector("span.rating").style.display="none"),o.src=a,o.srcset=a,o.className="",o.style.width="100%",o.style.marginBottom="15px",p.style.overflow="hidden",p.style.margin="0",f.style.backgroundColor="rgb(255,255,255)",f.style.color="#212121",h.style.display="block",h.innerHTML="",h.style.fontFamily=v.site.labelStyles.font,""!=c&&0!=v.site.straplineAllowed){var y=document.createElement("span")
y.className="strapline-text",y.textContent=c,h.appendChild(y),h.style.color=v.site.labelStyles.textColor,h.style.lineHeight="22px",h.style.marginTop="13px"}if(1==v.site.straplineLabel&&null!=u){var b=document.createElement("span")
b.className="free-text-label",h.insertBefore(b,h.firstChild),b.textContent=u,categoryStyle=b.style,categoryStyle.fontSize="80%",categoryStyle.fontWeight="600",categoryStyle.textTransform="uppercase",categoryStyle.marginRight="1ex",categoryStyle.color=v.site.labelStyles.freeTextColor}if(C.querySelector(".image").style.display="block",C.querySelector(".content").style.padding=v.site.paddingNeeded,null!=C.querySelector(".award")&&(C.querySelector(".award").style.display="none"),""!=u&&1==v.site.checkPostLabel?(m.textContent=u,m.style.fontFamily=v.site.labelStyles.font,m.style.color="#fff",m.style.backgroundColor=v.site.labelStyles.standoutColor,m.style.padding=".65em .7em",m.style.textTransform="uppercase",m.style.textDecoration="None",m.style.lineHeight="1.4em",m.style.fontSize=v.site.labelStyles.fontSize,m.style.position=v.site.labelStyles.position):m.style.display="none",0==v.site.deckCheck?m.style.display="none":(m.style.position="absolute",m.style.top="0",m.style.left="0"),1==v.site.bylineAllowed){var w=C.querySelector(".byline"),E=w.querySelector(".by-author"),x=w.querySelector(".published-date")
x.style.display="none",E&&(E.style.display="none"),d&&(w.style.display="block",w.style.margin=null!=c?"10px 0 -5px 0":"10px 0 5px 0",w.style.fontSize=v.site.labelStyles.fontSize,w.style.fontFamily=v.site.labelStyles.font,w.style.color=v.site.labelStyles.textColor,w.textContent=d)}}
switch(e){case"horizontal":n(),C.querySelector(".image").style.marginRight="20px",C.querySelector(".image").style.width="250px",C.querySelector(".image figure img").style.width="250px",C.querySelector(".image").style.float="left",C.querySelector(".image").style.marginTop="0",C.querySelector(".image").style.marginBottom="0",C.querySelector("article").style.overflow="hidden",C.querySelector("article").style.padding="15px 0 15px 0",C.querySelector(".category-link").style.top="15px",C.querySelector(".content").style.height="auto",C.querySelector(".content").style.padding="0 10 0 10",C.querySelector(".content").style.float="left",C.querySelector(".content").style.lineHeight="16px",C.querySelector("figure").style.maxHeight="140px",C.querySelector("figure").style.width="100%",C.querySelector(".content").style.width="calc(100% - 310px)",C.querySelector(".content").style.marginTop="-6px",C.querySelector(".content").style.padding="0 15px 15px 0",window.innerWidth<700&&window.innerWidth>=450&&(C.querySelector(".image").style.paddingLeft="20px",C.querySelector(".category-link").style.left="20px",C.querySelector(".image").style.float="left"),(-1!==window.location.host.indexOf("pcgamer")||-1!==window.location.host.indexOf("gamesradar"))&&(r.document.body.style.backgroundColor="rgb(237,237,237)",C.querySelector("article").style.backgroundColor="rgb(237,237,237)")
break
case"vertical":n(),C.querySelector(".content").style.lineHeight="16px",C.querySelector("figure").style.maxHeight="198px",window.innerWidth>=900&&(C.querySelector("figure").style.maxHeight="167px",C.querySelector(".image").style.marginBottom="15px",null!=v.site.labelAllowedDesktop&&(C.querySelector(".synopsis").style.display="none")),window.innerWidth<=700&&(C.querySelector(".image").style.display="none",C.querySelector(".category-link").style.display="none",C.querySelector(".content").style.padding="18px 20px",C.querySelector(".synopsis").style.marginBottom="0",C.querySelector(".content").style.padding="0 20px",C.querySelector("article").style.padding="20px 0",C.querySelector("img").style.marginBottom="0",(-1!==window.location.host.indexOf("pcgamer")||-1!==window.location.host.indexOf("gamesradar"))&&(r.document.body.style.backgroundColor="rgb(237,237,237)",C.querySelector("article").style.backgroundColor="rgb(237,237,237)"))
break
case"sidebar":var o=C.querySelector(".article-image img"),p=C.querySelector(".article-name"),f=C.querySelector("a")
o.src=a,o.srcset=a,f.href=s,f.target="same window"===l.toLowerCase().valueOf()?"_top":"_blank",f.style.display="block",C.style.cssText=m(_),C.style.height="auto",C.style.backgroundColor="rgb(220,221,223)",o.style.cssText=m(_.querySelector(".article-image img")),o.style.height="auto",C.querySelector(".article-image").style.cssText=m(_.querySelector(".article-image")),p.style.cssText=m(_.querySelector(".article-name")),C.querySelector(".article-image-container").style.cssText=m(_.querySelector(".article-image-container")),p.textContent=i,p.style.float="left"
var h=document.createElement("span")
p.style.height="auto",p.appendChild(h)
var g=C.querySelector(".article-name span")
g.style.background="white",g.style.padding="2px",g.style.fontSize="10px",g.style.fontWeight="400",g.style.fontFamily="Open Sans, sans-serif",g.textContent="Sponsored",g.style.marginLeft="10px",g.style.color="inherit",g.style.textTransform="uppercase"}},m=function(e){var t,n=window.getComputedStyle(e),r=[]
if(""!=n.cssText)return n.cssText
for(t in n)"string"==typeof n[t]&&r.push(t+" : "+n[t])
return r.join("; ")},g=function(e){var t=document.querySelector(".dfp-sponsored.index-"+[e+1]+" iframe")
n[e].querySelector("img").style.visibility="visible",setTimeout(function(){null!==t&&(t.style.height=n[e].offsetHeight+"px",t.style.display="block")},200)},v={listing:{layout:{0:{style:"vertical",setHeight:!0},700:{style:"horizontal",setHeight:!0}}},home:{layout:{0:{style:"vertical",setHeight:!0},700:{style:"horizontal",setHeight:!0},900:{style:"vertical",setHeight:!1}}},article:{layout:{0:{style:"sidebar",setHeight:!0}}}},y="listing"
document.querySelector(".impact")?y="home":document.querySelector("#article-body")&&(y="article")
var b={creativebloq:{requiredFonts:{external:["Open+Sans:700:latin","Open+Sans:400:latin"],internal:["OpenSans"]},labelStyles:{font:"Open Sans,Arial, sans-serif",backgroundColor:"#E94E1B",fontSize:"0.8125rem",textColor:"#333",freeTextColor:"#e94e1b"},paddingNeeded:"0",checkPostLabel:!0,deckCheck:!1,straplineLabel:!0,bylineAllowed:!0,straplineAllowed:!0},pcgamer:{requiredFonts:{external:["Roboto+Condensed:700","Open+Sans:400:latin"],internal:["OpenSans","RobotoCondensed"]},labelStyles:{font:"Open Sans,Arial, sans-serif",backgroundColor:"#DC191B",fontSize:"0.8125rem",textColor:"#333",standoutColor:"#0f1618",freeTextColor:"#dc191b"},paddingNeeded:"0 15px 15px",checkPostLabel:!0,deckCheck:!0,straplineLabel:!0,bylineAllowed:!0,straplineAllowed:!0},gamesradar:{requiredFonts:{external:["Open+Sans:700:latin","Open+Sans:400:latin"],internal:["OpenSans","OpenSansCondensed"]},labelStyles:{font:"Open Sans,Arial, sans-serif",backgroundColor:"#F26722",fontSize:"0.8125rem",textColor:"#666",standoutColor:"#232128",freeTextColor:"#f26722"},paddingNeeded:"0 15px 15px",checkPostLabel:!0,deckCheck:!0,straplineLabel:!0,bylineAllowed:!0,straplineAllowed:!1,labelAllowedDesktop:!1},techradar:{requiredFonts:{external:["Open+Sans+Condensed:700:latin","Open+Sans:400:latin"],internal:["OpenSans"]},labelStyles:{font:"Open Sans,Arial, sans-serif",backgroundColor:"#2f6e91",fontSize:"0.8125rem",textColor:"#333",standoutColor:"#e6248a",freeTextColor:"#e6248a"},paddingNeeded:"0",checkPostLabel:!0,deckCheck:!0,straplineLabel:!0,bylineAllowed:!0,blockTag:!0,straplineAllowed:!0}};-1!==window.location.host.indexOf("creativebloq")?v.site=b.creativebloq:-1!==window.location.host.indexOf("pcgamer")?v.site=b.pcgamer:-1!==window.location.host.indexOf("gamesradar")?v.site=b.gamesradar:-1!==window.location.host.indexOf("techradar")&&(v.site=b.techradar),f()
var w=window.document.querySelector(".sponsored-post"),_=w.nextElementSibling
if(_&&-1===_.className.indexOf("listingResult"))for(var E=0;5>E&&(_=_.nextElementSibling,!(_&&_.className.indexOf("listingResult")>=0));E++);if((null==_||-1===_.className.indexOf("listingResult"))&&(_=w.previousElementSibling,null==_))return
var C=r.document.createElement("div")
C.innerHTML=_.innerHTML,C.className=_.className
var x=Object.keys(v[y].layout)
n.push(C)
for(var E=0;E<x.length;E++){var S=null
if(window.innerWidth>=x[E]&&("undefined"==typeof x[E+1]||window.innerWidth<x[E+1])&&(S=x[E]),null!==S){if(h(v[y].layout[S].style),"undefined"!=typeof v[y].layout[S].setHeight&&v[y].layout[S].setHeight===!0){var k=C.querySelector("img")
k&&(k.style.visibility="hidden",k.addEventListener("load",g.bind(null,t-1))),console.debug("sponsored-post: set height event listener","yes "+S)}else console.debug("sponsored-post: set height event listener","no "+S)
break}}o.appendChild(C),t++}catch(T){console.error(T)}var A="iframe-"+(1e8*Math.random()|0)
r.frameElement.className+=" "+A+" "
var N=-1,M=-1
window.requestAnimationFrame(p),setTimeout(p,1e3),setInterval(function(){window.document.hidden||window.requestAnimationFrame(p)},3e3),p()}
window.renderSponsoredPost=r,e.sponsoredShim.sendRender(r)}),define("ads",["amazon_direct_match_helper","onscroll_helper","x_bidder_helper","app/utils","feat_helper","metrics","bordeaux","hoist_mobile_mpu","dfp_skin","sponsoredPost"],function(e,t,n,r,o,i,a,s,l){"use strict"
return function(r){function c(e,t){return function(){var n=t()
e.width=0|n.width,e.height=(0|n.height)+1}}function u(){return document.querySelector("article.review-article")?document.querySelector("article.review-article").textContent.length:document.querySelector("article.news-article")?document.querySelector("article.news-article").textContent.length:0}function d(e){return window.location.href.indexOf(e)>=0}function p(){return"sticky-mobile"===k}function f(){return document.querySelector(".sticky-next-prev")}function h(e){if(p()){m.then(function(){T.remove()})
var t=function(e){m.then(function(){console.log("calling callback",e,"because leaderboard is actually third party skin!"),e()})}
e.isEmpty?T.remove():((window.related||new Promise(function(e){window.related=e})).then(function(){T.related()}),window.moveRecommendation=function(){T.related()},window.stickyMobile?window.stickyMobile(t):window.stickyMobile=Promise.resolve(t))}}console.log("Running legacy ads..."),l()
var m=new Promise(function(e){window.vanillaAdvertising={thirdPartySkin:function(t){console.log("Third party skin loading in - type:",t),e(t)}}}),g=1,v=759,y=760,b=1024,w=1025,_=function(){var e=window.document.documentElement.clientWidth,t=window.document.body
return"CSS1Compat"===window.document.compatMode&&e||t&&t.clientWidth||e}(),E="mobile"
1e3>_&&_>=700?E="tablet":_>=1e3&&(E="desktop")
var C=Math.min(screen.width,screen.height),x="false"
C>=375&&(x="true")
var S=Math.random()>=.5?"A":"B",k="standard"
"mobile"!==E||d("stickymobile=0")||(k="sticky-mobile"),window.innerWidth>=w&&d("techradar.com")&&(document.querySelector("article.review-article")||document.querySelector("article.news-article"))&&(k=u()>11e3?"standard-long":"standard-short")
var T={createStickyMobileAd:function(){var e=document.createElement("div")
e.className="stickyContainer"
var t={position:"fixed",bottom:"0",width:"100%",height:"auto",display:"flex",justifyContent:"center",zIndex:"999",backgroundColor:"white"},n=document.createElement("div"),r={width:"320px",height:"50px",backgroundColor:"white"}
n.className="stickyAd",Object.assign(e.style,t),Object.assign(n.style,r),e.appendChild(n),document.body.appendChild(e)},remove:function(){var e=document.querySelector(".stickyContainer")
e.style.display="none",T.related=function(){}},related:function(){var e=document.querySelector(".magic-container"),t=document.querySelector(".modal-fb")
e&&(e.style.bottom=t&&e?t.offsetHeight+60+"px":"60px")}}
return new Promise(function(l,u){a.ads(r,i,o).then(function(a){function u(e){return function(){console.log("debug_ad_metrics:","Ad",e,"successfully viewed"),C&&i.viewed(e)}}function m(e){return function(t,n){C&&o.then(function(r){t.isEmpty||(i.loaded(t,Date.now(),e),r.add("Ads",n.getElement(),function(t,n){i.view(t,n,e)},.5,function(){},function(){}))}).catch(function(e){console.log("Exception when initialising advert for tracking",e)})}}function _(e,n,a){function l(e,t,n){if("mpu1"===e)switch(t){case"article":var r,o=document.querySelectorAll("#article-body p:not(:empty)")
if(document.querySelector(".fancy-box"))r=document.querySelector("#article-body > p:nth-of-type(2)")
else for(var i in o)if(o.length&&"IMG"!=o[i].firstChild.tagName){r=o[i]
break}return r||n
case"listing":return d("gamesradar.com")&&document.querySelector(".product-brands")?document.querySelector(".product-brands"):document.querySelectorAll(".listingResult:not(.sponsored-post)")[2]
case"hub":return document.querySelector(".feature-block")||n
default:return n}if("mpu2"===e)switch(t){case"article":if(document.querySelector(".game-spec-box"))return document.querySelector(".game-spec-box")
if(document.querySelector(".gallery"))return
break
case"listing":return d("gamesradar.com")&&document.querySelector(".product-brands")?document.querySelectorAll(".listingResult:not(.sponsored-post)")[4]:document.querySelectorAll(".listingResult:not(.sponsored-post)")[7]
case"hub":return document.querySelector(".list-bottom-links")?document.querySelector(".list-bottom-links"):d("musicradar.com")?document.querySelectorAll(".listingResult:not(.sponsored-post)")[4]:document.querySelectorAll(".listingResult:not(.sponsored-post)")[7]
default:return n}return n}if(Array.prototype.reduce){var _=[].concat(n).reduce(function(e,t){return e+t+"|"},"|")
console.log("send","event","Prebidders","Loaded",_,0|a,{nonInteraction:!0}),Math.random()>.9&&a>0&&ga("send","event","Prebidders","Loaded",_,0|a,{nonInteraction:!0})}var x=!1,S=!1
document.getElementsByClassName("impact").length&&(x=!0,null!=document.getElementById("home-tabs")&&(S=!0))
var A=!1
document.getElementsByClassName("all three").length&&(A=!0)
var M=!1
document.getElementsByClassName("all three-three-four").length&&(M=!0)
var P=!1
document.getElementsByClassName("vertical-homepaginated").length&&(P=!0)
var D=!0
r.addEventListener("advertsRequested",function(){if(!D)try{console.log("Amazon direct Match starting to clear targets")
var e
for(e in amznads.ads)amznads.ads.hasOwnProperty(e)&&(googletag.pubads().clearTargeting(e),console.log("Amazon amazon_direct_match_helper Match Target Cleared ->",e))}catch(t){console.log("exception when clearing Amazon Direct Match targeting",t)}D=!1}),N(window.dfp_config,k)
var I=function(){var e=function(){var e=document.getElementById("engagement-block")
if(null!=e){var t=document.querySelectorAll("#article-body > p"),n=document.getElementById("engagement-warning")
if(t.length>3){var r=t[Math.floor((2*t.length-1)/3)+1]
r.appendChild(n),r.appendChild(e)}else e.style.display="none",n.style.display="none"}}
if(P)var t={newHome1:document.querySelector(".vertical-homepaginated .listingResultsWrapper:nth-of-type(1) .listingResults > .result6"),newHome2:document.querySelector(".vertical-homepaginated .listingResultsWrapper:nth-of-type(1) .listingResults > .popular-box"),newHome3:document.querySelector(".vertical-homepaginated .listingResultsWrapper:nth-of-type(1) .listingResults > .result18")},n={lightbox1:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome1},tablet:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome1},desktop:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome1}},lightbox2:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2}},lightbox3:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},tablet:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},desktop:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3}}},r="listing"
else if(S)var t={newHome1:document.querySelector(".impact .dfp-leaderboard-container"),newHome2:document.querySelector(".impact .listingResultsWrapper:nth-of-type(1) .listingResults > .listingResult:nth-of-type(3)"),newHome3:document.querySelector(".impact section.popular-box")},n={lightbox1:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1}},lightbox2:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:document.querySelectorAll(".listingResult:not(.sponsored-post)")[5]},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2}},lightbox3:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},tablet:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},desktop:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3}}},r="listing"
else if(A)var t={newHome1:document.querySelector(".impact .dfp-leaderboard-container"),newHome2:document.querySelector(".impact .listingResultsWrapper:nth-of-type(1) .listingResults > .listingResult:nth-of-type(4)"),newHome3:document.querySelector(".impact .interruptor")},n={lightbox1:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1}},lightbox2:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:document.querySelectorAll(".listingResult:not(.sponsored-post)")[7]},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2}},lightbox3:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},tablet:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},desktop:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3}}},r="listing"
else if(M)var t={newHome1:document.querySelector(".impact .dfp-leaderboard-container"),newHome2:document.querySelector(".impact .listingResultsWrapper:nth-of-type(1) .listingResults > .listingResult:nth-of-type(5)"),newHome3:document.querySelector(".impact section.popular-box")},n={lightbox1:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1}},lightbox2:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:document.querySelectorAll(".listingResult:not(.sponsored-post)")[4]},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2}},lightbox3:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},tablet:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3},desktop:{classes:"dfp-responsive",adjacency:"after",slot:t.newHome3}}},r="listing"
else if(x)var t={newHome1:document.querySelector(".impact .trending-wrapper")||document.querySelector(".impact .dfp-leaderboard-container"),newHome2:document.querySelector(".impact .listingResultsWrapper:nth-of-type(1) .listingResults > .listingResult:nth-of-type(6)"),newHome3:document.querySelector(".impact .listingResultsWrapper:nth-of-type(2)")},n={lightbox1:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome1}},lightbox2:{mobile:{classes:"dfp-responsive",adjacency:"after",slot:document.querySelectorAll(".listingResult:not(.sponsored-post)")[5]},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome2}},lightbox3:{mobile:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome3},tablet:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome3},desktop:{classes:"dfp-responsive",adjacency:"before",slot:t.newHome3}}},r="listing"
else var t={endOfPage:f()?document.querySelector(".bodyCopy"):document.querySelector(".pagination-numerical-list")||document.querySelector(".next-prev-container")||document.querySelector(".box.pagination"),firstParagraphInArticle:document.querySelector("#article-body p:not(:empty)"),secondParagraphInArticle:document.querySelectorAll("#article-body p")[1],galleryArticle:document.querySelector("#article-body .last-visible"),firstFeatureBlock:document.querySelector(".feature-block"),afterBrowseCategories:document.querySelector(".review-categories-block"),firstListingResultsListingResult:document.querySelector(".listingResults > .listingResult"),firstListingResult:document.querySelector(".listingResult"),secondListingResult:document.querySelectorAll(".listingResult")[1],fifthListingResult:document.querySelectorAll(".listingResult")[4],firstListingResultsWrapper:document.querySelector(".listingResultsWrapper"),secondListingResultsWrapper:document.querySelectorAll(".listingResultsWrapper")[1],secondListingResultsWrapperSecondListingResult:document.querySelector(".listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),thirdListingResultsWrapperSecondListingResult:document.querySelector(".listingResultsWrapper + .listingResultsWrapper + .listingResultsWrapper .listingResult + .listingResult"),sidebarPopularBox:document.querySelector("#sidebar > .popular-box"),sidebar:document.getElementById("sidebar")},n={usSponsored:{hub:{mobile:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult}},article:{mobile:{classes:"",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"",adjacency:"after",slot:t.secondListingResult}},listing:{mobile:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult}}},ukSponsored1:{hub:{mobile:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResult}},article:{mobile:{classes:"",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"",adjacency:"after",slot:t.secondListingResult}},listing:{mobile:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult},tablet:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult},desktop:{classes:"dfp-reset",adjacency:"after",slot:t.secondListingResult}}},ukSponsored2:{hub:{mobile:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},tablet:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},desktop:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult}},article:{mobile:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},tablet:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},desktop:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult}},listing:{mobile:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},tablet:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult},desktop:{classes:"",adjacency:"after",slot:t.secondListingResultsWrapperSecondListingResult}}},ukSponsored3:{hub:{mobile:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},tablet:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},desktop:{classes:"dfp-reset dfp-full-width",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult}},article:{mobile:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},tablet:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},desktop:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult}},listing:{mobile:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},tablet:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult},desktop:{classes:"",adjacency:"after",slot:t.thirdListingResultsWrapperSecondListingResult}}},mpu1:{hub:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:l("mpu1","hub",document.querySelectorAll(".listingResult:not(.sponsored-post)")[2])},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"prepend",slot:t.firstListingResultsWrapper},desktop:{classes:"dfp-mpu",adjacency:"prepend",slot:t.sidebar}},article:{mobile:{classes:"dfp-mpu dfp-in-article dfp-center",adjacency:"after",slot:l("mpu1","article",t.firstParagraphInArticle)},tablet:{classes:"dfp-mpu dfp-in-article dfp-right",adjacency:"after",slot:t.secondParagraphInArticle},desktop:{classes:"dfp-mpu",adjacency:"prepend",slot:t.sidebar}},listing:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:l("mpu1","listing",t.firstListingResult)},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:t.firstListingResult},desktop:{classes:"dfp-mpu",adjacency:"prepend",slot:t.sidebar}}},mpu2:{hub:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:l("mpu2","hub",t.firstListingResultsWrapper)},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"prepend",slot:t.secondListingResultsWrapper},desktop:{classes:"dfp-mpu",adjacency:"before",slot:t.sidebarPopularBox}},article:{mobile:{classes:"dfp-mpu dfp-in-article dfp-center",adjacency:f()?"after":p()?"before":"append",slot:l("mpu2","article",p()?document.querySelector(".gallery")?t.galleryArticle:t.endOfPage:t.sidebar)},tablet:{classes:"dfp-mpu dfp-center",adjacency:"append",slot:t.sidebar},desktop:{classes:"dfp-mpu",adjacency:"before",slot:t.sidebarPopularBox}},listing:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:l("mpu2","listing")||t.fifthListingResult},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:t.fifthListingResult},desktop:{classes:"dfp-mpu",adjacency:"before",slot:t.sidebarPopularBox}}},mpu3:{hub:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"after",slot:t.firstFeatureBlock},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"before",slot:t.sidebarPopularBox},desktop:{classes:"dfp-mpu",adjacency:"append",slot:t.sidebar}},article:{mobile:{classes:"dfp-mpu dfp-in-article dfp-center",adjacency:"append",slot:t.sidebar},tablet:{classes:"dfp-mpu dfp-center",adjacency:"append",slot:t.sidebar},desktop:{classes:"dfp-mpu",adjacency:"append",slot:t.sidebar}},listing:{mobile:{classes:"dfp-mpu dfp-listing",adjacency:"before",slot:t.sidebarPopularBox},tablet:{classes:"dfp-mpu dfp-listing",adjacency:"before",slot:t.sidebarPopularBox},desktop:{classes:"dfp-mpu",adjacency:"append",slot:t.sidebar}}}},r="listing"
return document.querySelectorAll("article.news-article").length||document.querySelectorAll("article.review-article").length?r="article":document.querySelectorAll(".feature-block").length&&(r="hub"),"mobile"===E&&p()&&T.createStickyMobileAd(),"desktop"!=E&&e(),console.log(n.lightbox3),x?{lightbox1:n.lightbox1[E],lightbox2:n.lightbox2[E],lightbox3:n.lightbox3[E]}:{usSponsored:n.usSponsored[r][E],ukSponsored1:n.ukSponsored1[r][E],ukSponsored2:n.ukSponsored2[r][E],ukSponsored3:n.ukSponsored3[r][E],mpu1:n.mpu1[r][E],mpu2:n.mpu2[r][E],mpu3:n.mpu3[r][E]}},R=I(),L=function(e,t){var n=function(){return null!=e.nextElementSibling&&e.nextElementSibling.className.indexOf("listingResult")>-1?e.nextElementSibling.getBoundingClientRect():null!=e.previousElementSibling?e.previousElementSibling.getBoundingClientRect():void 0}
t+=1,r.advert({element:e,cssClass:"",adjacency:"prepend",sizes:[[5,5]],settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_sponsored_"+t,cssClass:"dfp-sponsored index-"+t,targeting:{pos:t,placement:"dfp_rs_mobile_sponsored_"+t}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_sponsored_"+t,cssClass:"dfp-sponsored index-"+t,targeting:{pos:t,placement:"dfp_rs_tablet_sponsored_"+t}},{minWidth:w,slotname:"dfp_rs_desktop_sponsored_"+t,cssClass:"dfp-sponsored index-"+t,targeting:{pos:t,placement:"dfp_rs_desktop_sponsored_"+t}}],loaded:function(t,r){var o=r.getElement()
if(o.style.margin="0px",t.isEmpty)console.debug("sponsored-post: empty","is empty"),o.parentNode.removeChild(o)
else{o.nextElementSibling&&e.removeChild(o.nextElementSibling)
var i=o.querySelector("iframe")
c(i,n)()
var a=setInterval(c(i,n),500)
setTimeout(function(){clearInterval(a)},5e3)}}})}
Array.prototype.forEach.call(document.querySelectorAll(".sponsored-post"),L),console.log("ads config","isImpactWithTabs",S,"impactBlocksConfig1",A,"impactBlocksConfig2",M,"isVerticalHomePaginated",P),S||A||M||P?(console.debug("Ads","is impact but not techradar..."),r.advert({element:document.body,settings:{minWidth:w,slotname:"dfp_rs_desktop_skin_oop_1",cssClass:"dfp-oop",format:"roadblock",oop:!0,targeting:{oop:"skin",placement:"dfp_rs_desktop_skin_oop_1"}}}),r.advert({element:document.body,settings:[{maxWidth:v,slotname:"dfp_rs_mobile_overlay_oop_1",cssClass:"dfp-oop",oop:!0,format:"mobile",targeting:{oop:"overlay",placement:"dfp_rs_mobile_overlay_oop_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_overlay_oop_1",cssClass:"dfp-oop",oop:!0,targeting:{oop:"overlay",placement:"dfp_rs_tablet_overlay_oop_1"}},{minWidth:w,slotname:"dfp_rs_desktop_overlay_oop_1",cssClass:"dfp-oop",oop:!0,targeting:{oop:"overlay",placement:"dfp_rs_desktop_overlay_oop_1"}}]}),r.advert({element:p()?document.querySelector(".stickyAd"):R.lightbox1.slot,slotname:"dfp_lightbox1",cssClass:R.lightbox1.classes,loaded:m(0),viewed:u(0),adjacency:R.lightbox1.adjacency,targeting:{placement:"dfp_lightbox1",pos:1},settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_leaderboard_1",cssClass:"dfp-leaderboard-mobile dfp-center",sizes:[[320,50],[300,50]],format:["mobile","roadblock"],adjacency:"append",targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,11],[728,90],[728,91]]},{minWidth:w,sizes:[[10,10],[10,11],[970,250],[970,251],[728,90],[728,91]]}]}),r.advert({element:R.lightbox2.slot,slotname:"dfp_lightbox2",cssClass:R.lightbox2.classes,adjacency:R.lightbox2.adjacency,loaded:m(1),viewed:u(1),targeting:{placement:"dfp_lightbox2",pos:2},settings:[{element:R.lightbox2.slot||document.querySelectorAll(".listingResult:not(.sponsored-post)")[3],minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_mpu_1",cssClass:"dfp-mpu dfp-center",sizes:p()?[[300,250],[300,251],[300,600],[300,601]]:[[10,10],[10,12],[300,250],[300,252]],format:["mobile","roadblock"],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,12],[728,90],[728,92]]},{minWidth:w,sizes:[[10,10],[10,12],[970,250],[970,252],[728,90],[728,92]],loaded:function(e,t){t.getElement().style.marginBottom="40px",m(1)(e,t)}}]}),r.advert({element:R.lightbox3.slot,slotname:"dfp_lightbox3",cssClass:R.lightbox3.classes,loaded:m(2),viewed:u(2),adjacency:R.lightbox3.adjacency,targeting:{placement:"dfp_lightbox3",pos:3},settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_mpu_2",cssClass:"dfp-mpu dfp-center",sizes:p()?[[300,250],[300,252],[300,600],[300,602]]:[[10,10],[10,13],[300,250],[300,253]],format:["mobile","roadblock"],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,13],[728,90],[728,93]]},{minWidth:w,sizes:[[10,10],[10,13],[970,250],[970,253],[728,90],[728,93]]}]})):x?((d("itproportal.com")||d("techradar.com"))&&r.advert({element:document.body,settings:{minWidth:w,slotname:"dfp_rs_desktop_skin_oop_1",cssClass:"dfp-oop",format:"roadblock",oop:!0,targeting:{oop:"skin",placement:"dfp_rs_desktop_skin_oop_1"}}}),r.advert({element:p()?document.querySelector(".stickyAd"):R.lightbox1.slot,slotname:"dfp_lightbox1",cssClass:R.lightbox1.classes,loaded:m(0),viewed:u(0),adjacency:R.lightbox1.adjacency,targeting:{placement:"dfp_lightbox1",pos:1},settings:[{minWidth:g,maxWidth:v,sizes:[[320,50],[300,50]],slotname:"dfp_rs_mobile_leaderboard_1",cssClass:"dfp-leaderboard-mobile dfp-center",format:["mobile","roadblock"],adjacency:"append",targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,11],[728,90],[728,91]]},{minWidth:w,sizes:[[10,10],[10,11],[970,250],[970,251],[728,90],[728,91]]}]}),r.advert({element:R.lightbox2.slot,slotname:"dfp_lightbox2",cssClass:R.lightbox2.classes,adjacency:R.lightbox2.adjacency,targeting:{placement:"dfp_lightbox2",pos:2},viewed:u(1),settings:[{element:R.lightbox2.slot||document.querySelectorAll(".listingResult:not(.sponsored-post)")[3],minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_mpu_1",cssClass:"dfp-mpu dfp-center",sizes:p()?[[300,250],[300,251],[300,600],[300,601]]:[[10,10],[10,12],[300,250],[300,252]],format:["mobile","roadblock"],loaded:m(1),targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,12],[728,90],[728,92]],loaded:m(1)},{minWidth:w,sizes:[[10,10],[10,12],[970,250],[970,252],[728,90],[728,92]],loaded:function(e,t){t.getElement().style.marginBottom="40px",m(1)(e,t)}}]}),r.advert({element:R.lightbox3.slot,slotname:"dfp_lightbox3",cssClass:R.lightbox3.classes,loaded:m(2),viewed:u(2),adjacency:R.lightbox3.adjacency,targeting:{placement:"dfp_lightbox3",pos:3},settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_mpu_2",cssClass:"dfp-mpu dfp-center",sizes:p()?[[300,250],[300,252],[300,600],[300,602]]:[[10,10],[10,13],[300,250],[300,253]],format:["mobile","roadblock"],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2"}},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,13],[728,90],[728,93]]},{minWidth:w,sizes:[[10,10],[10,13],[970,250],[970,253],[728,90],[728,93]]}]})):("undefined"==typeof vanAdsConfig&&(window.vanAdsConfig={allowedAds:"*"}),"*"===vanAdsConfig.allowedAds&&(r.advert({element:R.usSponsored.slot,settings:{minWidth:g,slotname:"dfp_rs_us_sponsored",cssClass:R.usSponsored.classes,oop:!1,adjacency:R.usSponsored.adjacency,sizes:[[610,190]],targeting:{placement:"dfp_rs_us_sponsored"}}}),r.advert({element:R.ukSponsored1.slot,settings:{minWidth:g,slotname:"dfp_rs_uk_sponsored_1",cssClass:R.ukSponsored1.classes,adjacency:R.ukSponsored1.adjacency,sizes:[[610,190]],targeting:{placement:"dfp_rs_uk_sponsored_1",pos:1}}}),r.advert({element:R.ukSponsored2.slot,settings:{minWidth:g,slotname:"dfp_rs_uk_sponsored_2",cssClass:R.ukSponsored2.classes,adjacency:R.ukSponsored2.adjacency,sizes:[[610,190]],targeting:{placement:"dfp_rs_uk_sponsored_2",pos:2}}}),r.advert({element:R.ukSponsored3.slot,settings:{minWidth:g,slotname:"dfp_rs_uk_sponsored_3",cssClass:R.ukSponsored3.classes,adjacency:R.ukSponsored3.adjacency,sizes:[[610,190]],targeting:{placement:"dfp_rs_uk_sponsored_3",pos:3}}})),("*"===vanAdsConfig.allowedAds||-1!==vanAdsConfig.allowedAds.indexOf("leaderboard"))&&r.advert({element:p()?document.querySelector(".stickyAd"):document.querySelector(".dfp-leaderboard-container"),undertone:"hide",loaded:function(e,t){m(0)(e,t),h(e)},viewed:u(0),settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_leaderboard_1",cssClass:"dfp-leaderboard-mobile dfp-center",oop:!1,format:["mobile","roadblock"],adjacency:"append",sizes:p()?[[300,50],[320,50]]:[[320,50],[300,50]],targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_leaderboard_1",cssClass:"dfp-leaderboard-tablet dfp-center",oop:!1,format:"roadblock",adjacency:"append",sizes:[[728,90]],targeting:{pos:1,placement:"dfp_rs_tablet_leaderboard_1"}},{minWidth:w,slotname:"dfp_rs_desktop_leaderboard_1",cssClass:"dfp-leaderboard dfp-center",oop:!1,adjacency:"append",format:"roadblock",sizes:[[728,90],[970,250],[970,90],[970,66]],targeting:{pos:1,placement:"dfp_rs_desktop_leaderboard_1"}}]}),"*"===vanAdsConfig.allowedAds||-1!==vanAdsConfig.allowedAds.indexOf("mpu")?(r.advert({element:R.mpu1.slot,loaded:function(e,t){m(1)(e,t),s.slotMPU1(t.getElement())},viewed:u(1),settings:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_1",cssClass:R.mpu1.classes,oop:!1,format:["mobile","roadblock"],adjacency:R.mpu1.adjacency,sizes:p()?[[300,250],[300,251],[300,600],[300,601]]:[[300,250],[300,251]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_mpu_1",cssClass:R.mpu1.classes,oop:!1,format:"roadblock",adjacency:R.mpu1.adjacency,sizes:[[300,250],[300,251],[300,600],[300,601]],targeting:{pos:1,placement:"dfp_rs_tablet_mpu_1"}},{minWidth:w,slotname:"dfp_rs_desktop_mpu_1",cssClass:R.mpu1.classes,oop:!1,adjacency:R.mpu1.adjacency,format:"roadblock",sizes:[[300,250],[300,251],[300,600],[300,601]],targeting:{pos:1,placement:"dfp_rs_desktop_mpu_1"}}]}),r.advert({element:R.mpu2.slot,cssClass:R.mpu2.classes,adjacency:R.mpu2.adjacency,loaded:m(2),viewed:u(2),settings:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_2",sizes:p()?[[300,250],[300,252],[300,600],[300,602]]:[[300,250],[300,253],[300,600],[300,603]],format:["mobile","roadblock"],targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2"},loaded:function(e,t){m(3)(e,t),s.slotMPU2(t.getElement())}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_mpu_2",format:"roadblock",sizes:[[300,250],[300,252],[300,600],[300,602]],targeting:{pos:2,placement:"dfp_rs_tablet_mpu_2"}},{minWidth:w,slotname:"dfp_rs_desktop_mpu_2",format:"roadblock",sizes:[[300,250],[300,252],[300,600],[300,602]],targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2"}}]}),r.advert({element:R.mpu3.slot,cssClass:R.mpu3.classes,adjacency:R.mpu3.adjacency,viewed:u(3),settings:(p()?[]:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_3",sizes:[[300,250]],format:["adx"],targeting:{pos:3,placement:"dfp_rs_mobile_mpu_3"},loaded:m(3)}]).concat([{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_mpu_3",sizes:[[300,250]],format:"adx",targeting:{pos:3,placement:"dfp_rs_tablet_mpu_3"},loaded:m(3)},{minWidth:w,slotname:"dfp_rs_desktop_mpu_3",sizes:[[300,250]],format:"adx",targeting:{pos:3,placement:"dfp_rs_desktop_mpu_3"},loaded:function(e,n){window.setTimeout(function(){if(t.include&&!document.querySelector("article.gallery-image")){var r=document.createElement("div")
r.id="onscroll-sticky-mpu"
var o=document.createElement("script")
o.src=t.config.mpu,r.appendChild(o),n.getElement().parentElement.appendChild(r),o.onload=function(){window.OnScroll&&new window.OnScroll.Container}}else m(3)(e,n)},500)}}])})):-1!==vanAdsConfig.allowedAds.indexOf("mobile_mpu")&&r.advert({element:R.mpu1.slot,settings:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_1",cssClass:R.mpu1.classes,oop:!1,format:["mobile","roadblock"],adjacency:R.mpu1.adjacency,sizes:[[300,250],[300,251]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1"}}]}),("*"===vanAdsConfig.allowedAds||-1!==vanAdsConfig.allowedAds.indexOf("skin"))&&r.advert({element:document.body,settings:{minWidth:w,slotname:"dfp_rs_desktop_skin_oop_1",cssClass:"dfp-oop",format:"roadblock",oop:!0,targeting:{oop:"skin",placement:"dfp_rs_desktop_skin_oop_1"}}}),"*"===vanAdsConfig.allowedAds&&r.advert({element:document.body,settings:[{maxWidth:v,slotname:"dfp_rs_mobile_overlay_oop_1",cssClass:"dfp-oop",oop:!0,format:"mobile",targeting:{oop:"overlay",placement:"dfp_rs_mobile_overlay_oop_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_overlay_oop_1",cssClass:"dfp-oop",oop:!0,targeting:{oop:"overlay",placement:"dfp_rs_tablet_overlay_oop_1"}},{minWidth:w,slotname:"dfp_rs_desktop_overlay_oop_1",cssClass:"dfp-oop",oop:!0,targeting:{oop:"overlay",placement:"dfp_rs_desktop_overlay_oop_1"}}]}),r.advert({element:document.body,settings:{minWidth:w,cssClass:"dfp-oop",slotname:"dfp_rs_desktop_outstream_oop_1",oop:!0,sizes:[],targeting:{oop:"outstream",placement:"dfp_rs_desktop_outstream_oop_1"}}})),r.display()
var O=function(){return window.performance&&window.performance.timing&&window.performance.timing.domLoading?Date.now()-window.performance.timing.domLoading:null}()
C&&(i.request(dfp_config.ad_unit,O,Date.now(),k),o.then(function(e){window.location.href.indexOf("debug_ad_metrics")>=0&&window.addEventListener("keypress",function(){console.log("debug_ads_metrics:",JSON.stringify(i.formatForGA(e.getPageViewed()),null,4))}),window.addEventListener("unload",function(){i.sendData(i.formatForGA(e.getPageViewed()),k)})}).catch(function(e){console.log("Exception thrown when setting up ad metrics",e)}))}if(!a){var C=d("techradar.com")||d("gamesradar.com"),A=function(){var e={small:{min:0,max:1279},large:{min:1280,max:12e3}},t=window.screen.width,n="small"
if(!e)return n
for(var r in e)if(e.hasOwnProperty(r)&&t>=e[r].min&&t<=e[r].max)return r
return n},N=function(e,t){var n=e.ad_unit.substring(e.ad_unit.length-1)
"/"==n&&(console.log("DFP issue: missing ad unit. Replacing with default: /article "),e.ad_unit+="article"),r.config({singleRequest:e.single_request,unit:e.ad_unit,centerAds:!0})
var o=e.keywords.split(","),i=e.vertical.split(",")
window.location.href.indexOf("/tag/apple")>=0&&o.push("apple_homepage"),window.location.href.indexOf("/meet-the-team/")>=0&&(e.page_type="article")
var a={screen:A(),kw:o,articleid:e.article_id,manu:e.product_brand,pagetype:e.page_type?e.page_type.replace(",","-"):"",vertical:i,provertical:e.provertical,url:window.location.href,highImpact:M?"true":"false",hopscotch:"false",mode:t,sitePlatform:"vanilla",test:S,pageskin_yes:x}
"undefined"!=typeof e.brand&&(a.brand=e.brand),"undefined"!=typeof e.platform&&(a.platform=e.platform),"undefined"!=typeof e.genre&&(a.genre=e.genre),"undefined"!=typeof e.games&&(a.games=e.games),r.globalTargeting(a),console.log("Setting dfp global targeting",a)
try{window.Krux||((window.Krux=function(){Krux.q.push(arguments)}).q=[]),function(){function e(e){var t,n="kx"+e
return window.localStorage?window.localStorage[n]||"":navigator.cookieEnabled?(t=document.cookie.match(n+"=([^;]*)"),t&&unescape(t[1])||""):""}Krux.user=e("user"),Krux.segments=e("segs")?e("segs").split(","):[]
var t=[]
Krux.user&&(t.push("khost="+encodeURIComponent(location.hostname)),t.push("kuid="+Krux.user))
for(var n=0;n<Krux.segments.length;n++)t.push("ksg="+Krux.segments[n])
Krux.dfppKeyValues=t.length?t.join(";")+";":""}(),r.globalTargeting({kuid:Krux.user})}catch(s){console.log(s)}var l=function(e){if("object"==typeof e){var t=[]
for(var n in e)if(e.hasOwnProperty(n)){var r=e[n]
r=r.replace(/[#*()+\-='",<>\{\}\[\]\\\/]/gi,""),t.push(r)}return t}var o=e.replace(/[#*()+\-='",<>\{\}\[\]\\\/]/gi,"")
return o}
try{VAN.assignFep(FEP_object),"/"!=window.location.pathname&&""!=window.location.pathname&&r.globalTargeting({fepPrimaryProduct:l(FEP.fepPrimaryProduct),fepSecondaryProducts:l(FEP.fepSecondaryProducts),fepCompanies:l(FEP.fepCompanies),fepCategory:l(FEP.fepCategory),fepGroups:l(FEP.fepGroups),fepIAB:l(FEP.fepIAB),fepPrimaryCompany:l(FEP.fepPrimaryCompany),primaryCategory:l(FEP.primaryCategory),secondaryCategories:l(FEP.secondaryCategories),thirdCategories:l(FEP.thirdCategories)})}catch(c){console.log("Exception loading FEP AdTags: ",c)}r.setupGlobals()},M=sessionStorage.getItem("highImpact")||!1
if(sessionStorage.setItem("highImpact",!0),"undefined"==typeof vanAdsConfig||vanAdsConfig!==!1)if(window.Promise){var P=new Promise(function(e){setTimeout(function(){e("timeout")},500)}),D=new Promise(function(e){setTimeout(function(){e("timeout")},800)}),I=0
window.performance&&window.performance.now&&(I=window.performance.now()),Promise.all([Promise.race([t.promise,P]).then(function(e){return"OnScroll:"+e}),Promise.race([e,P]).then(function(e){return"Amazon:"+e}),Promise.race([n,D]).then(function(e){return"OpenX:"+e})]).then(function(e){var t=0
window.performance&&window.performance.now&&(t=window.performance.now()),_(M,e,t-I)}).catch(function(e){console.error("exception thrown with ads",e)})}else _(M)
var R={setDfpGlobalTargeting:N,infiniteNews:{newsArticleListAdverts:function(e){for(var t=0;t<e.length;t++)r.advert({element:e[t],slotname:"dfp_lightbox_news_ad",cssClass:"dfp-responsive",adjacency:"prepend",targeting:{placement:"dfp_lightbox1",pos:1},settings:[{minWidth:g,maxWidth:v,sizes:[[10,10],[10,11],[300,250],[300,251]],format:"mobile"},{minWidth:y,maxWidth:b,sizes:[[10,10],[10,11],[728,90],[728,91]]},{minWidth:w,sizes:[[10,10],[10,11],[970,250],[970,251],[728,90],[728,91]]}]})
r.refresh()},newsArticleItemContent:function(e,t){var n=r.advert({element:e,settings:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_1",cssClass:"dfp-mpu",oop:!1,format:["mobile","roadblock"],adjacency:"prepend",sizes:[[300,250],[300,251],[300,600],[300,601]],targeting:{pos:1,placement:"dfp_rs_mobile_mpu_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_mpu_1",cssClass:"dfp-mpu",oop:!1,format:"roadblock",adjacency:"prepend",sizes:[[300,250],[300,251],[300,600],[300,601]],targeting:{pos:1,placement:"dfp_rs_tablet_mpu_1"}},{minWidth:w,slotname:"dfp_rs_desktop_mpu_1",cssClass:"dfp-mpu",oop:!1,adjacency:"prepend",format:"roadblock",sizes:[[300,250],[300,251],[300,600],[300,601]],targeting:{pos:1,placement:"dfp_lightbox1"}}]}),o=r.advert({element:e,settings:[{maxWidth:v,slotname:"dfp_rs_mobile_mpu_2",sizes:[[300,250],[300,251],[300,600],[300,601]],format:["mobile","roadblock"],cssClass:"dfp-mpu",oop:!1,adjacency:"append",targeting:{pos:2,placement:"dfp_rs_mobile_mpu_2"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_mpu_3",sizes:[[300,250],[300,251],[300,600],[300,601]],format:"roadblock",cssClass:"dfp-mpu",oop:!1,adjacency:"append",targeting:{pos:2,placement:"dfp_rs_tablet_mpu_2"}},{minWidth:w,slotname:"dfp_rs_desktop_mpu_3",sizes:[[300,250],[300,251],[300,600],[300,601]],format:"roadblock",cssClass:"dfp-mpu",oop:!1,adjacency:"append",targeting:{pos:2,placement:"dfp_rs_desktop_mpu_2"}}]}),i=r.advert({element:t,slotname:"dfp_lightbox_news_ad",cssClass:"dfp-responsive",adjacency:"prepend",targeting:{placement:"dfp_lightbox1",pos:1},settings:[{minWidth:g,maxWidth:v,slotname:"dfp_rs_mobile_leaderboard_1",cssClass:"dfp-leaderboard-mobile dfp-center",oop:!1,format:["mobile","roadblock"],adjacency:"append",sizes:[[320,50],[300,50]],targeting:{pos:1,placement:"dfp_rs_mobile_leaderboard_1"}},{minWidth:y,maxWidth:b,slotname:"dfp_rs_tablet_leaderboard_1",cssClass:"dfp-leaderboard-tablet dfp-center",oop:!1,format:"roadblock",adjacency:"append",sizes:[[728,90]],targeting:{pos:1,placement:"dfp_rs_tablet_leaderboard_1"}},{minWidth:w,slotname:"dfp_rs_desktop_leaderboard_1",cssClass:"dfp-leaderboard dfp-center",oop:!1,adjacency:"append",format:"roadblock",sizes:[[728,90],[970,250],[970,90],[970,66]],targeting:{pos:1,placement:"dfp_rs_desktop_leaderboard_1"}}]})
return r.display(),[n,o,i]}}}
l(R)}}).catch(function(e){console.log("Exception in overall ads.js",e),u()})})}}),define("dfp",["bordeaux","dfp_legacy","ads"],function(e,t,n){var r=Promise.resolve(window.usingBordeauxAds?Promise.resolve(window.reliablePageLoad).then(function(){return window.bordeauxAds||Promise.resolve(!1)}):!1).then(function(r){if(console.log("Result of window.bordeauxAds:","window.usingBordeauxAds",window.usingBordeauxAds,"if true then use Promise window.bordeauxAds",window.bordeauxAds,"->",r,"or, if undefined then Promise.resolve(false)"),r)return console.log("::Not running legacy DFP & ads.js - using shim"),e.dfpShim
console.log("::Running legacy DFP & ads.js")
var o=t(),i=n(o)
return{refresh:function(){o.refresh()},getSlots:function(){return[]},addEventListener:function(e,t){o.addEventListener(e,t)},setKeywords:function(e){dfp_config.keywords=e,i.then(function(e){e.setDfpGlobalTargeting(dfp_config)})}}})
return{refresh:function(){r.then(function(e){e.refresh()})},getSlots:function(){return[]},addEventListener:function(e,t){r.then(function(n){n.addEventListener(e,t)})},setKeywords:function(e){r.then(function(t){t.setKeywords(e)})}}}),define("app/event_tracking",["es6promise_init","es6promise"],function(){var e={drivers:{},activeDrivers:[],activateDriver:function(t){return new Promise(function(n,r){e.drivers[t].init().then(function(){console.debug('Event Tracking driver "'+t+'" initialised'),n()},function(){console.debug("Driver "+t+" could not initialise, check init function"),r(t)})})},init:function(t){e.activeDrivers=[],Array.isArray(t)||(t=[t])
var n=[]
return t.forEach(function(t){n.push(e.activateDriver(t).then(function(){e.activeDrivers.push(t)}))}),new Promise(function(e,t){Promise.race(n).then(function(){e()},function(){t()})}).then(function(){console.debug("All Event Tracking drivers initialised")},function(e){console.error("Event tracking init failed for driver:"+e)})},send:function(t,n,r){console.debug("Event received, sending to drivers",t,n,r)
var o=[]
return e.activeDrivers.forEach(function(i){o.push(e.drivers[i].send(t,n,r))}),new Promise(function(e,t){Promise.all(o).then(function(){console.debug("Event sucessfully sent to all drivers"),e()},function(){console.debug("Event failed to send on all drivers"),t()})})}},t=function(e){if(window.indexedDB){var t=indexedDB.open(e.name,e.version)
t.onupgradeneeded=e.onupgrade(e),t.onsuccess=function(){console.debug("IndexedDB database ("+e.name+", version "+e.version+")  opened successfully")}}}
return e.drivers.indexedDB={name:"fibet",version:4,objectStoreOptions:{autoIncrement:!0},purgeDayOffest:-60,initPromise:null,init:function(){return e.drivers.indexedDB.initPromise=new Promise(function(t,n){if(window.indexedDB){var r=e.drivers.indexedDB.name,o=e.drivers.indexedDB.version,i=indexedDB.open(r,o)
i.onerror=function(e){console.error("IndexedDB database ("+r+", "+o+")  could not be opened: "+e.srcElement.error.message),n(e)},i.onupgradeneeded=e.drivers.indexedDB.openUpgrade,i.onsuccess=function(n){console.debug("IndexedDB database ("+r+", version "+o+")  opened successfully")
var i=Math.floor(Date.now()/1e3)
i+=60*e.drivers.indexedDB.purgeDayOffest*60*24,e.drivers.indexedDB.purgeOldEntries(i).then(function(){console.debug("Purged old indexedDB entries")},function(){console.debug("Purge unsuccessful")}).catch(function(e){console.debug("Some sort of error: ",e)}),t(n.target.result)}}else console.error("Browser does not support IndexedDB."),n()}),e.drivers.indexedDB.initPromise},createUpgradeFunction:function(e){return function(t){var n=e.name,r=e.version
console.debug("Upgrading IndexedDB database ("+n+", "+r+") from version "+t.oldVersion+" to version "+t.newVersion)
var o=t.target.result
if(t.oldVersion>0){console.debug("Deleting version "+t.oldVersion+" of the database")
try{o.deleteObjectStore(e.name)}catch(i){console.error("Error when deleting old object",i)}}var a=o.createObjectStore(e.name,e.objectStoreOptions)
a.createIndex("label","label",{unique:!1}),a.createIndex("category","category",{unique:!1}),a.createIndex("action","action",{unique:!1}),a.createIndex("timestamp","timestamp",{unique:!1}),console.debug("Upgrade complete")}},purgeOldEntries:function(t){return new Promise(function(n,r){e.drivers.indexedDB.initPromise.then(function(r){var o=new Date(1e3*t)
console.debug("Purging events before "+t+" ("+o+")")
var i=r.transaction([e.drivers.indexedDB.name],"readwrite"),a=i.objectStore(e.drivers.indexedDB.name),s=a.index("timestamp"),l=IDBKeyRange.upperBound(t,!0),c=0
s.openCursor(l).onsuccess=function(e){var t=e.target.result
if(t){c++
var r=t.value.timestamp,o=t.delete()
o.onsuccess=function(){console.debug("Deleted an entry with timestamp "+r)},t.continue()}else console.debug("Purge complete: "+c+" records deleted"),n()}},function(){console.debug("Could not purge entries: database could not be opened"),r()})})},send:function(t,n,r){return console.debug("Storing event in indexedDB"),new Promise(function(o,i){e.drivers.indexedDB.initPromise.then(function(a){var s=a.transaction([e.drivers.indexedDB.name],"readwrite"),l=s.objectStore(e.drivers.indexedDB.name)
s.oncomplete=function(){console.debug("Event saved within indexedDB"),o()},s.onerror=function(){console.debug("Event not be saved within indexedDB"),i()},l.add({category:t,action:n,label:r,timestamp:Math.floor(Date.now()/1e3)})},function(){console.debug("Could not store event: database could not be opened"),i()})})},getEventsByAction:function(t){return console.debug("Retrieving events with action: "+t),new Promise(function(n,r){e.drivers.indexedDB.initPromise.then(function(r){var o=r.transaction([e.drivers.indexedDB.name]),i=o.objectStore(e.drivers.indexedDB.name),a=i.index("action"),s=IDBKeyRange.only(t),l=[],c=a.openCursor(s)
c.onsuccess=function(e){var r=e.target.result
r?(l.push(r.value),r.continue()):(console.debug("Found "+l.length+" events with action: "+t),n(l))}},function(){console.debug("Could not retrieve events with action: "+t+": database could not be opened"),r()})})}},e.drivers.indexedDB.openUpgrade=e.drivers.indexedDB.createUpgradeFunction({name:e.drivers.indexedDB.name,version:e.drivers.indexedDB.version,objectStoreOptions:e.drivers.indexedDB.objectStoreOptions}),"undefined"!=typeof global&&(global.quickLoadScript="("+t.toString()+')({"name": "'+e.drivers.indexedDB.name+'", "version": '+e.drivers.indexedDB.version+', "objectStoreOptions": '+JSON.stringify(e.drivers.indexedDB.objectStoreOptions)+', "onupgrade": '+e.drivers.indexedDB.createUpgradeFunction.toString()+"})"),e.drivers.ga={init:function(){return new Promise(function(e,t){"ga"in window?e():t()})},send:function(e,t,n){return console.debug("Sending event to GA"),new Promise(function(r){ga("set","nonInteraction",!0),ga("send",{hitType:"event",eventCategory:e,eventAction:t,eventLabel:n}),console.debug("Event sent to GA"),r()}).catch(function(){console.error("Event not sent to GA")})}},e}),define("app/engagement",["dfp","app/event_tracking","app/utils"],function(e,t,n){var r=!1
e.addEventListener("advertsLoaded",function(){if(!r){r=!0
var e=document.getElementById("engagement-block"),o="/recommendation"
if(console.debug("Check if engagement block exists..."),null!=e){console.debug("Engagement block exists, look for recommendations")
for(var i=document.getElementById("article-body"),a=n.findElementRuns(i,"P"),s=!1,l=0;l<a.length;l++){var c=a[l]
if(c.length>3&&c.index+c.length/2>2){if(0==c.index)var u=i.children[2]
else var u=i.children[parseInt(c.index+c.length/2)-1]
u.appendChild(document.getElementById("engagement-warning")),u.appendChild(document.getElementById("engagement-block")),s=!0
break}}if(s){var d=function(){Array.prototype.forEach.call(e.querySelectorAll("a"),function(e){e.addEventListener("click",function(){t.send(e.getAttribute("data-ga-event-category"),e.getAttribute("href"),e.getAttribute("data-ga-event"))})})
var n=function(){if(e.getBoundingClientRect().top+e.getBoundingClientRect().height<window.innerHeight){window.removeEventListener("optimizedScroll",n)
var r=document.getElementById("engagement-block")
t.send(r.getAttribute("data-ga-event-category"),r.getAttribute("data-ga-event-action"),r.getAttribute("data-ga-event"))}}
window.addEventListener("optimizedScroll",n),n()},p=new XMLHttpRequest,f=function(){if(4===p.readyState&&200===p.status&&"undefined"!=typeof p.response){var e=p.response
console.debug("Recommendation response received - number of recommendations: ",e.length),e=n.shuffle(e).filter(function(e){return e.u!==window.location.pathname}).slice(0,3),e.length>0&&(document.querySelector("#engagement-block h5").innerHTML="Articles you should read",document.querySelector("#engagement-block").setAttribute("data-ga-event-category","personalised-engagement-widget-seen"),document.querySelector("#engagement-block").setAttribute("data-ga-event-action","Personalised Engagement Widget"),document.querySelector("#engagement-block").setAttribute("data-ga-event","personalised-engagement-widget"))
for(var t=n.shuffle([1,2,3]),r=e.length-1;r>=0;r--){var o=e[r],i=document.querySelector("section.engagement .item-"+t[r])
if(null!=i){i.querySelector("a").setAttribute("href",o.u),i.querySelector("a").setAttribute("data-ga-event-category","engagement-widget-personalisation-clicked"),i.querySelector("span.article-name").innerHTML=o.n
var a=o.m.replace(/[0-9]{2,4}-[0-9]{2,3}(?!-|[0-9])/,"110-80"),s=o.m.replace(/[0-9]{2,4}-[0-9]{2,3}(?!-|[0-9])/,"320-80")
console.debug("Generating new image URLs given image:",o.m),console.debug("Generated small image URL:",a),console.debug("Generated large image URL:",s)
var l=a+" 110w, "+s+" 320w"
console.debug("New srcset: ",l),i.querySelector("img").setAttribute("srcset",l)}}d(),document.getElementById("engagement-warning").style.display="block",document.getElementById("engagement-block").style.display="block",console.debug("Finished adding "+e.length+" recommendations to engagement widget at ",window.performance.now())}}
p.responseType="json",p.onreadystatechange=f,p.open("GET",o),p.send(),console.debug("Recommendation request sent")}}}})}),function(e){function t(e,t,n){switch(arguments.length){case 2:return null!=e?e:t
case 3:return null!=e?e:null!=t?t:n
default:throw new Error("Implement me")}}function n(e,t){return St.call(e,t)}function r(){return{empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1}}function o(e){bt.suppressDeprecationWarnings===!1&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+e)}function i(e,t){var n=!0
return p(function(){return n&&(o(e),n=!1),t.apply(this,arguments)},t)}function a(e,t){vn[e]||(o(t),vn[e]=!0)}function s(e,t){return function(n){return m(e.call(this,n),t)}}function l(e,t){return function(n){return this.localeData().ordinal(e.call(this,n),t)}}function c(){}function u(e,t){t!==!1&&P(e),f(this,e),this._d=new Date(+e._d)}function d(e){var t=x(e),n=t.year||0,r=t.quarter||0,o=t.month||0,i=t.week||0,a=t.day||0,s=t.hour||0,l=t.minute||0,c=t.second||0,u=t.millisecond||0
this._milliseconds=+u+1e3*c+6e4*l+36e5*s,this._days=+a+7*i,this._months=+o+3*r+12*n,this._data={},this._locale=bt.localeData(),this._bubble()}function p(e,t){for(var r in t)n(t,r)&&(e[r]=t[r])
return n(t,"toString")&&(e.toString=t.toString),n(t,"valueOf")&&(e.valueOf=t.valueOf),e}function f(e,t){var n,r,o
if("undefined"!=typeof t._isAMomentObject&&(e._isAMomentObject=t._isAMomentObject),"undefined"!=typeof t._i&&(e._i=t._i),"undefined"!=typeof t._f&&(e._f=t._f),"undefined"!=typeof t._l&&(e._l=t._l),"undefined"!=typeof t._strict&&(e._strict=t._strict),"undefined"!=typeof t._tzm&&(e._tzm=t._tzm),"undefined"!=typeof t._isUTC&&(e._isUTC=t._isUTC),"undefined"!=typeof t._offset&&(e._offset=t._offset),"undefined"!=typeof t._pf&&(e._pf=t._pf),"undefined"!=typeof t._locale&&(e._locale=t._locale),Rt.length>0)for(n in Rt)r=Rt[n],o=t[r],"undefined"!=typeof o&&(e[r]=o)
return e}function h(e){return 0>e?Math.ceil(e):Math.floor(e)}function m(e,t,n){for(var r=""+Math.abs(e),o=e>=0;r.length<t;)r="0"+r
return(o?n?"+":"":"-")+r}function g(e,t){var n={milliseconds:0,months:0}
return n.months=t.month()-e.month()+12*(t.year()-e.year()),e.clone().add(n.months,"M").isAfter(t)&&--n.months,n.milliseconds=+t-+e.clone().add(n.months,"M"),n}function v(e,t){var n
return t=O(t,e),e.isBefore(t)?n=g(e,t):(n=g(t,e),n.milliseconds=-n.milliseconds,n.months=-n.months),n}function y(e,t){return function(n,r){var o,i
return null===r||isNaN(+r)||(a(t,"moment()."+t+"(period, number) is deprecated. Please use moment()."+t+"(number, period)."),i=n,n=r,r=i),n="string"==typeof n?+n:n,o=bt.duration(n,r),b(this,o,e),this}}function b(e,t,n,r){var o=t._milliseconds,i=t._days,a=t._months
r=null==r?!0:r,o&&e._d.setTime(+e._d+o*n),i&&ft(e,"Date",pt(e,"Date")+i*n),a&&dt(e,pt(e,"Month")+a*n),r&&bt.updateOffset(e,i||a)}function w(e){return"[object Array]"===Object.prototype.toString.call(e)}function _(e){return"[object Date]"===Object.prototype.toString.call(e)||e instanceof Date}function E(e,t,n){var r,o=Math.min(e.length,t.length),i=Math.abs(e.length-t.length),a=0
for(r=0;o>r;r++)(n&&e[r]!==t[r]||!n&&k(e[r])!==k(t[r]))&&a++
return a+i}function C(e){if(e){var t=e.toLowerCase().replace(/(.)s$/,"$1")
e=un[e]||dn[t]||t}return e}function x(e){var t,r,o={}
for(r in e)n(e,r)&&(t=C(r),t&&(o[t]=e[r]))
return o}function S(t){var n,r
if(0===t.indexOf("week"))n=7,r="day"
else{if(0!==t.indexOf("month"))return
n=12,r="month"}bt[t]=function(o,i){var a,s,l=bt._locale[t],c=[]
if("number"==typeof o&&(i=o,o=e),s=function(e){var t=bt().utc().set(r,e)
return l.call(bt._locale,t,o||"")},null!=i)return s(i)
for(a=0;n>a;a++)c.push(s(a))
return c}}function k(e){var t=+e,n=0
return 0!==t&&isFinite(t)&&(n=t>=0?Math.floor(t):Math.ceil(t)),n}function T(e,t){return new Date(Date.UTC(e,t+1,0)).getUTCDate()}function A(e,t,n){return st(bt([e,11,31+t-n]),t,n).week}function N(e){return M(e)?366:365}function M(e){return e%4===0&&e%100!==0||e%400===0}function P(e){var t
e._a&&-2===e._pf.overflow&&(t=e._a[Tt]<0||e._a[Tt]>11?Tt:e._a[At]<1||e._a[At]>T(e._a[kt],e._a[Tt])?At:e._a[Nt]<0||e._a[Nt]>23?Nt:e._a[Mt]<0||e._a[Mt]>59?Mt:e._a[Pt]<0||e._a[Pt]>59?Pt:e._a[Dt]<0||e._a[Dt]>999?Dt:-1,e._pf._overflowDayOfYear&&(kt>t||t>At)&&(t=At),e._pf.overflow=t)}function D(e){return null==e._isValid&&(e._isValid=!isNaN(e._d.getTime())&&e._pf.overflow<0&&!e._pf.empty&&!e._pf.invalidMonth&&!e._pf.nullInput&&!e._pf.invalidFormat&&!e._pf.userInvalidated,e._strict&&(e._isValid=e._isValid&&0===e._pf.charsLeftOver&&0===e._pf.unusedTokens.length)),e._isValid}function I(e){return e?e.toLowerCase().replace("_","-"):e}function R(e){for(var t,n,r,o,i=0;i<e.length;){for(o=I(e[i]).split("-"),t=o.length,n=I(e[i+1]),n=n?n.split("-"):null;t>0;){if(r=L(o.slice(0,t).join("-")))return r
if(n&&n.length>=t&&E(o,n,!0)>=t-1)break
t--}i++}return null}function L(e){var t=null
if(!It[e]&&Lt)try{t=bt.locale(),require("./locale/"+e),bt.locale(t)}catch(n){}return It[e]}function O(e,t){return t._isUTC?bt(e).zone(t._offset||0):bt(e).local()}function B(e){return e.match(/\[[\s\S]/)?e.replace(/^\[|\]$/g,""):e.replace(/\\/g,"")}function q(e){var t,n,r=e.match(Ut)
for(t=0,n=r.length;n>t;t++)r[t]=gn[r[t]]?gn[r[t]]:B(r[t])
return function(o){var i=""
for(t=0;n>t;t++)i+=r[t]instanceof Function?r[t].call(o,e):r[t]
return i}}function U(e,t){return e.isValid()?(t=j(t,e.localeData()),pn[t]||(pn[t]=q(t)),pn[t](e)):e.localeData().invalidDate()}function j(e,t){function n(e){return t.longDateFormat(e)||e}var r=5
for(jt.lastIndex=0;r>=0&&jt.test(e);)e=e.replace(jt,n),jt.lastIndex=0,r-=1
return e}function F(e,t){var n,r=t._strict
switch(e){case"Q":return Qt
case"DDDD":return Jt
case"YYYY":case"GGGG":case"gggg":return r?en:zt
case"Y":case"G":case"g":return nn
case"YYYYYY":case"YYYYY":case"GGGGG":case"ggggg":return r?tn:Ht
case"S":if(r)return Qt
case"SS":if(r)return Zt
case"SSS":if(r)return Jt
case"DDD":return Wt
case"MMM":case"MMMM":case"dd":case"ddd":case"dddd":return Vt
case"a":case"A":return t._locale._meridiemParse
case"X":return $t
case"Z":case"ZZ":return Gt
case"T":return Kt
case"SSSS":return Yt
case"MM":case"DD":case"YY":case"GG":case"gg":case"HH":case"hh":case"mm":case"ss":case"ww":case"WW":return r?Zt:Ft
case"M":case"D":case"d":case"H":case"h":case"m":case"s":case"w":case"W":case"e":case"E":return Ft
case"Do":return Xt
default:return n=new RegExp(X($(e.replace("\\","")),"i"))}}function W(e){e=e||""
var t=e.match(Gt)||[],n=t[t.length-1]||[],r=(n+"").match(ln)||["-",0,0],o=+(60*r[1])+k(r[2])
return"+"===r[0]?-o:o}function z(e,t,n){var r,o=n._a
switch(e){case"Q":null!=t&&(o[Tt]=3*(k(t)-1))
break
case"M":case"MM":null!=t&&(o[Tt]=k(t)-1)
break
case"MMM":case"MMMM":r=n._locale.monthsParse(t),null!=r?o[Tt]=r:n._pf.invalidMonth=t
break
case"D":case"DD":null!=t&&(o[At]=k(t))
break
case"Do":null!=t&&(o[At]=k(parseInt(t,10)))
break
case"DDD":case"DDDD":null!=t&&(n._dayOfYear=k(t))
break
case"YY":o[kt]=bt.parseTwoDigitYear(t)
break
case"YYYY":case"YYYYY":case"YYYYYY":o[kt]=k(t)
break
case"a":case"A":n._isPm=n._locale.isPM(t)
break
case"H":case"HH":case"h":case"hh":o[Nt]=k(t)
break
case"m":case"mm":o[Mt]=k(t)
break
case"s":case"ss":o[Pt]=k(t)
break
case"S":case"SS":case"SSS":case"SSSS":o[Dt]=k(1e3*("0."+t))
break
case"X":n._d=new Date(1e3*parseFloat(t))
break
case"Z":case"ZZ":n._useUTC=!0,n._tzm=W(t)
break
case"dd":case"ddd":case"dddd":r=n._locale.weekdaysParse(t),null!=r?(n._w=n._w||{},n._w.d=r):n._pf.invalidWeekday=t
break
case"w":case"ww":case"W":case"WW":case"d":case"e":case"E":e=e.substr(0,1)
case"gggg":case"GGGG":case"GGGGG":e=e.substr(0,2),t&&(n._w=n._w||{},n._w[e]=k(t))
break
case"gg":case"GG":n._w=n._w||{},n._w[e]=bt.parseTwoDigitYear(t)}}function H(e){var n,r,o,i,a,s,l
n=e._w,null!=n.GG||null!=n.W||null!=n.E?(a=1,s=4,r=t(n.GG,e._a[kt],st(bt(),1,4).year),o=t(n.W,1),i=t(n.E,1)):(a=e._locale._week.dow,s=e._locale._week.doy,r=t(n.gg,e._a[kt],st(bt(),a,s).year),o=t(n.w,1),null!=n.d?(i=n.d,a>i&&++o):i=null!=n.e?n.e+a:a),l=lt(r,o,i,s,a),e._a[kt]=l.year,e._dayOfYear=l.dayOfYear}function Y(e){var n,r,o,i,a=[]
if(!e._d){for(o=G(e),e._w&&null==e._a[At]&&null==e._a[Tt]&&H(e),e._dayOfYear&&(i=t(e._a[kt],o[kt]),e._dayOfYear>N(i)&&(e._pf._overflowDayOfYear=!0),r=rt(i,0,e._dayOfYear),e._a[Tt]=r.getUTCMonth(),e._a[At]=r.getUTCDate()),n=0;3>n&&null==e._a[n];++n)e._a[n]=a[n]=o[n]
for(;7>n;n++)e._a[n]=a[n]=null==e._a[n]?2===n?1:0:e._a[n]
e._d=(e._useUTC?rt:nt).apply(null,a),null!=e._tzm&&e._d.setUTCMinutes(e._d.getUTCMinutes()+e._tzm)}}function V(e){var t
e._d||(t=x(e._i),e._a=[t.year,t.month,t.day,t.hour,t.minute,t.second,t.millisecond],Y(e))}function G(e){var t=new Date
return e._useUTC?[t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()]:[t.getFullYear(),t.getMonth(),t.getDate()]}function K(e){if(e._f===bt.ISO_8601)return void Z(e)
e._a=[],e._pf.empty=!0
var t,n,r,o,i,a=""+e._i,s=a.length,l=0
for(r=j(e._f,e._locale).match(Ut)||[],t=0;t<r.length;t++)o=r[t],n=(a.match(F(o,e))||[])[0],n&&(i=a.substr(0,a.indexOf(n)),i.length>0&&e._pf.unusedInput.push(i),a=a.slice(a.indexOf(n)+n.length),l+=n.length),gn[o]?(n?e._pf.empty=!1:e._pf.unusedTokens.push(o),z(o,n,e)):e._strict&&!n&&e._pf.unusedTokens.push(o)
e._pf.charsLeftOver=s-l,a.length>0&&e._pf.unusedInput.push(a),e._isPm&&e._a[Nt]<12&&(e._a[Nt]+=12),e._isPm===!1&&12===e._a[Nt]&&(e._a[Nt]=0),Y(e),P(e)}function $(e){return e.replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(e,t,n,r,o){return t||n||r||o})}function X(e){return e.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}function Q(e){var t,n,o,i,a
if(0===e._f.length)return e._pf.invalidFormat=!0,void(e._d=new Date(0/0))
for(i=0;i<e._f.length;i++)a=0,t=f({},e),null!=e._useUTC&&(t._useUTC=e._useUTC),t._pf=r(),t._f=e._f[i],K(t),D(t)&&(a+=t._pf.charsLeftOver,a+=10*t._pf.unusedTokens.length,t._pf.score=a,(null==o||o>a)&&(o=a,n=t))
p(e,n||t)}function Z(e){var t,n,r=e._i,o=rn.exec(r)
if(o){for(e._pf.iso=!0,t=0,n=an.length;n>t;t++)if(an[t][1].exec(r)){e._f=an[t][0]+(o[6]||" ")
break}for(t=0,n=sn.length;n>t;t++)if(sn[t][1].exec(r)){e._f+=sn[t][0]
break}r.match(Gt)&&(e._f+="Z"),K(e)}else e._isValid=!1}function J(e){Z(e),e._isValid===!1&&(delete e._isValid,bt.createFromInputFallback(e))}function et(e,t){var n,r=[]
for(n=0;n<e.length;++n)r.push(t(e[n],n))
return r}function tt(t){var n,r=t._i
r===e?t._d=new Date:_(r)?t._d=new Date(+r):null!==(n=Ot.exec(r))?t._d=new Date(+n[1]):"string"==typeof r?J(t):w(r)?(t._a=et(r.slice(0),function(e){return parseInt(e,10)}),Y(t)):"object"==typeof r?V(t):"number"==typeof r?t._d=new Date(r):bt.createFromInputFallback(t)}function nt(e,t,n,r,o,i,a){var s=new Date(e,t,n,r,o,i,a)
return 1970>e&&s.setFullYear(e),s}function rt(e){var t=new Date(Date.UTC.apply(null,arguments))
return 1970>e&&t.setUTCFullYear(e),t}function ot(e,t){if("string"==typeof e)if(isNaN(e)){if(e=t.weekdaysParse(e),"number"!=typeof e)return null}else e=parseInt(e,10)
return e}function it(e,t,n,r,o){return o.relativeTime(t||1,!!n,e,r)}function at(e,t,n){var r=bt.duration(e).abs(),o=xt(r.as("s")),i=xt(r.as("m")),a=xt(r.as("h")),s=xt(r.as("d")),l=xt(r.as("M")),c=xt(r.as("y")),u=o<fn.s&&["s",o]||1===i&&["m"]||i<fn.m&&["mm",i]||1===a&&["h"]||a<fn.h&&["hh",a]||1===s&&["d"]||s<fn.d&&["dd",s]||1===l&&["M"]||l<fn.M&&["MM",l]||1===c&&["y"]||["yy",c]
return u[2]=t,u[3]=+e>0,u[4]=n,it.apply({},u)}function st(e,t,n){var r,o=n-t,i=n-e.day()
return i>o&&(i-=7),o-7>i&&(i+=7),r=bt(e).add(i,"d"),{week:Math.ceil(r.dayOfYear()/7),year:r.year()}}function lt(e,t,n,r,o){var i,a,s=rt(e,0,1).getUTCDay()
return s=0===s?7:s,n=null!=n?n:o,i=o-s+(s>r?7:0)-(o>s?7:0),a=7*(t-1)+(n-o)+i+1,{year:a>0?e:e-1,dayOfYear:a>0?a:N(e-1)+a}}function ct(t){var n=t._i,r=t._f
return t._locale=t._locale||bt.localeData(t._l),null===n||r===e&&""===n?bt.invalid({nullInput:!0}):("string"==typeof n&&(t._i=n=t._locale.preparse(n)),bt.isMoment(n)?new u(n,!0):(r?w(r)?Q(t):K(t):tt(t),new u(t)))}function ut(e,t){var n,r
if(1===t.length&&w(t[0])&&(t=t[0]),!t.length)return bt()
for(n=t[0],r=1;r<t.length;++r)t[r][e](n)&&(n=t[r])
return n}function dt(e,t){var n
return"string"==typeof t&&(t=e.localeData().monthsParse(t),"number"!=typeof t)?e:(n=Math.min(e.date(),T(e.year(),t)),e._d["set"+(e._isUTC?"UTC":"")+"Month"](t,n),e)}function pt(e,t){return e._d["get"+(e._isUTC?"UTC":"")+t]()}function ft(e,t,n){return"Month"===t?dt(e,n):e._d["set"+(e._isUTC?"UTC":"")+t](n)}function ht(e,t){return function(n){return null!=n?(ft(this,e,n),bt.updateOffset(this,t),this):pt(this,e)}}function mt(e){return 400*e/146097}function gt(e){return 146097*e/400}function vt(e){bt.duration.fn[e]=function(){return this._data[e]}}function yt(e){"undefined"==typeof ender&&(wt=Ct.moment,Ct.moment=e?i("Accessing Moment through the global scope is deprecated, and will be removed in an upcoming release.",bt):bt)}for(var bt,wt,_t,Et="2.8.3",Ct="undefined"!=typeof global?global:this,xt=Math.round,St=Object.prototype.hasOwnProperty,kt=0,Tt=1,At=2,Nt=3,Mt=4,Pt=5,Dt=6,It={},Rt=[],Lt="undefined"!=typeof module&&module.exports,Ot=/^\/?Date\((\-?\d+)/i,Bt=/(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/,qt=/^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/,Ut=/(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,4}|X|zz?|ZZ?|.)/g,jt=/(\[[^\[]*\])|(\\)?(LT|LL?L?L?|l{1,4})/g,Ft=/\d\d?/,Wt=/\d{1,3}/,zt=/\d{1,4}/,Ht=/[+\-]?\d{1,6}/,Yt=/\d+/,Vt=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,Gt=/Z|[\+\-]\d\d:?\d\d/gi,Kt=/T/i,$t=/[\+\-]?\d+(\.\d{1,3})?/,Xt=/\d{1,2}/,Qt=/\d/,Zt=/\d\d/,Jt=/\d{3}/,en=/\d{4}/,tn=/[+-]?\d{6}/,nn=/[+-]?\d+/,rn=/^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/,on="YYYY-MM-DDTHH:mm:ssZ",an=[["YYYYYY-MM-DD",/[+-]\d{6}-\d{2}-\d{2}/],["YYYY-MM-DD",/\d{4}-\d{2}-\d{2}/],["GGGG-[W]WW-E",/\d{4}-W\d{2}-\d/],["GGGG-[W]WW",/\d{4}-W\d{2}/],["YYYY-DDD",/\d{4}-\d{3}/]],sn=[["HH:mm:ss.SSSS",/(T| )\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss",/(T| )\d\d:\d\d:\d\d/],["HH:mm",/(T| )\d\d:\d\d/],["HH",/(T| )\d\d/]],ln=/([\+\-]|\d\d)/gi,cn=("Date|Hours|Minutes|Seconds|Milliseconds".split("|"),{Milliseconds:1,Seconds:1e3,Minutes:6e4,Hours:36e5,Days:864e5,Months:2592e6,Years:31536e6}),un={ms:"millisecond",s:"second",m:"minute",h:"hour",d:"day",D:"date",w:"week",W:"isoWeek",M:"month",Q:"quarter",y:"year",DDD:"dayOfYear",e:"weekday",E:"isoWeekday",gg:"weekYear",GG:"isoWeekYear"},dn={dayofyear:"dayOfYear",isoweekday:"isoWeekday",isoweek:"isoWeek",weekyear:"weekYear",isoweekyear:"isoWeekYear"},pn={},fn={s:45,m:45,h:22,d:26,M:11},hn="DDD w W M D d".split(" "),mn="M D H h m s w W".split(" "),gn={M:function(){return this.month()+1},MMM:function(e){return this.localeData().monthsShort(this,e)},MMMM:function(e){return this.localeData().months(this,e)},D:function(){return this.date()},DDD:function(){return this.dayOfYear()},d:function(){return this.day()},dd:function(e){return this.localeData().weekdaysMin(this,e)},ddd:function(e){return this.localeData().weekdaysShort(this,e)},dddd:function(e){return this.localeData().weekdays(this,e)},w:function(){return this.week()},W:function(){return this.isoWeek()},YY:function(){return m(this.year()%100,2)},YYYY:function(){return m(this.year(),4)},YYYYY:function(){return m(this.year(),5)},YYYYYY:function(){var e=this.year(),t=e>=0?"+":"-"
return t+m(Math.abs(e),6)},gg:function(){return m(this.weekYear()%100,2)},gggg:function(){return m(this.weekYear(),4)},ggggg:function(){return m(this.weekYear(),5)},GG:function(){return m(this.isoWeekYear()%100,2)},GGGG:function(){return m(this.isoWeekYear(),4)},GGGGG:function(){return m(this.isoWeekYear(),5)},e:function(){return this.weekday()},E:function(){return this.isoWeekday()},a:function(){return this.localeData().meridiem(this.hours(),this.minutes(),!0)},A:function(){return this.localeData().meridiem(this.hours(),this.minutes(),!1)},H:function(){return this.hours()},h:function(){return this.hours()%12||12},m:function(){return this.minutes()},s:function(){return this.seconds()},S:function(){return k(this.milliseconds()/100)},SS:function(){return m(k(this.milliseconds()/10),2)},SSS:function(){return m(this.milliseconds(),3)},SSSS:function(){return m(this.milliseconds(),3)},Z:function(){var e=-this.zone(),t="+"
return 0>e&&(e=-e,t="-"),t+m(k(e/60),2)+":"+m(k(e)%60,2)},ZZ:function(){var e=-this.zone(),t="+"
return 0>e&&(e=-e,t="-"),t+m(k(e/60),2)+m(k(e)%60,2)},z:function(){return this.zoneAbbr()},zz:function(){return this.zoneName()},X:function(){return this.unix()},Q:function(){return this.quarter()}},vn={},yn=["months","monthsShort","weekdays","weekdaysShort","weekdaysMin"];hn.length;)_t=hn.pop(),gn[_t+"o"]=l(gn[_t],_t)
for(;mn.length;)_t=mn.pop(),gn[_t+_t]=s(gn[_t],2)
gn.DDDD=s(gn.DDD,3),p(c.prototype,{set:function(e){var t,n
for(n in e)t=e[n],"function"==typeof t?this[n]=t:this["_"+n]=t},_months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),months:function(e){return this._months[e.month()]},_monthsShort:"Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),monthsShort:function(e){return this._monthsShort[e.month()]},monthsParse:function(e){var t,n,r
for(this._monthsParse||(this._monthsParse=[]),t=0;12>t;t++)if(this._monthsParse[t]||(n=bt.utc([2e3,t]),r="^"+this.months(n,"")+"|^"+this.monthsShort(n,""),this._monthsParse[t]=new RegExp(r.replace(".",""),"i")),this._monthsParse[t].test(e))return t},_weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),weekdays:function(e){return this._weekdays[e.day()]},_weekdaysShort:"Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),weekdaysShort:function(e){return this._weekdaysShort[e.day()]},_weekdaysMin:"Su_Mo_Tu_We_Th_Fr_Sa".split("_"),weekdaysMin:function(e){return this._weekdaysMin[e.day()]},weekdaysParse:function(e){var t,n,r
for(this._weekdaysParse||(this._weekdaysParse=[]),t=0;7>t;t++)if(this._weekdaysParse[t]||(n=bt([2e3,1]).day(t),r="^"+this.weekdays(n,"")+"|^"+this.weekdaysShort(n,"")+"|^"+this.weekdaysMin(n,""),this._weekdaysParse[t]=new RegExp(r.replace(".",""),"i")),this._weekdaysParse[t].test(e))return t},_longDateFormat:{LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY LT",LLLL:"dddd, MMMM D, YYYY LT"},longDateFormat:function(e){var t=this._longDateFormat[e]
return!t&&this._longDateFormat[e.toUpperCase()]&&(t=this._longDateFormat[e.toUpperCase()].replace(/MMMM|MM|DD|dddd/g,function(e){return e.slice(1)}),this._longDateFormat[e]=t),t},isPM:function(e){return"p"===(e+"").toLowerCase().charAt(0)},_meridiemParse:/[ap]\.?m?\.?/i,meridiem:function(e,t,n){return e>11?n?"pm":"PM":n?"am":"AM"},_calendar:{sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},calendar:function(e,t){var n=this._calendar[e]
return"function"==typeof n?n.apply(t):n},_relativeTime:{future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},relativeTime:function(e,t,n,r){var o=this._relativeTime[n]
return"function"==typeof o?o(e,t,n,r):o.replace(/%d/i,e)},pastFuture:function(e,t){var n=this._relativeTime[e>0?"future":"past"]
return"function"==typeof n?n(t):n.replace(/%s/i,t)},ordinal:function(e){return this._ordinal.replace("%d",e)},_ordinal:"%d",preparse:function(e){return e},postformat:function(e){return e},week:function(e){return st(e,this._week.dow,this._week.doy).week},_week:{dow:0,doy:6},_invalidDate:"Invalid date",invalidDate:function(){return this._invalidDate}}),bt=function(t,n,o,i){var a
return"boolean"==typeof o&&(i=o,o=e),a={},a._isAMomentObject=!0,a._i=t,a._f=n,a._l=o,a._strict=i,a._isUTC=!1,a._pf=r(),ct(a)},bt.suppressDeprecationWarnings=!1,bt.createFromInputFallback=i("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.",function(e){e._d=new Date(e._i)}),bt.min=function(){var e=[].slice.call(arguments,0)
return ut("isBefore",e)},bt.max=function(){var e=[].slice.call(arguments,0)
return ut("isAfter",e)},bt.utc=function(t,n,o,i){var a
return"boolean"==typeof o&&(i=o,o=e),a={},a._isAMomentObject=!0,a._useUTC=!0,a._isUTC=!0,a._l=o,a._i=t,a._f=n,a._strict=i,a._pf=r(),ct(a).utc()},bt.unix=function(e){return bt(1e3*e)},bt.duration=function(e,t){var r,o,i,a,s=e,l=null
return bt.isDuration(e)?s={ms:e._milliseconds,d:e._days,M:e._months}:"number"==typeof e?(s={},t?s[t]=e:s.milliseconds=e):(l=Bt.exec(e))?(r="-"===l[1]?-1:1,s={y:0,d:k(l[At])*r,h:k(l[Nt])*r,m:k(l[Mt])*r,s:k(l[Pt])*r,ms:k(l[Dt])*r}):(l=qt.exec(e))?(r="-"===l[1]?-1:1,i=function(e){var t=e&&parseFloat(e.replace(",","."))
return(isNaN(t)?0:t)*r},s={y:i(l[2]),M:i(l[3]),d:i(l[4]),h:i(l[5]),m:i(l[6]),s:i(l[7]),w:i(l[8])}):"object"==typeof s&&("from"in s||"to"in s)&&(a=v(bt(s.from),bt(s.to)),s={},s.ms=a.milliseconds,s.M=a.months),o=new d(s),bt.isDuration(e)&&n(e,"_locale")&&(o._locale=e._locale),o},bt.version=Et,bt.defaultFormat=on,bt.ISO_8601=function(){},bt.momentProperties=Rt,bt.updateOffset=function(){},bt.relativeTimeThreshold=function(t,n){return fn[t]===e?!1:n===e?fn[t]:(fn[t]=n,!0)},bt.lang=i("moment.lang is deprecated. Use moment.locale instead.",function(e,t){return bt.locale(e,t)}),bt.locale=function(e,t){var n
return e&&(n="undefined"!=typeof t?bt.defineLocale(e,t):bt.localeData(e),n&&(bt.duration._locale=bt._locale=n)),bt._locale._abbr},bt.defineLocale=function(e,t){return null!==t?(t.abbr=e,It[e]||(It[e]=new c),It[e].set(t),bt.locale(e),It[e]):(delete It[e],null)},bt.langData=i("moment.langData is deprecated. Use moment.localeData instead.",function(e){return bt.localeData(e)}),bt.localeData=function(e){var t
if(e&&e._locale&&e._locale._abbr&&(e=e._locale._abbr),!e)return bt._locale
if(!w(e)){if(t=L(e))return t
e=[e]}return R(e)},bt.isMoment=function(e){return e instanceof u||null!=e&&n(e,"_isAMomentObject")},bt.isDuration=function(e){return e instanceof d}
for(_t=yn.length-1;_t>=0;--_t)S(yn[_t])
bt.normalizeUnits=function(e){return C(e)},bt.invalid=function(e){var t=bt.utc(0/0)
return null!=e?p(t._pf,e):t._pf.userInvalidated=!0,t},bt.parseZone=function(){return bt.apply(null,arguments).parseZone()},bt.parseTwoDigitYear=function(e){return k(e)+(k(e)>68?1900:2e3)},p(bt.fn=u.prototype,{clone:function(){return bt(this)},valueOf:function(){return+this._d+6e4*(this._offset||0)},unix:function(){return Math.floor(+this/1e3)},toString:function(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")},toDate:function(){return this._offset?new Date(+this):this._d},toISOString:function(){var e=bt(this).utc()
return 0<e.year()&&e.year()<=9999?U(e,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"):U(e,"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")},toArray:function(){var e=this
return[e.year(),e.month(),e.date(),e.hours(),e.minutes(),e.seconds(),e.milliseconds()]},isValid:function(){return D(this)},isDSTShifted:function(){return this._a?this.isValid()&&E(this._a,(this._isUTC?bt.utc(this._a):bt(this._a)).toArray())>0:!1},parsingFlags:function(){return p({},this._pf)},invalidAt:function(){return this._pf.overflow},utc:function(e){return this.zone(0,e)},local:function(e){return this._isUTC&&(this.zone(0,e),this._isUTC=!1,e&&this.add(this._dateTzOffset(),"m")),this},format:function(e){var t=U(this,e||bt.defaultFormat)
return this.localeData().postformat(t)},add:y(1,"add"),subtract:y(-1,"subtract"),diff:function(e,t,n){var r,o,i,a=O(e,this),s=6e4*(this.zone()-a.zone())
return t=C(t),"year"===t||"month"===t?(r=432e5*(this.daysInMonth()+a.daysInMonth()),o=12*(this.year()-a.year())+(this.month()-a.month()),i=this-bt(this).startOf("month")-(a-bt(a).startOf("month")),i-=6e4*(this.zone()-bt(this).startOf("month").zone()-(a.zone()-bt(a).startOf("month").zone())),o+=i/r,"year"===t&&(o/=12)):(r=this-a,o="second"===t?r/1e3:"minute"===t?r/6e4:"hour"===t?r/36e5:"day"===t?(r-s)/864e5:"week"===t?(r-s)/6048e5:r),n?o:h(o)},from:function(e,t){return bt.duration({to:this,from:e}).locale(this.locale()).humanize(!t)},fromNow:function(e){return this.from(bt(),e)},calendar:function(e){var t=e||bt(),n=O(t,this).startOf("day"),r=this.diff(n,"days",!0),o=-6>r?"sameElse":-1>r?"lastWeek":0>r?"lastDay":1>r?"sameDay":2>r?"nextDay":7>r?"nextWeek":"sameElse"
return this.format(this.localeData().calendar(o,this))},isLeapYear:function(){return M(this.year())},isDST:function(){return this.zone()<this.clone().month(0).zone()||this.zone()<this.clone().month(5).zone()},day:function(e){var t=this._isUTC?this._d.getUTCDay():this._d.getDay()
return null!=e?(e=ot(e,this.localeData()),this.add(e-t,"d")):t},month:ht("Month",!0),startOf:function(e){switch(e=C(e)){case"year":this.month(0)
case"quarter":case"month":this.date(1)
case"week":case"isoWeek":case"day":this.hours(0)
case"hour":this.minutes(0)
case"minute":this.seconds(0)
case"second":this.milliseconds(0)}return"week"===e?this.weekday(0):"isoWeek"===e&&this.isoWeekday(1),"quarter"===e&&this.month(3*Math.floor(this.month()/3)),this},endOf:function(e){return e=C(e),this.startOf(e).add(1,"isoWeek"===e?"week":e).subtract(1,"ms")},isAfter:function(e,t){return t=C("undefined"!=typeof t?t:"millisecond"),"millisecond"===t?(e=bt.isMoment(e)?e:bt(e),+this>+e):+this.clone().startOf(t)>+bt(e).startOf(t)},isBefore:function(e,t){return t=C("undefined"!=typeof t?t:"millisecond"),"millisecond"===t?(e=bt.isMoment(e)?e:bt(e),+e>+this):+this.clone().startOf(t)<+bt(e).startOf(t)},isSame:function(e,t){return t=C(t||"millisecond"),"millisecond"===t?(e=bt.isMoment(e)?e:bt(e),+this===+e):+this.clone().startOf(t)===+O(e,this).startOf(t)},min:i("moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548",function(e){return e=bt.apply(null,arguments),this>e?this:e}),max:i("moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548",function(e){return e=bt.apply(null,arguments),e>this?this:e}),zone:function(e,t){var n,r=this._offset||0
return null==e?this._isUTC?r:this._dateTzOffset():("string"==typeof e&&(e=W(e)),Math.abs(e)<16&&(e=60*e),!this._isUTC&&t&&(n=this._dateTzOffset()),this._offset=e,this._isUTC=!0,null!=n&&this.subtract(n,"m"),r!==e&&(!t||this._changeInProgress?b(this,bt.duration(r-e,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,bt.updateOffset(this,!0),this._changeInProgress=null)),this)},zoneAbbr:function(){return this._isUTC?"UTC":""},zoneName:function(){return this._isUTC?"Coordinated Universal Time":""},parseZone:function(){return this._tzm?this.zone(this._tzm):"string"==typeof this._i&&this.zone(this._i),this},hasAlignedHourOffset:function(e){return e=e?bt(e).zone():0,(this.zone()-e)%60===0},daysInMonth:function(){return T(this.year(),this.month())},dayOfYear:function(e){var t=xt((bt(this).startOf("day")-bt(this).startOf("year"))/864e5)+1
return null==e?t:this.add(e-t,"d")},quarter:function(e){return null==e?Math.ceil((this.month()+1)/3):this.month(3*(e-1)+this.month()%3)},weekYear:function(e){var t=st(this,this.localeData()._week.dow,this.localeData()._week.doy).year
return null==e?t:this.add(e-t,"y")},isoWeekYear:function(e){var t=st(this,1,4).year
return null==e?t:this.add(e-t,"y")},week:function(e){var t=this.localeData().week(this)
return null==e?t:this.add(7*(e-t),"d")},isoWeek:function(e){var t=st(this,1,4).week
return null==e?t:this.add(7*(e-t),"d")},weekday:function(e){var t=(this.day()+7-this.localeData()._week.dow)%7
return null==e?t:this.add(e-t,"d")},isoWeekday:function(e){return null==e?this.day()||7:this.day(this.day()%7?e:e-7)},isoWeeksInYear:function(){return A(this.year(),1,4)},weeksInYear:function(){var e=this.localeData()._week
return A(this.year(),e.dow,e.doy)},get:function(e){return e=C(e),this[e]()},set:function(e,t){return e=C(e),"function"==typeof this[e]&&this[e](t),this},locale:function(t){var n
return t===e?this._locale._abbr:(n=bt.localeData(t),null!=n&&(this._locale=n),this)},lang:i("moment().lang() is deprecated. Use moment().localeData() instead.",function(t){return t===e?this.localeData():this.locale(t)}),localeData:function(){return this._locale},_dateTzOffset:function(){return 15*Math.round(this._d.getTimezoneOffset()/15)}}),bt.fn.millisecond=bt.fn.milliseconds=ht("Milliseconds",!1),bt.fn.second=bt.fn.seconds=ht("Seconds",!1),bt.fn.minute=bt.fn.minutes=ht("Minutes",!1),bt.fn.hour=bt.fn.hours=ht("Hours",!0),bt.fn.date=ht("Date",!0),bt.fn.dates=i("dates accessor is deprecated. Use date instead.",ht("Date",!0)),bt.fn.year=ht("FullYear",!0),bt.fn.years=i("years accessor is deprecated. Use year instead.",ht("FullYear",!0)),bt.fn.days=bt.fn.day,bt.fn.months=bt.fn.month,bt.fn.weeks=bt.fn.week,bt.fn.isoWeeks=bt.fn.isoWeek,bt.fn.quarters=bt.fn.quarter,bt.fn.toJSON=bt.fn.toISOString,p(bt.duration.fn=d.prototype,{_bubble:function(){var e,t,n,r=this._milliseconds,o=this._days,i=this._months,a=this._data,s=0
a.milliseconds=r%1e3,e=h(r/1e3),a.seconds=e%60,t=h(e/60),a.minutes=t%60,n=h(t/60),a.hours=n%24,o+=h(n/24),s=h(mt(o)),o-=h(gt(s)),i+=h(o/30),o%=30,s+=h(i/12),i%=12,a.days=o,a.months=i,a.years=s},abs:function(){return this._milliseconds=Math.abs(this._milliseconds),this._days=Math.abs(this._days),this._months=Math.abs(this._months),this._data.milliseconds=Math.abs(this._data.milliseconds),this._data.seconds=Math.abs(this._data.seconds),this._data.minutes=Math.abs(this._data.minutes),this._data.hours=Math.abs(this._data.hours),this._data.months=Math.abs(this._data.months),this._data.years=Math.abs(this._data.years),this},weeks:function(){return h(this.days()/7)},valueOf:function(){return this._milliseconds+864e5*this._days+this._months%12*2592e6+31536e6*k(this._months/12)},humanize:function(e){var t=at(this,!e,this.localeData())
return e&&(t=this.localeData().pastFuture(+this,t)),this.localeData().postformat(t)},add:function(e,t){var n=bt.duration(e,t)
return this._milliseconds+=n._milliseconds,this._days+=n._days,this._months+=n._months,this._bubble(),this},subtract:function(e,t){var n=bt.duration(e,t)
return this._milliseconds-=n._milliseconds,this._days-=n._days,this._months-=n._months,this._bubble(),this},get:function(e){return e=C(e),this[e.toLowerCase()+"s"]()},as:function(e){var t,n
if(e=C(e),"month"===e||"year"===e)return t=this._days+this._milliseconds/864e5,n=this._months+12*mt(t),"month"===e?n:n/12
switch(t=this._days+gt(this._months/12),e){case"week":return t/7+this._milliseconds/6048e5
case"day":return t+this._milliseconds/864e5
case"hour":return 24*t+this._milliseconds/36e5
case"minute":return 24*t*60+this._milliseconds/6e4
case"second":return 24*t*60*60+this._milliseconds/1e3
case"millisecond":return Math.floor(24*t*60*60*1e3)+this._milliseconds
default:throw new Error("Unknown unit "+e)}},lang:bt.fn.lang,locale:bt.fn.locale,toIsoString:i("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",function(){return this.toISOString()}),toISOString:function(){var e=Math.abs(this.years()),t=Math.abs(this.months()),n=Math.abs(this.days()),r=Math.abs(this.hours()),o=Math.abs(this.minutes()),i=Math.abs(this.seconds()+this.milliseconds()/1e3)
return this.asSeconds()?(this.asSeconds()<0?"-":"")+"P"+(e?e+"Y":"")+(t?t+"M":"")+(n?n+"D":"")+(r||o||i?"T":"")+(r?r+"H":"")+(o?o+"M":"")+(i?i+"S":""):"P0D"},localeData:function(){return this._locale}}),bt.duration.fn.toString=bt.duration.fn.toISOString
for(_t in cn)n(cn,_t)&&vt(_t.toLowerCase())
bt.duration.fn.asMilliseconds=function(){return this.as("ms")},bt.duration.fn.asSeconds=function(){return this.as("s")},bt.duration.fn.asMinutes=function(){return this.as("m")},bt.duration.fn.asHours=function(){return this.as("h")},bt.duration.fn.asDays=function(){return this.as("d")},bt.duration.fn.asWeeks=function(){return this.as("weeks")},bt.duration.fn.asMonths=function(){return this.as("M")},bt.duration.fn.asYears=function(){return this.as("y")},bt.locale("en",{ordinal:function(e){var t=e%10,n=1===k(e%100/10)?"th":1===t?"st":2===t?"nd":3===t?"rd":"th"
return e+n}}),Lt?module.exports=bt:"function"==typeof define&&define.amd?(define("moment",["require","exports","module"],function(e,t,n){return n.config&&n.config()&&n.config().noGlobal===!0&&(Ct.moment=wt),bt}),yt(!0)):yt()}.call(this),define("app/date_utilities",["moment"],function(e){var t="YYYY-MM-DDTHH:mm:ssZ",n="MMMM DD, YYYY",r=30,o={safeRelativeDate:function(n){return e.utc(n,t).fromNow()},isNewerThan:function(n,r){return e.utc()<e.utc(n,t).add(r,"days")},safeAbsoluteDate:function(r){return e.utc(r,t).format(n)},updateRelativeDates:function(){var e=document.querySelectorAll(".relative-date")
Array.prototype.forEach.call(e,function(e){var t="",n=e.getAttribute("datetime")
t=o.isNewerThan(n,r)?o.safeRelativeDate(n):o.safeAbsoluteDate(n),e.innerHTML=t})}}
return o.updateRelativeDates(),o}),define("app/localisation_utilities",[],function(){return{getUrlPrefix:function(){return"undefined"==typeof window.location.pathname.split("/")[1]||"au"!=window.location.pathname.split("/")[1]&&"us"!=window.location.pathname.split("/")[1]&&"sg"!=window.location.pathname.split("/")[1]?"":"/"+window.location.pathname.split("/")[1]}}})
var Hogan={}
!function(e){function t(e,t,n){var r
return t&&"object"==typeof t&&(null!=t[e]?r=t[e]:n&&t.get&&"function"==typeof t.get&&(r=t.get(e))),r}function n(e,t,n,r,o,i){function a(){}function s(){}a.prototype=e,s.prototype=e.subs
var l,c=new a
c.subs=new s,c.subsText={},c.buf="",r=r||{},c.stackSubs=r,c.subsText=i
for(l in t)r[l]||(r[l]=t[l])
for(l in r)c.subs[l]=r[l]
o=o||{},c.stackPartials=o
for(l in n)o[l]||(o[l]=n[l])
for(l in o)c.partials[l]=o[l]
return c}function r(e){return String(null===e||void 0===e?"":e)}function o(e){return e=r(e),u.test(e)?e.replace(i,"&amp;").replace(a,"&lt;").replace(s,"&gt;").replace(l,"&#39;").replace(c,"&quot;"):e}e.Template=function(e,t,n,r){e=e||{},this.r=e.code||this.r,this.c=n,this.options=r||{},this.text=t||"",this.partials=e.partials||{},this.subs=e.subs||{},this.buf=""},e.Template.prototype={r:function(){return""},v:o,t:r,render:function(e,t,n){return this.ri([e],t||{},n)},ri:function(e,t,n){return this.r(e,t,n)},ep:function(e,t){var r=this.partials[e],o=t[r.name]
if(r.instance&&r.base==o)return r.instance
if("string"==typeof o){if(!this.c)throw new Error("No compiler available.")
o=this.c.compile(o,this.options)}if(!o)return null
if(this.partials[e].base=o,r.subs){t.stackText||(t.stackText={})
for(key in r.subs)t.stackText[key]||(t.stackText[key]=void 0!==this.activeSub&&t.stackText[this.activeSub]?t.stackText[this.activeSub]:this.text)
o=n(o,r.subs,r.partials,this.stackSubs,this.stackPartials,t.stackText)}return this.partials[e].instance=o,o},rp:function(e,t,n,r){var o=this.ep(e,n)
return o?o.ri(t,n,r):""},rs:function(e,t,n){var r=e[e.length-1]
if(!d(r))return void n(e,t,this)
for(var o=0;o<r.length;o++)e.push(r[o]),n(e,t,this),e.pop()},s:function(e,t,n,r,o,i,a){var s
return d(e)&&0===e.length?!1:("function"==typeof e&&(e=this.ms(e,t,n,r,o,i,a)),s=!!e,!r&&s&&t&&t.push("object"==typeof e?e:t[t.length-1]),s)},d:function(e,n,r,o){var i,a=e.split("."),s=this.f(a[0],n,r,o),l=this.options.modelGet,c=null
if("."===e&&d(n[n.length-2]))s=n[n.length-1]
else for(var u=1;u<a.length;u++)i=t(a[u],s,l),null!=i?(c=s,s=i):s=""
return o&&!s?!1:(o||"function"!=typeof s||(n.push(c),s=this.mv(s,n,r),n.pop()),s)},f:function(e,n,r,o){for(var i=!1,a=null,s=!1,l=this.options.modelGet,c=n.length-1;c>=0;c--)if(a=n[c],i=t(e,a,l),null!=i){s=!0
break}return s?(o||"function"!=typeof i||(i=this.mv(i,n,r)),i):o?!1:""},ls:function(e,t,n,o,i){var a=this.options.delimiters
return this.options.delimiters=i,this.b(this.ct(r(e.call(t,o)),t,n)),this.options.delimiters=a,!1},ct:function(e,t,n){if(this.options.disableLambda)throw new Error("Lambda features disabled.")
return this.c.compile(e,this.options).render(t,n)},b:function(e){this.buf+=e},fl:function(){var e=this.buf
return this.buf="",e},ms:function(e,t,n,r,o,i,a){var s,l=t[t.length-1],c=e.call(l)
return"function"==typeof c?r?!0:(s=this.activeSub&&this.subsText&&this.subsText[this.activeSub]?this.subsText[this.activeSub]:this.text,this.ls(c,l,n,s.substring(o,i),a)):c},mv:function(e,t,n){var o=t[t.length-1],i=e.call(o)
return"function"==typeof i?this.ct(r(i.call(o)),o,n):i},sub:function(e,t,n,r){var o=this.subs[e]
o&&(this.activeSub=e,o(t,n,this,r),this.activeSub=!1)}}
var i=/&/g,a=/</g,s=/>/g,l=/\'/g,c=/\"/g,u=/[&<>\"\']/,d=Array.isArray||function(e){return"[object Array]"===Object.prototype.toString.call(e)}}("undefined"!=typeof exports?exports:Hogan),function(e){function t(e){"}"===e.n.substr(e.n.length-1)&&(e.n=e.n.substring(0,e.n.length-1))}function n(e){return e.trim?e.trim():e.replace(/^\s*|\s*$/g,"")}function r(e,t,n){if(t.charAt(n)!=e.charAt(0))return!1
for(var r=1,o=e.length;o>r;r++)if(t.charAt(n+r)!=e.charAt(r))return!1
return!0}function o(t,n,r,s){var l=[],c=null,u=null,d=null
for(u=r[r.length-1];t.length>0;){if(d=t.shift(),u&&"<"==u.tag&&!(d.tag in b))throw new Error("Illegal content in < super tag.")
if(e.tags[d.tag]<=e.tags.$||i(d,s))r.push(d),d.nodes=o(t,d.tag,r,s)
else{if("/"==d.tag){if(0===r.length)throw new Error("Closing tag without opener: /"+d.n)
if(c=r.pop(),d.n!=c.n&&!a(d.n,c.n,s))throw new Error("Nesting error: "+c.n+" vs. "+d.n)
return c.end=d.i,l}"\n"==d.tag&&(d.last=0==t.length||"\n"==t[0].tag)}l.push(d)}if(r.length>0)throw new Error("missing closing tag: "+r.pop().n)
return l}function i(e,t){for(var n=0,r=t.length;r>n;n++)if(t[n].o==e.n)return e.tag="#",!0}function a(e,t,n){for(var r=0,o=n.length;o>r;r++)if(n[r].c==e&&n[r].o==t)return!0}function s(e){var t=[]
for(var n in e)t.push('"'+c(n)+'": function(c,p,t,i) {'+e[n]+"}")
return"{ "+t.join(",")+" }"}function l(e){var t=[]
for(var n in e.partials)t.push('"'+c(n)+'":{name:"'+c(e.partials[n].name)+'", '+l(e.partials[n])+"}")
return"partials: {"+t.join(",")+"}, subs: "+s(e.subs)}function c(e){return e.replace(y,"\\\\").replace(m,'\\"').replace(g,"\\n").replace(v,"\\r")}function u(e){return~e.indexOf(".")?"d":"f"}function d(e,t){var n="<"+(t.prefix||""),r=n+e.n+w++
return t.partials[r]={name:e.n,partials:{}},t.code+='t.b(t.rp("'+c(r)+'",c,p,"'+(e.indent||"")+'"));',r}function p(e,t){t.code+="t.b(t.t(t."+u(e.n)+'("'+c(e.n)+'",c,p,0)));'}function f(e){return"t.b("+e+");"}var h=/\S/,m=/\"/g,g=/\n/g,v=/\r/g,y=/\\/g
e.tags={"#":1,"^":2,"<":3,$:4,"/":5,"!":6,">":7,"=":8,_v:9,"{":10,"&":11,_t:12},e.scan=function(o,i){function a(){y.length>0&&(b.push({tag:"_t",text:new String(y)}),y="")}function s(){for(var t=!0,n=E;n<b.length;n++)if(t=e.tags[b[n].tag]<e.tags._v||"_t"==b[n].tag&&null===b[n].text.match(h),!t)return!1
return t}function l(e,t){if(a(),e&&s())for(var n,r=E;r<b.length;r++)b[r].text&&((n=b[r+1])&&">"==n.tag&&(n.indent=b[r].text.toString()),b.splice(r,1))
else t||b.push({tag:"\n"})
w=!1,E=b.length}function c(e,t){var r="="+x,o=e.indexOf(r,t),i=n(e.substring(e.indexOf("=",t)+1,o)).split(" ")
return C=i[0],x=i[i.length-1],o+r.length-1}var u=o.length,d=0,p=1,f=2,m=d,g=null,v=null,y="",b=[],w=!1,_=0,E=0,C="{{",x="}}"
for(i&&(i=i.split(" "),C=i[0],x=i[1]),_=0;u>_;_++)m==d?r(C,o,_)?(--_,a(),m=p):"\n"==o.charAt(_)?l(w):y+=o.charAt(_):m==p?(_+=C.length-1,v=e.tags[o.charAt(_+1)],g=v?o.charAt(_+1):"_v","="==g?(_=c(o,_),m=d):(v&&_++,m=f),w=_):r(x,o,_)?(b.push({tag:g,n:n(y),otag:C,ctag:x,i:"/"==g?w-C.length:_+x.length}),y="",_+=x.length-1,m=d,"{"==g&&("}}"==x?_++:t(b[b.length-1]))):y+=o.charAt(_)
return l(w,!0),b}
var b={_t:!0,"\n":!0,$:!0,"/":!0}
e.stringify=function(t){return"{code: function (c,p,i) { "+e.wrapMain(t.code)+" },"+l(t)+"}"}
var w=0
e.generate=function(t,n,r){w=0
var o={code:"",subs:{},partials:{}}
return e.walk(t,o),r.asString?this.stringify(o,n,r):this.makeTemplate(o,n,r)},e.wrapMain=function(e){return'var t=this;t.b(i=i||"");'+e+"return t.fl();"},e.template=e.Template,e.makeTemplate=function(e,t,n){var r=this.makePartials(e)
return r.code=new Function("c","p","i",this.wrapMain(e.code)),new this.template(r,t,this,n)},e.makePartials=function(e){var t,n={subs:{},partials:e.partials,name:e.name}
for(t in n.partials)n.partials[t]=this.makePartials(n.partials[t])
for(t in e.subs)n.subs[t]=new Function("c","p","t","i",e.subs[t])
return n},e.codegen={"#":function(t,n){n.code+="if(t.s(t."+u(t.n)+'("'+c(t.n)+'",c,p,1),c,p,0,'+t.i+","+t.end+',"'+t.otag+" "+t.ctag+'")){t.rs(c,p,function(c,p,t){',e.walk(t.nodes,n),n.code+="});c.pop();}"},"^":function(t,n){n.code+="if(!t.s(t."+u(t.n)+'("'+c(t.n)+'",c,p,1),c,p,1,0,0,"")){',e.walk(t.nodes,n),n.code+="};"},">":d,"<":function(t,n){var r={partials:{},code:"",subs:{},inPartial:!0}
e.walk(t.nodes,r)
var o=n.partials[d(t,n)]
o.subs=r.subs,o.partials=r.partials},$:function(t,n){var r={subs:{},code:"",partials:n.partials,prefix:t.n}
e.walk(t.nodes,r),n.subs[t.n]=r.code,n.inPartial||(n.code+='t.sub("'+c(t.n)+'",c,p,i);')},"\n":function(e,t){t.code+=f('"\\n"'+(e.last?"":" + i"))},_v:function(e,t){t.code+="t.b(t.v(t."+u(e.n)+'("'+c(e.n)+'",c,p,0)));'},_t:function(e,t){t.code+=f('"'+c(e.text)+'"')},"{":p,"&":p},e.walk=function(t,n){for(var r,o=0,i=t.length;i>o;o++)r=e.codegen[t[o].tag],r&&r(t[o],n)
return n},e.parse=function(e,t,n){return n=n||{},o(e,"",[],n.sectionTags||[])},e.cache={},e.cacheKey=function(e,t){return[e,!!t.asString,!!t.disableLambda,t.delimiters,!!t.modelGet].join("||")},e.compile=function(t,n){n=n||{}
var r=e.cacheKey(t,n),o=this.cache[r]
if(o){var i=o.partials
for(var a in i)delete i[a].instance
return o}return o=this.generate(this.parse(this.scan(t,n.delimiters),t,n),t,n),this.cache[r]=o}}("undefined"!=typeof exports?exports:Hogan),define("hogan",function(e){return function(){var t
return t||e.Hogan}}(this)),define("app/prev_next",["app/date_utilities","app/localisation_utilities","hogan","app/utils"],function(e,t,n){function r(){window.matchMedia("(max-width: 575px)").matches?h[0].parentNode.insertBefore(d,h[0]):p.insertBefore(d,f)}var o=document.querySelector(".current-prev-next.recent-news")
if(null!=o){var i=function(r,o,i,a){var s=Array.isArray(o.articleUrl)?o.articleUrl[0]:o.articleUrl
0!=s.indexOf("/")&&(s="/"+s)
var l=t.getUrlPrefix()+s,c='<a class="{{dir}}" href="{{url}}"><span class="direction">{{label}}<span class="labelExtend"> {{labelExtend}}</span></span><span class="page-title">{{{data.articleName}}}</span>',u=""
if(null!=o.publishedDate){var d=e.safeRelativeDate(o.publishedDate)
u="published {{publishedDate}}"}c+='<span class="supplementary">'+u+"</span></a>"
var p=n.compile(c),f=p.render({dir:r,url:l,label:i,data:o,publishedDate:d,labelExtend:a})
return f},a=function(e){var t={articleUrl:"/",publishedDate:null,articleName:"Go to the Homepage"}
return i(e+" home",t,"Homepage","")},s=document.querySelector("meta[name=pub_date]").getAttribute("content"),l=document.querySelector('article[itemtype="http://schema.org/NewsArticle"]'),c=null!==l?l.getAttribute("data-id"):!1
if(s&&moment.utc()<moment.utc(s,"YYYY-MM-DD").add(5,"days")&&null!=l&&c){var u=new XMLHttpRequest
if(window.ffte&&window.ffte.properties&&"feature"==window.ffte.properties.articleType?u.open("GET",t.getUrlPrefix()+"/data/recent-features/",!0):window.ffte&&window.ffte.properties&&"news"==window.ffte.properties.articleType&&u.open("GET",t.getUrlPrefix()+"/data/recent-news/",!0),u.onload=function(){function e(e,n){return e.id===c?(f+="undefined"!=typeof t[n+1]?i("prev",t[n+1],"Prev","article"):a("prev"),f+="undefined"!=typeof t[n-1]?i("next",t[n-1],"Next","article"):a("next"),!1):void 0}if(u.status>=200&&u.status<400){var t=JSON.parse(u.responseText),r=l.getElementsByTagName("h1")[0].innerHTML,s='<p class="current"><span class="title">Current article:</span><span class="page-title">"{{currentArticle}}"</span></p>',d=n.compile(s),p=d.render({currentArticle:r}),f=""
t.forEach(e),""!=f?o.innerHTML+=p+f:o.style.display="none",document.dispatchEvent(new CustomEvent("component_tracking.run"))}},u.send(),o.classList.contains("sticky-next-prev")&&window.matchMedia("(max-width: 575px)").matches){var d=o.parentNode,p=d.parentNode,f=d.nextElementSibling,h=document.getElementsByTagName("header")
h[0].parentNode.insertBefore(d,h[0]),window.addEventListener("optimizedResize",r)}}else null!=l&&c&&(o.style.display="none")}}),define("app/navigation_responsive",["app/utils"],function(e){"use strict"
var t,n,r,o,i=document.getElementsByClassName("nav-list")[0],a=document.querySelectorAll(".nav-list > .menu-item"),s=" reveal ",l=" hide ",c=document.querySelector(".menu-item-hover-reveal .sub-menu"),u=function(){var e
for(e=0;e<a.length;e+=1)a[e].className=a[e].className.replace(s,"")},d=function(e){var t
for(t=0;t<a.length;t+=1)a[t]!==e&&(a[t].className+=" "+l)},p=function(){for(t=0;t<a.length;t+=1)a[t].addEventListener("click",y)},f=function(){var e
for(e=0;e<a.length;e+=1)a[e].className=a[e].className.replace(l,"")},h=function(){return!!(window.innerWidth<700)},m=function(t,n){return n===!0&&e.hasClass(t.parentNode,"nav-list")?void c.insertBefore(t,c.querySelector(".sub-menu-item")):void 0},g=function(){return i=document.getElementsByClassName("nav-list")[0],"undefined"==typeof n&&(n=document.getElementsByClassName("menu-item-hover-reveal")[0]),"undefined"==typeof r&&(r=document.getElementsByClassName("nav-sub-set-container")[0]),"undefined"==typeof o&&(o=document.getElementsByClassName("button-i18n masthead-item")[0]),o&&document.getElementsByClassName("primary-nav single-tier")[0]?i.offsetWidth-n.offsetWidth-r.offsetWidth-o.offsetWidth:void 0!=r?i.offsetWidth-n.offsetWidth-r.offsetWidth:i.offsetWidth-n.offsetWidth},v=function(){var t,n,r=0,o=document.querySelectorAll(".sub-menu .menu-item")
if(!h()&&null!==c){if(n=g(),o.length)for(t=0;t<o.length;t+=1)try{document.querySelector(".nav-list").insertBefore(o[t],document.querySelector(".nav-list > .menu-item:last-child"))}catch(i){console.log(i),console.log("i",t),console.log(o),console.log("elem",o[t]),console.log(document.querySelector(".nav-list > .menu-item:last-child")),console.log(a),console.log(a.length),console.log(a[0]),console.log(a[0].parentNode)}for(a=document.querySelectorAll(".nav-list > .menu-item"),t=0;t<a.length;t+=1)e.hasClass(a[t],"menu-item-hover-reveal")||(r+=a[t].offsetWidth,m(a[t],r>n))
b()}},y=function(t){var n=this
if(h()&&e.hasClass(this,"menu-level-1")&&e.hasClass(this,"has-submenu")&&!e.hasClass(this,s)){t.preventDefault(),u()
var r=document.createElement("a")
r.innerHTML='<i class="icon icon-arrow-left"></i> Back',r.setAttribute("class","btn menu-item-back-btn"),r.onclick=function(){n.className=n.className.replace(s,""),n.addEventListener("click",y),f(),this.parentNode.removeChild(this)},this.parentNode.insertBefore(r,this),this.className+=s,this.removeEventListener("click",y),d(this)}},b=function(){var e=c.getElementsByClassName("menu-item")
n.className=n.className.replace(" more-show ",""),n.className=n.className.replace(" more-hide ",""),e.length?n.className+=" more-show ":c.childNodes.length||(n.className+=" more-hide ")}
p()
var w
window.addEventListener("resize",function(){clearTimeout(w),w=setTimeout(v,200)}),setTimeout(v,0),i.className+=" component-loaded "}),define("app/list_pagination",["app/date_utilities","app/localisation_utilities"],function(e,t){var n=function(){var e=document.querySelector(".listingResultsWrapper").getAttribute("data-total-count"),t=document.querySelectorAll(".listingResultsWrapper .listingResult").length
return console.debug("Is the load more button needed?",e>t),e>t},r=document.querySelectorAll(".homepage-load-more")
if(r.length>0)for(var o=0;o<r.length;o++){var i=r[o],a="/data/"+i.getAttribute("data-type")+"/"
n()?i.onclick=function(){var t=null==i.getAttribute("data-current")?2:i.getAttribute("data-current"),o=new XMLHttpRequest
i.classList.add("loading"),o.onreadystatechange=function(){if(4===o.readyState)if(200===o.status){if("undefined"!=typeof o.response){for(var a=0;a<r.length;a++)i.setAttribute("data-current",1+parseInt(t)),r[a].setAttribute("data-current",1+parseInt(t))
document.querySelector(".listingResults").insertAdjacentHTML("beforeend",o.response),e.updateRelativeDates(),i.classList.remove("loading"),n()||i.classList.add("hidden")}}else console.debug("Homepage article loading failed")},o.open("GET",a+t),o.send()}:i.classList.add("hidden"),i.onTouchStart=i.onClick}var s=function(){this.options={loadMoreHook:".load-more",loadMoreHtml:'<button class="load-more">Load More <i class="icon icon-arrow-down"></i> <i class="icon icon-loading spinner"></i></button>',loadingClass:"loading",hasPaginationClass:"has-pagination-button",listingResultsSelector:".listingResults",resultSelector:".listingResult",supplementalResultSelector:".feature-block .feature-block-item-wrapper",count:10,loadMoreTriggerSelector:".load-more",errorMessage:"Hmm. Something is stopping us from loading more content... why not try again!"},this.capitaliseFirstLetter=function(e){return e.charAt(0).toUpperCase()+e.slice(1)},this.latestUrl=function(e){var n=e.querySelectorAll(".listingResult time.published-date"),r=new Date(n.item(n.length-1).getAttribute("datetime"))
return console.log("list epoch",r),t.getUrlPrefix()+"/more/"+e.getAttribute("data-list")+"/"+parseInt(r.getTime()/1e3-1)},this.pageUrl=function(e){var n=e.querySelectorAll(".listingResult"),r=n.item(n.length-1).getAttribute("data-page")
return console.log("list currentpage",r),t.getUrlPrefix()+"/more/"+e.getAttribute("data-list")+"/"+(Number(r)+1)},this.getMore=function(t){var n=this
return function(r){var o=r.target.parentNode,i=r.target,a=!1
if(a=i.classList?i.classList.contains(n.options.loadingClass):new RegExp("(^| )"+n.options.loadingClass+"( |$)","gi").test(i.className))return!0
i.classList?i.classList.add(n.options.loadingClass):i.className+=" "+n.options.loadingClass
var s=t(o)
location.search&&(s+=location.search)
var l=new XMLHttpRequest
l.open("GET",s,!0),l.timeout=5e3,l.onload=function(){if(l.status>=200&&l.status<400){var t=l.responseText,r=document.createElement("div")
r.innerHTML=t
for(var a=r.childNodes,s=0;s<a.length;s++){var c=a.item(s)
o.querySelectorAll(n.options.listingResultsSelector).item(0).appendChild(c)}window.respimage(),setTimeout(function(){o.querySelectorAll(n.options.resultSelector).length==o.getAttribute("data-total-count")&&(i.style.display="none")},0),e.updateRelativeDates()}else i.style.display="none"
i.classList?i.classList.remove(n.options.loadingClass):i.className=i.className.replace(new RegExp("(^|\\b)"+n.options.loadingClass.split(" ").join("|")+"(\\b|$)","gi")," ")},l.onerror=function(){i.style.display="none"},l.send()}},this.sources={getLatest:this.getMore(this.latestUrl),getPage:this.getMore(this.pageUrl)},this.paginate=function(e){if(loadingClassFound=e.classList?e.classList.contains(this.options.hasPaginationClass):new RegExp("(^| )"+this.options.hasPaginationClass+"( |$)","gi").test(e.className))return!0
var t=e.querySelectorAll(this.options.resultSelector).length
if(document.querySelectorAll(this.options.supplementalResultSelector)&&(t+=document.querySelectorAll(this.options.supplementalResultSelector).length),t<e.getAttribute("data-total-count")){var n=e.querySelector(this.options.listingResultsSelector)
n.insertAdjacentHTML("afterend",this.options.loadMoreHtml)
var r=this.sources["get"+this.capitaliseFirstLetter(e.getAttribute("data-next"))],o=document.querySelector(this.options.loadMoreTriggerSelector)
o.onclick=r,e.classList?e.classList.add(this.options.hasPaginationClass):e.className+=" "+this.options.hasPaginationClass}}}
return s}),define("app/search",[],function(){var e=document.querySelector(".search-checkbox")
e.addEventListener("change",function(){e.parentNode.querySelector(".search-input").focus()})})
var AutoComplete=function(){"use strict"
function e(e,t,n,r,o){e&&e.abort()
var i,a=t.headers,s=Object.getOwnPropertyNames(a),l=t.method,c=t.url
for(l.match(/^GET$/i)&&(c+="?"+n),e=new XMLHttpRequest,e.open(l,c,!0),i=s.length-1;i>=0;i--)e.setRequestHeader(s[i],a[s[i]])
return e.onreadystatechange=function(){4==e.readyState&&200==e.status&&(t.post(o,e.response,t)||t.open(r,o))},e.send(n),e}function t(e,n){n?attrClass(e,"autocomplete"):setTimeout(function(){t(e,!0)},150)}function n(e,t){var n,r={}
for(n in e)r[n]=e[n]
for(n in t)r[n]=t[n]
return r}var r=function(o){if(this){var i,a=this,s={limit:0,method:"GET",noResult:"No result",paramName:"q",headers:{"Content-type":"application/x-www-form-urlencoded"},select:function(e,t){attr(e,{"data-autocomplete-old-value":e.value=attr(t,"data-autocomplete-value",t.innerHTML)})},open:function(e,t){var n=this
Array.prototype.forEach.call(t.getElementsByTagName("li"),function(t){t.onclick=function(t){n.select(e,t.target)}})},post:function(e,t,n){try{t=JSON.parse(t)
var r,o,i,a,s=function(){return domCreate("li")},l=function(e,t){return 0>t?e.reverse():e},c=function(e,t,n){return t.innerHTML=n,e.appendChild(t),s()},u=0,d=t.length,p=s(),f=domCreate("ul"),h=n.limit
if(Array.isArray(t))if(d)for(t=l(t,h);d>u&&(u<Math.abs(h)||!h);u++)p=c(f,p,t[u])
else r=!0,attrClass(p,"locked"),p=c(f,p,n.noResult)
else{i=l(Object.getOwnPropertyNames(t),h)
for(o in i)a=i[o],(parseInt(o)<Math.abs(h)||!h)&&(attr(p,{"data-autocomplete-value":a}),p=c(f,p,t[a]))}return e.hasChildNodes()&&e.childNodes[0].remove(),e.appendChild(f),r}catch(m){e.innerHTML=t}},pre:function(e){return e.value},selector:["input[data-autocomplete]"]}
a._custArgs=[],a._args=n(s,o||{}),i=a._args.selector,Array.isArray(i)||(i=[i]),i.forEach(function(n){Array.prototype.forEach.call(document.querySelectorAll(n),function(n){if(n.nodeName.match(/^INPUT$/i)&&n.type.match(/^TEXT|SEARCH$/i)){var r,o="data-autocomplete-old-value",i=domCreate("div"),s=function(){attr(i,{"class":"autocomplete",style:"top:"+(n.offsetTop+n.offsetHeight)+"px;left:"+n.offsetLeft+"px;width:"+n.clientWidth+"px;"})},l=function(){n.onfocus=n.onblur=n.onkeyup=null,n.removeEventListener("position",s),n.removeEventListener("destroy",l),i.parentNode.removeChild(i),a.CustParams(n,!0)},c=function(){var e=attr(n,o)
e&&n.value==e||attrClass(i,"autocomplete open")}
attr(n,{autocomplete:"off"}),s(n,i),n.addEventListener("position",s),n.addEventListener("destroy",l),n.parentNode.appendChild(i),n.onfocus=c,n.onblur=t.bind(null,i),n.onkeyup=function(t){var n,s,l,c,u=i.querySelector("li:first-child:not(.locked)"),d=t.target,p=a.CustParams(d),f=p.pre(d),h=attr(d,o),m=t.keyCode
13==m&&-1!=attr(i,"class").indexOf("open")&&(c=i.querySelector("li.active"),null!==c&&(a._args.select(d,c),attrClass(i,"autocomplete"))),38==m||40==m?(c=i.querySelector("li.active"),c?(n=Array.prototype.indexOf.call(c.parentNode.children,c),s=n+(m-39),l=i.getElementsByTagName("li").length,attrClass(c,""),0>s?s=l-1:s>=l&&(s=0),attrClass(c.parentElement.childNodes.item(s),"active")):u&&attrClass(u,"active")):13!=m&&(35>m||m>40)&&f&&p.url&&(h&&f==h||attrClass(i,"autocomplete open"),r=e(r,p,p.paramName+"="+f,d,i))}}})})}else new r(o)}
return r.prototype={CustParams:function(e,t){var r,o="data-autocomplete-id",i=this,a="data-autocomplete",s={limit:a+"-limit",method:a+"-method",noResult:a+"-no-result",paramName:a+"-param-name",url:a},l=Object.getOwnPropertyNames(s)
if(!t){if(!e.hasAttribute(o)){for(e.setAttribute(o,i._custArgs.length),r=l.length-1;r>=0;r--)s[l[r]]=attr(e,s[l[r]])
for(r in s)s.hasOwnProperty(r)&&!s[r]&&delete s[r]
s.limit&&(isNaN(s.limit)?delete s.limit:s.limit=parseInt(s.limit)),i._custArgs.push(n(i._args,s))}return i._custArgs[attr(e,o)]}delete i._custArgs[attr(e,o)]}},r}()
define("autocomplete",function(){}),define("app/instant_search",["autocomplete"],function(){function e(e,t){t||(t=window.location.href),e=e.replace(/[\[\]]/g,"\\$&")
var n=new RegExp("[?&]"+e+"(=([^&#]*)|&|#|$)"),r=n.exec(t)
return r&&r[2]?"&"+e+"="+decodeURIComponent(r[2].replace(/\+/g," ")):""}var t=function(e){if(""==e.target.value||e.target.value.length<2){var t=document.getElementsByClassName("autocomplete")[0]
t.hasChildNodes()&&t.childNodes[0].remove()}},n=function(e){if(setTimeout(function(){if(38==e.keyCode||40==e.keyCode){var t=document.querySelectorAll(".autocomplete ul li.active")[0],n=e.target
null!=t&&"autocompleteFooter"!=t.id?((null==n.getAttribute("data-autocomplete-old-value")||""==n.getAttribute("data-autocomplete-old-value"))&&n.setAttribute("data-autocomplete-old-value",n.value),n.value=t.getAttribute("data-autocomplete-value")):""!=n.getAttribute("data-autocomplete-old-value")&&(n.value=n.getAttribute("data-autocomplete-old-value"),n.setAttribute("data-autocomplete-old-value",""))}},50),13==e.keyCode){var t=document.querySelectorAll(".autocomplete ul li.active")[0],n=t.querySelectorAll("a")[0]
window.location=n.getAttribute("href")}},r=document.getElementById("reviewsSearch")
if(null!=r){var o=r.querySelector(".suggestive")
if(o.setAttribute("data-autocomplete","/data/search"),o.setAttribute("data-vanilla-autocomplete-extra","&articleType=reviews&format=instant"),""!==e("fcsis")){var i=document.createElement("input")
i.setAttribute("type","hidden"),i.setAttribute("name","fcsis"),i.setAttribute("value","stage"),o.parentNode.insertBefore(i,o.nextSibling)}o.oninput=t,o.addEventListener("keyup",n)}var a=document.getElementById("tuitionSearch")
if(null!=a){var s=a.querySelector(".suggestivetuition")
s.setAttribute("data-autocomplete","/data/search"),s.setAttribute("data-vanilla-autocomplete-extra","&articleType=how-to&format=instant"),s.oninput=t,s.addEventListener("keyup",n)}var l=document.getElementById("buyingGuideSearch")
if(null!=l){var c=l.querySelector(".suggestive")
c.setAttribute("data-autocomplete","/data/search"),c.setAttribute("data-vanilla-autocomplete-extra","&articleType=buying-guide&format=instant"),c.oninput=t,c.addEventListener("keyup",n)}AutoComplete({paramName:"searchTerm",method:"GET",noResult:"",limit:3,pre:function(t){var n=t.value.trim()
return n.length<2?"":n+t.getAttribute("data-vanilla-autocomplete-extra")+e("fcsis")},post:function(t,n,r){var o,i=domCreate("ul"),a=domCreate("li")
try{n=JSON.parse(n)
var s=n.length
if(!Array.isArray(n))throw new Error("Not an array")
if(s>0){for(var l=0;s>l&&(l<Math.abs(r.limit)||!r.limit);l++){var c=n[l],u="",d=function(e){return Array.isArray(e)?e.shift():e}
u=d(null!=c.articleMediaHero?c.articleMediaHero:c.articleMedia),a.innerHTML='<a href="'+c.articleUrl+'"><img src="'+u+'"><span class"suggestion">'+c.articleName+"</span></a>",a.setAttribute("data-autocomplete-value",c.articleName),i.appendChild(a),a=domCreate("li")}var p=t.parentNode.querySelector("input").value.trim(),f=domCreate("li")
f.id="autocompleteFooter",fcsis=e("fcsis"),f.innerHTML='<a class="clickevent" href="/search?searchTerm='+p+fcsis+'"><span>See all results for "'+p+'"</span><i class="icon icon-arrow-right"></i></a>',i.appendChild(f)}else o=!0,attr(a,{"class":"locked"}),a.innerHTML=r.noResult,i.appendChild(a)}catch(h){i=domCreate("ul"),a=domCreate("li"),a.innerHTML="Something has gone wrong with the request, please try again later",i.appendChild(a)}return t.hasChildNodes()&&t.childNodes[0].remove(),t.appendChild(i),o}})}),define("app/fallback",[],function(){if(!document.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure","1.1")){var e=document.getElementsByClassName("fallback")
e.length&&"undefined"!=typeof e[0].attributes.src&&"undefined"!=typeof e[0].attributes["data-fallback-src"]&&(e[0].style.display="block",e[0].attributes.src.nodeValue=e[0].attributes["data-fallback-src"].nodeValue)}}),define("app/party",[],function(){var e=function(){var e={},t=function(t){e[t]=document.createEvent("Event"),e[t].initEvent(t,!0,!0)},n=function(t){return void 0!==e[t]},r=function(t){n(t)&&document.dispatchEvent(e[t])}
return{createEvent:t,triggerEvent:r}}
return e()}),define("gallery_shim",["bordeaux"],function(e){return Promise.resolve(window.usingBordeauxAds?window.reliablePageLoad.then(function(){return window.bordeauxAds||Promise.resolve(!1)}):!1).then(function(t){return t?{legacy:!1,updateMobileAds:e.galleryShim.updateMobileAds}:{legacy:!0}})}),define("app/gallery",["dfp","app/utils","app/party","hoist_mobile_mpu","gallery_shim"],function(e,t,n,r,o){"use strict"
var i=700,a={quantCast:function(){try{"undefined"!=typeof _qevents&&"undefined"!=typeof futrQuantConfig&&_qevents.push({qacct:futrQuantConfig.code,labels:futrQuantConfig.Qlabel,event:"refresh"})}catch(e){console.warn("Quantcast push failed",e)}},sendPageview:function(e){console.log("Notifier.sendPageview",e),this.quantCast(),void 0!==ga&&void 0!==analytics_ga_data&&(analytics_ga_data.dimension9=e+"",ga("send","pageview",analytics_ga_data))}},s=function(t,n){var r=Array.prototype.slice.call(document.getElementsByClassName("gallery-radio")),o=document.getElementById("wrapper-gallery"),i=1,a=2,s=function(){return r.length},l=function(){var e,t
for(e=0;e<r.length;e+=1)if(r[e].checked===!0){t=e
break}return t},c=function(e){r[e].checked=!0,r[e].onchange()},u=function(){var e=o.getBoundingClientRect(),t=document.body.getBoundingClientRect()
e.top<0&&window.scrollTo(0,e.top-t.top)},d=function(){i%a===0?(console.log("Ads should refresh"),e.refresh()):console.log("Ads shouldn't refresh"),i+=1},p=function(){var e=l()+1
if(u(),d(),n.sendPageview(e),null!=o.querySelectorAll("article.gallery-image")[e]){var t=o.querySelectorAll("article.gallery-image")[e].querySelector(".lazyload")
null!=t&&t.classList.add("lazypreload")}},f=function(){var e,n=r.length
for(e=0;n>e;e+=1)r[e].onchange=function(){p(),t.triggerEvent("slidechanged")}},h=function(){return document.getElementsByClassName("gallery-radio").length},m=function(){h()&&(f(),t.createEvent("slidechanged"),o.querySelectorAll("article.gallery-image")[1].querySelector(".lazyload").classList.add("lazypreload"))}
return{init:m,gotoSlide:c,getCurrentSlide:l,getLength:s}}(n,a),l=function(t,n,a){var s,l,c=document.getElementsByClassName("gallery-image"),u=null,d=1,p=2,f=null,h=null
r.exposeMPU1.then(function(e){f=e}),r.exposeMPU2.then(function(e){h=e})
var m=function(){var e,n=d*p
for(e=0;e<c.length;e+=1)c.hasOwnProperty(e)&&a.removeClass(c[e],"last-visible")
for(e=0;n>e;e+=1)c.hasOwnProperty(e)&&(a.addClass(c[e],"visible"),e===n-1&&a.addClass(c[e],"last-visible"))
d+=1,t.triggerEvent("slidechanged")},g=function(){return window.innerWidth<i&&document.getElementsByClassName("gallery-radio").length},v=function(){o.then(function(t){function n(t){var n=e.getSlots()
n.forEach(function(e){e.getElement().id===t.id&&(e.destroy(),t.remove())})}var r=document.getElementsByClassName("last-visible")
if(t.legacy){var o,i,a=document.querySelectorAll(".visible")[document.querySelectorAll(".visible").length-2],s=document.querySelectorAll(".visible")[document.querySelectorAll(".visible").length-1];(null!==f||null!==h)&&(r.length?(f&&a.parentNode.insertBefore(f,a),h&&s.parentNode.insertBefore(h,s)):(o=document.getElementsByClassName("visible"),i=o[o.length-1],o.length%2==0?(f&&i.parentNode.appendChild(f),n(h)):(f&&i.parentNode.insertBefore(f,i),h&&i.parentNode.appendChild(h))),e.refresh())}else t.updateMobileAds(!Boolean(r.length))})},y=function(){null!==s&&(l=s.getBoundingClientRect().top)},b=function(){if(void 0!==s&&null!==s&&null!==l){var e=s.getBoundingClientRect().top-document.body.getBoundingClientRect().top
window.scrollTo(0,e-l)}},w=function(){s=document.querySelector(".last-visible"),null===u&&(u=document.createElement("button"),u.setAttribute("class","load-more"),u.innerHTML='Load next two <i class="icon icon-arrow-down"></i> <i class="icon icon-loading spinner"></i>',u.onclick=function(){var e=this
a.addClass(this,"loading"),setTimeout(function(){a.removeClass(e,"loading"),_()},1e3)}),null!==s&&void 0!==s.nextSibling?s.parentNode.insertBefore(u,s.nextSibling):u.parentNode.removeChild(u)},_=function(){var e,t=Array.prototype.slice.call(document.getElementsByClassName("visible"))
y(),m(),v(),b(),w(),e=t.length/p+1,n.sendPageview(e)},E=function(){g()&&(a.addClass(document.body,"mob-gallery"),m(),w(),o.then(function(e){e.legacy||e.updateMobileAds()}))}
return{init:E}}(n,a,t),c=function(e){var n=null,r=null,o=function(t){var n,o=e.getCurrentSlide(),i=document.getElementsByClassName("thumb")[0],a=i.clientWidth*(e.getLength()-6)
void 0===t?(n=i.clientWidth*o*-1+2*i.clientWidth,2>o&&(n=0),r.style.left=n+"px"):"number"==typeof t&&0!==t&&(n=i.clientWidth*t,r.style.left=Math.max(-a,Number(r.style.left.replace("px",""))+n)+"px",r.style.left=Math.min(0,Number(r.style.left.replace("px","")))+"px")},a=function(){var e
for(e=0;e<n.length;e+=1)t.removeClass(n[e],"current")},s=function(){var t=e.getCurrentSlide()
a(),n[t].className+=" current ",o()},l=function(){return document.getElementsByClassName("thumbs").length&&window.innerWidth>=i},c=function(){if(l()){var t,i,a=0,c=document.getElementsByClassName("thumbs-right")[0],u=document.getElementsByClassName("thumbs-left")[0]
for(r=document.getElementsByClassName("thumbs-wrapper")[0],n=Array.prototype.slice.call(document.getElementsByClassName("thumb")),a=n.length,t=0;a>t;t+=1)i=n[t].getElementsByClassName("thumb-link")[0],i.onclick=function(t){t.preventDefault()
var r=n.indexOf(this.parentNode)
e.gotoSlide(r)}
c.onclick=function(){o(-3)},u.onclick=function(){o(3)},document.addEventListener("slidechanged",s)}}
return{init:c}}(s),u=function(e){var t=function(){if(n()){var t=document.querySelector("#wrapper-gallery .bodyCopy")
if(null!==t){var r=document.createElement("span"),o=document.createElement("span")
r.appendChild(document.createElement("span")),o.appendChild(document.createElement("span")),r.classList.add("image-left"),o.classList.add("image-right"),t.appendChild(r),t.appendChild(o),o.onclick=function(t){t.preventDefault()
var n=e.getCurrentSlide()+1
n<e.getLength()?e.gotoSlide(n):n===e.getLength()&&e.gotoSlide(0)},r.onclick=function(t){t.preventDefault()
var n=e.getCurrentSlide()-1
n>=0?e.gotoSlide(n):0>n&&(console.log(e.getLength()),e.gotoSlide(e.getLength()-1))}}}},n=function(){return document.getElementsByClassName("gallery-radio").length&&(window.location.host.indexOf("gamesradar.com")>-1||window.location.host.indexOf("pcgamer.com")>-1||window.location.host.indexOf("itproportal.com")>-1)&&window.matchMedia("(min-width: "+i+"px)").matches}
return{init:t}}(s),d=function(e){var t=function(t){if(t=t||window.event,"39"==t.keyCode){event.preventDefault()
var n=e.getCurrentSlide()+1
n<e.getLength()?e.gotoSlide(n):n===e.getLength()&&e.gotoSlide(0)}if("37"==t.keyCode){event.preventDefault()
var n=e.getCurrentSlide()-1
n>=0?e.gotoSlide(n):0>n&&(console.log(e.getLength()),e.gotoSlide(e.getLength()-1))}},n=function(){if(r()){var e=document.querySelector("#wrapper-gallery .bodyCopy")
null!==e&&(document.onkeydown=t)}},r=function(){return document.getElementsByClassName("gallery-radio").length&&(window.location.host.indexOf("gamesradar.com")>-1||window.location.host.indexOf("pcgamer.com")>-1||window.location.host.indexOf("itproportal.com")>-1)&&window.matchMedia("(min-width: "+i+"px)").matches}
return{init:n}}(s)
l.init(),s.init(),c.init(),u.init(),d.init()}),define("app/socialite",[],function(){"use strict"
var e,t={facebook_share:{platform:"facebook",dataUrlPrefix:"http://graph.facebook.com/?callback=updateShareCountWithFacebookShareCount&ids=",batch:!0,intent:"share",modal:!0},facebook_like:{platform:"facebook",dataUrlPrefix:"https://graph.facebook.com/techradar",batch:!1,intent:"like",modal:!1},twitter_tweet:{platform:"twitter",dataUrlPrefix:"http://urls.api.twitter.com/1/urls/count.json?callback=updateShareCountWithTwitterTweetCount&url=",batch:!1,intent:"tweet",modal:!0},pinterest_pin:{platform:"pinterest",dataUrlPrefix:"http://api.pinterest.com/v1/urls/count.json?callback=updateShareCountWithPinterestPinCount&url=",batch:!1,intent:"pin",modal:!0}},n=!1,r=["facebook_share","twitter_tweet","pinterest_pin"],o=document.querySelectorAll(".socialite-widget"),i=(document.createElement("div"),0),a=function(e){if(n){var t=document.createElement("script")
t.src=e,document.head.appendChild(t)}},s=function(){var e,t=document.querySelectorAll('link[rel="alternate"]'),n=[]
if(t=Array.prototype.slice.call(t),!t.length)return!1
for(e=0;e<t.length;e+=1)n.push(t[e].getAttribute("hreflang").substr(-2,2))
return n},l=function(){var e=document.querySelector('link[rel="canonical"]')
try{var t=document.createElement("a")
return t.href=e.getAttribute("href"),t.host}catch(n){console.error("Malformed or missing canonical | "+n.name+": "+n.message)}},c=function(){var e=document.querySelector('link[rel="canonical"]')
try{var t=document.createElement("a")
return t.href=e.getAttribute("href"),t.href}catch(n){console.error("Malformed or missing canonical | "+n.name+": "+n.message)}},u=function(){var e,t,n=document.querySelectorAll('link[rel="alternate"]'),r=[],o=s()
if(o===!1)r[0]=c()
else for(e=0;e<n.length;e+=1){var i=document.createElement("a")
i.href=n[e].getAttribute("href"),t=i.protocol+"//"+l()+i.pathname,-1===r.indexOf(t)&&r.push(t)}return r},d=function(e){var t
o[0].childNodes[1].style.display="inline-block",t=document.querySelector(".num-shares-value"),"number"==typeof e&&(t.innerHTML=p(e))},p=function(e){return e>=1e9?(e/1e9).toFixed(1)+"G":e>=1e6?(e/1e6).toFixed(1)+"M":e>=1e3?(e/1e3).toFixed(1)+"K":e},f=function(e){var t=529,n=540
window.open(e,"dennis","scrollbars=no,resizable=yes,width="+t+",height="+n+",left="+(window.innerWidth-t)/2+",top="+(window.innerHeight-n)/2)}
if(window.updateShareCountWithFacebookShareCount=function(e){var t,n=0
for(t in e)void 0!==e[t].shares&&(n+=e[t].shares)
0!==n&&(i+=n,d(i))},window.updateShareCountWithTwitterTweetCount=function(e){void 0!==e.count&&0!=e.count&&(i+=e.count,d(i))},window.updateShareCountWithPinterestPinCount=function(e){void 0!==e.count&&0!=e.count&&(i+=e.count,d(i))},o.length){e=u()
for(var h in r){var m=""
if(void 0!==t[r[h]])if(t[r[h]].batch===!0)m=t[r[h]].dataUrlPrefix+e.join(","),a(m)
else for(var g=0;g<e.length;g+=1)m=t[r[h]].dataUrlPrefix+e[g],a(m)}var v=document.querySelectorAll(".socialite-widget-item > a")
Array.prototype.forEach.call(v,function(e){if(e.addEventListener("click",function(e){"function"==typeof ga&&ga("send","event","social-share",c(),e.target.parentNode.getAttribute("data-platform"))},!1),window.innerWidth>=700){if(void 0===t[e.getAttribute("data-platform")+"_"+e.getAttribute("data-action")])return
if(t[e.getAttribute("data-platform")+"_"+e.getAttribute("data-action")].modal===!1)return
e.onclick=function(e){var t=""
e.preventDefault(),t="I"===e.target.tagName?e.target.parentNode.getAttribute("href"):e.target.getAttribute("href"),f(t)}}})}}),define("serialize",[],function(){function e(e){if(e&&"FORM"===e.nodeName){var t,n={}
for(t=e.elements.length-1;t>=0;t-=1)if(""!==e.elements[t].name)switch(e.elements[t].nodeName){case"INPUT":switch(e.elements[t].type){case"text":case"hidden":case"password":case"button":case"reset":case"submit":case"date":case"email":n[e.elements[t].name]=e.elements[t].value
break
case"checkbox":case"radio":void 0===n[e.elements[t].name]&&(n[e.elements[t].name]=null),e.elements[t].checked&&(n[e.elements[t].name]=e.elements[t].value)
break
case"file":}break
case"TEXTAREA":n[e.elements[t].name]=e.elements[t].value
break
case"SELECT":switch(e.elements[t].type){case"select-one":n[e.elements[t].name]=e.elements[t].value}break
case"BUTTON":switch(e.elements[t].type){case"reset":case"submit":case"button":n[e.elements[t].name]=e.elements[t].value}}return n}}return e}),define("app/data",[],function(){var e={countryList:["Afghanistan","Albania","Algeria","Andorra","Angola","Antigua & Deps","Argentina","Armenia","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bhutan","Bolivia","Bosnia Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Central African Rep","Chad","Chile","China","Colombia","Comoros","Congo","Congo (Democratic Rep)","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada","Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland (Republic)","Israel","Italy","Ivory Coast","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati","Korea North","Korea South","Kosovo","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique","Myanmar, (Burma)","Namibia","Nauru","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","Norway","Oman","Pakistan","Palau","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Qatar","Romania","Russian Federation","Rwanda","St Kitts & Nevis","St Lucia","Saint Vincent & the Grenadines","Samoa","San Marino","Sao Tome & Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan","Vanuatu","Vatican City","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"]}
return e}),define("app/ui",[],function(){"use strict"
var e={confirm:function(e,t,n){var r,o,i,a,s=document.createElement("div"),l=function(){r.innerHTML='<div class="ui-confirm"><div class="ui-confirm-header">'+(e.logo||"")+'</div><div class="ui-confirm-content-wrapper"><div class="ui-confirm-content">'+(e.title?"<header>"+e.title+"</header>":"")+(e.message?'<p class="message">'+e.message+"</p>":"")+'</div></div><div class="ui-confirm-footer-wrapper"><div class="ui-confirm-footer"></div></div></div>',a=r.querySelector(".ui-confirm-footer"),e.btnNo!==!1&&a.appendChild(i),e.btnYes!==!1&&a.appendChild(o),document.body.appendChild(r),r.parentNode.insertBefore(s,r)},c=function(){document.body.removeChild(r),document.body.removeChild(s)}
r=document.createElement("div"),r.setAttribute("class","ui-confirm-wrapper"),e.btnYes!==!1&&(o=document.createElement("button"),o.setAttribute("class","ui-confirm-btn-yes"),o.innerHTML=e.btnYesText||"Ok",o.onclick=function(){c(),t&&t()}),e.btnNo!==!1&&(i=document.createElement("button"),i.setAttribute("class","ui-confirm-btn-no"),i.innerHTML=e.btnNoText||"Cancel",i.onclick=function(){c(),n&&n()}),s.setAttribute("class","ui-confirm-overlay"),l(e)},block:function(){var e,t=document.createElement("div"),n=function(){e.innerHTML='<i class="icon icon-loading spinner poll-loading"></i>',document.body.appendChild(e),e.parentNode.insertBefore(t,e)},e=document.createElement("div")
e.setAttribute("class","ui-confirm-wrapper wait"),t.setAttribute("class","ui-confirm-overlay"),n()},unblock:function(){var e=document.querySelector(".ui-confirm-overlay"),t=document.querySelector(".ui-confirm-wrapper")
e&&e.parentNode.removeChild(e),t&&t.parentNode.removeChild(t)}}
return e}),define("app/poll",["dfp","app/party","hogan","serialize","app/data","app/utils","app/ui"],function(e,t,n,r,o,i,a){"use strict"
var s={entry:null,categories:{},getCurrentCategory:function(){var e
for(e=0;e<this.UI.form.categories.length;e+=1)if(this.UI.form.categories[e].className.indexOf("active")>-1)return e
return-1},shouldInitialize:function(){return void 0!==window.pollData},submitEntry:function(){var e,n,o=r(this.UI.form)
if(this.UI.Validator.validateAdestraForm())if(e=this.UI.Validator.validateEntryData(o)){o=this.formatSubmission(o),s.addressQuerycontains("t3.com")?o.site="t3":s.addressQuerycontains("gamesradar.com")&&(o.site="gamesradar")
var i
i=s.addressQuerycontains("local.ft")?"http://local.api.poll.future.net.uk/":s.addressQuerycontains("dev.fte")||s.addressQuerycontains("stage.fte")?"http://stage.api.poll.future.net.uk/":"http://api.poll.future.net.uk/",n=new XMLHttpRequest,n.open("POST",i,!0),n.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8"),n.onload=function(){var e
if(4===this.readyState&&"undefined"!=typeof ga)for(e in o.votes)null!==o.votes[e]&&(s.addressQuerycontains("t3.com")?ga("send",{hitType:"event",eventCategory:"T3 Awards 2016",eventAction:null===o.votes[e]?"No vote":window.pollData.article.pollCategory[e].options[o.votes[e]].name,eventLabel:window.pollData.article.pollCategory[e].namifiedName}):s.addressQuerycontains("gamesradar.com")&&ga("send",{hitType:"event",eventCategory:"Golden Joystick Awards 2016",eventAction:null===o.votes[e]?"No vote":window.pollData.article.pollCategory[e].options[o.votes[e]].name,eventLabel:window.pollData.article.pollCategory[e].namifiedName}))
s.shareUUID=this.responseText,t.triggerEvent("pollentrysubmitsuccess")},n.onerror=function(){t.triggerEvent("pollentrysubmitsuccess")},n.send("vote="+JSON.stringify(o)),t.triggerEvent("pollvalidatesuccess")}else t.triggerEvent("pollvalidatefail")},addressQuerycontains:function(e){return window.location.href.indexOf(e)>=0},numCategoriesVoted:function(){var e,t,n,r=document.querySelectorAll(".poll-category"),o=0
for(t=0;t<r.length;t+=1)for(e=r[t].querySelectorAll(".poll-field-required"),n=0;n<e.length;n+=1)if(e[n].checked){o+=1
break}return o},formatSubmission:function(e){var t
e.votes={}
for(t in e)"category_"===t.substring(0,9)&&(e.votes[t.replace("category_","")]=null===e[t]?e[t]:parseInt(e[t]),delete e[t])
return e},initialize:function(){var e=this
this.shouldInitialize()&&(t.createEvent("pollentryupdated"),t.createEvent("pollentrysubmitted"),t.createEvent("pollentrysubmitsuccess"),t.createEvent("pollentrysubmitfail"),t.createEvent("pollvotecast"),t.createEvent("pollvalidatesuccess"),t.createEvent("pollvalidatefail"),t.createEvent("pollfinishedvoting"),this.UI.initialize(),e.Router.initialize(),document.addEventListener("pollentrysubmitted",function(){e.submitEntry()}))}}
s.UI={container:document.querySelector(".poll"),form:document.querySelector(".poll-form"),templatePrefix:"template-",currentClass:"active",autoNext:null,radios:[],contentDiv:document.getElementById("content"),iframeBreakPoint:700,updateAllYouTubes:function(e,t){"undefined"==typeof t&&(t="pauseVideo"),console.debug("awards","func",t),console.debug("awards","youtube changing",e),console.debug("awards","youtube changing",document.getElementById(e))
var n=document.querySelectorAll(".youtube-video")
console.debug("awards","all the tubes",n)
for(var r=0;r<n.length;r++){var o=n[r].querySelector("iframe")
console.debug("awards","tubes",o),(o&&o.getAttribute("id")!=e||o==typeof e==="undefined")&&(console.debug("awards","killing",n[r].querySelector("iframe")),o.contentWindow.postMessage('{"event":"command","func":"'+t+'","args":""}',"*"))}},loadYouTubeAPI:function(){if("undefined"==typeof YT){var e=document.createElement("script")
e.src="//www.youtube.com/iframe_api"
var t=document.getElementsByTagName("script")[0]
t.parentNode.insertBefore(e,t)}},initBrightCoves:function(){for(var e=s.Router.getCurrentPage().querySelectorAll(".brightcove-video"),t=0;t<e.length;t++)bc(e[t])},loadBrightCoves:function(){if(window.innerWidth>=s.UI.iframeBreakPoint)if("function"!=typeof bc){var e=document.createElement("script"),t=this
e.onload=function(){t.initBrightCoves()},e.src="http://players.brightcove.net/1242843965001/VJDDIDZ3e_default/index.min.js"
var n=document.getElementsByTagName("script")[0]
n.parentNode.insertBefore(e,n)}else this.initBrightCoves()},setUpYouTubes:function(e){for(var t=this,n=0;n<e.length;n++)console.debug("awards","adding click event to"+e[n].getAttribute("data-youtube-id")),e[n].addEventListener("click",function(e){var n="awards-"+e.target.getAttribute("data-youtube-id"),r=e.target.getAttribute("data-youtube-id")
document.getElementById(n).parentNode.setAttribute("style",""),new YT.Player(n,{videoId:r,playerVars:{autoplay:1},events:{onStateChange:function(e){1==e.data&&t.updateAllYouTubes(n)}}}),e.target.setAttribute("style","display:none")})},iframeLazyLoad:function(){if(window.innerWidth>=s.UI.iframeBreakPoint){var e=this
"undefined"!=typeof YT&&(console.debug("awards","page change kill all other YTs"),e.updateAllYouTubes())
var t=s.Router.getCurrentPage().querySelectorAll("div.play-overlay")
console.debug("awards","getting this many youtube iframes: ",t.length),t.length&&("undefined"!=typeof YT&&e.setUpYouTubes(t),window.onYouTubeIframeAPIReady=function(){e.setUpYouTubes(t),console.debug("awards","YT api ready")},e.loadYouTubeAPI())}else console.debug("awards","not loading iframes as never displayed below a window width of "+s.UI.iframeBreakPoint)},renderCategory:function(e,t,n){var r
e.slug=i.slugify(e.name),e.namifiedName=i.namify(e.name),r=this.generateMarkup("award-category",{category:e,count:t,countOne:t+1,isLast:n}),this.form.innerHTML+=r},renderForm:function(){var e
for(this.form.innerHTML="",this.renderStartPage(),e=0;e<window.pollData.article.pollCategory.length;e+=1)this.renderCategory(window.pollData.article.pollCategory[e],e,e===window.pollData.article.pollCategory.length-1)
this.renderSubmissionSection()},getRadios:function(){return this.radios.length||(this.radios=document.querySelectorAll(".poll-radio")),this.radios},gotoCategory:function(e){var n
for(n=0;n<this.form.categories.length;n+=1)this.form.categories[n].className=this.form.categories[n].className.replace(this.currentClass,"")
this.form.categories[e].className+=" "+this.currentClass,t.triggerEvent("pollcategorychanged")},renderStartPage:function(){var e={poll:{description:window.pollData.article.contentBody.landingPage.body,deadline:window.pollData.article.contentBody.landingPage.name},startButton:{text:"Start"}}
"undefined"!=typeof window.pollData.article.pollCategory[0].name&&(e.startButton.url="#"+i.slugify(window.pollData.article.pollCategory[0].name)),this.form.innerHTML+=s.UI.generateMarkup("start-page",e)},isStartPage:function(){var e=s.Router.getCurrentPage()
return e.className.indexOf("start-page")>-1},renderSubmissionSection:function(){if(s.addressQuerycontains("t3.com")){var e,t='<div class="form-field central"><label for="">Email*</label><input type="email" name="email"></input></div><div class="form-field central"><label>Name</label><input type="text" name="name"></input></div><div class="form-field central"><label for="dob-day">Date of birth</label><div class="inline-field"><input type="text" name="dob_day" maxlength="2" placeholder="DD" title="Day (DD)" inputmode="numeric" id="dob-day" class="dob-day"></input></div> / <div class="inline-field"><input type="text" name="dob_month" maxlength="2" placeholder="MM" title="Month (MM)" inputmode="numeric" class="dob-month"></input></div> / <div class="inline-field"><input type="text" name="dob_year" maxlength="4" placeholder="YYYY" title="Year (YYYY)" inputmode="numeric" class="dob-year"></input></div><p class="helper-text">e.g. 29 / 3 / 1986</p></div><div class="form-field central"><label>Country*</label><select name="locale"><optgroup><option selected="selected" value="United Kingdom">United Kingdom</option><option value="United States of America">United States of America</option><option value="Australia">Australia</option></optgroup><optgroup>'
for(e=0;e<o.countryList.length;e+=1)t+='<option value="'+o.countryList[e]+'">'+o.countryList[e]+"</option>"
t+='</optgroup></select></div><div class="form-field terms central"><input type="checkbox" name="terms" id="terms"></input> <label for="terms">Please tick this box to say that you have read and accept our <a href="http://www.futuretcs.com" target="_blank">Terms and Conditions</a> and <a href="http://www.futureplc.com/privacy-policy" target="_blank">Privacy Policy</a>*</label></div><div class="form-field terms central"><input type="checkbox" checked="true" name="newsletter_opt_in" id="newsletter_opt_in"></input> <label for="newsletter_opt_in">Yes, I want to receive the T3 newsletter</label></div><div class="form-field terms central"><input type="checkbox" name="marketing_opt_in" id="marketing_opt_in"></input> <label for="marketing_opt_in">Yes, I want to to receive promotional marketing material</label></div><div class="form-field terms central"><input type="checkbox" name="third_party_opt_in" id="third_party_opt_in"></input> <label for="third_party_opt_in">Yes, I want to to receive exclusive special offers from carefully selected third parties. We will not share your data with the third party and you will be able to unsubscribe at any time.</label></div><div class="form-field terms central"><button type="submit" class="button dark">Submit my votes <i class="icon icon-arrow-right"></i><i class="icon icon-loading spinner"></i></button></div>',this.form.innerHTML+=this.generateMarkup("submission-page",{title:"Submit my votes",text:"Thanks for voting! In order to submit your votes and be entered into a free prize draw to win one of five Acer Chromebooks<sup>*</sup> we need you to fill in a few details below so we can contact you if you are a winner. <br><br><sup>*</sup>Only open to UK residents.",description:"Submit your votes to win a prize",form:t})}else if(s.addressQuerycontains("gamesradar.com")){var e,t='<div class="form-field central"><label for="">Email*</label><input type="email" name="email"></input></div><div class="form-field central"><label>Name</label><input type="text" name="name"></input></div><div class="form-field central"><label for="dob-day">Date of birth</label><div class="inline-field"><input type="text" name="dob_day" maxlength="2" placeholder="DD" title="Day (DD)" inputmode="numeric" id="dob-day" class="dob-day"></input></div> / <div class="inline-field"><input type="text" name="dob_month" maxlength="2" placeholder="MM" title="Month (MM)" inputmode="numeric" class="dob-month"></input></div> / <div class="inline-field"><input type="text" name="dob_year" maxlength="4" placeholder="YYYY" title="Year (YYYY)" inputmode="numeric" class="dob-year"></input></div><p class="helper-text">e.g. 29 / 3 / 1986</p></div><div class="form-field central"><label>Country*</label><select name="locale"><optgroup><option selected="selected" value="United Kingdom">United Kingdom</option><option value="United States of America">United States of America</option><option value="Australia">Australia</option></optgroup><optgroup>'
for(e=0;e<o.countryList.length;e+=1)t+='<option value="'+o.countryList[e]+'">'+o.countryList[e]+"</option>"
t+='</optgroup></select></div><div class="form-field terms central"><input type="checkbox" name="terms" id="terms"></input> <label for="terms">Please tick this box to say that you have read and accept our <a href="http://www.futuretcs.com" target="_blank">Terms and Conditions</a> and <a href="http://www.futureplc.com/privacy-policy" target="_blank">Privacy Policy</a>*</label></div><div class="form-field terms central"><input type="checkbox" checked="true" name="newsletter_opt_in" id="newsletter_opt_in"></input> <label for="newsletter_opt_in">Yes, I want to receive the Gamesradar newsletter</label></div><div class="form-field terms central"><input type="checkbox" name="marketing_opt_in" id="marketing_opt_in"></input> <label for="marketing_opt_in">Yes, I want to to receive promotional marketing material</label></div><div class="form-field terms central"><input type="checkbox" name="third_party_opt_in" id="third_party_opt_in"></input> <label for="third_party_opt_in">Yes, I want to to receive exclusive special offers from carefully selected third parties. We will not share your data with the third party and you will be able to unsubscribe at any time.</label></div><div class="form-field terms central"><button type="submit" class="button dark">Submit my votes <i class="icon icon-arrow-right"></i><i class="icon icon-loading spinner"></i></button></div>',this.form.innerHTML+=this.generateMarkup("submission-page",{title:"Submit my votes",text:"Thanks for voting! In order to submit your votes and qualify for the game offers please fill in the details below and ensure you provide a valid email address.",description:"Submit your votes",form:t})}},renderSuccessPage:function(e){var t={title:window.pollData.article.contentBody.dataCapturePage.name,content:window.pollData.article.contentBody.dataCapturePage.body},n=null,r=document.querySelector('meta[property="og:image"]')
r&&(n=r.getAttribute("content")),e&&(s.addressQuerycontains("t3.com")?t.share={url:"http://www.t3.com/awardvotes/"+e,caption:encodeURIComponent("I've voted in the T3 Awards 2016"),image:n}:s.addressQuerycontains("gamesradar.com")&&(t.share={url:"http://www.gamesradar.com/awardvotes/"+e,caption:encodeURIComponent("I've voted in the Golden Joystick Awards 2016"),image:n})),this.container.innerHTML=this.generateMarkup("success-page",t),window.scrollTo(0,0)},generateMarkup:function(e,t){var r=document.getElementById(this.templatePrefix+e)
r=r.innerHTML
var o=n.compile(r),i=o.render(t)
return i},initialize:function(){var e,n,r,o=this,i=document.querySelector(".holding-page-content")
for(this.renderForm(),i.parentNode.removeChild(i),this.form.categories=document.querySelectorAll(".poll-category"),n=0;n<this.form.categories.length;n+=1)for(e=this.form.categories[n].querySelectorAll(".poll-radio"),r=0;r<e.length;r+=1)e[r].onchange=function(){t.triggerEvent("pollentryupdated")}
this.form.onsubmit=function(e){e.preventDefault(),t.triggerEvent("pollentrysubmitted")},t.createEvent("pollcategorychanged"),s.UI.pagination.initialize(),s.UI.progressBar.initialize(),s.UI.Validator.initialize(),document.addEventListener("pollentrysubmitsuccess",function(){o.renderSuccessPage(s.shareUUID)})
for(var l=document.querySelectorAll(".button-poll-vote"),n=0;n<l.length;n+=1)l[n].addEventListener("touchstart",function(){var e=document.getElementById(this.getAttribute("for"))
e.checked=!0},!0),l[n].addEventListener("click",function(){a.block(),s.UI.autoNext=setTimeout(function(){a.unblock(),s.Router.getCurrentPageIndex()>=s.Router.getPages().length-2?t.triggerEvent("pollfinishedvoting"):window.location.hash=s.Router.getPages()[s.Router.getCurrentPageIndex()+1].getAttribute("data-router-url")},500)},!0)
document.addEventListener("pollvalidatesuccess",function(){var e=o.form.querySelector('*[type="submit"]')
e.className+=" loading"}),document.addEventListener("pollcategorychanged",function(){clearTimeout(s.UI.autoNext),o.isStartPage()?-1===o.contentDiv.className.indexOf("poll-start-page")&&(o.contentDiv.className+=" poll-start-page"):o.contentDiv.className=o.contentDiv.className.replace("poll-start-page",""),"undefined"!=typeof ga&&ga("send","pageview",{dimension9:""+(s.Router.getCurrentPageIndex()+1)})})}},s.UI.pagination={containerTop:document.querySelector(".poll-pagination-sequential.top"),containerBottom:document.querySelector(".poll-pagination-sequential.bottom"),update:function(){var e,t,n,r,o,i,a=s.Router.getCurrentPageIndex()
if(0==a)return this.containerTop.innerHTML="",void(this.containerBottom.innerHTML="")
if(a==s.Router.getPages().length-1?(n={text:s.Router.getPages()[a-1].getAttribute("data-router-name"),link:s.Router.getPages()[a-1].getAttribute("data-router-url")},r=null):(n={text:s.Router.getPages()[a-1].getAttribute("data-router-name"),link:s.Router.getPages()[a-1].getAttribute("data-router-url")},r={text:s.Router.getPages()[a+1].getAttribute("data-router-name"),link:s.Router.getPages()[a+1].getAttribute("data-router-url")}),this.containerTop.innerHTML=s.UI.generateMarkup("pagination-sequential-top",{prev:n,next:r}),this.containerBottom.innerHTML=s.UI.generateMarkup("pagination-sequential-bottom",{prev:n,next:r}),s.Router.getCurrentPage().className.indexOf("last-category")>-1)for(i=document.querySelectorAll(".pagination .next a"),o=0;o<i.length;o+=1)i[o].onclick=function(e){e.preventDefault(),window.location.hash=s.Router.getPages()[s.Router.getCurrentPageIndex()+1].getAttribute("data-router-url")}
e=s.Router.getCurrentPage(),t=e.querySelector(".poll-category-header"),null!==t&&t.appendChild(this.containerTop)},initialize:function(){var e=this
document.addEventListener("pollcategorychanged",function(){e.update()})}},s.UI.progressBar={templateName:"",container:document.querySelector(".poll-progressbar"),update:function(){var e,t,n=[],r=s.Router.getPages()
if(s.UI.isStartPage())return void(this.container.innerHTML="")
for(e=0;e<r.length;e+=1)n[e]=r[e].className.indexOf("start-page")>-1?{completed:!0,link:"#start",current:r[e].className.indexOf("active")>-1}:r[e].className.indexOf("submission-page")>-1?{completed:!1,link:!1,current:r[e].className.indexOf("active")>-1}:{completed:r[e].querySelectorAll('input[name="category_'+i.namify(r[e].getAttribute("data-category-position"))+'"]:checked').length,current:r[e].className.indexOf("active")>-1,link:"#"+r[e].getAttribute("data-category-slug")}
this.container.innerHTML=s.UI.generateMarkup("progressbar",{blocks:n,blockWidth:100/n.length}),t=s.Router.getCurrentPage(),t.insertBefore(this.container,t.querySelector(".poll-category-header").nextSibling)},initialize:function(){var e=this
document.addEventListener("pollcategorychanged",function(){e.update()}),document.addEventListener("pollentryupdated",function(){e.update()})}},s.Router={pages:[],visibleClass:"active",getPages:function(){return this.pages.length||(this.pages=document.querySelectorAll(".router-page")),this.pages},route:function(t){var n
if(""==t)return this.getPages()[0].className+=" "+this.visibleClass,void(s.addressQuerycontains("t3.com")?e.setKeywords("T3awards2016,awards-home"):s.addressQuerycontains("gamesradar.com")&&e.setKeywords("GoldenJoystickawards2016,awards-home"))
for(n=0;n<this.getPages().length;n+=1)this.getPages()[n].className=this.getPages()[n].className.replace(" "+this.visibleClass,""),this.getPages()[n].getAttribute("data-router-url")===window.location.hash&&(this.getPages()[n].className+=" "+this.visibleClass,s.addressQuerycontains("t3.com")?null!==this.getPages()[n].getAttribute("data-category-slug")?e.setKeywords("T3awards2016,"+this.getPages()[n].getAttribute("data-category-slug")):"#submit"==t?e.setKeywords("T3awards2016,submit-form"):e.setKeywords("T3awards2016,awards-home"):s.addressQuerycontains("gamesradar.com")&&(null!==this.getPages()[n].getAttribute("data-category-slug")?e.setKeywords("GoldenJoystickawards2016,"+this.getPages()[n].getAttribute("data-category-slug")):"#submit"==t?e.setKeywords("GoldenJoystickawards2016,submit-form"):e.setKeywords("GoldenJoystickawards2016,awards-home")),e.refresh())
s.UI.loadBrightCoves(),s.UI.iframeLazyLoad(),this.jumpToTop()},getCurrentPage:function(){var e
for(e=0;e<this.getPages().length;e+=1)if(this.getPages()[e].className.indexOf(this.visibleClass)>-1)return this.getPages()[e]
return!1},getCurrentPageIndex:function(){var e
for(e=0;e<this.getPages().length;e+=1)if(this.getPages()[e].className.indexOf(this.visibleClass)>-1)return e
return!1},jumpToTop:function(){window.scrollTo(0,0)},initialize:function(){var e=this
!function(e){if(!("onhashchange"in e.document.body)){var t=e.location,n=t.href,r=t.hash
setInterval(function(){var o=t.href,i=t.hash
i!=r&&"function"==typeof e.onhashchange&&(e.onhashchange({type:"hashchange",oldURL:n,newURL:o}),n=o,r=i)},100)}}(window),window.onhashchange=function(){e.route(window.location.hash),t.triggerEvent("pollcategorychanged")},e.route(window.location.hash)}},s.UI.Validator={confirmationCheckbox:null,adestraFormValidationRules:[{name:"email",rules:"required|valid_email",message:"Please enter a valid email address"},{name:"locale",rules:"required",message:"This field is required"},{name:"terms",rules:"required"},{name:"name",rules:"required",message:"This field is required"},{name:"dob_day",rules:"valid_day",message:"You must enter a value between 01 and 31"},{name:"dob_month",rules:"valid_month",message:"You must enter a value between 01 and 12"},{name:"dob_year",rules:"valid_year",message:"You must enter a valid year"}],hasBeenFilled:function(e){switch(e.type){case"text":case"email":return null!==e.value
case"select-one":return"-1"!==e.value
case"checkbox":return e.checked}},clearErrorMessages:function(){var e,t,n,r=document.getElementsByClassName("form-error-message"),o=document.getElementsByClassName("form-field")
if(e=r.length,e>0)for(t=0;e>t;t+=1)r[0].parentElement.removeChild(r[0])
for(n=0;n<o.length;n+=1)o[n].className=o[n].className.replace(" has-error","")},validateAdestraForm:function(){var e,t,n,r,o,i,a=[],s=document.createElement("div"),l=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
for(s.setAttribute("class","form-error-message"),this.clearErrorMessages(),e=0;e<this.adestraFormValidationRules.length;e+=1)for(r=document.querySelector('*[name="'+this.adestraFormValidationRules[e].name+'"]'),o=this.adestraFormValidationRules[e].rules.split("|"),t=0;t<o.length;t+=1)switch(o[t]){case"required":this.hasBeenFilled(r)||a.push({name:r.name,message:"Field is required"})
break
case"valid_email":l.test(r.value)||a.push({name:r.name,message:"Please enter a valid email address"})
break
case"valid_day":(r.value<1||r.value>31)&&a.push({name:r.name,message:"Please enter a valid date of birth"})
break
case"valid_month":(r.value<1||r.value>12)&&a.push({name:r.name,message:"Please enter a valid date of birth"})
break
case"valid_year":(r.value<1900||r.value>2016)&&a.push({name:r.name,message:"Please enter a valid date of birth"})}if(a.length){var c=!1
for(n=0;n<a.length;n+=1){var u=document.querySelector('*[name="'+a[n].name+'"]')
if(i=u.parentNode,c||"dob_day"!=a[n].name&&"dob_month"!=a[n].name&&"dob_year"!=a[n].name){if("dob_day"!=a[n].name&&"dob_month"!=a[n].name&&"dob_year"!=a[n].name){var d=s.cloneNode()
d.innerHTML=a[n].message,i.parentNode.insertBefore(d,i.nextSibling),u.parentNode.className.indexOf("form-field")>-1&&(u.parentNode.className.indexOf("has-error")&&(u.parentNode.className+=" has-error"),u.parentNode.className.indexOf("central")>-1&&(d.className+=" central"))}}else{var d=s.cloneNode()
d.innerHTML=a[n].message,i.parentNode.parentNode.insertBefore(d,i.parentNode.nextSibling),c=!0,u.parentNode.parentNode.className+=" has-error"}}return!1}return!0},validateEntryData:function(){return!!(s.numCategoriesVoted()===s.UI.form.categories.length||s.numCategoriesVoted()>0)},initialize:function(){this.confirmationCheckbox=document.createElement("input"),this.confirmationCheckbox.type="checkbox",this.confirmationCheckbox.className="poll-confirmation-checkbox",s.UI.form.appendChild(this.confirmationCheckbox),document.addEventListener("pollfinishedvoting",function(){0===s.numCategoriesVoted()?a.confirm({logo:'<div class="poll-category-logo"></div>',title:"But you haven't chosen anything!",message:"Please vote in at least 1 category",btnYes:!1,btnNoText:"Ok"},function(){},function(){}):window.location.href="#submit"})}},s.initialize()}),!function(){"use strict"
function e(e,t,n){"addEventListener"in window?e.addEventListener(t,n,!1):"attachEvent"in window&&e.attachEvent("on"+t,n)}function t(){var e,t=["moz","webkit","o","ms"]
for(e=0;e<t.length&&!S;e+=1)S=window[t[e]+"RequestAnimationFrame"]
S||o(" RequestAnimationFrame not supported")}function n(){var e="Host page"
return window.top!==window.self&&(e=window.parentIFrame?window.parentIFrame.getId():"Nested host page"),e}function r(e){return E+"["+n()+"]"+e}function o(e){b&&"object"==typeof window.console&&console.log(r(e))}function i(e){"object"==typeof window.console&&console.warn(r(e))}function a(e){function t(){function e(){u(P),l(),T[D].resizedCallback(P)}a("Height"),a("Width"),d(e,P,"resetPage")}function n(e){var t=e.id
o(" Removing iFrame: "+t),e.parentNode.removeChild(e),T[t].closedCallback(t),delete T[t],o(" --")}function r(){var e=M.substr(C).split(":")
return{iframe:document.getElementById(e[0]),id:e[0],height:e[1],width:e[2],type:e[3]}}function a(e){var t=Number(T[D]["max"+e]),n=Number(T[D]["min"+e]),r=e.toLowerCase(),i=Number(P[r])
if(n>t)throw new Error("Value for min"+e+" can not be greater than max"+e)
o(" Checking "+r+" is in range "+n+"-"+t),n>i&&(i=n,o(" Set "+r+" to min value")),i>t&&(i=t,o(" Set "+r+" to max value")),P[r]=""+i}function p(){function t(){function e(){o(" Checking connection is from allowed list of origins: "+r)
var e
for(e=0;e<r.length;e++)if(r[e]===n)return!0
return!1}function t(){return o(" Checking connection is from: "+i),n===i}return r.constructor===Array?e():t()}var n=e.origin,r=T[D].checkOrigin,i=P.iframe.src.split("/").slice(0,3).join("/")
if(r&&""+n!="null"&&!t())throw new Error("Unexpected message received from: "+n+" for "+P.iframe.id+". Message was: "+e.data+". This error can be disabled by setting the checkOrigin: false option or by providing of array of trusted domains.")
return!0}function f(){return E===(""+M).substr(0,C)}function h(){var e=P.type in{"true":1,"false":1,undefined:1}
return e&&o(" Ignoring init message from meta parent page"),e}function m(e){return M.substr(M.indexOf(":")+_+e)}function g(e){o(" MessageCallback passed: {iframe: "+P.iframe.id+", message: "+e+"}"),T[D].messageCallback({iframe:P.iframe,message:JSON.parse(e)}),o(" --")}function v(){return null===P.iframe?(i(" IFrame ("+P.id+") not found"),!1):!0}function y(e){var t=e.getBoundingClientRect()
return s(),{x:parseInt(t.left,10)+parseInt(x.x,10),y:parseInt(t.top,10)+parseInt(x.y,10)}}function w(e){function t(){x=a,S(),o(" --")}function n(){return{x:Number(P.width)+r.x,y:Number(P.height)+r.y}}var r=e?y(P.iframe):{x:0,y:0},a=n()
o(" Reposition requested from iFrame (offset x:"+r.x+" y:"+r.y+")"),window.top!==window.self?window.parentIFrame?e?window.parentIFrame.scrollToOffset(a.x,a.y):window.parentIFrame.scrollTo(P.width,P.height):i(" Unable to scroll to requested position, window.parentIFrame not found"):t()}function S(){!1!==T[D].scrollCallback(x)&&l()}function k(e){function t(e){var t=y(e)
o(" Moving to in page link (#"+n+") at x: "+t.x+" y: "+t.y),x={x:t.x,y:t.y},S(),o(" --")}var n=e.split("#")[1]||"",r=decodeURIComponent(n),i=document.getElementById(r)||document.getElementsByName(r)[0]
window.top!==window.self?window.parentIFrame?window.parentIFrame.moveToAnchor(n):o(" In page link #"+n+" not found and window.parentIFrame not found"):i?t(i):o(" In page link #"+n+" not found")}function A(){switch(P.type){case"close":n(P.iframe)
break
case"message":g(m(6))
break
case"scrollTo":w(!1)
break
case"scrollToOffset":w(!0)
break
case"inPageLink":k(m(9))
break
case"reset":c(P)
break
case"init":t(),T[D].initCallback(P.iframe)
break
default:t()}}function N(e){var t=!0
return T[e]||(t=!1,i(P.type+" No settings for "+e+". Message was: "+M)),t}var M=e.data,P={},D=null
f()&&(P=r(),D=P.id,!h()&&N(D)&&(b=T[D].log,o(" Received: "+M),v()&&p()&&(T[D].firstRun=!1,A())))}function s(){null===x&&(x={x:void 0!==window.pageXOffset?window.pageXOffset:document.documentElement.scrollLeft,y:void 0!==window.pageYOffset?window.pageYOffset:document.documentElement.scrollTop},o(" Get page position: "+x.x+","+x.y))}function l(){null!==x&&(window.scrollTo(x.x,x.y),o(" Set page position: "+x.x+","+x.y),x=null)}function c(e){function t(){u(e),p("reset","reset",e.iframe,e.id)}o(" Size reset requested by "+("init"===e.type?"host page":"iFrame")),s(),d(t,e,"init")}function u(e){function t(t){e.iframe.style[t]=e[t]+"px",o(" IFrame ("+n+") "+t+" set to "+e[t]+"px")}var n=e.iframe.id
T[n].sizeHeight&&t("height"),T[n].sizeWidth&&t("width")}function d(e,t,n){n!==t.type&&S?(o(" Requesting animation frame"),S(e)):e()}function p(e,t,n,r){n&&n.contentWindow?(o("["+e+"] Sending msg to iframe ("+t+")"),n.contentWindow.postMessage(E+t,"*")):(i("["+e+"] IFrame not found"),T[r]&&delete T[r])}function f(t){function n(){function e(e){1/0!==T[h][e]&&0!==T[h][e]&&(f.style[e]=T[h][e]+"px",o(" Set "+e+" = "+T[h][e]+"px"))}e("maxHeight"),e("minHeight"),e("maxWidth"),e("minWidth")}function r(e){return""===e&&(f.id=e="iFrameResizer"+y++,b=(t||{}).log,o(" Added missing iframe ID: "+e+" ("+f.src+")")),e}function i(){o(" IFrame scrolling "+(T[h].scrolling?"enabled":"disabled")+" for "+h),f.style.overflow=!1===T[h].scrolling?"hidden":"auto",f.scrolling=!1===T[h].scrolling?"no":"yes"}function a(){("number"==typeof T[h].bodyMargin||"0"===T[h].bodyMargin)&&(T[h].bodyMarginV1=T[h].bodyMargin,T[h].bodyMargin=""+T[h].bodyMargin+"px")}function s(){return h+":"+T[h].bodyMarginV1+":"+T[h].sizeWidth+":"+T[h].log+":"+T[h].interval+":"+T[h].enablePublicMethods+":"+T[h].autoResize+":"+T[h].bodyMargin+":"+T[h].heightCalculationMethod+":"+T[h].bodyBackground+":"+T[h].bodyPadding+":"+T[h].tolerance+":"+T[h].enableInPageLinks+":"+T[h].resizeFrom}function l(t){e(f,"load",function(){var e=T[h].firstRun
p("iFrame.onload",t,f),!e&&T[h].heightCalculationMethod in k&&c({iframe:f,height:0,width:0,type:"init"})}),p("init",t,f)}function u(e){if("object"!=typeof e)throw new TypeError("Options is not an object.")}function d(e){e=e||{},T[h]={firstRun:!0},u(e)
for(var t in N)N.hasOwnProperty(t)&&(T[h][t]=e.hasOwnProperty(t)?e[t]:N[t])
b=T[h].log}var f=this,h=r(f.id)
d(t),i(),n(),a(),l(s())}function h(e,t){null===A&&(A=setTimeout(function(){A=null,e()},t))}function m(){function e(e){return"parent"===T[e].resizeFrom&&T[e].autoResize&&!T[e].firstRun}h(function(){for(var t in T)e(t)&&p("Window resize","resize",document.getElementById(t),t)},66)}function g(){function n(e,t){if(!e.tagName)throw new TypeError("Object is not a valid DOM element")
if("IFRAME"!==e.tagName.toUpperCase())throw new TypeError("Expected <IFRAME> tag, found <"+e.tagName+">.")
f.call(e,t)}return t(),e(window,"message",a),e(window,"resize",m),function(e,t){switch(typeof t){case"undefined":case"string":Array.prototype.forEach.call(document.querySelectorAll(t||"iframe"),function(t){n(t,e)})
break
case"object":n(t,e)
break
default:throw new TypeError("Unexpected data type ("+typeof t+").")}}}function v(e){e.fn.iFrameResize=function(e){return this.filter("iframe").each(function(t,n){f.call(n,e)}).end()}}var y=0,b=!1,w="message",_=w.length,E="[iFrameSizer]",C=E.length,x=null,S=window.requestAnimationFrame,k={max:1,scroll:1,bodyScroll:1,documentElementScroll:1},T={},A=null,N={autoResize:!0,bodyBackground:null,bodyMargin:null,bodyMarginV1:8,bodyPadding:null,checkOrigin:!0,enableInPageLinks:!1,enablePublicMethods:!1,heightCalculationMethod:"offset",interval:32,log:!1,maxHeight:1/0,maxWidth:1/0,minHeight:0,minWidth:0,resizeFrom:"parent",scrolling:!1,sizeHeight:!0,sizeWidth:!1,tolerance:0,closedCallback:function(){},initCallback:function(){},messageCallback:function(){},resizedCallback:function(){},scrollCallback:function(){return!0}}
window.jQuery&&v(jQuery),"function"==typeof define&&define.amd?define("iframeResizer",[],g):"object"==typeof module&&"object"==typeof module.exports?module.exports=g():window.iFrameResize=window.iFrameResize||g()}(),define("app/newsletter",["iframeResizer"],function(e){var t=document.querySelector(".newsletter-signup iframe")
t&&t.className.indexOf("dynamic-height")>-1&&e([],".newsletter-signup iframe")}),define("app/cookies",[],function(){"use strict"
return{getItem:function(e){return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"+encodeURIComponent(e).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=\\s*([^;]*).*$)|^.*$"),"$1"))||null},setItem:function(e,t,n,r,o,i){if(!e||/^(?:expires|max\-age|path|domain|secure)$/i.test(e))return!1
var a=""
if(n)switch(n.constructor){case Number:a=n===1/0?"; expires=Fri, 31 Dec 9999 23:59:59 GMT":"; max-age="+n
break
case String:a="; expires="+n
break
case Date:a="; expires="+n.toUTCString()}return document.cookie=encodeURIComponent(e)+"="+encodeURIComponent(t)+a+(o?"; domain="+o:"")+(r?"; path="+r:"")+(i?"; secure":""),!0},removeItem:function(e,t,n){return e&&this.hasItem(e)?(document.cookie=encodeURIComponent(e)+"=; expires=Thu, 01 Jan 1970 00:00:00 GMT"+(n?"; domain="+n:"")+(t?"; path="+t:""),!0):!1},hasItem:function(e){return new RegExp("(?:^|;\\s*)"+encodeURIComponent(e).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=").test(document.cookie)},keys:function(){for(var e=document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g,"").split(/\s*(?:\=[^;]*)?;\s*/),t=0;t<e.length;t++)e[t]=decodeURIComponent(e[t])
return e}}}),define("app/suggest_next_article",["app/utils","hogan","app/event_tracking","app/localisation_utilities","app/cookies"],function(e,t,n,r,o){"use strict"
var i=function(t,r,o){var i=[],a=null,s=null,l=0,c=new Event("data.variants_loaded"),u=function(e){l++,e!==!1&&(""==t||-1===e.href.indexOf(t)&&window.location.pathname!=e.href?i.push(e):console.warn("unset as matched current article")),(l===r.length||l===s)&&document.dispatchEvent(c)},d=function(t){if("undefined"!=typeof r[t].method){if("function"==typeof r[t].validate&&r[t].validate()===!1)return u(!1),void console.warn("Failed vaildation: "+r[t].url)
var i=r[t].method(o)
if("function"==typeof r[t].validatePromise){var a=r[t].validatePromise()
a.then(function(){u({id:r[t].id,label:r[t].label,href:i.href,text:i.text})},function(){})}else u({id:r[t].id,label:r[t].label,href:i.href,text:i.text})}else if("undefined"!=typeof r[t].selector)try{var c=document.querySelector(r[t].selector)
"undefined"!==c&&null!==c&&c.getAttribute("href")&&c.textContent&&u({id:r[t].id,label:r[t].label,href:c.getAttribute("href"),text:c.textContent})}catch(d){u(!1),console.warn("Failed to load dom variant: "+r[t].selector,d)}else if("undefined"!=typeof r[t].url){if("function"==typeof r[t].validate&&r[t].validate()===!1)return u(!1),void console.warn("Failed vaildation: "+r[t].url)
try{var p=new XMLHttpRequest,f=function(){if(4===p.readyState)if(200===p.status)if("undefined"!=typeof p.response&&p.response.length){var o=p.response
o=e.shuffle(o)
for(var i=!1,a=0;a<o.length;a++){var c=o[a]
c=r[t].normalise(c)
var d=c.articleUrl[0],f=function(e,n){return function(a){for(var s=!1,l=0;l<a.length;l++){var c=a[l]
if("suggestion-seen"==c.category||"suggestion-dismissed"==c.category||"suggestion-clicked"==c.category){s=!0
break}}s?i||n!=o.length-1||u(!1):(i=!0,u({id:r[t].id,label:r[t].label,href:e.articleUrl[0],text:e.articleName,showSVG:!1}))}}(c,a)
n.drivers.indexedDB.getEventsByAction(d).then(f,function(){s--,l--,u(!1)})}}else u(!1),console.warn("No results for external variant: "+r[t].label)
else u(!1),console.warn("Failed to load external variant: "+r[t].url+" - "+p.status)}
p.responseType="json",p.onreadystatechange=f,"undefined"!=typeof r[t].withCredentials&&r[t].withCredentials&&(p.withCredentials=!0),p.open("GET",r[t].url),p.send()}catch(d){console.warn("Failed to push variant",d)}}else console.warn("Unknown variant source")}
this.setVariants=function(){var e=Math.floor(Math.random()*r.length)
a=r[e].id
var t=[]
t.push(e)
for(var n=0;n<r.length;n++)"undefined"==typeof r[n].url&&n!==e&&t.push(n)
s=t.length
for(var o=0;o<t.length;o++)d(t[o])},this.getVariants=function(){if(i.length){for(var t=0;t<i.length;t++)if(i[t].id===a)return[i[t]]
return[e.shuffle(i)[0]]}return null}},a={eventsSetup:!1,data:null,dataInstance:null,seenEventSent:!1,percentageRead:.9,template:'<header><span>More like this…</span><button class="magic-close"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"  x="0px" y="0px" width="14px" height="14px" viewBox="0 0 14 14" overflow="visible" enable-background="new 0 0 14 14" xml:space="preserve"><defs></defs><polygon fill="#000000" points="14,11.2001953 9.7998047,6.9995117 13.9990234,2.7998047 11.1992188,0 7,4.199707 2.8007812,0 0.0009766,2.7998047 4.2001953,6.9995117 0,11.2001953 2.7998047,14 7,9.7998047 11.2001953,14 "/></svg></button></header><div class="widget-similar-phones"><ul class="widget-similar-phones-ul"><li class="similar-phones-item clearfix"><a data-ga-event="{{data.label}}" href="{{data.href}}" class="clearfix"><span class="related-article-title">{{{data.text}}}</span></a></li></ul>',headings:{latest:"You should read",most_popular:"You should read",most_shared:"You should read",recommendation:"You should read...",related:"More like this","free-keys":"Like free games?",gja:"Voting closes on Nov 4th",black_friday:"Don't Miss Out",cyber_monday:"Don't Miss Out",pcg_weekender:"Play pre-release games at the PC Gamer Weekender"},variantSource:null,elements:null,fetchData:function(){var e
if(null===this.dataInstance&&(e=m.getCurrentArticleProgress(),e>=.5)){var t=this.elements.article.getAttribute("data-id")
null!=t&&(t=t.replace(/[^0-9]/g,"")),this.dataInstance=new i(t,this.variantSource,s),this.dataInstance.setVariants()}},update:function(){try{this.fetchData(),this.createContainer(),this.placeContainer()}catch(e){console.error("Failed to suggest article",e)}},init:function(e,t,n){if(null!==t.article&&null!==t.articleBody){var r=this
r.variantSource=e,r.elements=t,r.key=n,r.seenEventSent=!1,r.eventsSetup===!1&&(window.addEventListener("optimizedScroll",function(){r.update()}),document.addEventListener("data.variants_loaded",function(){r.data=r.dataInstance.getVariants()}),r.eventsSetup=!0)}},createContainer:function(){if(null===document.querySelector(".magic-container")){var e,r
if(this.elements.container)return
if(null===this.data||!this.data.length)return
e=t.compile(this.template),r=document.createElement("div"),r.classList.add("magic-container"),r.innerHTML=e.render({data:this.data[0]}),document.body.appendChild(r),window.related?window.related():window.related=Promise.resolve(),this.elements.container=document.querySelector(".magic-container"),this.elements.container.querySelector("header span").innerHTML=this.headings[this.data[0].label],this.elements.suggestionLink=this.elements.container.querySelector("a")
var o=this
this.elements.container.querySelector("a > span").addEventListener("click",function(e){e.stopPropagation(),n.send("suggestion-clicked ",o.elements.suggestionLink.getAttribute("href"),o.elements.suggestionLink.getAttribute("data-ga-event"))}),this.elements.container.querySelector(".magic-close").addEventListener("click",function(){n.send("suggestion-dismissed",o.elements.suggestionLink.getAttribute("href"),o.elements.suggestionLink.getAttribute("data-ga-event")),o.elements.container.parentNode.removeChild(o.elements.container)})}},placeContainer:function(){var e
if(null!==this.data&&null!==this.elements.container)if(e=m.getCurrentArticleProgress(),e>=this.percentageRead-.15?this.elements.container.classList.add("almost"):this.elements.container.classList.remove("almost"),e>=this.percentageRead){window.moveRecommendation&&window.moveRecommendation(),this.elements.container.classList.add("hello")
var t=this
this.seenEventSent===!1&&(n.send("suggestion-seen",t.elements.suggestionLink.getAttribute("href"),t.elements.suggestionLink.getAttribute("data-ga-event")),this.seenEventSent=!0)}else this.elements.container.classList.remove("hello")}},s=null,l=document.location.href;-1!==window.location.href.indexOf("techradar")&"http://www.techradar.com/news/digital-home/black-friday-2016-1318385"!=l&&"http://www.techradar.com/news/internet/cyber-monday-deals-1310024"!=l&&(s="techradar")
var c=1478303999e3,u=Date.now()
c>u&&(-1!==window.location.href.indexOf("gamesradar")&&(s="gamesradar"),-1!==window.location.href.indexOf("pcgamer")&&(s="pcgamer"),-1!==window.location.href.indexOf("t3")&&-1!==window.location.href.indexOf("games")&&(s="t3"))
var d=148737594e4
if(d>u&&-1!==window.location.href.indexOf("pcgamer")&&(s="pcgamer"),d>u&&-1!==window.location.href.indexOf("gamesradar")&&(s="gamesradar"),null!=s){var p={techradar:{article:document.querySelector('article[itemtype="http://schema.org/NewsArticle"]'),articleBody:document.getElementById("article-body")},gamesradar:{article:document.querySelector('article[itemtype="http://schema.org/NewsArticle"]'),articleBody:document.getElementById("article-body")},t3:{article:document.querySelector('article[itemtype="http://schema.org/NewsArticle"]'),articleBody:document.getElementById("article-body")},pcgamer:{article:document.querySelector('article[itemtype="http://schema.org/NewsArticle"]'),articleBody:document.getElementById("article-body")}},f=function(){return{text:"Vote for your favourite games in the 2016 Golden Joystick Awards",href:"http://www.gamesradar.com/goldenjoystickawards/?ref=gjswidget"}},h=function(){var e=f().href
return new Promise(function(t,r){n.drivers.indexedDB.getEventsByAction(e).then(function(e){var n=864e5,o=Date.now(),i=e.filter(function(e){return 1e3*e.timestamp>o-n})
console.log("GJA LINK - Total",e.length,"Today",i.length),i.length<3?t():r()},r)})},m=function(t){var n=function(){if(null!==t.articleBody){var n=t.articleBody.getBoundingClientRect().top-document.body.getBoundingClientRect().top
return(e.windowScrollTop()+window.innerHeight-n)/t.articleBody.clientHeight}return 0}
return{getCurrentArticleProgress:n}}(p[s]),g={t3:[{id:23,label:"gja",method:f,validatePromise:h}]}
g.techradar=[{id:5,url:"/recommendation",label:"recommendation",sourceIndex:0,withCredentials:!0,normalise:function(e){return e.n&&e.u&&(e.articleName=e.n,e.articleUrl=[e.u]),e},validate:function(){return window.gaCookieSet&&null!=o.getItem("_ga")&&""!=o.getItem("_ga")}}]
var v=document.getElementsByTagName("html")[0].getAttribute("data-locale"),y=document.location.href
if(("GB"==v||"US"==v)&&"http://www.techradar.com/news/digital-home/black-friday-2016-1318385"!=y&&"http://www.techradar.com/news/internet/cyber-monday-deals-1310024"!=y){var b={start:14800176e5,end:1480291199e3},w={start:14802912e5,end:148041e7},_=Date.now()
_>b.start&&_<b.end&&(g.techradar=[{id:1,label:"black_friday",method:function(){return{text:"The Best Black Friday Deals 2016",href:"http://www.techradar.com/news/digital-home/black-friday-2016-1318385"}}}]),_>w.start&&_<w.end&&(g.techradar=[{id:1,label:"cyber_monday",method:function(){return{text:"The Best Cyber Monday Deals 2016",href:"http://www.techradar.com/news/internet/cyber-monday-deals-1310024"}}}])}d>u&&("UK"==v||"GB"==v)&&(g.pcgamer=[{id:22,label:"pcg_weekender",method:function(){return{text:"Click here to find out more!",href:"http://weekender.pcgamer.com/?utm_source=pcgamer.com&utm_campaign=pcgw-slider&utm_medium=referral"}}}],g.gamesradar=[{id:1090,label:"pcg_weekender",method:function(){return{text:"Click here to find out more!",href:"http://weekender.pcgamer.com/?utm_source=gamesradar.com&utm_campaign=pcgw-slider&utm_medium=referral"}}}]),a.init(g[s],p[s],s)}}),define("app/component_tracking",["app/utils"],function(e){"use strict"
if(void 0!==window.vanillaComponents){var t=["click"],n=function(n){return e.inArray(n,t)},r=function(e,t,n,r){ga?(ga("set","nonInteraction",!0),ga("send","event","Component",e,t,{dimension1:window.analytics_ga_data.dimension1||null,dimension5:window.analytics_ga_data.dimension5||null,dimension16:n.dimension16||null,dimension17:n.dimension17||null,dimension39:window.location.pathname,dimension49:n.dimension49||null}),r&&r()):r&&r()},o=function(e){var t=e.getAttribute("data-track-type"),n=e.getAttribute("data-component"),r=e.getAttribute("data-index"),o=e.getAttribute("data-count")
return null===t||null===n||null===r||null===o?!1:{type:t,component:n,index:r,count:o}},i={handleClick:function(){var e=o(this),t={}
e!==!1&&(t.dimension16=e.index,t.dimension17=e.count,null!==this.getAttribute("href")&&(t.dimension49=this.getAttribute("href").replace(/^(?:\/\/|[^\/]+)*/,"")),r("Click",e.component,t))}},a=function(r,o,a){var s,l,c,u,d=o.querySelectorAll(r.identifier),p=[]
if(n(r.type)){for(u=d.length,s=0;u>s;s+=1)a.excludeHidden?e.isHidden(d[s])||p.push(s):p.push(s)
for(l=0;l<p.length;l++)if(null==d[p[l]].getAttribute("data-index"))for(d[p[l]].setAttribute("data-track-type",r.type),d[p[l]].setAttribute("data-index",l+1),d[p[l]].setAttribute("data-component",a.name),d[p[l]].setAttribute("data-count",p.length),c=0;c<t.length;c+=1)d[p[l]].addEventListener(t[c],i["handle"+e.toSentenceCase(t[c])])}},s=function(e){var t,n=document.querySelector(e.identifier)
if(null!==n)for(t=0;t<e.trackable.length;t+=1)a(e.trackable[t],n,e)},l=function(e){var t
if(e.length)for(t=0;t<e.length;t+=1)s(e[t])}
window.reliableDOMContentLoaded.then(function(){l(window.vanillaComponents)}),window.reliablePageLoad.then(function(){l(window.vanillaComponents)}),document.addEventListener("component_tracking.run",function(){l(window.vanillaComponents)},!1)}}),define("app/hub_tweets",[],function(){if(-1!==location.host.indexOf("techradar")&&("/iphone-live"==location.pathname||"/xmasradar-2015"==location.pathname))try{window.twttr=function(e,t,n){var r,o=e.getElementsByTagName(t)[0],i=window.twttr||{}
return e.getElementById(n)?i:(r=e.createElement(t),r.id=n,r.src="https://platform.twitter.com/widgets.js",o.parentNode.insertBefore(r,o),i._e=[],i.ready=function(e){i._e.push(e)},i)}(document,"script","twitter-wjs")
for(var e=document.querySelectorAll(".listingResults > .listingResult"),t=2,n=0;n<window._van_hub_tweets.length;n++){var r=document.createElement("div")
if(r.classList.add("listingTweet"),r.innerHTML=window._van_hub_tweets[n].html,t<e.length){var o=e[t]
document.querySelector(".listingResults").insertBefore(r,o)}else document.querySelector(".listingResults").appendChild(r)
t+=5}window.twttr.ready(function(){console.log("twttr ready"),twttr.widgets.load()})}catch(i){console.error("Failed to insert tweets",i)}}),define("app/init",["fastclick","app/utils","app/list_pagination","app/event_tracking"],function(e,t,n,r){"use strict"
document.body.classList.remove("no-js"),document.body.classList.add("js"),e.attach(document.body),t.updateBodyClasses()
var o=document.querySelectorAll(".paginated")
Array.prototype.forEach.call(o,function(e){var t=new n
t.paginate(e)}),r.init(["ga","indexedDB"])}),define("app/height_fix",[],function(){if(-1!==window.location.href.indexOf("techradar.com"))for(var e=function(e){for(var t=0;t<e.length;t++)e[t].className=e[t].className.replace(/result\d+/,"result"+(t+1))},t=function(t,n){var o=[3,4,4],i={},a=r[n].querySelectorAll(".listingResult.small"),s=r[n].offsetTop,l=null
e(a),t.style.height=t.scrollHeight+"px"
for(var c=a.length-o[n];c<a.length;c++)a[c]&&(i[c]=a[c].offsetTop-s,null!==l&&i[c]!==l&&(a[c].style.display="none"),l=i[c])
t.style.height="auto"},n=function(e,n){var r=new MutationObserver(function(){t(e,n)})
r.observe(e,{attributes:!1,childList:!0,characterData:!0,subtree:!0})},r=document.querySelectorAll(".impact .listingResults"),o=0;o<r.length;o++)t(r[o],o),n(r[o],o)}),define("app/trending_responsive",[],function(){"use strict"
function e(){var e=n.offsetWidth,i=o.offsetWidth
t()
for(var a=0,s=0;s<r.length-1;s++){var l=r[s]
a+=l.offsetWidth,a>=e-i&&(l.style.display="none")}}function t(){for(var e=0;e<r.length;e++)r[e].style.display="inline-block"}if(document.getElementsByClassName("trending-items").length&&document.getElementsByClassName("sub-set").length){var n=document.getElementsByClassName("trending-items")[0],r=document.getElementsByClassName("trending-item"),o=document.getElementsByClassName("sub-set")[0]
null!=n&&null!=r&&null!=o&&(e(),window.addEventListener("resize",e))}}),define("app/tabs",["app/date_utilities"],function(e){if(document.getElementById("home-tabs")){var t=document.getElementsByClassName("hometab")
if(t.length>0)for(var n=0;n<t.length;n++){var r=t[n]
console.log("adding event to "+r.innerHTML),r.onclick=function(){for(var t=document.getElementsByClassName("hometab"),n=this.getAttribute("data-attr-list"),r=0;r<t.length;r++)t[r].classList.remove("active")
this.classList.add("active")
for(var o=document.getElementsByClassName("listingResultsWrapper"),i=0;i<o.length;i++)o[i].style.display="none"
var a=document.getElementsByClassName("listingResultsWrapper "+n)
if(a[0].style.display="block","all"!=n){var s=a[0].getElementsByClassName("listingResults")
s[0].innerHTML=""
var l,c=Math.floor(Date.now()/1e3),u="/more/home"+n+"/latest/"+c
l=window.XMLHttpRequest?new XMLHttpRequest:new ActiveXObject("Microsoft.XMLHTTP"),l.onreadystatechange=function(){l.readyState==XMLHttpRequest.DONE&&(200==l.status?(s[0].innerHTML=""+l.responseText,e.updateRelativeDates()):400==l.status?console.log("There was an error 400 loading "+u):console.log("something else other than 200 was returned loading "+u))},l.open("GET",u,!0),l.send()}}}console.log("Showing Tabs"),document.getElementById("home-tabs").style.display="block"}}),define("app/review_ordering",[],function(){if(document.getElementById("reviews_order_by_dropdown")){var e=document.getElementById("reviews_order_by_dropdown"),t="order_by"
t=t.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]")
var n=new RegExp("[\\?&]"+t+"=([^&#]*)"),r=n.exec(location.search)
r&&(r=decodeURIComponent(r[1].replace(/\+/g," ")))
for(var o=0;o<e.options.length;o++)e.options[o].value==r&&(e.options[o].selected=!0)
e.onchange=function(){window.location=e[e.selectedIndex].value>""?window.location.pathname+"?order_by="+e[e.selectedIndex].value:window.location.pathname}}}),define("app/game-review-score-load",[],function(){function e(){function e(e,t,n){return Math.max(t,Math.min(n,e))}function n(e,t){var n=51,o=t*Math.PI/180,i=Math.sin(o)*n,a=Math.cos(o)*-n,s=t>180?1:0,l="M 0 0 v -%@ A %@ %@ 1 ".replace(/%@/gi,n)+s+" 1 "+i+" "+a+" z",c=r.querySelector(".score-loading-dial")
c.setAttribute("d",l),window.location.href.indexOf("pcgamer")>-1&&r.classList.remove("in-view")}var r=document.querySelector(".in-view")
if(null!==r.querySelector(".score-loading-dial")){var o=0
if(null!==r.querySelector(".review-score-generic")||null!==r.querySelector(".review-score-pcg-generic"))var i=360
else var i=272
if(window.location.href.indexOf("pcgamer")>-1){var o=t,a=e(o*i,0,i)
n(o,a)}else window.setTimeout(function(){var a=window.setInterval(function(){o+=.01,o>=t&&(r.classList.remove("in-view"),window.clearInterval(a))
var s=e(o*i,0,i)
n(o,s)},1)},1e3)}else if(null!==r.querySelector(".progress-bar")){var s=r.querySelector(".progress-bar")
s.classList.add("transition"),s.style.width=100*t+"%",r.classList.remove("in-view")}}if(null!==document.querySelector(".score")&&null!==document.querySelector(".verdict-boxout")){if(null!==document.querySelector(".out-of-score-text"))if(5==document.querySelector(".score").textContent)var t=.99
else var t=document.querySelector(".score").textContent/5
else if(100==document.querySelector(".score").textContent)var t=.999
else var t=document.querySelector(".score").textContent/10/10
for(var n=document.querySelectorAll(".review-score-container"),r=0;r<n.length;r++){var o=n[r],i=o.getBoundingClientRect()
if(window.innerHeight<i.top){var a=function(){var t=o.getBoundingClientRect()
window.innerHeight>t.top&&(o.classList.add("in-view"),e(),window.removeEventListener("scroll",a))}
window.addEventListener("scroll",a)}else o.classList.add("in-view"),e()}}}),define("app/game-review-image-height",[],function(){if(window.location.host.indexOf("gamesradar.com")>-1){var e=document.querySelector(".center-cropped"),t=null,n=function(){var n=t[0].clientHeight
n&&(e.style.height=n+"px")}
null!==e&&(t=e.getElementsByTagName("img"),t.length&&(t[0].addEventListener("load",function(){n()},!1),window.addEventListener("resize",function(){n()})))}}),define("app/limit-list-links",[],function(){var e=function(){if(window.matchMedia("(min-width: 900px)").matches){var e=document.getElementById("Item1"),t=document.getElementsByClassName("mainCarousel"),n=document.getElementById("carouselblock"),r=document.querySelectorAll(".list-text-links .listingResult"),o=document.querySelector(".list-text-links .list-title"),a=document.querySelector(".list-text-links"),s=document.querySelector(".list-text-links .list-heading-link")
if(null!=e&&null!=r&&null!=o){var l=o.offsetHeight,c=t.length-1
if("610"==t[c].offsetWidth)if(n)var u=n.offsetHeight-15
else var u=t[c].offsetHeight-15
else var u=e.offsetHeight
for(a.style.height=u+"px",s&&(s.style.visibility="visible",u-=s.offsetHeight+5),i=0;i<r.length;i++)l+=r[i].offsetHeight,r[i].style.display=l>u?"none":"block"}}}
e()}),define("app/read-more",[],function(){var e=document.querySelectorAll(".read-more-button")
if(e.length>0){console.debug("Found "+e.length+" read more buttons")
for(var t=0;t<e.length;t++){var n=e[t]
n.addEventListener("click",function(){var e=this.previousElementSibling.classList.toggle("hidden")
console.debug((e?"Added":"Removed")+" hidden class from read more text."),this.classList.toggle("closed"),this.querySelector("span").innerHTML=e?"More":"Less",this.querySelector("i").setAttribute("class","icon"+(e?" icon-arrow-down":" icon-arrow-up"))})}}}),define("app/enlargeimages",[],function(){var e=function(e){for(var r=document.getElementsByClassName("expandable"),o=0;o<r.length;o++)if(r[o].getAttribute("data-original-mos")){var i=r[o].parentNode
if("thumb-link"!=i.className&&"center-cropped"!=i.className){if(e&&(r[o].onclick=function(){n(this.getAttribute("data-original-mos"),!1)},r[o].style.cursor="pointer"),"FIGURE"!=i.nodeName){var a=document.createElement("figure"),s=r[o].cloneNode(!0)
a.appendChild(s),i.replaceChild(a,r[o]),i=a}i.classList.add("expandable-image")
var l=document.createElement("div")
l.className="expand",l.classList.add("icon"),l.classList.add("icon-expand-image"),l.onclick=function(){n(t(this).getAttribute("data-original-mos"),!1)},i.appendChild(l)}}},t=function(e){for(var t=e.parentNode.getElementsByTagName("img"),n=0;n<t.length;n++)if(t[n].getAttribute("data-original-mos"))return t[n]},n=function(e,t){t||window.open(e)}
e(!1)}),define("app/advancedsearch",["app/date_utilities"],function(e){function t(e){window.location.hostname.indexOf(".fte.")>-1&&("object"==typeof e||"array"==typeof e?console.debug(["Advanced Search",e]):console.debug("Advanced Search: "+e))}function n(e){var t=document.getElementById("advancedsearchsort"),n=document.getElementsByName("searchfilter"),r=document.getElementsByName("searchplatform")
if(e)var o="publishedDate",i="all"
else{o=t.options[t.selectedIndex].value
for(var a=0;a<n.length;a++)if(n[a].checked)var i=n[a].value
if(r)for(var a=0;a<r.length;a++)if(r[a].checked)var s=r[a].value}var l=new Object
return l.sortorder=o,l.articletype=i,s&&(l.articleplatform=s),l}function r(e){var r,a=n(e),l="/filter/search?searchTerm="+o("searchTerm")+"&sortBy="+a.sortorder+"&articleType="+a.articletype,c=o("searchTerm")+a.sortorder+a.articletype
a.articleplatform&&(c+=a.articleplatform,l=l+"&articlePlatform="+a.articleplatform),null!=o("fcsis")&&(l+="&fcsis="+o("fcsis")),s[c]?(t("Displaying from cache"),i(c,a)):(document.getElementsByClassName("listingResults")[0].style.display="none",document.getElementsByClassName("load-more").length>0&&(document.getElementsByClassName("load-more")[0].style.display="none"),document.getElementById("searchloading").style.display="block",t("Searching by AJAX"),t(l),r=window.XMLHttpRequest?new XMLHttpRequest:new ActiveXObject("Microsoft.XMLHTTP"),r.onreadystatechange=function(){r.readyState==XMLHttpRequest.DONE&&(200==r.status?(s[c]=r.responseText,i(c,a)):(t(r.status+": "+l),s[c]="No results found",i(c,a)))},r.open("GET",l,!0),r.send())}function o(e,t){t||(t=window.location.href),e=e.replace(/[\[\]]/g,"\\$&")
var n=new RegExp("[?&]"+e+"(=([^&#]*)|&|#|$)"),r=n.exec(t)
return r?r[2]?decodeURIComponent(r[2].replace(/\+/g," ")):"":null}function i(t,n){var r=s[t]
document.getElementsByClassName("listingResults")[0].innerHTML=r
var i=document.getElementsByClassName("listingResults")[0].parentNode
i.setAttribute("data-list","filter/search/"+o("searchTerm")+"/"+n.articletype+"/"+n.sortorder),e.updateRelativeDates(),document.getElementById("searchloading").style.display="none",document.getElementsByClassName("listingResults")[0].style.display="block","No results found"!=r&&document.getElementsByClassName("load-more").length>0&&(document.getElementsByClassName("load-more")[0].style.display="block")}function a(){if(window.matchMedia("(max-width: 575px)").matches&&document.querySelector(".header")){var e=document.querySelector(".header")
e.addEventListener("click",function(){var t=e.nextElementSibling.classList.toggle("invisible")
e.querySelector("span").innerHTML=t?"Show":"Hide",e.querySelector("i").setAttribute("class","icon"+(t?" icon-arrow-down":" icon-arrow-up"))})}}var s=[]
t("Initializing Advanced Search Events")
var l=document.getElementById("searchfilter")
if(l){t("Advanced Search Enabled")
var c=document.getElementById("advancedsearchsort")
c&&(c.onchange=function(){r(!1)})
for(var u=document.getElementsByName("searchfilter"),d=0;d<u.length;d++)u[d].onchange=function(){r(!1)}
for(var p=document.getElementsByName("searchplatform"),d=0;d<p.length;d++)p[d].onchange=function(){r(!1)}
l.style.display="block"}a(),window.addEventListener("resize",function(){a()}),l&&(document.querySelector(".clear-filters")&&document.querySelector(".clear-filters").addEventListener("click",function(){var e=!1
document.getElementById("searchfilterform").reset(),r(e)}),document.getElementById("searchfilterform").reset())}),!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e()
else if("function"==typeof define&&define.amd)define("react",[],e)
else{var t
t="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:this,t.React=e()}}(function(){return function e(t,n,r){function o(a,s){if(!n[a]){if(!t[a]){var l="function"==typeof require&&require
if(!s&&l)return l(a,!0)
if(i)return i(a,!0)
var c=new Error("Cannot find module '"+a+"'")
throw c.code="MODULE_NOT_FOUND",c}var u=n[a]={exports:{}}
t[a][0].call(u.exports,function(e){var n=t[a][1][e]
return o(n?n:e)},u,u.exports,e,t,n,r)}return n[a].exports}for(var i="function"==typeof require&&require,a=0;a<r.length;a++)o(r[a])
return o}({1:[function(e,t){"use strict"
var n=e(35),r=e(45),o=e(61),i=e(23),a=e(104),s={}
i(s,o),i(s,{findDOMNode:a("findDOMNode","ReactDOM","react-dom",n,n.findDOMNode),render:a("render","ReactDOM","react-dom",n,n.render),unmountComponentAtNode:a("unmountComponentAtNode","ReactDOM","react-dom",n,n.unmountComponentAtNode),renderToString:a("renderToString","ReactDOMServer","react-dom/server",r,r.renderToString),renderToStaticMarkup:a("renderToStaticMarkup","ReactDOMServer","react-dom/server",r,r.renderToStaticMarkup)}),s.__SECRET_DOM_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=n,s.__SECRET_DOM_SERVER_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=r,t.exports=s},{104:104,23:23,35:35,45:45,61:61}],2:[function(e,t){"use strict"
var n=e(63),r=e(106),o=e(136),i={componentDidMount:function(){this.props.autoFocus&&o(r(this))}},a={Mixin:i,focusDOMComponent:function(){o(n.getNode(this._rootNodeID))}}
t.exports=a},{106:106,136:136,63:63}],3:[function(e,t){"use strict"
function n(){var e=window.opera
return"object"==typeof e&&"function"==typeof e.version&&parseInt(e.version(),10)<=12}function r(e){return(e.ctrlKey||e.altKey||e.metaKey)&&!(e.ctrlKey&&e.altKey)}function o(e){switch(e){case T.topCompositionStart:return A.compositionStart
case T.topCompositionEnd:return A.compositionEnd
case T.topCompositionUpdate:return A.compositionUpdate}}function i(e,t){return e===T.topKeyDown&&t.keyCode===w}function a(e,t){switch(e){case T.topKeyUp:return-1!==b.indexOf(t.keyCode)
case T.topKeyDown:return t.keyCode!==w
case T.topKeyPress:case T.topMouseDown:case T.topBlur:return!0
default:return!1}}function s(e){var t=e.detail
return"object"==typeof t&&"data"in t?t.data:null}function l(e,t,n,r,l){var c,u
if(_?c=o(e):M?a(e,r)&&(c=A.compositionEnd):i(e,r)&&(c=A.compositionStart),!c)return null
x&&(M||c!==A.compositionStart?c===A.compositionEnd&&M&&(u=M.getData()):M=m.getPooled(t))
var d=g.getPooled(c,n,r,l)
if(u)d.data=u
else{var p=s(r)
null!==p&&(d.data=p)}return f.accumulateTwoPhaseDispatches(d),d}function c(e,t){switch(e){case T.topCompositionEnd:return s(t)
case T.topKeyPress:var n=t.which
return n!==S?null:(N=!0,k)
case T.topTextInput:var r=t.data
return r===k&&N?null:r
default:return null}}function u(e,t){if(M){if(e===T.topCompositionEnd||a(e,t)){var n=M.getData()
return m.release(M),M=null,n}return null}switch(e){case T.topPaste:return null
case T.topKeyPress:return t.which&&!r(t)?String.fromCharCode(t.which):null
case T.topCompositionEnd:return x?null:t.data
default:return null}}function d(e,t,n,r,o){var i
if(i=C?c(e,r):u(e,r),!i)return null
var a=v.getPooled(A.beforeInput,n,r,o)
return a.data=i,f.accumulateTwoPhaseDispatches(a),a}var p=e(15),f=e(19),h=e(128),m=e(20),g=e(88),v=e(92),y=e(146),b=[9,13,27,32],w=229,_=h.canUseDOM&&"CompositionEvent"in window,E=null
h.canUseDOM&&"documentMode"in document&&(E=document.documentMode)
var C=h.canUseDOM&&"TextEvent"in window&&!E&&!n(),x=h.canUseDOM&&(!_||E&&E>8&&11>=E),S=32,k=String.fromCharCode(S),T=p.topLevelTypes,A={beforeInput:{phasedRegistrationNames:{bubbled:y({onBeforeInput:null}),captured:y({onBeforeInputCapture:null})},dependencies:[T.topCompositionEnd,T.topKeyPress,T.topTextInput,T.topPaste]},compositionEnd:{phasedRegistrationNames:{bubbled:y({onCompositionEnd:null}),captured:y({onCompositionEndCapture:null})},dependencies:[T.topBlur,T.topCompositionEnd,T.topKeyDown,T.topKeyPress,T.topKeyUp,T.topMouseDown]},compositionStart:{phasedRegistrationNames:{bubbled:y({onCompositionStart:null}),captured:y({onCompositionStartCapture:null})},dependencies:[T.topBlur,T.topCompositionStart,T.topKeyDown,T.topKeyPress,T.topKeyUp,T.topMouseDown]},compositionUpdate:{phasedRegistrationNames:{bubbled:y({onCompositionUpdate:null}),captured:y({onCompositionUpdateCapture:null})},dependencies:[T.topBlur,T.topCompositionUpdate,T.topKeyDown,T.topKeyPress,T.topKeyUp,T.topMouseDown]}},N=!1,M=null,P={eventTypes:A,extractEvents:function(e,t,n,r,o){return[l(e,t,n,r,o),d(e,t,n,r,o)]}}
t.exports=P},{128:128,146:146,15:15,19:19,20:20,88:88,92:92}],4:[function(e,t){"use strict"
function n(e,t){return e+t.charAt(0).toUpperCase()+t.substring(1)}var r={animationIterationCount:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,stopOpacity:!0,strokeDashoffset:!0,strokeOpacity:!0,strokeWidth:!0},o=["Webkit","ms","Moz","O"]
Object.keys(r).forEach(function(e){o.forEach(function(t){r[n(t,e)]=r[e]})})
var i={background:{backgroundAttachment:!0,backgroundColor:!0,backgroundImage:!0,backgroundPositionX:!0,backgroundPositionY:!0,backgroundRepeat:!0},backgroundPosition:{backgroundPositionX:!0,backgroundPositionY:!0},border:{borderWidth:!0,borderStyle:!0,borderColor:!0},borderBottom:{borderBottomWidth:!0,borderBottomStyle:!0,borderBottomColor:!0},borderLeft:{borderLeftWidth:!0,borderLeftStyle:!0,borderLeftColor:!0},borderRight:{borderRightWidth:!0,borderRightStyle:!0,borderRightColor:!0},borderTop:{borderTopWidth:!0,borderTopStyle:!0,borderTopColor:!0},font:{fontStyle:!0,fontVariant:!0,fontWeight:!0,fontSize:!0,lineHeight:!0,fontFamily:!0},outline:{outlineWidth:!0,outlineStyle:!0,outlineColor:!0}},a={isUnitlessNumber:r,shorthandPropertyExpansions:i}
t.exports=a},{}],5:[function(e,t){"use strict"
var n=e(4),r=e(128),o=e(69),i=(e(130),e(103)),a=e(141),s=e(148),l=(e(151),s(function(e){return a(e)})),c=!1,u="cssFloat"
if(r.canUseDOM){var d=document.createElement("div").style
try{d.font=""}catch(p){c=!0}void 0===document.documentElement.style.cssFloat&&(u="styleFloat")}var f={createMarkupForStyles:function(e){var t=""
for(var n in e)if(e.hasOwnProperty(n)){var r=e[n]
null!=r&&(t+=l(n)+":",t+=i(n,r)+";")}return t||null},setValueForStyles:function(e,t){var r=e.style
for(var o in t)if(t.hasOwnProperty(o)){var a=i(o,t[o])
if("float"===o&&(o=u),a)r[o]=a
else{var s=c&&n.shorthandPropertyExpansions[o]
if(s)for(var l in s)r[l]=""
else r[o]=""}}}}
o.measureMethods(f,"CSSPropertyOperations",{setValueForStyles:"setValueForStyles"}),t.exports=f},{103:103,128:128,130:130,141:141,148:148,151:151,4:4,69:69}],6:[function(e,t){"use strict"
function n(){this._callbacks=null,this._contexts=null}var r=e(24),o=e(23),i=e(142)
o(n.prototype,{enqueue:function(e,t){this._callbacks=this._callbacks||[],this._contexts=this._contexts||[],this._callbacks.push(e),this._contexts.push(t)},notifyAll:function(){var e=this._callbacks,t=this._contexts
if(e){e.length!==t.length?i(!1):void 0,this._callbacks=null,this._contexts=null
for(var n=0;n<e.length;n++)e[n].call(t[n])
e.length=0,t.length=0}},reset:function(){this._callbacks=null,this._contexts=null},destructor:function(){this.reset()}}),r.addPoolingTo(n),t.exports=n},{142:142,23:23,24:24}],7:[function(e,t){"use strict"
function n(e){var t=e.nodeName&&e.nodeName.toLowerCase()
return"select"===t||"input"===t&&"file"===e.type}function r(e){var t=E.getPooled(A.change,M,e,C(e))
b.accumulateTwoPhaseDispatches(t),_.batchedUpdates(o,t)}function o(e){y.enqueueEvents(e),y.processEventQueue(!1)}function i(e,t){N=e,M=t,N.attachEvent("onchange",r)}function a(){N&&(N.detachEvent("onchange",r),N=null,M=null)}function s(e,t,n){return e===T.topChange?n:void 0}function l(e,t,n){e===T.topFocus?(a(),i(t,n)):e===T.topBlur&&a()}function c(e,t){N=e,M=t,P=e.value,D=Object.getOwnPropertyDescriptor(e.constructor.prototype,"value"),Object.defineProperty(N,"value",L),N.attachEvent("onpropertychange",d)}function u(){N&&(delete N.value,N.detachEvent("onpropertychange",d),N=null,M=null,P=null,D=null)}function d(e){if("value"===e.propertyName){var t=e.srcElement.value
t!==P&&(P=t,r(e))}}function p(e,t,n){return e===T.topInput?n:void 0}function f(e,t,n){e===T.topFocus?(u(),c(t,n)):e===T.topBlur&&u()}function h(e){return e!==T.topSelectionChange&&e!==T.topKeyUp&&e!==T.topKeyDown||!N||N.value===P?void 0:(P=N.value,M)}function m(e){return e.nodeName&&"input"===e.nodeName.toLowerCase()&&("checkbox"===e.type||"radio"===e.type)}function g(e,t,n){return e===T.topClick?n:void 0}var v=e(15),y=e(16),b=e(19),w=e(128),_=e(81),E=e(90),C=e(112),x=e(117),S=e(118),k=e(146),T=v.topLevelTypes,A={change:{phasedRegistrationNames:{bubbled:k({onChange:null}),captured:k({onChangeCapture:null})},dependencies:[T.topBlur,T.topChange,T.topClick,T.topFocus,T.topInput,T.topKeyDown,T.topKeyUp,T.topSelectionChange]}},N=null,M=null,P=null,D=null,I=!1
w.canUseDOM&&(I=x("change")&&(!("documentMode"in document)||document.documentMode>8))
var R=!1
w.canUseDOM&&(R=x("input")&&(!("documentMode"in document)||document.documentMode>9))
var L={get:function(){return D.get.call(this)},set:function(e){P=""+e,D.set.call(this,e)}},O={eventTypes:A,extractEvents:function(e,t,r,o,i){var a,c
if(n(t)?I?a=s:c=l:S(t)?R?a=p:(a=h,c=f):m(t)&&(a=g),a){var u=a(e,t,r)
if(u){var d=E.getPooled(A.change,u,o,i)
return d.type="change",b.accumulateTwoPhaseDispatches(d),d}}c&&c(e,t,r)}}
t.exports=O},{112:112,117:117,118:118,128:128,146:146,15:15,16:16,19:19,81:81,90:90}],8:[function(e,t){"use strict"
var n=0,r={createReactRootIndex:function(){return n++}}
t.exports=r},{}],9:[function(e,t){"use strict"
function n(e,t,n){var r=n>=e.childNodes.length?null:e.childNodes.item(n)
e.insertBefore(t,r)}var r=e(12),o=e(65),i=e(69),a=e(122),s=e(123),l=e(142),c={dangerouslyReplaceNodeWithMarkup:r.dangerouslyReplaceNodeWithMarkup,updateTextContent:s,processUpdates:function(e,t){for(var i,c=null,u=null,d=0;d<e.length;d++)if(i=e[d],i.type===o.MOVE_EXISTING||i.type===o.REMOVE_NODE){var p=i.fromIndex,f=i.parentNode.childNodes[p],h=i.parentID
f?void 0:l(!1),c=c||{},c[h]=c[h]||[],c[h][p]=f,u=u||[],u.push(f)}var m
if(m=t.length&&"string"==typeof t[0]?r.dangerouslyRenderMarkup(t):t,u)for(var g=0;g<u.length;g++)u[g].parentNode.removeChild(u[g])
for(var v=0;v<e.length;v++)switch(i=e[v],i.type){case o.INSERT_MARKUP:n(i.parentNode,m[i.markupIndex],i.toIndex)
break
case o.MOVE_EXISTING:n(i.parentNode,c[i.parentID][i.fromIndex],i.toIndex)
break
case o.SET_MARKUP:a(i.parentNode,i.content)
break
case o.TEXT_CONTENT:s(i.parentNode,i.content)
break
case o.REMOVE_NODE:}}}
i.measureMethods(c,"DOMChildrenOperations",{updateTextContent:"updateTextContent"}),t.exports=c},{12:12,122:122,123:123,142:142,65:65,69:69}],10:[function(e,t){"use strict"
function n(e,t){return(e&t)===t}var r=e(142),o={MUST_USE_ATTRIBUTE:1,MUST_USE_PROPERTY:2,HAS_SIDE_EFFECTS:4,HAS_BOOLEAN_VALUE:8,HAS_NUMERIC_VALUE:16,HAS_POSITIVE_NUMERIC_VALUE:48,HAS_OVERLOADED_BOOLEAN_VALUE:64,injectDOMPropertyConfig:function(e){var t=o,i=e.Properties||{},s=e.DOMAttributeNamespaces||{},l=e.DOMAttributeNames||{},c=e.DOMPropertyNames||{},u=e.DOMMutationMethods||{}
e.isCustomAttribute&&a._isCustomAttributeFunctions.push(e.isCustomAttribute)
for(var d in i){a.properties.hasOwnProperty(d)?r(!1):void 0
var p=d.toLowerCase(),f=i[d],h={attributeName:p,attributeNamespace:null,propertyName:d,mutationMethod:null,mustUseAttribute:n(f,t.MUST_USE_ATTRIBUTE),mustUseProperty:n(f,t.MUST_USE_PROPERTY),hasSideEffects:n(f,t.HAS_SIDE_EFFECTS),hasBooleanValue:n(f,t.HAS_BOOLEAN_VALUE),hasNumericValue:n(f,t.HAS_NUMERIC_VALUE),hasPositiveNumericValue:n(f,t.HAS_POSITIVE_NUMERIC_VALUE),hasOverloadedBooleanValue:n(f,t.HAS_OVERLOADED_BOOLEAN_VALUE)}
if(h.mustUseAttribute&&h.mustUseProperty?r(!1):void 0,!h.mustUseProperty&&h.hasSideEffects?r(!1):void 0,h.hasBooleanValue+h.hasNumericValue+h.hasOverloadedBooleanValue<=1?void 0:r(!1),l.hasOwnProperty(d)){var m=l[d]
h.attributeName=m}s.hasOwnProperty(d)&&(h.attributeNamespace=s[d]),c.hasOwnProperty(d)&&(h.propertyName=c[d]),u.hasOwnProperty(d)&&(h.mutationMethod=u[d]),a.properties[d]=h}}},i={},a={ID_ATTRIBUTE_NAME:"data-reactid",properties:{},getPossibleStandardName:null,_isCustomAttributeFunctions:[],isCustomAttribute:function(e){for(var t=0;t<a._isCustomAttributeFunctions.length;t++){var n=a._isCustomAttributeFunctions[t]
if(n(e))return!0}return!1},getDefaultValueForProperty:function(e,t){var n,r=i[e]
return r||(i[e]=r={}),t in r||(n=document.createElement(e),r[t]=n[t]),r[t]},injection:o}
t.exports=a},{142:142}],11:[function(e,t){"use strict"
function n(e){return c.hasOwnProperty(e)?!0:l.hasOwnProperty(e)?!1:s.test(e)?(c[e]=!0,!0):(l[e]=!0,!1)}function r(e,t){return null==t||e.hasBooleanValue&&!t||e.hasNumericValue&&isNaN(t)||e.hasPositiveNumericValue&&1>t||e.hasOverloadedBooleanValue&&t===!1}var o=e(10),i=e(69),a=e(120),s=(e(151),/^[a-zA-Z_][\w\.\-]*$/),l={},c={},u={createMarkupForID:function(e){return o.ID_ATTRIBUTE_NAME+"="+a(e)},setAttributeForID:function(e,t){e.setAttribute(o.ID_ATTRIBUTE_NAME,t)},createMarkupForProperty:function(e,t){var n=o.properties.hasOwnProperty(e)?o.properties[e]:null
if(n){if(r(n,t))return""
var i=n.attributeName
return n.hasBooleanValue||n.hasOverloadedBooleanValue&&t===!0?i+'=""':i+"="+a(t)}return o.isCustomAttribute(e)?null==t?"":e+"="+a(t):null},createMarkupForCustomAttribute:function(e,t){return n(e)&&null!=t?e+"="+a(t):""},setValueForProperty:function(e,t,n){var i=o.properties.hasOwnProperty(t)?o.properties[t]:null
if(i){var a=i.mutationMethod
if(a)a(e,n)
else if(r(i,n))this.deleteValueForProperty(e,t)
else if(i.mustUseAttribute){var s=i.attributeName,l=i.attributeNamespace
l?e.setAttributeNS(l,s,""+n):i.hasBooleanValue||i.hasOverloadedBooleanValue&&n===!0?e.setAttribute(s,""):e.setAttribute(s,""+n)}else{var c=i.propertyName
i.hasSideEffects&&""+e[c]==""+n||(e[c]=n)}}else o.isCustomAttribute(t)&&u.setValueForAttribute(e,t,n)},setValueForAttribute:function(e,t,r){n(t)&&(null==r?e.removeAttribute(t):e.setAttribute(t,""+r))},deleteValueForProperty:function(e,t){var n=o.properties.hasOwnProperty(t)?o.properties[t]:null
if(n){var r=n.mutationMethod
if(r)r(e,void 0)
else if(n.mustUseAttribute)e.removeAttribute(n.attributeName)
else{var i=n.propertyName,a=o.getDefaultValueForProperty(e.nodeName,i)
n.hasSideEffects&&""+e[i]===a||(e[i]=a)}}else o.isCustomAttribute(t)&&e.removeAttribute(t)}}
i.measureMethods(u,"DOMPropertyOperations",{setValueForProperty:"setValueForProperty",setValueForAttribute:"setValueForAttribute",deleteValueForProperty:"deleteValueForProperty"}),t.exports=u},{10:10,120:120,151:151,69:69}],12:[function(e,t){"use strict"
function n(e){return e.substring(1,e.indexOf(" "))}var r=e(128),o=e(133),i=e(134),a=e(138),s=e(142),l=/^(<[^ \/>]+)/,c="data-danger-index",u={dangerouslyRenderMarkup:function(e){r.canUseDOM?void 0:s(!1)
for(var t,u={},d=0;d<e.length;d++)e[d]?void 0:s(!1),t=n(e[d]),t=a(t)?t:"*",u[t]=u[t]||[],u[t][d]=e[d]
var p=[],f=0
for(t in u)if(u.hasOwnProperty(t)){var h,m=u[t]
for(h in m)if(m.hasOwnProperty(h)){var g=m[h]
m[h]=g.replace(l,"$1 "+c+'="'+h+'" ')}for(var v=o(m.join(""),i),y=0;y<v.length;++y){var b=v[y]
b.hasAttribute&&b.hasAttribute(c)&&(h=+b.getAttribute(c),b.removeAttribute(c),p.hasOwnProperty(h)?s(!1):void 0,p[h]=b,f+=1)}}return f!==p.length?s(!1):void 0,p.length!==e.length?s(!1):void 0,p},dangerouslyReplaceNodeWithMarkup:function(e,t){r.canUseDOM?void 0:s(!1),t?void 0:s(!1),"html"===e.tagName.toLowerCase()?s(!1):void 0
var n
n="string"==typeof t?o(t,i)[0]:t,e.parentNode.replaceChild(n,e)}}
t.exports=u},{128:128,133:133,134:134,138:138,142:142}],13:[function(e,t){"use strict"
var n=e(146),r=[n({ResponderEventPlugin:null}),n({SimpleEventPlugin:null}),n({TapEventPlugin:null}),n({EnterLeaveEventPlugin:null}),n({ChangeEventPlugin:null}),n({SelectEventPlugin:null}),n({BeforeInputEventPlugin:null})]
t.exports=r},{146:146}],14:[function(e,t){"use strict"
var n=e(15),r=e(19),o=e(94),i=e(63),a=e(146),s=n.topLevelTypes,l=i.getFirstReactDOM,c={mouseEnter:{registrationName:a({onMouseEnter:null}),dependencies:[s.topMouseOut,s.topMouseOver]},mouseLeave:{registrationName:a({onMouseLeave:null}),dependencies:[s.topMouseOut,s.topMouseOver]}},u=[null,null],d={eventTypes:c,extractEvents:function(e,t,n,a,d){if(e===s.topMouseOver&&(a.relatedTarget||a.fromElement))return null
if(e!==s.topMouseOut&&e!==s.topMouseOver)return null
var p
if(t.window===t)p=t
else{var f=t.ownerDocument
p=f?f.defaultView||f.parentWindow:window}var h,m,g="",v=""
if(e===s.topMouseOut?(h=t,g=n,m=l(a.relatedTarget||a.toElement),m?v=i.getID(m):m=p,m=m||p):(h=p,m=t,v=n),h===m)return null
var y=o.getPooled(c.mouseLeave,g,a,d)
y.type="mouseleave",y.target=h,y.relatedTarget=m
var b=o.getPooled(c.mouseEnter,v,a,d)
return b.type="mouseenter",b.target=m,b.relatedTarget=h,r.accumulateEnterLeaveDispatches(y,b,g,v),u[0]=y,u[1]=b,u}}
t.exports=d},{146:146,15:15,19:19,63:63,94:94}],15:[function(e,t){"use strict"
var n=e(145),r=n({bubbled:null,captured:null}),o=n({topAbort:null,topBlur:null,topCanPlay:null,topCanPlayThrough:null,topChange:null,topClick:null,topCompositionEnd:null,topCompositionStart:null,topCompositionUpdate:null,topContextMenu:null,topCopy:null,topCut:null,topDoubleClick:null,topDrag:null,topDragEnd:null,topDragEnter:null,topDragExit:null,topDragLeave:null,topDragOver:null,topDragStart:null,topDrop:null,topDurationChange:null,topEmptied:null,topEncrypted:null,topEnded:null,topError:null,topFocus:null,topInput:null,topKeyDown:null,topKeyPress:null,topKeyUp:null,topLoad:null,topLoadedData:null,topLoadedMetadata:null,topLoadStart:null,topMouseDown:null,topMouseMove:null,topMouseOut:null,topMouseOver:null,topMouseUp:null,topPaste:null,topPause:null,topPlay:null,topPlaying:null,topProgress:null,topRateChange:null,topReset:null,topScroll:null,topSeeked:null,topSeeking:null,topSelectionChange:null,topStalled:null,topSubmit:null,topSuspend:null,topTextInput:null,topTimeUpdate:null,topTouchCancel:null,topTouchEnd:null,topTouchMove:null,topTouchStart:null,topVolumeChange:null,topWaiting:null,topWheel:null}),i={topLevelTypes:o,PropagationPhases:r}
t.exports=i},{145:145}],16:[function(e,t){"use strict"
var n=e(17),r=e(18),o=e(54),i=e(100),a=e(108),s=e(142),l=(e(151),{}),c=null,u=function(e,t){e&&(r.executeDispatchesInOrder(e,t),e.isPersistent()||e.constructor.release(e))},d=function(e){return u(e,!0)},p=function(e){return u(e,!1)},f=null,h={injection:{injectMount:r.injection.injectMount,injectInstanceHandle:function(e){f=e},getInstanceHandle:function(){return f},injectEventPluginOrder:n.injectEventPluginOrder,injectEventPluginsByName:n.injectEventPluginsByName},eventNameDispatchConfigs:n.eventNameDispatchConfigs,registrationNameModules:n.registrationNameModules,putListener:function(e,t,r){"function"!=typeof r?s(!1):void 0
var o=l[t]||(l[t]={})
o[e]=r
var i=n.registrationNameModules[t]
i&&i.didPutListener&&i.didPutListener(e,t,r)},getListener:function(e,t){var n=l[t]
return n&&n[e]},deleteListener:function(e,t){var r=n.registrationNameModules[t]
r&&r.willDeleteListener&&r.willDeleteListener(e,t)
var o=l[t]
o&&delete o[e]},deleteAllListeners:function(e){for(var t in l)if(l[t][e]){var r=n.registrationNameModules[t]
r&&r.willDeleteListener&&r.willDeleteListener(e,t),delete l[t][e]}},extractEvents:function(e,t,r,o,a){for(var s,l=n.plugins,c=0;c<l.length;c++){var u=l[c]
if(u){var d=u.extractEvents(e,t,r,o,a)
d&&(s=i(s,d))}}return s},enqueueEvents:function(e){e&&(c=i(c,e))},processEventQueue:function(e){var t=c
c=null,e?a(t,d):a(t,p),c?s(!1):void 0,o.rethrowCaughtError()},__purge:function(){l={}},__getListenerBank:function(){return l}}
t.exports=h},{100:100,108:108,142:142,151:151,17:17,18:18,54:54}],17:[function(e,t){"use strict"
function n(){if(a)for(var e in s){var t=s[e],n=a.indexOf(e)
if(n>-1?void 0:i(!1),!l.plugins[n]){t.extractEvents?void 0:i(!1),l.plugins[n]=t
var o=t.eventTypes
for(var c in o)r(o[c],t,c)?void 0:i(!1)}}}function r(e,t,n){l.eventNameDispatchConfigs.hasOwnProperty(n)?i(!1):void 0,l.eventNameDispatchConfigs[n]=e
var r=e.phasedRegistrationNames
if(r){for(var a in r)if(r.hasOwnProperty(a)){var s=r[a]
o(s,t,n)}return!0}return e.registrationName?(o(e.registrationName,t,n),!0):!1}function o(e,t,n){l.registrationNameModules[e]?i(!1):void 0,l.registrationNameModules[e]=t,l.registrationNameDependencies[e]=t.eventTypes[n].dependencies}var i=e(142),a=null,s={},l={plugins:[],eventNameDispatchConfigs:{},registrationNameModules:{},registrationNameDependencies:{},injectEventPluginOrder:function(e){a?i(!1):void 0,a=Array.prototype.slice.call(e),n()},injectEventPluginsByName:function(e){var t=!1
for(var r in e)if(e.hasOwnProperty(r)){var o=e[r]
s.hasOwnProperty(r)&&s[r]===o||(s[r]?i(!1):void 0,s[r]=o,t=!0)}t&&n()},getPluginModuleForEvent:function(e){var t=e.dispatchConfig
if(t.registrationName)return l.registrationNameModules[t.registrationName]||null
for(var n in t.phasedRegistrationNames)if(t.phasedRegistrationNames.hasOwnProperty(n)){var r=l.registrationNameModules[t.phasedRegistrationNames[n]]
if(r)return r}return null},_resetEventPlugins:function(){a=null
for(var e in s)s.hasOwnProperty(e)&&delete s[e]
l.plugins.length=0
var t=l.eventNameDispatchConfigs
for(var n in t)t.hasOwnProperty(n)&&delete t[n]
var r=l.registrationNameModules
for(var o in r)r.hasOwnProperty(o)&&delete r[o]}}
t.exports=l},{142:142}],18:[function(e,t){"use strict"
function n(e){return e===m.topMouseUp||e===m.topTouchEnd||e===m.topTouchCancel}function r(e){return e===m.topMouseMove||e===m.topTouchMove}function o(e){return e===m.topMouseDown||e===m.topTouchStart}function i(e,t,n,r){var o=e.type||"unknown-event"
e.currentTarget=h.Mount.getNode(r),t?p.invokeGuardedCallbackWithCatch(o,n,e,r):p.invokeGuardedCallback(o,n,e,r),e.currentTarget=null}function a(e,t){var n=e._dispatchListeners,r=e._dispatchIDs
if(Array.isArray(n))for(var o=0;o<n.length&&!e.isPropagationStopped();o++)i(e,t,n[o],r[o])
else n&&i(e,t,n,r)
e._dispatchListeners=null,e._dispatchIDs=null}function s(e){var t=e._dispatchListeners,n=e._dispatchIDs
if(Array.isArray(t)){for(var r=0;r<t.length&&!e.isPropagationStopped();r++)if(t[r](e,n[r]))return n[r]}else if(t&&t(e,n))return n
return null}function l(e){var t=s(e)
return e._dispatchIDs=null,e._dispatchListeners=null,t}function c(e){var t=e._dispatchListeners,n=e._dispatchIDs
Array.isArray(t)?f(!1):void 0
var r=t?t(e,n):null
return e._dispatchListeners=null,e._dispatchIDs=null,r}function u(e){return!!e._dispatchListeners}var d=e(15),p=e(54),f=e(142),h=(e(151),{Mount:null,injectMount:function(e){h.Mount=e}}),m=d.topLevelTypes,g={isEndish:n,isMoveish:r,isStartish:o,executeDirectDispatch:c,executeDispatchesInOrder:a,executeDispatchesInOrderStopAtTrue:l,hasDispatches:u,getNode:function(e){return h.Mount.getNode(e)},getID:function(e){return h.Mount.getID(e)},injection:h}
t.exports=g},{142:142,15:15,151:151,54:54}],19:[function(e,t){"use strict"
function n(e,t,n){var r=t.dispatchConfig.phasedRegistrationNames[n]
return v(e,r)}function r(e,t,r){var o=t?g.bubbled:g.captured,i=n(e,r,o)
i&&(r._dispatchListeners=h(r._dispatchListeners,i),r._dispatchIDs=h(r._dispatchIDs,e))}function o(e){e&&e.dispatchConfig.phasedRegistrationNames&&f.injection.getInstanceHandle().traverseTwoPhase(e.dispatchMarker,r,e)}function i(e){e&&e.dispatchConfig.phasedRegistrationNames&&f.injection.getInstanceHandle().traverseTwoPhaseSkipTarget(e.dispatchMarker,r,e)}function a(e,t,n){if(n&&n.dispatchConfig.registrationName){var r=n.dispatchConfig.registrationName,o=v(e,r)
o&&(n._dispatchListeners=h(n._dispatchListeners,o),n._dispatchIDs=h(n._dispatchIDs,e))}}function s(e){e&&e.dispatchConfig.registrationName&&a(e.dispatchMarker,null,e)}function l(e){m(e,o)}function c(e){m(e,i)}function u(e,t,n,r){f.injection.getInstanceHandle().traverseEnterLeave(n,r,a,e,t)}function d(e){m(e,s)}var p=e(15),f=e(16),h=(e(151),e(100)),m=e(108),g=p.PropagationPhases,v=f.getListener,y={accumulateTwoPhaseDispatches:l,accumulateTwoPhaseDispatchesSkipTarget:c,accumulateDirectDispatches:d,accumulateEnterLeaveDispatches:u}
t.exports=y},{100:100,108:108,15:15,151:151,16:16}],20:[function(e,t){"use strict"
function n(e){this._root=e,this._startText=this.getText(),this._fallbackText=null}var r=e(24),o=e(23),i=e(115)
o(n.prototype,{destructor:function(){this._root=null,this._startText=null,this._fallbackText=null},getText:function(){return"value"in this._root?this._root.value:this._root[i()]},getData:function(){if(this._fallbackText)return this._fallbackText
var e,t,n=this._startText,r=n.length,o=this.getText(),i=o.length
for(e=0;r>e&&n[e]===o[e];e++);var a=r-e
for(t=1;a>=t&&n[r-t]===o[i-t];t++);var s=t>1?1-t:void 0
return this._fallbackText=o.slice(e,s),this._fallbackText}}),r.addPoolingTo(n),t.exports=n},{115:115,23:23,24:24}],21:[function(e,t){"use strict"
var n,r=e(10),o=e(128),i=r.injection.MUST_USE_ATTRIBUTE,a=r.injection.MUST_USE_PROPERTY,s=r.injection.HAS_BOOLEAN_VALUE,l=r.injection.HAS_SIDE_EFFECTS,c=r.injection.HAS_NUMERIC_VALUE,u=r.injection.HAS_POSITIVE_NUMERIC_VALUE,d=r.injection.HAS_OVERLOADED_BOOLEAN_VALUE
if(o.canUseDOM){var p=document.implementation
n=p&&p.hasFeature&&p.hasFeature("http://www.w3.org/TR/SVG11/feature#BasicStructure","1.1")}var f={isCustomAttribute:RegExp.prototype.test.bind(/^(data|aria)-[a-z_][a-z\d_.\-]*$/),Properties:{accept:null,acceptCharset:null,accessKey:null,action:null,allowFullScreen:i|s,allowTransparency:i,alt:null,async:s,autoComplete:null,autoPlay:s,capture:i|s,cellPadding:null,cellSpacing:null,charSet:i,challenge:i,checked:a|s,classID:i,className:n?i:a,cols:i|u,colSpan:null,content:null,contentEditable:null,contextMenu:i,controls:a|s,coords:null,crossOrigin:null,data:null,dateTime:i,"default":s,defer:s,dir:null,disabled:i|s,download:d,draggable:null,encType:null,form:i,formAction:i,formEncType:i,formMethod:i,formNoValidate:s,formTarget:i,frameBorder:i,headers:null,height:i,hidden:i|s,high:null,href:null,hrefLang:null,htmlFor:null,httpEquiv:null,icon:null,id:a,inputMode:i,integrity:null,is:i,keyParams:i,keyType:i,kind:null,label:null,lang:null,list:i,loop:a|s,low:null,manifest:i,marginHeight:null,marginWidth:null,max:null,maxLength:i,media:i,mediaGroup:null,method:null,min:null,minLength:i,multiple:a|s,muted:a|s,name:null,nonce:i,noValidate:s,open:s,optimum:null,pattern:null,placeholder:null,poster:null,preload:null,radioGroup:null,readOnly:a|s,rel:null,required:s,reversed:s,role:i,rows:i|u,rowSpan:null,sandbox:null,scope:null,scoped:s,scrolling:null,seamless:i|s,selected:a|s,shape:null,size:i|u,sizes:i,span:u,spellCheck:null,src:null,srcDoc:a,srcLang:null,srcSet:i,start:c,step:null,style:null,summary:null,tabIndex:null,target:null,title:null,type:null,useMap:null,value:a|l,width:i,wmode:i,wrap:null,about:i,datatype:i,inlist:i,prefix:i,property:i,resource:i,"typeof":i,vocab:i,autoCapitalize:i,autoCorrect:i,autoSave:null,color:null,itemProp:i,itemScope:i|s,itemType:i,itemID:i,itemRef:i,results:null,security:i,unselectable:i},DOMAttributeNames:{acceptCharset:"accept-charset",className:"class",htmlFor:"for",httpEquiv:"http-equiv"},DOMPropertyNames:{autoComplete:"autocomplete",autoFocus:"autofocus",autoPlay:"autoplay",autoSave:"autosave",encType:"encoding",hrefLang:"hreflang",radioGroup:"radiogroup",spellCheck:"spellcheck",srcDoc:"srcdoc",srcSet:"srcset"}}
t.exports=f},{10:10,128:128}],22:[function(e,t){"use strict"
function n(e){null!=e.checkedLink&&null!=e.valueLink?l(!1):void 0}function r(e){n(e),null!=e.value||null!=e.onChange?l(!1):void 0}function o(e){n(e),null!=e.checked||null!=e.onChange?l(!1):void 0}function i(e){if(e){var t=e.getName()
if(t)return" Check the render method of `"+t+"`."}return""}var a=e(72),s=e(71),l=e(142),c=(e(151),{button:!0,checkbox:!0,image:!0,hidden:!0,radio:!0,reset:!0,submit:!0}),u={value:function(e,t){return!e[t]||c[e.type]||e.onChange||e.readOnly||e.disabled?null:new Error("You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultValue`. Otherwise, set either `onChange` or `readOnly`.")},checked:function(e,t){return!e[t]||e.onChange||e.readOnly||e.disabled?null:new Error("You provided a `checked` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultChecked`. Otherwise, set either `onChange` or `readOnly`.")},onChange:a.func},d={},p={checkPropTypes:function(e,t,n){for(var r in u){if(u.hasOwnProperty(r))var o=u[r](t,r,e,s.prop)
o instanceof Error&&!(o.message in d)&&(d[o.message]=!0,i(n))}},getValue:function(e){return e.valueLink?(r(e),e.valueLink.value):e.value},getChecked:function(e){return e.checkedLink?(o(e),e.checkedLink.value):e.checked},executeOnChange:function(e,t){return e.valueLink?(r(e),e.valueLink.requestChange(t.target.value)):e.checkedLink?(o(e),e.checkedLink.requestChange(t.target.checked)):e.onChange?e.onChange.call(void 0,t):void 0}}
t.exports=p},{142:142,151:151,71:71,72:72}],23:[function(e,t){"use strict"
function n(e){if(null==e)throw new TypeError("Object.assign target cannot be null or undefined")
for(var t=Object(e),n=Object.prototype.hasOwnProperty,r=1;r<arguments.length;r++){var o=arguments[r]
if(null!=o){var i=Object(o)
for(var a in i)n.call(i,a)&&(t[a]=i[a])}}return t}t.exports=n},{}],24:[function(e,t){"use strict"
var n=e(142),r=function(e){var t=this
if(t.instancePool.length){var n=t.instancePool.pop()
return t.call(n,e),n}return new t(e)},o=function(e,t){var n=this
if(n.instancePool.length){var r=n.instancePool.pop()
return n.call(r,e,t),r}return new n(e,t)},i=function(e,t,n){var r=this
if(r.instancePool.length){var o=r.instancePool.pop()
return r.call(o,e,t,n),o}return new r(e,t,n)},a=function(e,t,n,r){var o=this
if(o.instancePool.length){var i=o.instancePool.pop()
return o.call(i,e,t,n,r),i}return new o(e,t,n,r)},s=function(e,t,n,r,o){var i=this
if(i.instancePool.length){var a=i.instancePool.pop()
return i.call(a,e,t,n,r,o),a}return new i(e,t,n,r,o)},l=function(e){var t=this
e instanceof t?void 0:n(!1),e.destructor(),t.instancePool.length<t.poolSize&&t.instancePool.push(e)},c=10,u=r,d=function(e,t){var n=e
return n.instancePool=[],n.getPooled=t||u,n.poolSize||(n.poolSize=c),n.release=l,n},p={addPoolingTo:d,oneArgumentPooler:r,twoArgumentPooler:o,threeArgumentPooler:i,fourArgumentPooler:a,fiveArgumentPooler:s}
t.exports=p},{142:142}],25:[function(e,t){"use strict"
var n=(e(60),e(106)),r=(e(151),"_getDOMNodeDidWarn"),o={getDOMNode:function(){return this.constructor[r]=!0,n(this)}}
t.exports=o},{106:106,151:151,60:60}],26:[function(e,t){"use strict"
function n(e){return Object.prototype.hasOwnProperty.call(e,m)||(e[m]=f++,d[e[m]]={}),d[e[m]]}var r=e(15),o=e(16),i=e(17),a=e(55),s=e(69),l=e(99),c=e(23),u=e(117),d={},p=!1,f=0,h={topAbort:"abort",topBlur:"blur",topCanPlay:"canplay",topCanPlayThrough:"canplaythrough",topChange:"change",topClick:"click",topCompositionEnd:"compositionend",topCompositionStart:"compositionstart",topCompositionUpdate:"compositionupdate",topContextMenu:"contextmenu",topCopy:"copy",topCut:"cut",topDoubleClick:"dblclick",topDrag:"drag",topDragEnd:"dragend",topDragEnter:"dragenter",topDragExit:"dragexit",topDragLeave:"dragleave",topDragOver:"dragover",topDragStart:"dragstart",topDrop:"drop",topDurationChange:"durationchange",topEmptied:"emptied",topEncrypted:"encrypted",topEnded:"ended",topError:"error",topFocus:"focus",topInput:"input",topKeyDown:"keydown",topKeyPress:"keypress",topKeyUp:"keyup",topLoadedData:"loadeddata",topLoadedMetadata:"loadedmetadata",topLoadStart:"loadstart",topMouseDown:"mousedown",topMouseMove:"mousemove",topMouseOut:"mouseout",topMouseOver:"mouseover",topMouseUp:"mouseup",topPaste:"paste",topPause:"pause",topPlay:"play",topPlaying:"playing",topProgress:"progress",topRateChange:"ratechange",topScroll:"scroll",topSeeked:"seeked",topSeeking:"seeking",topSelectionChange:"selectionchange",topStalled:"stalled",topSuspend:"suspend",topTextInput:"textInput",topTimeUpdate:"timeupdate",topTouchCancel:"touchcancel",topTouchEnd:"touchend",topTouchMove:"touchmove",topTouchStart:"touchstart",topVolumeChange:"volumechange",topWaiting:"waiting",topWheel:"wheel"},m="_reactListenersID"+String(Math.random()).slice(2),g=c({},a,{ReactEventListener:null,injection:{injectReactEventListener:function(e){e.setHandleTopLevel(g.handleTopLevel),g.ReactEventListener=e}},setEnabled:function(e){g.ReactEventListener&&g.ReactEventListener.setEnabled(e)},isEnabled:function(){return!(!g.ReactEventListener||!g.ReactEventListener.isEnabled())},listenTo:function(e,t){for(var o=t,a=n(o),s=i.registrationNameDependencies[e],l=r.topLevelTypes,c=0;c<s.length;c++){var d=s[c]
a.hasOwnProperty(d)&&a[d]||(d===l.topWheel?u("wheel")?g.ReactEventListener.trapBubbledEvent(l.topWheel,"wheel",o):u("mousewheel")?g.ReactEventListener.trapBubbledEvent(l.topWheel,"mousewheel",o):g.ReactEventListener.trapBubbledEvent(l.topWheel,"DOMMouseScroll",o):d===l.topScroll?u("scroll",!0)?g.ReactEventListener.trapCapturedEvent(l.topScroll,"scroll",o):g.ReactEventListener.trapBubbledEvent(l.topScroll,"scroll",g.ReactEventListener.WINDOW_HANDLE):d===l.topFocus||d===l.topBlur?(u("focus",!0)?(g.ReactEventListener.trapCapturedEvent(l.topFocus,"focus",o),g.ReactEventListener.trapCapturedEvent(l.topBlur,"blur",o)):u("focusin")&&(g.ReactEventListener.trapBubbledEvent(l.topFocus,"focusin",o),g.ReactEventListener.trapBubbledEvent(l.topBlur,"focusout",o)),a[l.topBlur]=!0,a[l.topFocus]=!0):h.hasOwnProperty(d)&&g.ReactEventListener.trapBubbledEvent(d,h[d],o),a[d]=!0)}},trapBubbledEvent:function(e,t,n){return g.ReactEventListener.trapBubbledEvent(e,t,n)},trapCapturedEvent:function(e,t,n){return g.ReactEventListener.trapCapturedEvent(e,t,n)},ensureScrollValueMonitoring:function(){if(!p){var e=l.refreshScrollValues
g.ReactEventListener.monitorScrollValue(e),p=!0}},eventNameDispatchConfigs:o.eventNameDispatchConfigs,registrationNameModules:o.registrationNameModules,putListener:o.putListener,getListener:o.getListener,deleteListener:o.deleteListener,deleteAllListeners:o.deleteAllListeners})
s.measureMethods(g,"ReactBrowserEventEmitter",{putListener:"putListener",deleteListener:"deleteListener"}),t.exports=g},{117:117,15:15,16:16,17:17,23:23,55:55,69:69,99:99}],27:[function(e,t){"use strict"
function n(e,t,n){var r=void 0===e[n]
null!=t&&r&&(e[n]=o(t,null))}var r=e(74),o=e(116),i=e(124),a=e(125),s=(e(151),{instantiateChildren:function(e){if(null==e)return null
var t={}
return a(e,n,t),t},updateChildren:function(e,t,n,a){if(!t&&!e)return null
var s
for(s in t)if(t.hasOwnProperty(s)){var l=e&&e[s],c=l&&l._currentElement,u=t[s]
if(null!=l&&i(c,u))r.receiveComponent(l,u,n,a),t[s]=l
else{l&&r.unmountComponent(l,s)
var d=o(u,null)
t[s]=d}}for(s in e)!e.hasOwnProperty(s)||t&&t.hasOwnProperty(s)||r.unmountComponent(e[s])
return t},unmountChildren:function(e){for(var t in e)if(e.hasOwnProperty(t)){var n=e[t]
r.unmountComponent(n)}}})
t.exports=s},{116:116,124:124,125:125,151:151,74:74}],28:[function(e,t){"use strict"
function n(e){return(""+e).replace(b,"//")}function r(e,t){this.func=e,this.context=t,this.count=0}function o(e,t){var n=e.func,r=e.context
n.call(r,t,e.count++)}function i(e,t,n){if(null==e)return e
var i=r.getPooled(t,n)
g(e,o,i),r.release(i)}function a(e,t,n,r){this.result=e,this.keyPrefix=t,this.func=n,this.context=r,this.count=0}function s(e,t,r){var o=e.result,i=e.keyPrefix,a=e.func,s=e.context,c=a.call(s,t,e.count++)
Array.isArray(c)?l(c,o,r,m.thatReturnsArgument):null!=c&&(h.isValidElement(c)&&(c=h.cloneAndReplaceKey(c,i+(c!==t?n(c.key||"")+"/":"")+r)),o.push(c))}function l(e,t,r,o,i){var l=""
null!=r&&(l=n(r)+"/")
var c=a.getPooled(t,l,o,i)
g(e,s,c),a.release(c)}function c(e,t,n){if(null==e)return e
var r=[]
return l(e,r,null,t,n),r}function u(){return null}function d(e){return g(e,u,null)}function p(e){var t=[]
return l(e,t,null,m.thatReturnsArgument),t}var f=e(24),h=e(50),m=e(134),g=e(125),v=f.twoArgumentPooler,y=f.fourArgumentPooler,b=/\/(?!\/)/g
r.prototype.destructor=function(){this.func=null,this.context=null,this.count=0},f.addPoolingTo(r,v),a.prototype.destructor=function(){this.result=null,this.keyPrefix=null,this.func=null,this.context=null,this.count=0},f.addPoolingTo(a,y)
var w={forEach:i,map:c,mapIntoWithKeyPrefixInternal:l,count:d,toArray:p}
t.exports=w},{125:125,134:134,24:24,50:50}],29:[function(e,t){"use strict"
function n(e,t){var n=_.hasOwnProperty(t)?_[t]:null
C.hasOwnProperty(t)&&(n!==b.OVERRIDE_BASE?m(!1):void 0),e.hasOwnProperty(t)&&(n!==b.DEFINE_MANY&&n!==b.DEFINE_MANY_MERGED?m(!1):void 0)}function r(e,t){if(t){"function"==typeof t?m(!1):void 0,d.isValidElement(t)?m(!1):void 0
var r=e.prototype
t.hasOwnProperty(y)&&E.mixins(e,t.mixins)
for(var o in t)if(t.hasOwnProperty(o)&&o!==y){var i=t[o]
if(n(r,o),E.hasOwnProperty(o))E[o](e,i)
else{var l=_.hasOwnProperty(o),c=r.hasOwnProperty(o),u="function"==typeof i,p=u&&!l&&!c&&t.autobind!==!1
if(p)r.__reactAutoBindMap||(r.__reactAutoBindMap={}),r.__reactAutoBindMap[o]=i,r[o]=i
else if(c){var f=_[o]
!l||f!==b.DEFINE_MANY_MERGED&&f!==b.DEFINE_MANY?m(!1):void 0,f===b.DEFINE_MANY_MERGED?r[o]=a(r[o],i):f===b.DEFINE_MANY&&(r[o]=s(r[o],i))}else r[o]=i}}}}function o(e,t){if(t)for(var n in t){var r=t[n]
if(t.hasOwnProperty(n)){var o=n in E
o?m(!1):void 0
var i=n in e
i?m(!1):void 0,e[n]=r}}}function i(e,t){e&&t&&"object"==typeof e&&"object"==typeof t?void 0:m(!1)
for(var n in t)t.hasOwnProperty(n)&&(void 0!==e[n]?m(!1):void 0,e[n]=t[n])
return e}function a(e,t){return function(){var n=e.apply(this,arguments),r=t.apply(this,arguments)
if(null==n)return r
if(null==r)return n
var o={}
return i(o,n),i(o,r),o}}function s(e,t){return function(){e.apply(this,arguments),t.apply(this,arguments)}}function l(e,t){var n=t.bind(e)
return n}function c(e){for(var t in e.__reactAutoBindMap)if(e.__reactAutoBindMap.hasOwnProperty(t)){var n=e.__reactAutoBindMap[t]
e[t]=l(e,n)}}var u=e(30),d=e(50),p=(e(71),e(70),e(67)),f=e(23),h=e(135),m=e(142),g=e(145),v=e(146),y=(e(151),v({mixins:null})),b=g({DEFINE_ONCE:null,DEFINE_MANY:null,OVERRIDE_BASE:null,DEFINE_MANY_MERGED:null}),w=[],_={mixins:b.DEFINE_MANY,statics:b.DEFINE_MANY,propTypes:b.DEFINE_MANY,contextTypes:b.DEFINE_MANY,childContextTypes:b.DEFINE_MANY,getDefaultProps:b.DEFINE_MANY_MERGED,getInitialState:b.DEFINE_MANY_MERGED,getChildContext:b.DEFINE_MANY_MERGED,render:b.DEFINE_ONCE,componentWillMount:b.DEFINE_MANY,componentDidMount:b.DEFINE_MANY,componentWillReceiveProps:b.DEFINE_MANY,shouldComponentUpdate:b.DEFINE_ONCE,componentWillUpdate:b.DEFINE_MANY,componentDidUpdate:b.DEFINE_MANY,componentWillUnmount:b.DEFINE_MANY,updateComponent:b.OVERRIDE_BASE},E={displayName:function(e,t){e.displayName=t},mixins:function(e,t){if(t)for(var n=0;n<t.length;n++)r(e,t[n])},childContextTypes:function(e,t){e.childContextTypes=f({},e.childContextTypes,t)},contextTypes:function(e,t){e.contextTypes=f({},e.contextTypes,t)},getDefaultProps:function(e,t){e.getDefaultProps=e.getDefaultProps?a(e.getDefaultProps,t):t},propTypes:function(e,t){e.propTypes=f({},e.propTypes,t)},statics:function(e,t){o(e,t)},autobind:function(){}},C={replaceState:function(e,t){this.updater.enqueueReplaceState(this,e),t&&this.updater.enqueueCallback(this,t)},isMounted:function(){return this.updater.isMounted(this)},setProps:function(e,t){this.updater.enqueueSetProps(this,e),t&&this.updater.enqueueCallback(this,t)},replaceProps:function(e,t){this.updater.enqueueReplaceProps(this,e),t&&this.updater.enqueueCallback(this,t)}},x=function(){}
f(x.prototype,u.prototype,C)
var S={createClass:function(e){var t=function(e,t,n){this.__reactAutoBindMap&&c(this),this.props=e,this.context=t,this.refs=h,this.updater=n||p,this.state=null
var r=this.getInitialState?this.getInitialState():null
"object"!=typeof r||Array.isArray(r)?m(!1):void 0,this.state=r}
t.prototype=new x,t.prototype.constructor=t,w.forEach(r.bind(null,t)),r(t,e),t.getDefaultProps&&(t.defaultProps=t.getDefaultProps()),t.prototype.render?void 0:m(!1)
for(var n in _)t.prototype[n]||(t.prototype[n]=null)
return t},injection:{injectMixin:function(e){w.push(e)}}}
t.exports=S},{135:135,142:142,145:145,146:146,151:151,23:23,30:30,50:50,67:67,70:70,71:71}],30:[function(e,t){"use strict"
function n(e,t,n){this.props=e,this.context=t,this.refs=o,this.updater=n||r}var r=e(67),o=(e(102),e(135)),i=e(142)
e(151),n.prototype.isReactComponent={},n.prototype.setState=function(e,t){"object"!=typeof e&&"function"!=typeof e&&null!=e?i(!1):void 0,this.updater.enqueueSetState(this,e),t&&this.updater.enqueueCallback(this,t)},n.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this),e&&this.updater.enqueueCallback(this,e)},t.exports=n},{102:102,135:135,142:142,151:151,67:67}],31:[function(e,t){"use strict"
var n=e(40),r=e(63),o={processChildrenUpdates:n.dangerouslyProcessChildrenUpdates,replaceNodeWithMarkupByID:n.dangerouslyReplaceNodeWithMarkupByID,unmountIDFromEnvironment:function(e){r.purgeID(e)}}
t.exports=o},{40:40,63:63}],32:[function(e,t){"use strict"
var n=e(142),r=!1,o={unmountIDFromEnvironment:null,replaceNodeWithMarkupByID:null,processChildrenUpdates:null,injection:{injectEnvironment:function(e){r?n(!1):void 0,o.unmountIDFromEnvironment=e.unmountIDFromEnvironment,o.replaceNodeWithMarkupByID=e.replaceNodeWithMarkupByID,o.processChildrenUpdates=e.processChildrenUpdates,r=!0}}}
t.exports=o},{142:142}],33:[function(e,t){"use strict"
function n(e){var t=e._currentElement._owner||null
if(t){var n=t.getName()
if(n)return" Check the render method of `"+n+"`."}return""}function r(){}var o=e(32),i=e(34),a=e(50),s=e(60),l=e(69),c=e(71),u=(e(70),e(74)),d=e(80),p=e(23),f=e(135),h=e(142),m=e(124)
e(151),r.prototype.render=function(){var e=s.get(this)._currentElement.type
return e(this.props,this.context,this.updater)}
var g=1,v={construct:function(e){this._currentElement=e,this._rootNodeID=null,this._instance=null,this._pendingElement=null,this._pendingStateQueue=null,this._pendingReplaceState=!1,this._pendingForceUpdate=!1,this._renderedComponent=null,this._context=null,this._mountOrder=0,this._topLevelWrapper=null,this._pendingCallbacks=null},mountComponent:function(e,t,n){this._context=n,this._mountOrder=g++,this._rootNodeID=e
var o,i,l=this._processProps(this._currentElement.props),c=this._processContext(n),p=this._currentElement.type,m="prototype"in p
m&&(o=new p(l,c,d)),(!m||null===o||o===!1||a.isValidElement(o))&&(i=o,o=new r(p)),o.props=l,o.context=c,o.refs=f,o.updater=d,this._instance=o,s.set(o,this)
var v=o.state
void 0===v&&(o.state=v=null),"object"!=typeof v||Array.isArray(v)?h(!1):void 0,this._pendingStateQueue=null,this._pendingReplaceState=!1,this._pendingForceUpdate=!1,o.componentWillMount&&(o.componentWillMount(),this._pendingStateQueue&&(o.state=this._processPendingState(o.props,o.context))),void 0===i&&(i=this._renderValidatedComponent()),this._renderedComponent=this._instantiateReactComponent(i)
var y=u.mountComponent(this._renderedComponent,e,t,this._processChildContext(n))
return o.componentDidMount&&t.getReactMountReady().enqueue(o.componentDidMount,o),y},unmountComponent:function(){var e=this._instance
e.componentWillUnmount&&e.componentWillUnmount(),u.unmountComponent(this._renderedComponent),this._renderedComponent=null,this._instance=null,this._pendingStateQueue=null,this._pendingReplaceState=!1,this._pendingForceUpdate=!1,this._pendingCallbacks=null,this._pendingElement=null,this._context=null,this._rootNodeID=null,this._topLevelWrapper=null,s.remove(e)},_maskContext:function(e){var t=null,n=this._currentElement.type,r=n.contextTypes
if(!r)return f
t={}
for(var o in r)t[o]=e[o]
return t},_processContext:function(e){var t=this._maskContext(e)
return t},_processChildContext:function(e){var t=this._currentElement.type,n=this._instance,r=n.getChildContext&&n.getChildContext()
if(r){"object"!=typeof t.childContextTypes?h(!1):void 0
for(var o in r)o in t.childContextTypes?void 0:h(!1)
return p({},e,r)}return e},_processProps:function(e){return e},_checkPropTypes:function(e,t,r){var o=this.getName()
for(var i in e)if(e.hasOwnProperty(i)){var a
try{"function"!=typeof e[i]?h(!1):void 0,a=e[i](t,i,o,r)}catch(s){a=s}a instanceof Error&&(n(this),r===c.prop)}},receiveComponent:function(e,t,n){var r=this._currentElement,o=this._context
this._pendingElement=null,this.updateComponent(t,r,e,o,n)},performUpdateIfNecessary:function(e){null!=this._pendingElement&&u.receiveComponent(this,this._pendingElement||this._currentElement,e,this._context),(null!==this._pendingStateQueue||this._pendingForceUpdate)&&this.updateComponent(e,this._currentElement,this._currentElement,this._context,this._context)},updateComponent:function(e,t,n,r,o){var i,a=this._instance,s=this._context===o?a.context:this._processContext(o)
t===n?i=n.props:(i=this._processProps(n.props),a.componentWillReceiveProps&&a.componentWillReceiveProps(i,s))
var l=this._processPendingState(i,s),c=this._pendingForceUpdate||!a.shouldComponentUpdate||a.shouldComponentUpdate(i,l,s)
c?(this._pendingForceUpdate=!1,this._performComponentUpdate(n,i,l,s,e,o)):(this._currentElement=n,this._context=o,a.props=i,a.state=l,a.context=s)},_processPendingState:function(e,t){var n=this._instance,r=this._pendingStateQueue,o=this._pendingReplaceState
if(this._pendingReplaceState=!1,this._pendingStateQueue=null,!r)return n.state
if(o&&1===r.length)return r[0]
for(var i=p({},o?r[0]:n.state),a=o?1:0;a<r.length;a++){var s=r[a]
p(i,"function"==typeof s?s.call(n,i,e,t):s)}return i},_performComponentUpdate:function(e,t,n,r,o,i){var a,s,l,c=this._instance,u=Boolean(c.componentDidUpdate)
u&&(a=c.props,s=c.state,l=c.context),c.componentWillUpdate&&c.componentWillUpdate(t,n,r),this._currentElement=e,this._context=i,c.props=t,c.state=n,c.context=r,this._updateRenderedComponent(o,i),u&&o.getReactMountReady().enqueue(c.componentDidUpdate.bind(c,a,s,l),c)},_updateRenderedComponent:function(e,t){var n=this._renderedComponent,r=n._currentElement,o=this._renderValidatedComponent()
if(m(r,o))u.receiveComponent(n,o,e,this._processChildContext(t))
else{var i=this._rootNodeID,a=n._rootNodeID
u.unmountComponent(n),this._renderedComponent=this._instantiateReactComponent(o)
var s=u.mountComponent(this._renderedComponent,i,e,this._processChildContext(t))
this._replaceNodeWithMarkupByID(a,s)}},_replaceNodeWithMarkupByID:function(e,t){o.replaceNodeWithMarkupByID(e,t)},_renderValidatedComponentWithoutOwnerOrContext:function(){var e=this._instance,t=e.render()
return t},_renderValidatedComponent:function(){var e
i.current=this
try{e=this._renderValidatedComponentWithoutOwnerOrContext()}finally{i.current=null}return null===e||e===!1||a.isValidElement(e)?void 0:h(!1),e},attachRef:function(e,t){var n=this.getPublicInstance()
null==n?h(!1):void 0
var r=t.getPublicInstance(),o=n.refs===f?n.refs={}:n.refs
o[e]=r},detachRef:function(e){var t=this.getPublicInstance().refs
delete t[e]},getName:function(){var e=this._currentElement.type,t=this._instance&&this._instance.constructor
return e.displayName||t&&t.displayName||e.name||t&&t.name||null},getPublicInstance:function(){var e=this._instance
return e instanceof r?null:e},_instantiateReactComponent:null}
l.measureMethods(v,"ReactCompositeComponent",{mountComponent:"mountComponent",updateComponent:"updateComponent",_renderValidatedComponent:"_renderValidatedComponent"})
var y={Mixin:v}
t.exports=y},{124:124,135:135,142:142,151:151,23:23,32:32,34:34,50:50,60:60,69:69,70:70,71:71,74:74,80:80}],34:[function(e,t){"use strict"
var n={current:null}
t.exports=n},{}],35:[function(e,t){"use strict"
var n=e(34),r=e(46),o=e(49),i=e(59),a=e(63),s=e(69),l=e(74),c=e(81),u=e(82),d=e(106),p=e(121)
e(151),o.inject()
var f=s.measure("React","render",a.render),h={findDOMNode:d,render:f,unmountComponentAtNode:a.unmountComponentAtNode,version:u,unstable_batchedUpdates:c.batchedUpdates,unstable_renderSubtreeIntoContainer:p}
"undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.inject&&__REACT_DEVTOOLS_GLOBAL_HOOK__.inject({CurrentOwner:n,InstanceHandles:i,Mount:a,Reconciler:l,TextComponent:r}),t.exports=h},{106:106,121:121,151:151,34:34,46:46,49:49,59:59,63:63,69:69,74:74,81:81,82:82}],36:[function(e,t){"use strict"
var n={onClick:!0,onDoubleClick:!0,onMouseDown:!0,onMouseMove:!0,onMouseUp:!0,onClickCapture:!0,onDoubleClickCapture:!0,onMouseDownCapture:!0,onMouseMoveCapture:!0,onMouseUpCapture:!0},r={getNativeProps:function(e,t){if(!t.disabled)return t
var r={}
for(var o in t)t.hasOwnProperty(o)&&!n[o]&&(r[o]=t[o])
return r}}
t.exports=r},{}],37:[function(e,t){"use strict"
function n(){return this}function r(){var e=this._reactInternalComponent
return!!e}function o(){}function i(e,t){var n=this._reactInternalComponent
n&&(P.enqueueSetPropsInternal(n,e),t&&P.enqueueCallbackInternal(n,t))}function a(e,t){var n=this._reactInternalComponent
n&&(P.enqueueReplacePropsInternal(n,e),t&&P.enqueueCallbackInternal(n,t))}function s(e,t){t&&(null!=t.dangerouslySetInnerHTML&&(null!=t.children?L(!1):void 0,"object"==typeof t.dangerouslySetInnerHTML&&Y in t.dangerouslySetInnerHTML?void 0:L(!1)),null!=t.style&&"object"!=typeof t.style?L(!1):void 0)}function l(e,t,n,r){var o=A.findReactContainerForID(e)
if(o){var i=o.nodeType===V?o.ownerDocument:o
j(t,i)}r.getReactMountReady().enqueue(c,{id:e,registrationName:t,listener:n})}function c(){var e=this
_.putListener(e.id,e.registrationName,e.listener)}function u(){var e=this
e._rootNodeID?void 0:L(!1)
var t=A.getNode(e._rootNodeID)
switch(t?void 0:L(!1),e._tag){case"iframe":e._wrapperState.listeners=[_.trapBubbledEvent(w.topLevelTypes.topLoad,"load",t)]
break
case"video":case"audio":e._wrapperState.listeners=[]
for(var n in G)G.hasOwnProperty(n)&&e._wrapperState.listeners.push(_.trapBubbledEvent(w.topLevelTypes[n],G[n],t))
break
case"img":e._wrapperState.listeners=[_.trapBubbledEvent(w.topLevelTypes.topError,"error",t),_.trapBubbledEvent(w.topLevelTypes.topLoad,"load",t)]
break
case"form":e._wrapperState.listeners=[_.trapBubbledEvent(w.topLevelTypes.topReset,"reset",t),_.trapBubbledEvent(w.topLevelTypes.topSubmit,"submit",t)]}}function d(){x.mountReadyWrapper(this)}function p(){k.postUpdateWrapper(this)}function f(e){Z.call(Q,e)||(X.test(e)?void 0:L(!1),Q[e]=!0)}function h(e,t){return e.indexOf("-")>=0||null!=t.is}function m(e){f(e),this._tag=e.toLowerCase(),this._renderedChildren=null,this._previousStyle=null,this._previousStyleCopy=null,this._rootNodeID=null,this._wrapperState=null,this._topLevelWrapper=null,this._nodeWithLegacyProperties=null}var g=e(2),v=e(5),y=e(10),b=e(11),w=e(15),_=e(26),E=e(31),C=e(36),x=e(41),S=e(42),k=e(43),T=e(47),A=e(63),N=e(64),M=e(69),P=e(80),D=e(23),I=e(102),R=e(105),L=e(142),O=(e(117),e(146)),B=e(122),q=e(123),U=(e(149),e(126),e(151),_.deleteListener),j=_.listenTo,F=_.registrationNameModules,W={string:!0,number:!0},z=O({children:null}),H=O({style:null}),Y=O({__html:null}),V=1,G={topAbort:"abort",topCanPlay:"canplay",topCanPlayThrough:"canplaythrough",topDurationChange:"durationchange",topEmptied:"emptied",topEncrypted:"encrypted",topEnded:"ended",topError:"error",topLoadedData:"loadeddata",topLoadedMetadata:"loadedmetadata",topLoadStart:"loadstart",topPause:"pause",topPlay:"play",topPlaying:"playing",topProgress:"progress",topRateChange:"ratechange",topSeeked:"seeked",topSeeking:"seeking",topStalled:"stalled",topSuspend:"suspend",topTimeUpdate:"timeupdate",topVolumeChange:"volumechange",topWaiting:"waiting"},K={area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0},$={listing:!0,pre:!0,textarea:!0},X=(D({menuitem:!0},K),/^[a-zA-Z][a-zA-Z:_\.\-\d]*$/),Q={},Z={}.hasOwnProperty
m.displayName="ReactDOMComponent",m.Mixin={construct:function(e){this._currentElement=e},mountComponent:function(e,t,n){this._rootNodeID=e
var r=this._currentElement.props
switch(this._tag){case"iframe":case"img":case"form":case"video":case"audio":this._wrapperState={listeners:null},t.getReactMountReady().enqueue(u,this)
break
case"button":r=C.getNativeProps(this,r,n)
break
case"input":x.mountWrapper(this,r,n),r=x.getNativeProps(this,r,n)
break
case"option":S.mountWrapper(this,r,n),r=S.getNativeProps(this,r,n)
break
case"select":k.mountWrapper(this,r,n),r=k.getNativeProps(this,r,n),n=k.processChildContext(this,r,n)
break
case"textarea":T.mountWrapper(this,r,n),r=T.getNativeProps(this,r,n)}s(this,r)
var o
if(t.useCreateElement){var i=n[A.ownerDocumentContextKey],a=i.createElement(this._currentElement.type)
b.setAttributeForID(a,this._rootNodeID),A.getID(a),this._updateDOMProperties({},r,t,a),this._createInitialChildren(t,r,n,a),o=a}else{var l=this._createOpenTagMarkupAndPutListeners(t,r),c=this._createContentMarkup(t,r,n)
o=!c&&K[this._tag]?l+"/>":l+">"+c+"</"+this._currentElement.type+">"}switch(this._tag){case"input":t.getReactMountReady().enqueue(d,this)
case"button":case"select":case"textarea":r.autoFocus&&t.getReactMountReady().enqueue(g.focusDOMComponent,this)}return o},_createOpenTagMarkupAndPutListeners:function(e,t){var n="<"+this._currentElement.type
for(var r in t)if(t.hasOwnProperty(r)){var o=t[r]
if(null!=o)if(F.hasOwnProperty(r))o&&l(this._rootNodeID,r,o,e)
else{r===H&&(o&&(o=this._previousStyleCopy=D({},t.style)),o=v.createMarkupForStyles(o))
var i=null
null!=this._tag&&h(this._tag,t)?r!==z&&(i=b.createMarkupForCustomAttribute(r,o)):i=b.createMarkupForProperty(r,o),i&&(n+=" "+i)}}if(e.renderToStaticMarkup)return n
var a=b.createMarkupForID(this._rootNodeID)
return n+" "+a},_createContentMarkup:function(e,t,n){var r="",o=t.dangerouslySetInnerHTML
if(null!=o)null!=o.__html&&(r=o.__html)
else{var i=W[typeof t.children]?t.children:null,a=null!=i?null:t.children
if(null!=i)r=R(i)
else if(null!=a){var s=this.mountChildren(a,e,n)
r=s.join("")}}return $[this._tag]&&"\n"===r.charAt(0)?"\n"+r:r},_createInitialChildren:function(e,t,n,r){var o=t.dangerouslySetInnerHTML
if(null!=o)null!=o.__html&&B(r,o.__html)
else{var i=W[typeof t.children]?t.children:null,a=null!=i?null:t.children
if(null!=i)q(r,i)
else if(null!=a)for(var s=this.mountChildren(a,e,n),l=0;l<s.length;l++)r.appendChild(s[l])}},receiveComponent:function(e,t,n){var r=this._currentElement
this._currentElement=e,this.updateComponent(t,r,e,n)},updateComponent:function(e,t,n,r){var o=t.props,i=this._currentElement.props
switch(this._tag){case"button":o=C.getNativeProps(this,o),i=C.getNativeProps(this,i)
break
case"input":x.updateWrapper(this),o=x.getNativeProps(this,o),i=x.getNativeProps(this,i)
break
case"option":o=S.getNativeProps(this,o),i=S.getNativeProps(this,i)
break
case"select":o=k.getNativeProps(this,o),i=k.getNativeProps(this,i)
break
case"textarea":T.updateWrapper(this),o=T.getNativeProps(this,o),i=T.getNativeProps(this,i)}s(this,i),this._updateDOMProperties(o,i,e,null),this._updateDOMChildren(o,i,e,r),!I&&this._nodeWithLegacyProperties&&(this._nodeWithLegacyProperties.props=i),"select"===this._tag&&e.getReactMountReady().enqueue(p,this)},_updateDOMProperties:function(e,t,n,r){var o,i,a
for(o in e)if(!t.hasOwnProperty(o)&&e.hasOwnProperty(o))if(o===H){var s=this._previousStyleCopy
for(i in s)s.hasOwnProperty(i)&&(a=a||{},a[i]="")
this._previousStyleCopy=null}else F.hasOwnProperty(o)?e[o]&&U(this._rootNodeID,o):(y.properties[o]||y.isCustomAttribute(o))&&(r||(r=A.getNode(this._rootNodeID)),b.deleteValueForProperty(r,o))
for(o in t){var c=t[o],u=o===H?this._previousStyleCopy:e[o]
if(t.hasOwnProperty(o)&&c!==u)if(o===H)if(c?c=this._previousStyleCopy=D({},c):this._previousStyleCopy=null,u){for(i in u)!u.hasOwnProperty(i)||c&&c.hasOwnProperty(i)||(a=a||{},a[i]="")
for(i in c)c.hasOwnProperty(i)&&u[i]!==c[i]&&(a=a||{},a[i]=c[i])}else a=c
else F.hasOwnProperty(o)?c?l(this._rootNodeID,o,c,n):u&&U(this._rootNodeID,o):h(this._tag,t)?(r||(r=A.getNode(this._rootNodeID)),o===z&&(c=null),b.setValueForAttribute(r,o,c)):(y.properties[o]||y.isCustomAttribute(o))&&(r||(r=A.getNode(this._rootNodeID)),null!=c?b.setValueForProperty(r,o,c):b.deleteValueForProperty(r,o))}a&&(r||(r=A.getNode(this._rootNodeID)),v.setValueForStyles(r,a))},_updateDOMChildren:function(e,t,n,r){var o=W[typeof e.children]?e.children:null,i=W[typeof t.children]?t.children:null,a=e.dangerouslySetInnerHTML&&e.dangerouslySetInnerHTML.__html,s=t.dangerouslySetInnerHTML&&t.dangerouslySetInnerHTML.__html,l=null!=o?null:e.children,c=null!=i?null:t.children,u=null!=o||null!=a,d=null!=i||null!=s
null!=l&&null==c?this.updateChildren(null,n,r):u&&!d&&this.updateTextContent(""),null!=i?o!==i&&this.updateTextContent(""+i):null!=s?a!==s&&this.updateMarkup(""+s):null!=c&&this.updateChildren(c,n,r)},unmountComponent:function(){switch(this._tag){case"iframe":case"img":case"form":case"video":case"audio":var e=this._wrapperState.listeners
if(e)for(var t=0;t<e.length;t++)e[t].remove()
break
case"input":x.unmountWrapper(this)
break
case"html":case"head":case"body":L(!1)}if(this.unmountChildren(),_.deleteAllListeners(this._rootNodeID),E.unmountIDFromEnvironment(this._rootNodeID),this._rootNodeID=null,this._wrapperState=null,this._nodeWithLegacyProperties){var n=this._nodeWithLegacyProperties
n._reactInternalComponent=null,this._nodeWithLegacyProperties=null}},getPublicInstance:function(){if(!this._nodeWithLegacyProperties){var e=A.getNode(this._rootNodeID)
e._reactInternalComponent=this,e.getDOMNode=n,e.isMounted=r,e.setState=o,e.replaceState=o,e.forceUpdate=o,e.setProps=i,e.replaceProps=a,e.props=this._currentElement.props,this._nodeWithLegacyProperties=e}return this._nodeWithLegacyProperties}},M.measureMethods(m,"ReactDOMComponent",{mountComponent:"mountComponent",updateComponent:"updateComponent"}),D(m.prototype,m.Mixin,N.Mixin),t.exports=m},{10:10,102:102,105:105,11:11,117:117,122:122,123:123,126:126,142:142,146:146,149:149,15:15,151:151,2:2,23:23,26:26,31:31,36:36,41:41,42:42,43:43,47:47,5:5,63:63,64:64,69:69,80:80}],38:[function(e,t){"use strict"
function n(e){return r.createFactory(e)}var r=e(50),o=(e(51),e(147)),i=o({a:"a",abbr:"abbr",address:"address",area:"area",article:"article",aside:"aside",audio:"audio",b:"b",base:"base",bdi:"bdi",bdo:"bdo",big:"big",blockquote:"blockquote",body:"body",br:"br",button:"button",canvas:"canvas",caption:"caption",cite:"cite",code:"code",col:"col",colgroup:"colgroup",data:"data",datalist:"datalist",dd:"dd",del:"del",details:"details",dfn:"dfn",dialog:"dialog",div:"div",dl:"dl",dt:"dt",em:"em",embed:"embed",fieldset:"fieldset",figcaption:"figcaption",figure:"figure",footer:"footer",form:"form",h1:"h1",h2:"h2",h3:"h3",h4:"h4",h5:"h5",h6:"h6",head:"head",header:"header",hgroup:"hgroup",hr:"hr",html:"html",i:"i",iframe:"iframe",img:"img",input:"input",ins:"ins",kbd:"kbd",keygen:"keygen",label:"label",legend:"legend",li:"li",link:"link",main:"main",map:"map",mark:"mark",menu:"menu",menuitem:"menuitem",meta:"meta",meter:"meter",nav:"nav",noscript:"noscript",object:"object",ol:"ol",optgroup:"optgroup",option:"option",output:"output",p:"p",param:"param",picture:"picture",pre:"pre",progress:"progress",q:"q",rp:"rp",rt:"rt",ruby:"ruby",s:"s",samp:"samp",script:"script",section:"section",select:"select",small:"small",source:"source",span:"span",strong:"strong",style:"style",sub:"sub",summary:"summary",sup:"sup",table:"table",tbody:"tbody",td:"td",textarea:"textarea",tfoot:"tfoot",th:"th",thead:"thead",time:"time",title:"title",tr:"tr",track:"track",u:"u",ul:"ul","var":"var",video:"video",wbr:"wbr",circle:"circle",clipPath:"clipPath",defs:"defs",ellipse:"ellipse",g:"g",image:"image",line:"line",linearGradient:"linearGradient",mask:"mask",path:"path",pattern:"pattern",polygon:"polygon",polyline:"polyline",radialGradient:"radialGradient",rect:"rect",stop:"stop",svg:"svg",text:"text",tspan:"tspan"},n)
t.exports=i},{147:147,50:50,51:51}],39:[function(e,t){"use strict"
var n={useCreateElement:!1}
t.exports=n},{}],40:[function(e,t){"use strict"
var n=e(9),r=e(11),o=e(63),i=e(69),a=e(142),s={dangerouslySetInnerHTML:"`dangerouslySetInnerHTML` must be set using `updateInnerHTMLByID()`.",style:"`style` must be set using `updateStylesByID()`."},l={updatePropertyByID:function(e,t,n){var i=o.getNode(e)
s.hasOwnProperty(t)?a(!1):void 0,null!=n?r.setValueForProperty(i,t,n):r.deleteValueForProperty(i,t)},dangerouslyReplaceNodeWithMarkupByID:function(e,t){var r=o.getNode(e)
n.dangerouslyReplaceNodeWithMarkup(r,t)},dangerouslyProcessChildrenUpdates:function(e,t){for(var r=0;r<e.length;r++)e[r].parentNode=o.getNode(e[r].parentID)
n.processUpdates(e,t)}}
i.measureMethods(l,"ReactDOMIDOperations",{dangerouslyReplaceNodeWithMarkupByID:"dangerouslyReplaceNodeWithMarkupByID",dangerouslyProcessChildrenUpdates:"dangerouslyProcessChildrenUpdates"}),t.exports=l},{11:11,142:142,63:63,69:69,9:9}],41:[function(e,t){"use strict"
function n(){this._rootNodeID&&d.updateWrapper(this)}function r(e){var t=this._currentElement.props,r=i.executeOnChange(t,e)
s.asap(n,this)
var o=t.name
if("radio"===t.type&&null!=o){for(var l=a.getNode(this._rootNodeID),d=l;d.parentNode;)d=d.parentNode
for(var p=d.querySelectorAll("input[name="+JSON.stringify(""+o)+'][type="radio"]'),f=0;f<p.length;f++){var h=p[f]
if(h!==l&&h.form===l.form){var m=a.getID(h)
m?void 0:c(!1)
var g=u[m]
g?void 0:c(!1),s.asap(n,g)}}}return r}var o=e(40),i=e(22),a=e(63),s=e(81),l=e(23),c=e(142),u={},d={getNativeProps:function(e,t){var n=i.getValue(t),r=i.getChecked(t),o=l({},t,{defaultChecked:void 0,defaultValue:void 0,value:null!=n?n:e._wrapperState.initialValue,checked:null!=r?r:e._wrapperState.initialChecked,onChange:e._wrapperState.onChange})
return o},mountWrapper:function(e,t){var n=t.defaultValue
e._wrapperState={initialChecked:t.defaultChecked||!1,initialValue:null!=n?n:null,onChange:r.bind(e)}},mountReadyWrapper:function(e){u[e._rootNodeID]=e},unmountWrapper:function(e){delete u[e._rootNodeID]},updateWrapper:function(e){var t=e._currentElement.props,n=t.checked
null!=n&&o.updatePropertyByID(e._rootNodeID,"checked",n||!1)
var r=i.getValue(t)
null!=r&&o.updatePropertyByID(e._rootNodeID,"value",""+r)}}
t.exports=d},{142:142,22:22,23:23,40:40,63:63,81:81}],42:[function(e,t){"use strict"
var n=e(28),r=e(43),o=e(23),i=(e(151),r.valueContextKey),a={mountWrapper:function(e,t,n){var r=n[i],o=null
if(null!=r)if(o=!1,Array.isArray(r)){for(var a=0;a<r.length;a++)if(""+r[a]==""+t.value){o=!0
break}}else o=""+r==""+t.value
e._wrapperState={selected:o}},getNativeProps:function(e,t){var r=o({selected:void 0,children:void 0},t)
null!=e._wrapperState.selected&&(r.selected=e._wrapperState.selected)
var i=""
return n.forEach(t.children,function(e){null!=e&&("string"==typeof e||"number"==typeof e)&&(i+=e)}),i&&(r.children=i),r}}
t.exports=a},{151:151,23:23,28:28,43:43}],43:[function(e,t){"use strict"
function n(){if(this._rootNodeID&&this._wrapperState.pendingUpdate){this._wrapperState.pendingUpdate=!1
var e=this._currentElement.props,t=i.getValue(e)
null!=t&&r(this,Boolean(e.multiple),t)}}function r(e,t,n){var r,o,i=a.getNode(e._rootNodeID).options
if(t){for(r={},o=0;o<n.length;o++)r[""+n[o]]=!0
for(o=0;o<i.length;o++){var s=r.hasOwnProperty(i[o].value)
i[o].selected!==s&&(i[o].selected=s)}}else{for(r=""+n,o=0;o<i.length;o++)if(i[o].value===r)return void(i[o].selected=!0)
i.length&&(i[0].selected=!0)}}function o(e){var t=this._currentElement.props,r=i.executeOnChange(t,e)
return this._wrapperState.pendingUpdate=!0,s.asap(n,this),r}var i=e(22),a=e(63),s=e(81),l=e(23),c=(e(151),"__ReactDOMSelect_value$"+Math.random().toString(36).slice(2)),u={valueContextKey:c,getNativeProps:function(e,t){return l({},t,{onChange:e._wrapperState.onChange,value:void 0})},mountWrapper:function(e,t){var n=i.getValue(t)
e._wrapperState={pendingUpdate:!1,initialValue:null!=n?n:t.defaultValue,onChange:o.bind(e),wasMultiple:Boolean(t.multiple)}},processChildContext:function(e,t,n){var r=l({},n)
return r[c]=e._wrapperState.initialValue,r},postUpdateWrapper:function(e){var t=e._currentElement.props
e._wrapperState.initialValue=void 0
var n=e._wrapperState.wasMultiple
e._wrapperState.wasMultiple=Boolean(t.multiple)
var o=i.getValue(t)
null!=o?(e._wrapperState.pendingUpdate=!1,r(e,Boolean(t.multiple),o)):n!==Boolean(t.multiple)&&(null!=t.defaultValue?r(e,Boolean(t.multiple),t.defaultValue):r(e,Boolean(t.multiple),t.multiple?[]:""))}}
t.exports=u},{151:151,22:22,23:23,63:63,81:81}],44:[function(e,t){"use strict"
function n(e,t,n,r){return e===n&&t===r}function r(e){var t=document.selection,n=t.createRange(),r=n.text.length,o=n.duplicate()
o.moveToElementText(e),o.setEndPoint("EndToStart",n)
var i=o.text.length,a=i+r
return{start:i,end:a}}function o(e){var t=window.getSelection&&window.getSelection()
if(!t||0===t.rangeCount)return null
var r=t.anchorNode,o=t.anchorOffset,i=t.focusNode,a=t.focusOffset,s=t.getRangeAt(0)
try{s.startContainer.nodeType,s.endContainer.nodeType}catch(l){return null}var c=n(t.anchorNode,t.anchorOffset,t.focusNode,t.focusOffset),u=c?0:s.toString().length,d=s.cloneRange()
d.selectNodeContents(e),d.setEnd(s.startContainer,s.startOffset)
var p=n(d.startContainer,d.startOffset,d.endContainer,d.endOffset),f=p?0:d.toString().length,h=f+u,m=document.createRange()
m.setStart(r,o),m.setEnd(i,a)
var g=m.collapsed
return{start:g?h:f,end:g?f:h}}function i(e,t){var n,r,o=document.selection.createRange().duplicate()
"undefined"==typeof t.end?(n=t.start,r=n):t.start>t.end?(n=t.end,r=t.start):(n=t.start,r=t.end),o.moveToElementText(e),o.moveStart("character",n),o.setEndPoint("EndToStart",o),o.moveEnd("character",r-n),o.select()}function a(e,t){if(window.getSelection){var n=window.getSelection(),r=e[c()].length,o=Math.min(t.start,r),i="undefined"==typeof t.end?o:Math.min(t.end,r)
if(!n.extend&&o>i){var a=i
i=o,o=a}var s=l(e,o),u=l(e,i)
if(s&&u){var d=document.createRange()
d.setStart(s.node,s.offset),n.removeAllRanges(),o>i?(n.addRange(d),n.extend(u.node,u.offset)):(d.setEnd(u.node,u.offset),n.addRange(d))}}}var s=e(128),l=e(114),c=e(115),u=s.canUseDOM&&"selection"in document&&!("getSelection"in window),d={getOffsets:u?r:o,setOffsets:u?i:a}
t.exports=d},{114:114,115:115,128:128}],45:[function(e,t){"use strict"
var n=e(49),r=e(78),o=e(82)
n.inject()
var i={renderToString:r.renderToString,renderToStaticMarkup:r.renderToStaticMarkup,version:o}
t.exports=i},{49:49,78:78,82:82}],46:[function(e,t){"use strict"
var n=e(9),r=e(11),o=e(31),i=e(63),a=e(23),s=e(105),l=e(123),c=(e(126),function(){})
a(c.prototype,{construct:function(e){this._currentElement=e,this._stringText=""+e,this._rootNodeID=null,this._mountIndex=0},mountComponent:function(e,t,n){if(this._rootNodeID=e,t.useCreateElement){var o=n[i.ownerDocumentContextKey],a=o.createElement("span")
return r.setAttributeForID(a,e),i.getID(a),l(a,this._stringText),a}var c=s(this._stringText)
return t.renderToStaticMarkup?c:"<span "+r.createMarkupForID(e)+">"+c+"</span>"},receiveComponent:function(e){if(e!==this._currentElement){this._currentElement=e
var t=""+e
if(t!==this._stringText){this._stringText=t
var r=i.getNode(this._rootNodeID)
n.updateTextContent(r,t)}}},unmountComponent:function(){o.unmountIDFromEnvironment(this._rootNodeID)}}),t.exports=c},{105:105,11:11,123:123,126:126,23:23,31:31,63:63,9:9}],47:[function(e,t){"use strict"
function n(){this._rootNodeID&&c.updateWrapper(this)}function r(e){var t=this._currentElement.props,r=o.executeOnChange(t,e)
return a.asap(n,this),r}var o=e(22),i=e(40),a=e(81),s=e(23),l=e(142),c=(e(151),{getNativeProps:function(e,t){null!=t.dangerouslySetInnerHTML?l(!1):void 0
var n=s({},t,{defaultValue:void 0,value:void 0,children:e._wrapperState.initialValue,onChange:e._wrapperState.onChange})
return n},mountWrapper:function(e,t){var n=t.defaultValue,i=t.children
null!=i&&(null!=n?l(!1):void 0,Array.isArray(i)&&(i.length<=1?void 0:l(!1),i=i[0]),n=""+i),null==n&&(n="")
var a=o.getValue(t)
e._wrapperState={initialValue:""+(null!=a?a:n),onChange:r.bind(e)}},updateWrapper:function(e){var t=e._currentElement.props,n=o.getValue(t)
null!=n&&i.updatePropertyByID(e._rootNodeID,"value",""+n)}})
t.exports=c},{142:142,151:151,22:22,23:23,40:40,81:81}],48:[function(e,t){"use strict"
function n(){this.reinitializeTransaction()}var r=e(81),o=e(98),i=e(23),a=e(134),s={initialize:a,close:function(){d.isBatchingUpdates=!1}},l={initialize:a,close:r.flushBatchedUpdates.bind(r)},c=[l,s]
i(n.prototype,o.Mixin,{getTransactionWrappers:function(){return c}})
var u=new n,d={isBatchingUpdates:!1,batchedUpdates:function(e,t,n,r,o,i){var a=d.isBatchingUpdates
d.isBatchingUpdates=!0,a?e(t,n,r,o,i):u.perform(e,null,t,n,r,o,i)}}
t.exports=d},{134:134,23:23,81:81,98:98}],49:[function(e,t){"use strict"
function n(){x||(x=!0,g.EventEmitter.injectReactEventListener(m),g.EventPluginHub.injectEventPluginOrder(a),g.EventPluginHub.injectInstanceHandle(v),g.EventPluginHub.injectMount(y),g.EventPluginHub.injectEventPluginsByName({SimpleEventPlugin:E,EnterLeaveEventPlugin:s,ChangeEventPlugin:o,SelectEventPlugin:w,BeforeInputEventPlugin:r}),g.NativeComponent.injectGenericComponentClass(f),g.NativeComponent.injectTextComponentClass(h),g.Class.injectMixin(u),g.DOMProperty.injectDOMPropertyConfig(c),g.DOMProperty.injectDOMPropertyConfig(C),g.EmptyComponent.injectEmptyComponent("noscript"),g.Updates.injectReconcileTransaction(b),g.Updates.injectBatchingStrategy(p),g.RootIndex.injectCreateReactRootIndex(l.canUseDOM?i.createReactRootIndex:_.createReactRootIndex),g.Component.injectEnvironment(d))}var r=e(3),o=e(7),i=e(8),a=e(13),s=e(14),l=e(128),c=e(21),u=e(25),d=e(31),p=e(48),f=e(37),h=e(46),m=e(56),g=e(57),v=e(59),y=e(63),b=e(73),w=e(84),_=e(85),E=e(86),C=e(83),x=!1
t.exports={inject:n}},{128:128,13:13,14:14,21:21,25:25,3:3,31:31,37:37,46:46,48:48,56:56,57:57,59:59,63:63,7:7,73:73,8:8,83:83,84:84,85:85,86:86}],50:[function(e,t){"use strict"
var n=e(34),r=e(23),o=(e(102),"function"==typeof Symbol&&Symbol.for&&Symbol.for("react.element")||60103),i={key:!0,ref:!0,__self:!0,__source:!0},a=function(e,t,n,r,i,a,s){var l={$$typeof:o,type:e,key:t,ref:n,props:s,_owner:a}
return l}
a.createElement=function(e,t,r){var o,s={},l=null,c=null,u=null,d=null
if(null!=t){c=void 0===t.ref?null:t.ref,l=void 0===t.key?null:""+t.key,u=void 0===t.__self?null:t.__self,d=void 0===t.__source?null:t.__source
for(o in t)t.hasOwnProperty(o)&&!i.hasOwnProperty(o)&&(s[o]=t[o])}var p=arguments.length-2
if(1===p)s.children=r
else if(p>1){for(var f=Array(p),h=0;p>h;h++)f[h]=arguments[h+2]
s.children=f}if(e&&e.defaultProps){var m=e.defaultProps
for(o in m)"undefined"==typeof s[o]&&(s[o]=m[o])}return a(e,l,c,u,d,n.current,s)},a.createFactory=function(e){var t=a.createElement.bind(null,e)
return t.type=e,t},a.cloneAndReplaceKey=function(e,t){var n=a(e.type,t,e.ref,e._self,e._source,e._owner,e.props)
return n},a.cloneAndReplaceProps=function(e,t){var n=a(e.type,e.key,e.ref,e._self,e._source,e._owner,t)
return n},a.cloneElement=function(e,t,o){var s,l=r({},e.props),c=e.key,u=e.ref,d=e._self,p=e._source,f=e._owner
if(null!=t){void 0!==t.ref&&(u=t.ref,f=n.current),void 0!==t.key&&(c=""+t.key)
for(s in t)t.hasOwnProperty(s)&&!i.hasOwnProperty(s)&&(l[s]=t[s])}var h=arguments.length-2
if(1===h)l.children=o
else if(h>1){for(var m=Array(h),g=0;h>g;g++)m[g]=arguments[g+2]
l.children=m}return a(e.type,c,u,d,p,f,l)},a.isValidElement=function(e){return"object"==typeof e&&null!==e&&e.$$typeof===o},t.exports=a},{102:102,23:23,34:34}],51:[function(e,t){"use strict"
function n(){if(u.current){var e=u.current.getName()
if(e)return" Check the render method of `"+e+"`."}return""}function r(e,t){e._store&&!e._store.validated&&null==e.key&&(e._store.validated=!0,o("uniqueKey",e,t))}function o(e,t,r){var o=n()
if(!o){var i="string"==typeof r?r:r.displayName||r.name
i&&(o=" Check the top-level render call using <"+i+">.")}var a=f[e]||(f[e]={})
if(a[o])return null
a[o]=!0
var s={parentOrOwner:o,url:" See https://fb.me/react-warning-keys for more information.",childOwner:null}
return t&&t._owner&&t._owner!==u.current&&(s.childOwner=" It was passed a child from "+t._owner.getName()+"."),s}function i(e,t){if("object"==typeof e)if(Array.isArray(e))for(var n=0;n<e.length;n++){var o=e[n]
l.isValidElement(o)&&r(o,t)}else if(l.isValidElement(e))e._store&&(e._store.validated=!0)
else if(e){var i=d(e)
if(i&&i!==e.entries)for(var a,s=i.call(e);!(a=s.next()).done;)l.isValidElement(a.value)&&r(a.value,t)}}function a(e,t,r,o){for(var i in t)if(t.hasOwnProperty(i)){var a
try{"function"!=typeof t[i]?p(!1):void 0,a=t[i](r,i,e,o)}catch(s){a=s}a instanceof Error&&!(a.message in h)&&(h[a.message]=!0,n())}}function s(e){var t=e.type
if("function"==typeof t){var n=t.displayName||t.name
t.propTypes&&a(n,t.propTypes,e.props,c.prop),"function"==typeof t.getDefaultProps}}var l=e(50),c=e(71),u=(e(70),e(34)),d=(e(102),e(113)),p=e(142),f=(e(151),{}),h={},m={createElement:function(e){var t="string"==typeof e||"function"==typeof e,n=l.createElement.apply(this,arguments)
if(null==n)return n
if(t)for(var r=2;r<arguments.length;r++)i(arguments[r],e)
return s(n),n},createFactory:function(e){var t=m.createElement.bind(null,e)
return t.type=e,t},cloneElement:function(){for(var e=l.cloneElement.apply(this,arguments),t=2;t<arguments.length;t++)i(arguments[t],e.type)
return s(e),e}}
t.exports=m},{102:102,113:113,142:142,151:151,34:34,50:50,70:70,71:71}],52:[function(e,t){"use strict"
function n(){i.registerNullComponentID(this._rootNodeID)}var r,o=e(50),i=e(53),a=e(74),s=e(23),l={injectEmptyComponent:function(e){r=o.createElement(e)}},c=function(e){this._currentElement=null,this._rootNodeID=null,this._renderedComponent=e(r)}
s(c.prototype,{construct:function(){},mountComponent:function(e,t,r){return t.getReactMountReady().enqueue(n,this),this._rootNodeID=e,a.mountComponent(this._renderedComponent,e,t,r)},receiveComponent:function(){},unmountComponent:function(){a.unmountComponent(this._renderedComponent),i.deregisterNullComponentID(this._rootNodeID),this._rootNodeID=null,this._renderedComponent=null}}),c.injection=l,t.exports=c},{23:23,50:50,53:53,74:74}],53:[function(e,t){"use strict"
function n(e){return!!i[e]}function r(e){i[e]=!0}function o(e){delete i[e]}var i={},a={isNullComponentID:n,registerNullComponentID:r,deregisterNullComponentID:o}
t.exports=a},{}],54:[function(e,t){"use strict"
function n(e,t,n,o){try{return t(n,o)}catch(i){return void(null===r&&(r=i))}}var r=null,o={invokeGuardedCallback:n,invokeGuardedCallbackWithCatch:n,rethrowCaughtError:function(){if(r){var e=r
throw r=null,e}}}
t.exports=o},{}],55:[function(e,t){"use strict"
function n(e){r.enqueueEvents(e),r.processEventQueue(!1)}var r=e(16),o={handleTopLevel:function(e,t,o,i,a){var s=r.extractEvents(e,t,o,i,a)
n(s)}}
t.exports=o},{16:16}],56:[function(e,t){"use strict"
function n(e){var t=d.getID(e),n=u.getReactRootIDFromNodeID(t),r=d.findReactContainerForID(n),o=d.getFirstReactDOM(r)
return o}function r(e,t){this.topLevelType=e,this.nativeEvent=t,this.ancestors=[]}function o(e){i(e)}function i(e){for(var t=d.getFirstReactDOM(h(e.nativeEvent))||window,r=t;r;)e.ancestors.push(r),r=n(r)
for(var o=0;o<e.ancestors.length;o++){t=e.ancestors[o]
var i=d.getID(t)||""
g._handleTopLevel(e.topLevelType,t,i,e.nativeEvent,h(e.nativeEvent))}}function a(e){var t=m(window)
e(t)}var s=e(127),l=e(128),c=e(24),u=e(59),d=e(63),p=e(81),f=e(23),h=e(112),m=e(139)
f(r.prototype,{destructor:function(){this.topLevelType=null,this.nativeEvent=null,this.ancestors.length=0}}),c.addPoolingTo(r,c.twoArgumentPooler)
var g={_enabled:!0,_handleTopLevel:null,WINDOW_HANDLE:l.canUseDOM?window:null,setHandleTopLevel:function(e){g._handleTopLevel=e},setEnabled:function(e){g._enabled=!!e},isEnabled:function(){return g._enabled},trapBubbledEvent:function(e,t,n){var r=n
return r?s.listen(r,t,g.dispatchEvent.bind(null,e)):null},trapCapturedEvent:function(e,t,n){var r=n
return r?s.capture(r,t,g.dispatchEvent.bind(null,e)):null},monitorScrollValue:function(e){var t=a.bind(null,e)
s.listen(window,"scroll",t)},dispatchEvent:function(e,t){if(g._enabled){var n=r.getPooled(e,t)
try{p.batchedUpdates(o,n)}finally{r.release(n)}}}}
t.exports=g},{112:112,127:127,128:128,139:139,23:23,24:24,59:59,63:63,81:81}],57:[function(e,t){"use strict"
var n=e(10),r=e(16),o=e(32),i=e(29),a=e(52),s=e(26),l=e(66),c=e(69),u=e(76),d=e(81),p={Component:o.injection,Class:i.injection,DOMProperty:n.injection,EmptyComponent:a.injection,EventPluginHub:r.injection,EventEmitter:s.injection,NativeComponent:l.injection,Perf:c.injection,RootIndex:u.injection,Updates:d.injection}
t.exports=p},{10:10,16:16,26:26,29:29,32:32,52:52,66:66,69:69,76:76,81:81}],58:[function(e,t){"use strict"
function n(e){return o(document.documentElement,e)}var r=e(44),o=e(131),i=e(136),a=e(137),s={hasSelectionCapabilities:function(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase()
return t&&("input"===t&&"text"===e.type||"textarea"===t||"true"===e.contentEditable)},getSelectionInformation:function(){var e=a()
return{focusedElem:e,selectionRange:s.hasSelectionCapabilities(e)?s.getSelection(e):null}},restoreSelection:function(e){var t=a(),r=e.focusedElem,o=e.selectionRange
t!==r&&n(r)&&(s.hasSelectionCapabilities(r)&&s.setSelection(r,o),i(r))},getSelection:function(e){var t
if("selectionStart"in e)t={start:e.selectionStart,end:e.selectionEnd}
else if(document.selection&&e.nodeName&&"input"===e.nodeName.toLowerCase()){var n=document.selection.createRange()
n.parentElement()===e&&(t={start:-n.moveStart("character",-e.value.length),end:-n.moveEnd("character",-e.value.length)})}else t=r.getOffsets(e)
return t||{start:0,end:0}},setSelection:function(e,t){var n=t.start,o=t.end
if("undefined"==typeof o&&(o=n),"selectionStart"in e)e.selectionStart=n,e.selectionEnd=Math.min(o,e.value.length)
else if(document.selection&&e.nodeName&&"input"===e.nodeName.toLowerCase()){var i=e.createTextRange()
i.collapse(!0),i.moveStart("character",n),i.moveEnd("character",o-n),i.select()}else r.setOffsets(e,t)}}
t.exports=s},{131:131,136:136,137:137,44:44}],59:[function(e,t){"use strict"
function n(e){return p+e.toString(36)}function r(e,t){return e.charAt(t)===p||t===e.length}function o(e){return""===e||e.charAt(0)===p&&e.charAt(e.length-1)!==p}function i(e,t){return 0===t.indexOf(e)&&r(t,e.length)}function a(e){return e?e.substr(0,e.lastIndexOf(p)):""}function s(e,t){if(o(e)&&o(t)?void 0:d(!1),i(e,t)?void 0:d(!1),e===t)return e
var n,a=e.length+f
for(n=a;n<t.length&&!r(t,n);n++);return t.substr(0,n)}function l(e,t){var n=Math.min(e.length,t.length)
if(0===n)return""
for(var i=0,a=0;n>=a;a++)if(r(e,a)&&r(t,a))i=a
else if(e.charAt(a)!==t.charAt(a))break
var s=e.substr(0,i)
return o(s)?void 0:d(!1),s}function c(e,t,n,r,o,l){e=e||"",t=t||"",e===t?d(!1):void 0
var c=i(t,e)
c||i(e,t)?void 0:d(!1)
for(var u=0,p=c?a:s,f=e;;f=p(f,t)){var m
if(o&&f===e||l&&f===t||(m=n(f,c,r)),m===!1||f===t)break
u++<h?void 0:d(!1)}}var u=e(76),d=e(142),p=".",f=p.length,h=1e4,m={createReactRootID:function(){return n(u.createReactRootIndex())},createReactID:function(e,t){return e+t},getReactRootIDFromNodeID:function(e){if(e&&e.charAt(0)===p&&e.length>1){var t=e.indexOf(p,1)
return t>-1?e.substr(0,t):e}return null},traverseEnterLeave:function(e,t,n,r,o){var i=l(e,t)
i!==e&&c(e,i,n,r,!1,!0),i!==t&&c(i,t,n,o,!0,!1)},traverseTwoPhase:function(e,t,n){e&&(c("",e,t,n,!0,!1),c(e,"",t,n,!1,!0))},traverseTwoPhaseSkipTarget:function(e,t,n){e&&(c("",e,t,n,!0,!0),c(e,"",t,n,!0,!0))},traverseAncestors:function(e,t,n){c("",e,t,n,!0,!1)},getFirstCommonAncestorID:l,_getNextDescendantID:s,isAncestorIDOf:i,SEPARATOR:p}
t.exports=m},{142:142,76:76}],60:[function(e,t){"use strict"
var n={remove:function(e){e._reactInternalInstance=void 0},get:function(e){return e._reactInternalInstance},has:function(e){return void 0!==e._reactInternalInstance},set:function(e,t){e._reactInternalInstance=t}}
t.exports=n},{}],61:[function(e,t){"use strict"
var n=e(28),r=e(30),o=e(29),i=e(38),a=e(50),s=(e(51),e(72)),l=e(82),c=e(23),u=e(119),d=a.createElement,p=a.createFactory,f=a.cloneElement,h={Children:{map:n.map,forEach:n.forEach,count:n.count,toArray:n.toArray,only:u},Component:r,createElement:d,cloneElement:f,isValidElement:a.isValidElement,PropTypes:s,createClass:o.createClass,createFactory:p,createMixin:function(e){return e},DOM:i,version:l,__spread:c}
t.exports=h},{119:119,23:23,28:28,29:29,30:30,38:38,50:50,51:51,72:72,82:82}],62:[function(e,t){"use strict"
var n=e(101),r=/\/?>/,o={CHECKSUM_ATTR_NAME:"data-react-checksum",addChecksumToMarkup:function(e){var t=n(e)
return e.replace(r," "+o.CHECKSUM_ATTR_NAME+'="'+t+'"$&')},canReuseMarkup:function(e,t){var r=t.getAttribute(o.CHECKSUM_ATTR_NAME)
r=r&&parseInt(r,10)
var i=n(e)
return i===r}}
t.exports=o},{101:101}],63:[function(e,t){"use strict"
function n(e,t){for(var n=Math.min(e.length,t.length),r=0;n>r;r++)if(e.charAt(r)!==t.charAt(r))return r
return e.length===t.length?-1:n}function r(e){return e?e.nodeType===F?e.documentElement:e.firstChild:null}function o(e){var t=r(e)
return t&&$.getID(t)}function i(e){var t=a(e)
if(t)if(U.hasOwnProperty(t)){var n=U[t]
n!==e&&(u(n,t)?L(!1):void 0,U[t]=e)}else U[t]=e
return t}function a(e){return e&&e.getAttribute&&e.getAttribute(q)||""}function s(e,t){var n=a(e)
n!==t&&delete U[n],e.setAttribute(q,t),U[t]=e}function l(e){return U.hasOwnProperty(e)&&u(U[e],e)||(U[e]=$.findReactNodeByID(e)),U[e]}function c(e){var t=S.get(e)._rootNodeID
return C.isNullComponentID(t)?null:(U.hasOwnProperty(t)&&u(U[t],t)||(U[t]=$.findReactNodeByID(t)),U[t])}function u(e,t){if(e){a(e)!==t?L(!1):void 0
var n=$.findReactContainerForID(t)
if(n&&I(n,e))return!0}return!1}function d(e){delete U[e]}function p(e){var t=U[e]
return t&&u(t,e)?void(G=t):!1}function f(e){G=null,x.traverseAncestors(e,p)
var t=G
return G=null,t}function h(e,t,n,r,o,i){_.useCreateElement&&(i=P({},i),i[z]=n.nodeType===F?n:n.ownerDocument)
var a=A.mountComponent(e,t,r,i)
e._renderedComponent._topLevelWrapper=e,$._mountImageIntoNode(a,n,o,r)}function m(e,t,n,r,o){var i=M.ReactReconcileTransaction.getPooled(r)
i.perform(h,null,e,t,n,i,r,o),M.ReactReconcileTransaction.release(i)}function g(e,t){for(A.unmountComponent(e),t.nodeType===F&&(t=t.documentElement);t.lastChild;)t.removeChild(t.lastChild)}function v(e){var t=o(e)
return t?t!==x.getReactRootIDFromNodeID(t):!1}function y(e){for(;e&&e.parentNode!==e;e=e.parentNode)if(1===e.nodeType){var t=a(e)
if(t){var n,r=x.getReactRootIDFromNodeID(t),o=e
do if(n=a(o),o=o.parentNode,null==o)return null
while(n!==r)
if(o===Y[r])return e}}return null}var b=e(10),w=e(26),_=(e(34),e(39)),E=e(50),C=e(53),x=e(59),S=e(60),k=e(62),T=e(69),A=e(74),N=e(80),M=e(81),P=e(23),D=e(135),I=e(131),R=e(116),L=e(142),O=e(122),B=e(124),q=(e(126),e(151),b.ID_ATTRIBUTE_NAME),U={},j=1,F=9,W=11,z="__ReactMount_ownerDocument$"+Math.random().toString(36).slice(2),H={},Y={},V=[],G=null,K=function(){}
K.prototype.isReactComponent={},K.prototype.render=function(){return this.props}
var $={TopLevelWrapper:K,_instancesByReactRootID:H,scrollMonitor:function(e,t){t()},_updateRootComponent:function(e,t,n,r){return $.scrollMonitor(n,function(){N.enqueueElementInternal(e,t),r&&N.enqueueCallbackInternal(e,r)}),e},_registerComponent:function(e,t){!t||t.nodeType!==j&&t.nodeType!==F&&t.nodeType!==W?L(!1):void 0,w.ensureScrollValueMonitoring()
var n=$.registerContainer(t)
return H[n]=e,n},_renderNewRootComponent:function(e,t,n,r){var o=R(e,null),i=$._registerComponent(o,t)
return M.batchedUpdates(m,o,i,t,n,r),o},renderSubtreeIntoContainer:function(e,t,n,r){return null==e||null==e._reactInternalInstance?L(!1):void 0,$._renderSubtreeIntoContainer(e,t,n,r)},_renderSubtreeIntoContainer:function(e,t,n,i){E.isValidElement(t)?void 0:L(!1)
var s=new E(K,null,null,null,null,null,t),l=H[o(n)]
if(l){var c=l._currentElement,u=c.props
if(B(u,t)){var d=l._renderedComponent.getPublicInstance(),p=i&&function(){i.call(d)}
return $._updateRootComponent(l,s,n,p),d}$.unmountComponentAtNode(n)}var f=r(n),h=f&&!!a(f),m=v(n),g=h&&!l&&!m,y=$._renderNewRootComponent(s,n,g,null!=e?e._reactInternalInstance._processChildContext(e._reactInternalInstance._context):D)._renderedComponent.getPublicInstance()
return i&&i.call(y),y},render:function(e,t,n){return $._renderSubtreeIntoContainer(null,e,t,n)},registerContainer:function(e){var t=o(e)
return t&&(t=x.getReactRootIDFromNodeID(t)),t||(t=x.createReactRootID()),Y[t]=e,t},unmountComponentAtNode:function(e){!e||e.nodeType!==j&&e.nodeType!==F&&e.nodeType!==W?L(!1):void 0
var t=o(e),n=H[t]
if(!n){var r=(v(e),a(e))
return r&&r===x.getReactRootIDFromNodeID(r),!1}return M.batchedUpdates(g,n,e),delete H[t],delete Y[t],!0},findReactContainerForID:function(e){var t=x.getReactRootIDFromNodeID(e),n=Y[t]
return n},findReactNodeByID:function(e){var t=$.findReactContainerForID(e)
return $.findComponentRoot(t,e)},getFirstReactDOM:function(e){return y(e)},findComponentRoot:function(e,t){var n=V,r=0,o=f(t)||e
for(n[0]=o.firstChild,n.length=1;r<n.length;){for(var i,a=n[r++];a;){var s=$.getID(a)
s?t===s?i=a:x.isAncestorIDOf(s,t)&&(n.length=r=0,n.push(a.firstChild)):n.push(a.firstChild),a=a.nextSibling}if(i)return n.length=0,i}n.length=0,L(!1)},_mountImageIntoNode:function(e,t,o,i){if(!t||t.nodeType!==j&&t.nodeType!==F&&t.nodeType!==W?L(!1):void 0,o){var a=r(t)
if(k.canReuseMarkup(e,a))return
var s=a.getAttribute(k.CHECKSUM_ATTR_NAME)
a.removeAttribute(k.CHECKSUM_ATTR_NAME)
var l=a.outerHTML
a.setAttribute(k.CHECKSUM_ATTR_NAME,s)
var c=e,u=n(c,l)
" (client) "+c.substring(u-20,u+20)+"\n (server) "+l.substring(u-20,u+20),t.nodeType===F?L(!1):void 0}if(t.nodeType===F?L(!1):void 0,i.useCreateElement){for(;t.lastChild;)t.removeChild(t.lastChild)
t.appendChild(e)}else O(t,e)},ownerDocumentContextKey:z,getReactRootID:o,getID:i,setID:s,getNode:l,getNodeFromInstance:c,isValid:u,purgeID:d}
T.measureMethods($,"ReactMount",{_renderNewRootComponent:"_renderNewRootComponent",_mountImageIntoNode:"_mountImageIntoNode"}),t.exports=$},{10:10,116:116,122:122,124:124,126:126,131:131,135:135,142:142,151:151,23:23,26:26,34:34,39:39,50:50,53:53,59:59,60:60,62:62,69:69,74:74,80:80,81:81}],64:[function(e,t){"use strict"
function n(e,t,n){m.push({parentID:e,parentNode:null,type:u.INSERT_MARKUP,markupIndex:g.push(t)-1,content:null,fromIndex:null,toIndex:n})}function r(e,t,n){m.push({parentID:e,parentNode:null,type:u.MOVE_EXISTING,markupIndex:null,content:null,fromIndex:t,toIndex:n})}function o(e,t){m.push({parentID:e,parentNode:null,type:u.REMOVE_NODE,markupIndex:null,content:null,fromIndex:t,toIndex:null})}function i(e,t){m.push({parentID:e,parentNode:null,type:u.SET_MARKUP,markupIndex:null,content:t,fromIndex:null,toIndex:null})}function a(e,t){m.push({parentID:e,parentNode:null,type:u.TEXT_CONTENT,markupIndex:null,content:t,fromIndex:null,toIndex:null})}function s(){m.length&&(c.processChildrenUpdates(m,g),l())}function l(){m.length=0,g.length=0}var c=e(32),u=e(65),d=(e(34),e(74)),p=e(27),f=e(107),h=0,m=[],g=[],v={Mixin:{_reconcilerInstantiateChildren:function(e,t,n){return p.instantiateChildren(e,t,n)},_reconcilerUpdateChildren:function(e,t,n,r){var o
return o=f(t),p.updateChildren(e,o,n,r)},mountChildren:function(e,t,n){var r=this._reconcilerInstantiateChildren(e,t,n)
this._renderedChildren=r
var o=[],i=0
for(var a in r)if(r.hasOwnProperty(a)){var s=r[a],l=this._rootNodeID+a,c=d.mountComponent(s,l,t,n)
s._mountIndex=i++,o.push(c)}return o},updateTextContent:function(e){h++
var t=!0
try{var n=this._renderedChildren
p.unmountChildren(n)
for(var r in n)n.hasOwnProperty(r)&&this._unmountChild(n[r])
this.setTextContent(e),t=!1}finally{h--,h||(t?l():s())}},updateMarkup:function(e){h++
var t=!0
try{var n=this._renderedChildren
p.unmountChildren(n)
for(var r in n)n.hasOwnProperty(r)&&this._unmountChildByName(n[r],r)
this.setMarkup(e),t=!1}finally{h--,h||(t?l():s())}},updateChildren:function(e,t,n){h++
var r=!0
try{this._updateChildren(e,t,n),r=!1}finally{h--,h||(r?l():s())}},_updateChildren:function(e,t,n){var r=this._renderedChildren,o=this._reconcilerUpdateChildren(r,e,t,n)
if(this._renderedChildren=o,o||r){var i,a=0,s=0
for(i in o)if(o.hasOwnProperty(i)){var l=r&&r[i],c=o[i]
l===c?(this.moveChild(l,s,a),a=Math.max(l._mountIndex,a),l._mountIndex=s):(l&&(a=Math.max(l._mountIndex,a),this._unmountChild(l)),this._mountChildByNameAtIndex(c,i,s,t,n)),s++}for(i in r)!r.hasOwnProperty(i)||o&&o.hasOwnProperty(i)||this._unmountChild(r[i])}},unmountChildren:function(){var e=this._renderedChildren
p.unmountChildren(e),this._renderedChildren=null},moveChild:function(e,t,n){e._mountIndex<n&&r(this._rootNodeID,e._mountIndex,t)},createChild:function(e,t){n(this._rootNodeID,t,e._mountIndex)},removeChild:function(e){o(this._rootNodeID,e._mountIndex)},setTextContent:function(e){a(this._rootNodeID,e)},setMarkup:function(e){i(this._rootNodeID,e)},_mountChildByNameAtIndex:function(e,t,n,r,o){var i=this._rootNodeID+t,a=d.mountComponent(e,i,r,o)
e._mountIndex=n,this.createChild(e,a)},_unmountChild:function(e){this.removeChild(e),e._mountIndex=null}}}
t.exports=v},{107:107,27:27,32:32,34:34,65:65,74:74}],65:[function(e,t){"use strict"
var n=e(145),r=n({INSERT_MARKUP:null,MOVE_EXISTING:null,REMOVE_NODE:null,SET_MARKUP:null,TEXT_CONTENT:null})
t.exports=r},{145:145}],66:[function(e,t){"use strict"
function n(e){if("function"==typeof e.type)return e.type
var t=e.type,n=u[t]
return null==n&&(u[t]=n=l(t)),n}function r(e){return c?void 0:s(!1),new c(e.type,e.props)}function o(e){return new d(e)}function i(e){return e instanceof d}var a=e(23),s=e(142),l=null,c=null,u={},d=null,p={injectGenericComponentClass:function(e){c=e},injectTextComponentClass:function(e){d=e},injectComponentClasses:function(e){a(u,e)}},f={getComponentClassForElement:n,createInternalComponent:r,createInstanceForText:o,isTextComponent:i,injection:p}
t.exports=f},{142:142,23:23}],67:[function(e,t){"use strict"
function n(){}var r=(e(151),{isMounted:function(){return!1},enqueueCallback:function(){},enqueueForceUpdate:function(e){n(e,"forceUpdate")},enqueueReplaceState:function(e){n(e,"replaceState")},enqueueSetState:function(e){n(e,"setState")},enqueueSetProps:function(e){n(e,"setProps")},enqueueReplaceProps:function(e){n(e,"replaceProps")}})
t.exports=r},{151:151}],68:[function(e,t){"use strict"
var n=e(142),r={isValidOwner:function(e){return!(!e||"function"!=typeof e.attachRef||"function"!=typeof e.detachRef)},addComponentAsRefTo:function(e,t,o){r.isValidOwner(o)?void 0:n(!1),o.attachRef(t,e)},removeComponentAsRefFrom:function(e,t,o){r.isValidOwner(o)?void 0:n(!1),o.getPublicInstance().refs[t]===e.getPublicInstance()&&o.detachRef(t)}}
t.exports=r},{142:142}],69:[function(e,t){"use strict"
function n(e,t,n){return n}var r={enableMeasure:!1,storedMeasure:n,measureMethods:function(){},measure:function(e,t,n){return n},injection:{injectMeasure:function(e){r.storedMeasure=e}}}
t.exports=r},{}],70:[function(e,t){"use strict"
var n={}
t.exports=n},{}],71:[function(e,t){"use strict"
var n=e(145),r=n({prop:null,context:null,childContext:null})
t.exports=r},{145:145}],72:[function(e,t){"use strict"
function n(e){function t(t,n,r,o,i,a){if(o=o||_,a=a||r,null==n[r]){var s=y[i]
return t?new Error("Required "+s+" `"+a+"` was not specified in "+("`"+o+"`.")):null}return e(n,r,o,i,a)}var n=t.bind(null,!1)
return n.isRequired=t.bind(null,!0),n}function r(e){function t(t,n,r,o,i){var a=t[n],s=h(a)
if(s!==e){var l=y[o],c=m(a)
return new Error("Invalid "+l+" `"+i+"` of type "+("`"+c+"` supplied to `"+r+"`, expected ")+("`"+e+"`."))}return null}return n(t)}function o(){return n(b.thatReturns(null))}function i(e){function t(t,n,r,o,i){var a=t[n]
if(!Array.isArray(a)){var s=y[o],l=h(a)
return new Error("Invalid "+s+" `"+i+"` of type "+("`"+l+"` supplied to `"+r+"`, expected an array."))}for(var c=0;c<a.length;c++){var u=e(a,c,r,o,i+"["+c+"]")
if(u instanceof Error)return u}return null}return n(t)}function a(){function e(e,t,n,r,o){if(!v.isValidElement(e[t])){var i=y[r]
return new Error("Invalid "+i+" `"+o+"` supplied to "+("`"+n+"`, expected a single ReactElement."))}return null}return n(e)}function s(e){function t(t,n,r,o,i){if(!(t[n]instanceof e)){var a=y[o],s=e.name||_,l=g(t[n])
return new Error("Invalid "+a+" `"+i+"` of type "+("`"+l+"` supplied to `"+r+"`, expected ")+("instance of `"+s+"`."))}return null}return n(t)}function l(e){function t(t,n,r,o,i){for(var a=t[n],s=0;s<e.length;s++)if(a===e[s])return null
var l=y[o],c=JSON.stringify(e)
return new Error("Invalid "+l+" `"+i+"` of value `"+a+"` "+("supplied to `"+r+"`, expected one of "+c+"."))}return n(Array.isArray(e)?t:function(){return new Error("Invalid argument supplied to oneOf, expected an instance of array.")})}function c(e){function t(t,n,r,o,i){var a=t[n],s=h(a)
if("object"!==s){var l=y[o]
return new Error("Invalid "+l+" `"+i+"` of type "+("`"+s+"` supplied to `"+r+"`, expected an object."))}for(var c in a)if(a.hasOwnProperty(c)){var u=e(a,c,r,o,i+"."+c)
if(u instanceof Error)return u}return null}return n(t)}function u(e){function t(t,n,r,o,i){for(var a=0;a<e.length;a++){var s=e[a]
if(null==s(t,n,r,o,i))return null}var l=y[o]
return new Error("Invalid "+l+" `"+i+"` supplied to "+("`"+r+"`."))}return n(Array.isArray(e)?t:function(){return new Error("Invalid argument supplied to oneOfType, expected an instance of array.")})}function d(){function e(e,t,n,r,o){if(!f(e[t])){var i=y[r]
return new Error("Invalid "+i+" `"+o+"` supplied to "+("`"+n+"`, expected a ReactNode."))}return null}return n(e)}function p(e){function t(t,n,r,o,i){var a=t[n],s=h(a)
if("object"!==s){var l=y[o]
return new Error("Invalid "+l+" `"+i+"` of type `"+s+"` "+("supplied to `"+r+"`, expected `object`."))}for(var c in e){var u=e[c]
if(u){var d=u(a,c,r,o,i+"."+c)
if(d)return d}}return null}return n(t)}function f(e){switch(typeof e){case"number":case"string":case"undefined":return!0
case"boolean":return!e
case"object":if(Array.isArray(e))return e.every(f)
if(null===e||v.isValidElement(e))return!0
var t=w(e)
if(!t)return!1
var n,r=t.call(e)
if(t!==e.entries){for(;!(n=r.next()).done;)if(!f(n.value))return!1}else for(;!(n=r.next()).done;){var o=n.value
if(o&&!f(o[1]))return!1}return!0
default:return!1}}function h(e){var t=typeof e
return Array.isArray(e)?"array":e instanceof RegExp?"object":t}function m(e){var t=h(e)
if("object"===t){if(e instanceof Date)return"date"
if(e instanceof RegExp)return"regexp"}return t}function g(e){return e.constructor&&e.constructor.name?e.constructor.name:"<<anonymous>>"}var v=e(50),y=e(70),b=e(134),w=e(113),_="<<anonymous>>",E={array:r("array"),bool:r("boolean"),func:r("function"),number:r("number"),object:r("object"),string:r("string"),any:o(),arrayOf:i,element:a(),instanceOf:s,node:d(),objectOf:c,oneOf:l,oneOfType:u,shape:p}
t.exports=E},{113:113,134:134,50:50,70:70}],73:[function(e,t){"use strict"
function n(e){this.reinitializeTransaction(),this.renderToStaticMarkup=!1,this.reactMountReady=r.getPooled(null),this.useCreateElement=!e&&a.useCreateElement}var r=e(6),o=e(24),i=e(26),a=e(39),s=e(58),l=e(98),c=e(23),u={initialize:s.getSelectionInformation,close:s.restoreSelection},d={initialize:function(){var e=i.isEnabled()
return i.setEnabled(!1),e},close:function(e){i.setEnabled(e)}},p={initialize:function(){this.reactMountReady.reset()},close:function(){this.reactMountReady.notifyAll()}},f=[u,d,p],h={getTransactionWrappers:function(){return f},getReactMountReady:function(){return this.reactMountReady},destructor:function(){r.release(this.reactMountReady),this.reactMountReady=null}}
c(n.prototype,l.Mixin,h),o.addPoolingTo(n),t.exports=n},{23:23,24:24,26:26,39:39,58:58,6:6,98:98}],74:[function(e,t){"use strict"
function n(){r.attachRefs(this,this._currentElement)}var r=e(75),o={mountComponent:function(e,t,r,o){var i=e.mountComponent(t,r,o)
return e._currentElement&&null!=e._currentElement.ref&&r.getReactMountReady().enqueue(n,e),i},unmountComponent:function(e){r.detachRefs(e,e._currentElement),e.unmountComponent()},receiveComponent:function(e,t,o,i){var a=e._currentElement
if(t!==a||i!==e._context){var s=r.shouldUpdateRefs(a,t)
s&&r.detachRefs(e,a),e.receiveComponent(t,o,i),s&&e._currentElement&&null!=e._currentElement.ref&&o.getReactMountReady().enqueue(n,e)}},performUpdateIfNecessary:function(e,t){e.performUpdateIfNecessary(t)}}
t.exports=o},{75:75}],75:[function(e,t){"use strict"
function n(e,t,n){"function"==typeof e?e(t.getPublicInstance()):o.addComponentAsRefTo(t,e,n)}function r(e,t,n){"function"==typeof e?e(null):o.removeComponentAsRefFrom(t,e,n)}var o=e(68),i={}
i.attachRefs=function(e,t){if(null!==t&&t!==!1){var r=t.ref
null!=r&&n(r,e,t._owner)}},i.shouldUpdateRefs=function(e,t){var n=null===e||e===!1,r=null===t||t===!1
return n||r||t._owner!==e._owner||t.ref!==e.ref},i.detachRefs=function(e,t){if(null!==t&&t!==!1){var n=t.ref
null!=n&&r(n,e,t._owner)}},t.exports=i},{68:68}],76:[function(e,t){"use strict"
var n={injectCreateReactRootIndex:function(e){r.createReactRootIndex=e}},r={createReactRootIndex:null,injection:n}
t.exports=r},{}],77:[function(e,t){"use strict"
var n={isBatchingUpdates:!1,batchedUpdates:function(){}}
t.exports=n},{}],78:[function(e,t){"use strict"
function n(e){i.isValidElement(e)?void 0:f(!1)
var t
try{u.injection.injectBatchingStrategy(l)
var n=a.createReactRootID()
return t=c.getPooled(!1),t.perform(function(){var r=p(e,null),o=r.mountComponent(n,t,d)
return s.addChecksumToMarkup(o)},null)}finally{c.release(t),u.injection.injectBatchingStrategy(o)}}function r(e){i.isValidElement(e)?void 0:f(!1)
var t
try{u.injection.injectBatchingStrategy(l)
var n=a.createReactRootID()
return t=c.getPooled(!0),t.perform(function(){var r=p(e,null)
return r.mountComponent(n,t,d)},null)}finally{c.release(t),u.injection.injectBatchingStrategy(o)}}var o=e(48),i=e(50),a=e(59),s=e(62),l=e(77),c=e(79),u=e(81),d=e(135),p=e(116),f=e(142)
t.exports={renderToString:n,renderToStaticMarkup:r}},{116:116,135:135,142:142,48:48,50:50,59:59,62:62,77:77,79:79,81:81}],79:[function(e,t){"use strict"
function n(e){this.reinitializeTransaction(),this.renderToStaticMarkup=e,this.reactMountReady=o.getPooled(null),this.useCreateElement=!1}var r=e(24),o=e(6),i=e(98),a=e(23),s=e(134),l={initialize:function(){this.reactMountReady.reset()},close:s},c=[l],u={getTransactionWrappers:function(){return c},getReactMountReady:function(){return this.reactMountReady},destructor:function(){o.release(this.reactMountReady),this.reactMountReady=null}}
a(n.prototype,i.Mixin,u),r.addPoolingTo(n),t.exports=n},{134:134,23:23,24:24,6:6,98:98}],80:[function(e,t){"use strict"
function n(e){a.enqueueUpdate(e)}function r(e){var t=i.get(e)
return t?t:null}var o=(e(34),e(50)),i=e(60),a=e(81),s=e(23),l=e(142),c=(e(151),{isMounted:function(e){var t=i.get(e)
return t?!!t._renderedComponent:!1},enqueueCallback:function(e,t){"function"!=typeof t?l(!1):void 0
var o=r(e)
return o?(o._pendingCallbacks?o._pendingCallbacks.push(t):o._pendingCallbacks=[t],void n(o)):null},enqueueCallbackInternal:function(e,t){"function"!=typeof t?l(!1):void 0,e._pendingCallbacks?e._pendingCallbacks.push(t):e._pendingCallbacks=[t],n(e)},enqueueForceUpdate:function(e){var t=r(e,"forceUpdate")
t&&(t._pendingForceUpdate=!0,n(t))},enqueueReplaceState:function(e,t){var o=r(e,"replaceState")
o&&(o._pendingStateQueue=[t],o._pendingReplaceState=!0,n(o))},enqueueSetState:function(e,t){var o=r(e,"setState")
if(o){var i=o._pendingStateQueue||(o._pendingStateQueue=[])
i.push(t),n(o)}},enqueueSetProps:function(e,t){var n=r(e,"setProps")
n&&c.enqueueSetPropsInternal(n,t)},enqueueSetPropsInternal:function(e,t){var r=e._topLevelWrapper
r?void 0:l(!1)
var i=r._pendingElement||r._currentElement,a=i.props,c=s({},a.props,t)
r._pendingElement=o.cloneAndReplaceProps(i,o.cloneAndReplaceProps(a,c)),n(r)},enqueueReplaceProps:function(e,t){var n=r(e,"replaceProps")
n&&c.enqueueReplacePropsInternal(n,t)},enqueueReplacePropsInternal:function(e,t){var r=e._topLevelWrapper
r?void 0:l(!1)
var i=r._pendingElement||r._currentElement,a=i.props
r._pendingElement=o.cloneAndReplaceProps(i,o.cloneAndReplaceProps(a,t)),n(r)},enqueueElementInternal:function(e,t){e._pendingElement=t,n(e)}})
t.exports=c},{142:142,151:151,23:23,34:34,50:50,60:60,81:81}],81:[function(e,t){"use strict"
function n(){S.ReactReconcileTransaction&&b?void 0:m(!1)}function r(){this.reinitializeTransaction(),this.dirtyComponentsLength=null,this.callbackQueue=c.getPooled(),this.reconcileTransaction=S.ReactReconcileTransaction.getPooled(!1)}function o(e,t,r,o,i,a){n(),b.batchedUpdates(e,t,r,o,i,a)}function i(e,t){return e._mountOrder-t._mountOrder}function a(e){var t=e.dirtyComponentsLength
t!==g.length?m(!1):void 0,g.sort(i)
for(var n=0;t>n;n++){var r=g[n],o=r._pendingCallbacks
if(r._pendingCallbacks=null,p.performUpdateIfNecessary(r,e.reconcileTransaction),o)for(var a=0;a<o.length;a++)e.callbackQueue.enqueue(o[a],r.getPublicInstance())}}function s(e){return n(),b.isBatchingUpdates?void g.push(e):void b.batchedUpdates(s,e)}function l(e,t){b.isBatchingUpdates?void 0:m(!1),v.enqueue(e,t),y=!0}var c=e(6),u=e(24),d=e(69),p=e(74),f=e(98),h=e(23),m=e(142),g=[],v=c.getPooled(),y=!1,b=null,w={initialize:function(){this.dirtyComponentsLength=g.length},close:function(){this.dirtyComponentsLength!==g.length?(g.splice(0,this.dirtyComponentsLength),C()):g.length=0}},_={initialize:function(){this.callbackQueue.reset()},close:function(){this.callbackQueue.notifyAll()}},E=[w,_]
h(r.prototype,f.Mixin,{getTransactionWrappers:function(){return E},destructor:function(){this.dirtyComponentsLength=null,c.release(this.callbackQueue),this.callbackQueue=null,S.ReactReconcileTransaction.release(this.reconcileTransaction),this.reconcileTransaction=null},perform:function(e,t,n){return f.Mixin.perform.call(this,this.reconcileTransaction.perform,this.reconcileTransaction,e,t,n)}}),u.addPoolingTo(r)
var C=function(){for(;g.length||y;){if(g.length){var e=r.getPooled()
e.perform(a,null,e),r.release(e)}if(y){y=!1
var t=v
v=c.getPooled(),t.notifyAll(),c.release(t)}}}
C=d.measure("ReactUpdates","flushBatchedUpdates",C)
var x={injectReconcileTransaction:function(e){e?void 0:m(!1),S.ReactReconcileTransaction=e},injectBatchingStrategy:function(e){e?void 0:m(!1),"function"!=typeof e.batchedUpdates?m(!1):void 0,"boolean"!=typeof e.isBatchingUpdates?m(!1):void 0,b=e}},S={ReactReconcileTransaction:null,batchedUpdates:o,enqueueUpdate:s,flushBatchedUpdates:C,injection:x,asap:l}
t.exports=S},{142:142,23:23,24:24,6:6,69:69,74:74,98:98}],82:[function(e,t){"use strict"
t.exports="0.14.8"},{}],83:[function(e,t){"use strict"
var n=e(10),r=n.injection.MUST_USE_ATTRIBUTE,o={xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace"},i={Properties:{clipPath:r,cx:r,cy:r,d:r,dx:r,dy:r,fill:r,fillOpacity:r,fontFamily:r,fontSize:r,fx:r,fy:r,gradientTransform:r,gradientUnits:r,markerEnd:r,markerMid:r,markerStart:r,offset:r,opacity:r,patternContentUnits:r,patternUnits:r,points:r,preserveAspectRatio:r,r:r,rx:r,ry:r,spreadMethod:r,stopColor:r,stopOpacity:r,stroke:r,strokeDasharray:r,strokeLinecap:r,strokeOpacity:r,strokeWidth:r,textAnchor:r,transform:r,version:r,viewBox:r,x1:r,x2:r,x:r,xlinkActuate:r,xlinkArcrole:r,xlinkHref:r,xlinkRole:r,xlinkShow:r,xlinkTitle:r,xlinkType:r,xmlBase:r,xmlLang:r,xmlSpace:r,y1:r,y2:r,y:r},DOMAttributeNamespaces:{xlinkActuate:o.xlink,xlinkArcrole:o.xlink,xlinkHref:o.xlink,xlinkRole:o.xlink,xlinkShow:o.xlink,xlinkTitle:o.xlink,xlinkType:o.xlink,xmlBase:o.xml,xmlLang:o.xml,xmlSpace:o.xml},DOMAttributeNames:{clipPath:"clip-path",fillOpacity:"fill-opacity",fontFamily:"font-family",fontSize:"font-size",gradientTransform:"gradientTransform",gradientUnits:"gradientUnits",markerEnd:"marker-end",markerMid:"marker-mid",markerStart:"marker-start",patternContentUnits:"patternContentUnits",patternUnits:"patternUnits",preserveAspectRatio:"preserveAspectRatio",spreadMethod:"spreadMethod",stopColor:"stop-color",stopOpacity:"stop-opacity",strokeDasharray:"stroke-dasharray",strokeLinecap:"stroke-linecap",strokeOpacity:"stroke-opacity",strokeWidth:"stroke-width",textAnchor:"text-anchor",viewBox:"viewBox",xlinkActuate:"xlink:actuate",xlinkArcrole:"xlink:arcrole",xlinkHref:"xlink:href",xlinkRole:"xlink:role",xlinkShow:"xlink:show",xlinkTitle:"xlink:title",xlinkType:"xlink:type",xmlBase:"xml:base",xmlLang:"xml:lang",xmlSpace:"xml:space"}}
t.exports=i},{10:10}],84:[function(e,t){"use strict"
function n(e){if("selectionStart"in e&&s.hasSelectionCapabilities(e))return{start:e.selectionStart,end:e.selectionEnd}
if(window.getSelection){var t=window.getSelection()
return{anchorNode:t.anchorNode,anchorOffset:t.anchorOffset,focusNode:t.focusNode,focusOffset:t.focusOffset}}if(document.selection){var n=document.selection.createRange()
return{parentElement:n.parentElement(),text:n.text,top:n.boundingTop,left:n.boundingLeft}}}function r(e,t){if(b||null==g||g!==c())return null
var r=n(g)
if(!y||!p(y,r)){y=r
var o=l.getPooled(m.select,v,e,t)
return o.type="select",o.target=g,i.accumulateTwoPhaseDispatches(o),o}return null}var o=e(15),i=e(19),a=e(128),s=e(58),l=e(90),c=e(137),u=e(118),d=e(146),p=e(149),f=o.topLevelTypes,h=a.canUseDOM&&"documentMode"in document&&document.documentMode<=11,m={select:{phasedRegistrationNames:{bubbled:d({onSelect:null}),captured:d({onSelectCapture:null})},dependencies:[f.topBlur,f.topContextMenu,f.topFocus,f.topKeyDown,f.topMouseDown,f.topMouseUp,f.topSelectionChange]}},g=null,v=null,y=null,b=!1,w=!1,_=d({onSelect:null}),E={eventTypes:m,extractEvents:function(e,t,n,o,i){if(!w)return null
switch(e){case f.topFocus:(u(t)||"true"===t.contentEditable)&&(g=t,v=n,y=null)
break
case f.topBlur:g=null,v=null,y=null
break
case f.topMouseDown:b=!0
break
case f.topContextMenu:case f.topMouseUp:return b=!1,r(o,i)
case f.topSelectionChange:if(h)break
case f.topKeyDown:case f.topKeyUp:return r(o,i)}return null},didPutListener:function(e,t){t===_&&(w=!0)}}
t.exports=E},{118:118,128:128,137:137,146:146,149:149,15:15,19:19,58:58,90:90}],85:[function(e,t){"use strict"
var n=Math.pow(2,53),r={createReactRootIndex:function(){return Math.ceil(Math.random()*n)}}
t.exports=r},{}],86:[function(e,t){"use strict"
var n=e(15),r=e(127),o=e(19),i=e(63),a=e(87),s=e(90),l=e(91),c=e(93),u=e(94),d=e(89),p=e(95),f=e(96),h=e(97),m=e(134),g=e(109),v=e(142),y=e(146),b=n.topLevelTypes,w={abort:{phasedRegistrationNames:{bubbled:y({onAbort:!0}),captured:y({onAbortCapture:!0})}},blur:{phasedRegistrationNames:{bubbled:y({onBlur:!0}),captured:y({onBlurCapture:!0})}},canPlay:{phasedRegistrationNames:{bubbled:y({onCanPlay:!0}),captured:y({onCanPlayCapture:!0})}},canPlayThrough:{phasedRegistrationNames:{bubbled:y({onCanPlayThrough:!0}),captured:y({onCanPlayThroughCapture:!0})}},click:{phasedRegistrationNames:{bubbled:y({onClick:!0}),captured:y({onClickCapture:!0})}},contextMenu:{phasedRegistrationNames:{bubbled:y({onContextMenu:!0}),captured:y({onContextMenuCapture:!0})}},copy:{phasedRegistrationNames:{bubbled:y({onCopy:!0}),captured:y({onCopyCapture:!0})}},cut:{phasedRegistrationNames:{bubbled:y({onCut:!0}),captured:y({onCutCapture:!0})}},doubleClick:{phasedRegistrationNames:{bubbled:y({onDoubleClick:!0}),captured:y({onDoubleClickCapture:!0})}},drag:{phasedRegistrationNames:{bubbled:y({onDrag:!0}),captured:y({onDragCapture:!0})}},dragEnd:{phasedRegistrationNames:{bubbled:y({onDragEnd:!0}),captured:y({onDragEndCapture:!0})}},dragEnter:{phasedRegistrationNames:{bubbled:y({onDragEnter:!0}),captured:y({onDragEnterCapture:!0})}},dragExit:{phasedRegistrationNames:{bubbled:y({onDragExit:!0}),captured:y({onDragExitCapture:!0})}},dragLeave:{phasedRegistrationNames:{bubbled:y({onDragLeave:!0}),captured:y({onDragLeaveCapture:!0})}},dragOver:{phasedRegistrationNames:{bubbled:y({onDragOver:!0}),captured:y({onDragOverCapture:!0})}},dragStart:{phasedRegistrationNames:{bubbled:y({onDragStart:!0}),captured:y({onDragStartCapture:!0})}},drop:{phasedRegistrationNames:{bubbled:y({onDrop:!0}),captured:y({onDropCapture:!0})}},durationChange:{phasedRegistrationNames:{bubbled:y({onDurationChange:!0}),captured:y({onDurationChangeCapture:!0})}},emptied:{phasedRegistrationNames:{bubbled:y({onEmptied:!0}),captured:y({onEmptiedCapture:!0})}},encrypted:{phasedRegistrationNames:{bubbled:y({onEncrypted:!0}),captured:y({onEncryptedCapture:!0})}},ended:{phasedRegistrationNames:{bubbled:y({onEnded:!0}),captured:y({onEndedCapture:!0})}},error:{phasedRegistrationNames:{bubbled:y({onError:!0}),captured:y({onErrorCapture:!0})}},focus:{phasedRegistrationNames:{bubbled:y({onFocus:!0}),captured:y({onFocusCapture:!0})}},input:{phasedRegistrationNames:{bubbled:y({onInput:!0}),captured:y({onInputCapture:!0})}},keyDown:{phasedRegistrationNames:{bubbled:y({onKeyDown:!0}),captured:y({onKeyDownCapture:!0})}},keyPress:{phasedRegistrationNames:{bubbled:y({onKeyPress:!0}),captured:y({onKeyPressCapture:!0})}},keyUp:{phasedRegistrationNames:{bubbled:y({onKeyUp:!0}),captured:y({onKeyUpCapture:!0})}},load:{phasedRegistrationNames:{bubbled:y({onLoad:!0}),captured:y({onLoadCapture:!0})}},loadedData:{phasedRegistrationNames:{bubbled:y({onLoadedData:!0}),captured:y({onLoadedDataCapture:!0})}},loadedMetadata:{phasedRegistrationNames:{bubbled:y({onLoadedMetadata:!0}),captured:y({onLoadedMetadataCapture:!0})}},loadStart:{phasedRegistrationNames:{bubbled:y({onLoadStart:!0}),captured:y({onLoadStartCapture:!0})}},mouseDown:{phasedRegistrationNames:{bubbled:y({onMouseDown:!0}),captured:y({onMouseDownCapture:!0})}},mouseMove:{phasedRegistrationNames:{bubbled:y({onMouseMove:!0}),captured:y({onMouseMoveCapture:!0})}},mouseOut:{phasedRegistrationNames:{bubbled:y({onMouseOut:!0}),captured:y({onMouseOutCapture:!0})}},mouseOver:{phasedRegistrationNames:{bubbled:y({onMouseOver:!0}),captured:y({onMouseOverCapture:!0})}},mouseUp:{phasedRegistrationNames:{bubbled:y({onMouseUp:!0}),captured:y({onMouseUpCapture:!0})}},paste:{phasedRegistrationNames:{bubbled:y({onPaste:!0}),captured:y({onPasteCapture:!0})}},pause:{phasedRegistrationNames:{bubbled:y({onPause:!0}),captured:y({onPauseCapture:!0})}},play:{phasedRegistrationNames:{bubbled:y({onPlay:!0}),captured:y({onPlayCapture:!0})}},playing:{phasedRegistrationNames:{bubbled:y({onPlaying:!0}),captured:y({onPlayingCapture:!0})}},progress:{phasedRegistrationNames:{bubbled:y({onProgress:!0}),captured:y({onProgressCapture:!0})}},rateChange:{phasedRegistrationNames:{bubbled:y({onRateChange:!0}),captured:y({onRateChangeCapture:!0})}},reset:{phasedRegistrationNames:{bubbled:y({onReset:!0}),captured:y({onResetCapture:!0})}},scroll:{phasedRegistrationNames:{bubbled:y({onScroll:!0}),captured:y({onScrollCapture:!0})}},seeked:{phasedRegistrationNames:{bubbled:y({onSeeked:!0}),captured:y({onSeekedCapture:!0})}},seeking:{phasedRegistrationNames:{bubbled:y({onSeeking:!0}),captured:y({onSeekingCapture:!0})}},stalled:{phasedRegistrationNames:{bubbled:y({onStalled:!0}),captured:y({onStalledCapture:!0})}},submit:{phasedRegistrationNames:{bubbled:y({onSubmit:!0}),captured:y({onSubmitCapture:!0})}},suspend:{phasedRegistrationNames:{bubbled:y({onSuspend:!0}),captured:y({onSuspendCapture:!0})}},timeUpdate:{phasedRegistrationNames:{bubbled:y({onTimeUpdate:!0}),captured:y({onTimeUpdateCapture:!0})}},touchCancel:{phasedRegistrationNames:{bubbled:y({onTouchCancel:!0}),captured:y({onTouchCancelCapture:!0})}},touchEnd:{phasedRegistrationNames:{bubbled:y({onTouchEnd:!0}),captured:y({onTouchEndCapture:!0})}},touchMove:{phasedRegistrationNames:{bubbled:y({onTouchMove:!0}),captured:y({onTouchMoveCapture:!0})}},touchStart:{phasedRegistrationNames:{bubbled:y({onTouchStart:!0}),captured:y({onTouchStartCapture:!0})}},volumeChange:{phasedRegistrationNames:{bubbled:y({onVolumeChange:!0}),captured:y({onVolumeChangeCapture:!0})}},waiting:{phasedRegistrationNames:{bubbled:y({onWaiting:!0}),captured:y({onWaitingCapture:!0})}},wheel:{phasedRegistrationNames:{bubbled:y({onWheel:!0}),captured:y({onWheelCapture:!0})}}},_={topAbort:w.abort,topBlur:w.blur,topCanPlay:w.canPlay,topCanPlayThrough:w.canPlayThrough,topClick:w.click,topContextMenu:w.contextMenu,topCopy:w.copy,topCut:w.cut,topDoubleClick:w.doubleClick,topDrag:w.drag,topDragEnd:w.dragEnd,topDragEnter:w.dragEnter,topDragExit:w.dragExit,topDragLeave:w.dragLeave,topDragOver:w.dragOver,topDragStart:w.dragStart,topDrop:w.drop,topDurationChange:w.durationChange,topEmptied:w.emptied,topEncrypted:w.encrypted,topEnded:w.ended,topError:w.error,topFocus:w.focus,topInput:w.input,topKeyDown:w.keyDown,topKeyPress:w.keyPress,topKeyUp:w.keyUp,topLoad:w.load,topLoadedData:w.loadedData,topLoadedMetadata:w.loadedMetadata,topLoadStart:w.loadStart,topMouseDown:w.mouseDown,topMouseMove:w.mouseMove,topMouseOut:w.mouseOut,topMouseOver:w.mouseOver,topMouseUp:w.mouseUp,topPaste:w.paste,topPause:w.pause,topPlay:w.play,topPlaying:w.playing,topProgress:w.progress,topRateChange:w.rateChange,topReset:w.reset,topScroll:w.scroll,topSeeked:w.seeked,topSeeking:w.seeking,topStalled:w.stalled,topSubmit:w.submit,topSuspend:w.suspend,topTimeUpdate:w.timeUpdate,topTouchCancel:w.touchCancel,topTouchEnd:w.touchEnd,topTouchMove:w.touchMove,topTouchStart:w.touchStart,topVolumeChange:w.volumeChange,topWaiting:w.waiting,topWheel:w.wheel}
for(var E in _)_[E].dependencies=[E]
var C=y({onClick:null}),x={},S={eventTypes:w,extractEvents:function(e,t,n,r,i){var m=_[e]
if(!m)return null
var y
switch(e){case b.topAbort:case b.topCanPlay:case b.topCanPlayThrough:case b.topDurationChange:case b.topEmptied:case b.topEncrypted:case b.topEnded:case b.topError:case b.topInput:case b.topLoad:case b.topLoadedData:case b.topLoadedMetadata:case b.topLoadStart:case b.topPause:case b.topPlay:case b.topPlaying:case b.topProgress:case b.topRateChange:case b.topReset:case b.topSeeked:case b.topSeeking:case b.topStalled:case b.topSubmit:case b.topSuspend:case b.topTimeUpdate:case b.topVolumeChange:case b.topWaiting:y=s
break
case b.topKeyPress:if(0===g(r))return null
case b.topKeyDown:case b.topKeyUp:y=c
break
case b.topBlur:case b.topFocus:y=l
break
case b.topClick:if(2===r.button)return null
case b.topContextMenu:case b.topDoubleClick:case b.topMouseDown:case b.topMouseMove:case b.topMouseOut:case b.topMouseOver:case b.topMouseUp:y=u
break
case b.topDrag:case b.topDragEnd:case b.topDragEnter:case b.topDragExit:case b.topDragLeave:case b.topDragOver:case b.topDragStart:case b.topDrop:y=d
break
case b.topTouchCancel:case b.topTouchEnd:case b.topTouchMove:case b.topTouchStart:y=p
break
case b.topScroll:y=f
break
case b.topWheel:y=h
break
case b.topCopy:case b.topCut:case b.topPaste:y=a}y?void 0:v(!1)
var w=y.getPooled(m,n,r,i)
return o.accumulateTwoPhaseDispatches(w),w},didPutListener:function(e,t){if(t===C){var n=i.getNode(e)
x[e]||(x[e]=r.listen(n,"click",m))}},willDeleteListener:function(e,t){t===C&&(x[e].remove(),delete x[e])}}
t.exports=S},{109:109,127:127,134:134,142:142,146:146,15:15,19:19,63:63,87:87,89:89,90:90,91:91,93:93,94:94,95:95,96:96,97:97}],87:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(90),o={clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}
r.augmentClass(n,o),t.exports=n},{90:90}],88:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(90),o={data:null}
r.augmentClass(n,o),t.exports=n},{90:90}],89:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(94),o={dataTransfer:null}
r.augmentClass(n,o),t.exports=n},{94:94}],90:[function(e,t){"use strict"
function n(e,t,n,r){this.dispatchConfig=e,this.dispatchMarker=t,this.nativeEvent=n
var o=this.constructor.Interface
for(var a in o)if(o.hasOwnProperty(a)){var s=o[a]
s?this[a]=s(n):"target"===a?this.target=r:this[a]=n[a]}var l=null!=n.defaultPrevented?n.defaultPrevented:n.returnValue===!1
this.isDefaultPrevented=l?i.thatReturnsTrue:i.thatReturnsFalse,this.isPropagationStopped=i.thatReturnsFalse}var r=e(24),o=e(23),i=e(134),a=(e(151),{type:null,target:null,currentTarget:i.thatReturnsNull,eventPhase:null,bubbles:null,cancelable:null,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:null,isTrusted:null})
o(n.prototype,{preventDefault:function(){this.defaultPrevented=!0
var e=this.nativeEvent
e&&(e.preventDefault?e.preventDefault():e.returnValue=!1,this.isDefaultPrevented=i.thatReturnsTrue)},stopPropagation:function(){var e=this.nativeEvent
e&&(e.stopPropagation?e.stopPropagation():e.cancelBubble=!0,this.isPropagationStopped=i.thatReturnsTrue)},persist:function(){this.isPersistent=i.thatReturnsTrue},isPersistent:i.thatReturnsFalse,destructor:function(){var e=this.constructor.Interface
for(var t in e)this[t]=null
this.dispatchConfig=null,this.dispatchMarker=null,this.nativeEvent=null}}),n.Interface=a,n.augmentClass=function(e,t){var n=this,i=Object.create(n.prototype)
o(i,e.prototype),e.prototype=i,e.prototype.constructor=e,e.Interface=o({},n.Interface,t),e.augmentClass=n.augmentClass,r.addPoolingTo(e,r.fourArgumentPooler)},r.addPoolingTo(n,r.fourArgumentPooler),t.exports=n},{134:134,151:151,23:23,24:24}],91:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(96),o={relatedTarget:null}
r.augmentClass(n,o),t.exports=n},{96:96}],92:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(90),o={data:null}
r.augmentClass(n,o),t.exports=n},{90:90}],93:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(96),o=e(109),i=e(110),a=e(111),s={key:i,location:null,ctrlKey:null,shiftKey:null,altKey:null,metaKey:null,repeat:null,locale:null,getModifierState:a,charCode:function(e){return"keypress"===e.type?o(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?o(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}}
r.augmentClass(n,s),t.exports=n},{109:109,110:110,111:111,96:96}],94:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(96),o=e(99),i=e(111),a={screenX:null,screenY:null,clientX:null,clientY:null,ctrlKey:null,shiftKey:null,altKey:null,metaKey:null,getModifierState:i,button:function(e){var t=e.button
return"which"in e?t:2===t?2:4===t?1:0},buttons:null,relatedTarget:function(e){return e.relatedTarget||(e.fromElement===e.srcElement?e.toElement:e.fromElement)},pageX:function(e){return"pageX"in e?e.pageX:e.clientX+o.currentScrollLeft},pageY:function(e){return"pageY"in e?e.pageY:e.clientY+o.currentScrollTop}}
r.augmentClass(n,a),t.exports=n},{111:111,96:96,99:99}],95:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(96),o=e(111),i={touches:null,targetTouches:null,changedTouches:null,altKey:null,metaKey:null,ctrlKey:null,shiftKey:null,getModifierState:o}
r.augmentClass(n,i),t.exports=n},{111:111,96:96}],96:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(90),o=e(112),i={view:function(e){if(e.view)return e.view
var t=o(e)
if(null!=t&&t.window===t)return t
var n=t.ownerDocument
return n?n.defaultView||n.parentWindow:window},detail:function(e){return e.detail||0}}
r.augmentClass(n,i),t.exports=n},{112:112,90:90}],97:[function(e,t){"use strict"
function n(e,t,n,o){r.call(this,e,t,n,o)}var r=e(94),o={deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:null,deltaMode:null}
r.augmentClass(n,o),t.exports=n},{94:94}],98:[function(e,t){"use strict"
var n=e(142),r={reinitializeTransaction:function(){this.transactionWrappers=this.getTransactionWrappers(),this.wrapperInitData?this.wrapperInitData.length=0:this.wrapperInitData=[],this._isInTransaction=!1},_isInTransaction:!1,getTransactionWrappers:null,isInTransaction:function(){return!!this._isInTransaction},perform:function(e,t,r,o,i,a,s,l){this.isInTransaction()?n(!1):void 0
var c,u
try{this._isInTransaction=!0,c=!0,this.initializeAll(0),u=e.call(t,r,o,i,a,s,l),c=!1}finally{try{if(c)try{this.closeAll(0)}catch(d){}else this.closeAll(0)}finally{this._isInTransaction=!1}}return u},initializeAll:function(e){for(var t=this.transactionWrappers,n=e;n<t.length;n++){var r=t[n]
try{this.wrapperInitData[n]=o.OBSERVED_ERROR,this.wrapperInitData[n]=r.initialize?r.initialize.call(this):null}finally{if(this.wrapperInitData[n]===o.OBSERVED_ERROR)try{this.initializeAll(n+1)}catch(i){}}}},closeAll:function(e){this.isInTransaction()?void 0:n(!1)
for(var t=this.transactionWrappers,r=e;r<t.length;r++){var i,a=t[r],s=this.wrapperInitData[r]
try{i=!0,s!==o.OBSERVED_ERROR&&a.close&&a.close.call(this,s),i=!1}finally{if(i)try{this.closeAll(r+1)}catch(l){}}}this.wrapperInitData.length=0}},o={Mixin:r,OBSERVED_ERROR:{}}
t.exports=o},{142:142}],99:[function(e,t){"use strict"
var n={currentScrollLeft:0,currentScrollTop:0,refreshScrollValues:function(e){n.currentScrollLeft=e.x,n.currentScrollTop=e.y}}
t.exports=n},{}],100:[function(e,t){"use strict"
function n(e,t){if(null==t?r(!1):void 0,null==e)return t
var n=Array.isArray(e),o=Array.isArray(t)
return n&&o?(e.push.apply(e,t),e):n?(e.push(t),e):o?[e].concat(t):[e,t]}var r=e(142)
t.exports=n},{142:142}],101:[function(e,t){"use strict"
function n(e){for(var t=1,n=0,o=0,i=e.length,a=-4&i;a>o;){for(;o<Math.min(o+4096,a);o+=4)n+=(t+=e.charCodeAt(o))+(t+=e.charCodeAt(o+1))+(t+=e.charCodeAt(o+2))+(t+=e.charCodeAt(o+3))
t%=r,n%=r}for(;i>o;o++)n+=t+=e.charCodeAt(o)
return t%=r,n%=r,t|n<<16}var r=65521
t.exports=n},{}],102:[function(e,t){"use strict"
var n=!1
t.exports=n},{}],103:[function(e,t){"use strict"
function n(e,t){var n=null==t||"boolean"==typeof t||""===t
if(n)return""
var r=isNaN(t)
return r||0===t||o.hasOwnProperty(e)&&o[e]?""+t:("string"==typeof t&&(t=t.trim()),t+"px")}var r=e(4),o=r.isUnitlessNumber
t.exports=n},{4:4}],104:[function(e,t){"use strict"
function n(e,t,n,r,o){return o}e(23),e(151),t.exports=n},{151:151,23:23}],105:[function(e,t){"use strict"
function n(e){return o[e]}function r(e){return(""+e).replace(i,n)}var o={"&":"&amp;",">":"&gt;","<":"&lt;",'"':"&quot;","'":"&#x27;"},i=/[&><"']/g
t.exports=r},{}],106:[function(e,t){"use strict"
function n(e){return null==e?null:1===e.nodeType?e:r.has(e)?o.getNodeFromInstance(e):(null!=e.render&&"function"==typeof e.render?i(!1):void 0,void i(!1))}var r=(e(34),e(60)),o=e(63),i=e(142)
e(151),t.exports=n},{142:142,151:151,34:34,60:60,63:63}],107:[function(e,t){"use strict"
function n(e,t,n){var r=e,o=void 0===r[n]
o&&null!=t&&(r[n]=t)}function r(e){if(null==e)return e
var t={}
return o(e,n,t),t}var o=e(125)
e(151),t.exports=r},{125:125,151:151}],108:[function(e,t){"use strict"
var n=function(e,t,n){Array.isArray(e)?e.forEach(t,n):e&&t.call(n,e)}
t.exports=n},{}],109:[function(e,t){"use strict"
function n(e){var t,n=e.keyCode
return"charCode"in e?(t=e.charCode,0===t&&13===n&&(t=13)):t=n,t>=32||13===t?t:0}t.exports=n},{}],110:[function(e,t){"use strict"
function n(e){if(e.key){var t=o[e.key]||e.key
if("Unidentified"!==t)return t}if("keypress"===e.type){var n=r(e)
return 13===n?"Enter":String.fromCharCode(n)}return"keydown"===e.type||"keyup"===e.type?i[e.keyCode]||"Unidentified":""}var r=e(109),o={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},i={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"}
t.exports=n},{109:109}],111:[function(e,t){"use strict"
function n(e){var t=this,n=t.nativeEvent
if(n.getModifierState)return n.getModifierState(e)
var r=o[e]
return r?!!n[r]:!1}function r(){return n}var o={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"}
t.exports=r},{}],112:[function(e,t){"use strict"
function n(e){var t=e.target||e.srcElement||window
return 3===t.nodeType?t.parentNode:t}t.exports=n},{}],113:[function(e,t){"use strict"
function n(e){var t=e&&(r&&e[r]||e[o])
return"function"==typeof t?t:void 0}var r="function"==typeof Symbol&&Symbol.iterator,o="@@iterator"
t.exports=n},{}],114:[function(e,t){"use strict"
function n(e){for(;e&&e.firstChild;)e=e.firstChild
return e}function r(e){for(;e;){if(e.nextSibling)return e.nextSibling
e=e.parentNode}}function o(e,t){for(var o=n(e),i=0,a=0;o;){if(3===o.nodeType){if(a=i+o.textContent.length,t>=i&&a>=t)return{node:o,offset:t-i}
i=a}o=n(r(o))}}t.exports=o},{}],115:[function(e,t){"use strict"
function n(){return!o&&r.canUseDOM&&(o="textContent"in document.documentElement?"textContent":"innerText"),o}var r=e(128),o=null
t.exports=n},{128:128}],116:[function(e,t){"use strict"
function n(e){return"function"==typeof e&&"undefined"!=typeof e.prototype&&"function"==typeof e.prototype.mountComponent&&"function"==typeof e.prototype.receiveComponent}function r(e){var t
if(null===e||e===!1)t=new i(r)
else if("object"==typeof e){var o=e
!o||"function"!=typeof o.type&&"string"!=typeof o.type?l(!1):void 0,t="string"==typeof o.type?a.createInternalComponent(o):n(o.type)?new o.type(o):new c}else"string"==typeof e||"number"==typeof e?t=a.createInstanceForText(e):l(!1)
return t.construct(e),t._mountIndex=0,t._mountImage=null,t}var o=e(33),i=e(52),a=e(66),s=e(23),l=e(142),c=(e(151),function(){})
s(c.prototype,o.Mixin,{_instantiateReactComponent:r}),t.exports=r},{142:142,151:151,23:23,33:33,52:52,66:66}],117:[function(e,t){"use strict"
function n(e,t){if(!o.canUseDOM||t&&!("addEventListener"in document))return!1
var n="on"+e,i=n in document
if(!i){var a=document.createElement("div")
a.setAttribute(n,"return;"),i="function"==typeof a[n]}return!i&&r&&"wheel"===e&&(i=document.implementation.hasFeature("Events.wheel","3.0")),i}var r,o=e(128)
o.canUseDOM&&(r=document.implementation&&document.implementation.hasFeature&&document.implementation.hasFeature("","")!==!0),t.exports=n},{128:128}],118:[function(e,t){"use strict"
function n(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase()
return t&&("input"===t&&r[e.type]||"textarea"===t)}var r={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0}
t.exports=n},{}],119:[function(e,t){"use strict"
function n(e){return r.isValidElement(e)?void 0:o(!1),e}var r=e(50),o=e(142)
t.exports=n},{142:142,50:50}],120:[function(e,t){"use strict"
function n(e){return'"'+r(e)+'"'}var r=e(105)
t.exports=n},{105:105}],121:[function(e,t){"use strict"
var n=e(63)
t.exports=n.renderSubtreeIntoContainer},{63:63}],122:[function(e,t){"use strict"
var n=e(128),r=/^[ \r\n\t\f]/,o=/<(!--|link|noscript|meta|script|style)[ \r\n\t\f\/>]/,i=function(e,t){e.innerHTML=t}
if("undefined"!=typeof MSApp&&MSApp.execUnsafeLocalFunction&&(i=function(e,t){MSApp.execUnsafeLocalFunction(function(){e.innerHTML=t})}),n.canUseDOM){var a=document.createElement("div")
a.innerHTML=" ",""===a.innerHTML&&(i=function(e,t){if(e.parentNode&&e.parentNode.replaceChild(e,e),r.test(t)||"<"===t[0]&&o.test(t)){e.innerHTML=String.fromCharCode(65279)+t
var n=e.firstChild
1===n.data.length?e.removeChild(n):n.deleteData(0,1)}else e.innerHTML=t})}t.exports=i},{128:128}],123:[function(e,t){"use strict"
var n=e(128),r=e(105),o=e(122),i=function(e,t){e.textContent=t}
n.canUseDOM&&("textContent"in document.documentElement||(i=function(e,t){o(e,r(t))})),t.exports=i},{105:105,122:122,128:128}],124:[function(e,t){"use strict"
function n(e,t){var n=null===e||e===!1,r=null===t||t===!1
if(n||r)return n===r
var o=typeof e,i=typeof t
return"string"===o||"number"===o?"string"===i||"number"===i:"object"===i&&e.type===t.type&&e.key===t.key}t.exports=n},{}],125:[function(e,t){"use strict"
function n(e){return h[e]}function r(e,t){return e&&null!=e.key?i(e.key):t.toString(36)}function o(e){return(""+e).replace(m,n)}function i(e){return"$"+o(e)}function a(e,t,n,o){var s=typeof e
if(("undefined"===s||"boolean"===s)&&(e=null),null===e||"string"===s||"number"===s||l.isValidElement(e))return n(o,e,""===t?p+r(e,0):t),1
var c,h,m=0,g=""===t?p:t+f
if(Array.isArray(e))for(var v=0;v<e.length;v++)c=e[v],h=g+r(c,v),m+=a(c,h,n,o)
else{var y=u(e)
if(y){var b,w=y.call(e)
if(y!==e.entries)for(var _=0;!(b=w.next()).done;)c=b.value,h=g+r(c,_++),m+=a(c,h,n,o)
else for(;!(b=w.next()).done;){var E=b.value
E&&(c=E[1],h=g+i(E[0])+f+r(c,0),m+=a(c,h,n,o))}}else"object"===s&&(String(e),d(!1))}return m}function s(e,t,n){return null==e?0:a(e,"",t,n)}var l=(e(34),e(50)),c=e(59),u=e(113),d=e(142),p=(e(151),c.SEPARATOR),f=":",h={"=":"=0",".":"=1",":":"=2"},m=/[=.:]/g
t.exports=s},{113:113,142:142,151:151,34:34,50:50,59:59}],126:[function(e,t){"use strict"
var n=(e(23),e(134)),r=(e(151),n)
t.exports=r},{134:134,151:151,23:23}],127:[function(e,t){"use strict"
var n=e(134),r={listen:function(e,t,n){return e.addEventListener?(e.addEventListener(t,n,!1),{remove:function(){e.removeEventListener(t,n,!1)}}):e.attachEvent?(e.attachEvent("on"+t,n),{remove:function(){e.detachEvent("on"+t,n)}}):void 0},capture:function(e,t,r){return e.addEventListener?(e.addEventListener(t,r,!0),{remove:function(){e.removeEventListener(t,r,!0)}}):{remove:n}},registerDefault:function(){}}
t.exports=r},{134:134}],128:[function(e,t){"use strict"
var n=!("undefined"==typeof window||!window.document||!window.document.createElement),r={canUseDOM:n,canUseWorkers:"undefined"!=typeof Worker,canUseEventListeners:n&&!(!window.addEventListener&&!window.attachEvent),canUseViewport:n&&!!window.screen,isInWorker:!n}
t.exports=r},{}],129:[function(e,t){"use strict"
function n(e){return e.replace(r,function(e,t){return t.toUpperCase()})}var r=/-(.)/g
t.exports=n},{}],130:[function(e,t){"use strict"
function n(e){return r(e.replace(o,"ms-"))}var r=e(129),o=/^-ms-/
t.exports=n},{129:129}],131:[function(e,t){"use strict"
function n(e,t){var n=!0
e:for(;n;){var o=e,i=t
if(n=!1,o&&i){if(o===i)return!0
if(r(o))return!1
if(r(i)){e=o,t=i.parentNode,n=!0
continue e}return o.contains?o.contains(i):o.compareDocumentPosition?!!(16&o.compareDocumentPosition(i)):!1}return!1}}var r=e(144)
t.exports=n},{144:144}],132:[function(e,t){"use strict"
function n(e){return!!e&&("object"==typeof e||"function"==typeof e)&&"length"in e&&!("setInterval"in e)&&"number"!=typeof e.nodeType&&(Array.isArray(e)||"callee"in e||"item"in e)}function r(e){return n(e)?Array.isArray(e)?e.slice():o(e):[e]}var o=e(150)
t.exports=r},{150:150}],133:[function(e,t){"use strict"
function n(e){var t=e.match(c)
return t&&t[1].toLowerCase()}function r(e,t){var r=l
l?void 0:s(!1)
var o=n(e),c=o&&a(o)
if(c){r.innerHTML=c[1]+e+c[2]
for(var u=c[0];u--;)r=r.lastChild}else r.innerHTML=e
var d=r.getElementsByTagName("script")
d.length&&(t?void 0:s(!1),i(d).forEach(t))
for(var p=i(r.childNodes);r.lastChild;)r.removeChild(r.lastChild)
return p}var o=e(128),i=e(132),a=e(138),s=e(142),l=o.canUseDOM?document.createElement("div"):null,c=/^\s*<(\w+)/
t.exports=r},{128:128,132:132,138:138,142:142}],134:[function(e,t){"use strict"
function n(e){return function(){return e}}function r(){}r.thatReturns=n,r.thatReturnsFalse=n(!1),r.thatReturnsTrue=n(!0),r.thatReturnsNull=n(null),r.thatReturnsThis=function(){return this},r.thatReturnsArgument=function(e){return e},t.exports=r},{}],135:[function(e,t){"use strict"
var n={}
t.exports=n},{}],136:[function(e,t){"use strict"
function n(e){try{e.focus()}catch(t){}}t.exports=n},{}],137:[function(e,t){"use strict"
function n(){if("undefined"==typeof document)return null
try{return document.activeElement||document.body}catch(e){return document.body}}t.exports=n},{}],138:[function(e,t){"use strict"
function n(e){return i?void 0:o(!1),d.hasOwnProperty(e)||(e="*"),a.hasOwnProperty(e)||(i.innerHTML="*"===e?"<link />":"<"+e+"></"+e+">",a[e]=!i.firstChild),a[e]?d[e]:null}var r=e(128),o=e(142),i=r.canUseDOM?document.createElement("div"):null,a={},s=[1,'<select multiple="true">',"</select>"],l=[1,"<table>","</table>"],c=[3,"<table><tbody><tr>","</tr></tbody></table>"],u=[1,'<svg xmlns="http://www.w3.org/2000/svg">',"</svg>"],d={"*":[1,"?<div>","</div>"],area:[1,"<map>","</map>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],legend:[1,"<fieldset>","</fieldset>"],param:[1,"<object>","</object>"],tr:[2,"<table><tbody>","</tbody></table>"],optgroup:s,option:s,caption:l,colgroup:l,tbody:l,tfoot:l,thead:l,td:c,th:c},p=["circle","clipPath","defs","ellipse","g","image","line","linearGradient","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","text","tspan"]
p.forEach(function(e){d[e]=u,a[e]=!0}),t.exports=n},{128:128,142:142}],139:[function(e,t){"use strict"
function n(e){return e===window?{x:window.pageXOffset||document.documentElement.scrollLeft,y:window.pageYOffset||document.documentElement.scrollTop}:{x:e.scrollLeft,y:e.scrollTop}}t.exports=n},{}],140:[function(e,t){"use strict"
function n(e){return e.replace(r,"-$1").toLowerCase()}var r=/([A-Z])/g
t.exports=n},{}],141:[function(e,t){"use strict"
function n(e){return r(e).replace(o,"-ms-")}var r=e(140),o=/^ms-/
t.exports=n},{140:140}],142:[function(e,t){"use strict"
function n(e,t,n,r,o,i,a,s){if(!e){var l
if(void 0===t)l=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.")
else{var c=[n,r,o,i,a,s],u=0
l=new Error(t.replace(/%s/g,function(){return c[u++]})),l.name="Invariant Violation"}throw l.framesToPop=1,l}}t.exports=n},{}],143:[function(e,t){"use strict"
function n(e){return!(!e||!("function"==typeof Node?e instanceof Node:"object"==typeof e&&"number"==typeof e.nodeType&&"string"==typeof e.nodeName))}t.exports=n},{}],144:[function(e,t){"use strict"
function n(e){return r(e)&&3==e.nodeType}var r=e(143)
t.exports=n},{143:143}],145:[function(e,t){"use strict"
var n=e(142),r=function(e){var t,r={}
e instanceof Object&&!Array.isArray(e)?void 0:n(!1)
for(t in e)e.hasOwnProperty(t)&&(r[t]=t)
return r}
t.exports=r},{142:142}],146:[function(e,t){"use strict"
var n=function(e){var t
for(t in e)if(e.hasOwnProperty(t))return t
return null}
t.exports=n},{}],147:[function(e,t){"use strict"
function n(e,t,n){if(!e)return null
var o={}
for(var i in e)r.call(e,i)&&(o[i]=t.call(n,e[i],i,e))
return o}var r=Object.prototype.hasOwnProperty
t.exports=n},{}],148:[function(e,t){"use strict"
function n(e){var t={}
return function(n){return t.hasOwnProperty(n)||(t[n]=e.call(this,n)),t[n]}}t.exports=n},{}],149:[function(e,t){"use strict"
function n(e,t){if(e===t)return!0
if("object"!=typeof e||null===e||"object"!=typeof t||null===t)return!1
var n=Object.keys(e),o=Object.keys(t)
if(n.length!==o.length)return!1
for(var i=r.bind(t),a=0;a<n.length;a++)if(!i(n[a])||e[n[a]]!==t[n[a]])return!1
return!0}var r=Object.prototype.hasOwnProperty
t.exports=n},{}],150:[function(e,t){"use strict"
function n(e){var t=e.length
if(Array.isArray(e)||"object"!=typeof e&&"function"!=typeof e?r(!1):void 0,"number"!=typeof t?r(!1):void 0,0===t||t-1 in e?void 0:r(!1),e.hasOwnProperty)try{return Array.prototype.slice.call(e)}catch(n){}for(var o=Array(t),i=0;t>i;i++)o[i]=e[i]
return o}var r=e(142)
t.exports=n},{142:142}],151:[function(e,t){"use strict"
var n=e(134),r=n
t.exports=r},{134:134}]},{},[1])(1)}),function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e(require("react"))
else if("function"==typeof define&&define.amd)define("react_dom",["react"],e)
else{var t
t="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:this,t.ReactDOM=e(t.React)}}(function(e){return e.__SECRET_DOM_DO_NOT_USE_OR_YOU_WILL_BE_FIRED}),define("app/magWidget",["react","react_dom"],function(e,t){var n=document.getElementById("magWidget")
if(null!=n){var r=5e3,o=e.createClass({displayName:"AnimateDemo",getInitialState:function(){return{current:0,magazinecontent:{magazines:[]}}},componentDidMount:function(){this.setState({magazinecontent:JSON.parse(document.getElementById("magazinecontentJSON").innerHTML)}),this.interval=setInterval(this.tick,r)},componentWillUnmount:function(){clearInterval(this.interval)},tick:function(){this.state.current<this.state.magazinecontent.magazines.length-1?this.setState({current:this.state.current+1}):this.setState({current:0})},handleChange:function(e){clearInterval(this.interval),this.interval=setInterval(this.tick,r),0>e?this.setState({current:this.state.magazinecontent.magazines.length-1}):e>this.state.magazinecontent.magazines.length-1?this.setState({current:0}):this.setState({current:e})},render:function(){var t="mfmradio-",n="mfmlabel-",r="mfmlinks-",o=this.state.magazinecontent.magazines.map(function(r,o){return e.createElement("label",{className:"mfmlabel",id:n+o,htmlFor:t+o})}),i=this.state.magazinecontent.magazines.map(function(n,r){return r==this.state.current?e.createElement("input",{type:"radio",name:"mfmradio",id:t+r,checked:!0,onChange:this.handleChange.bind(this,r)}):e.createElement("input",{type:"radio",name:"mfmradio",id:t+r,onChange:this.handleChange.bind(this,r)})},this),a=this.state.magazinecontent.magazines.map(function(t,n){return e.createElement("div",{className:"mfm-links",id:r+n},e.createElement("div",{className:"arrow left",onClick:this.handleChange.bind(this,n-1)},e.createElement("i",{className:"icon icon-arrow-left"})),e.createElement("div",{className:"grey-box"},e.createElement("a",{target:"_blank",href:t.link},e.createElement("img",{src:t.image,alt:"",title:"example","data-pin-nopin":"true"})),e.createElement("div",{className:"promotion"},e.createElement("h1",null,t.offer),e.createElement("h2",null,t.byline),e.createElement("a",{target:"_blank",href:t.link,className:"button"},t.button))),e.createElement("div",{className:"arrow right",onClick:this.handleChange.bind(this,n+1)},e.createElement("i",{className:"icon icon-arrow-right"})))},this)
return e.createElement("section",{className:"box magWidget"},e.createElement("h3",{className:"separator-heading"},e.createElement("span",null,e.createElement("i",{className:"icon icon-magazine"}),"Our great mags")),i,o,a)}})
t.render(e.createElement(o,null),n)}}),define("app/sticky_nav",[],function(){function e(){var e=document.querySelector(".btn-scroll-right"),t=document.querySelector(".btn-scroll-left")
0!=d.scrollLeft&&t.classList.remove("disabled"),d.scrollWidth>d.offsetWidth&&e.classList.remove("disabled")}function t(){for(var e=0;e<h.length;e++)if(h[e].classList.contains("current"))return e}function n(e){if(e.currentTarget.classList.contains("btn-scroll-right"))m++
else if(e.currentTarget.classList.contains("btn-scroll-left")){m--
for(var t=m;t>0;t--)h[t].offsetLeft<d.scrollLeft&&(m=t)}var n=Math.min(Math.max(m,0),h.length-1)
d.scrollLeft=h[n].offsetLeft,o()}function r(){requestAnimationFrame(o)}function o(){var e=document.querySelector(".btn-scroll-left"),t=document.querySelector(".btn-scroll-right")
0!=d.scrollLeft&&e.classList.contains("disabled")?e.classList.remove("disabled"):0==d.scrollLeft&&0==e.classList.contains("disabled")?e.classList.add("disabled"):d.scrollWidth-d.offsetWidth<d.scrollLeft+2?t.classList.add("disabled"):t.classList.contains("disabled")&&t.classList.remove("disabled")}function a(e,t){var n=Date.now()
return function(){n-Date.now()<t&&(e(),n=Date.now())}}function s(){var e=c.parentNode,t=e.getBoundingClientRect(),n=document.body.getBoundingClientRect()
return n?t.top-n.top<window.pageYOffset:!1}function l(){s()?(c.classList.add("sticky"),c.style.width=c.parentNode.style.width?c.parentNode.style.width:c.parentNode.offsetWidth+"px"):c.classList.remove("sticky")}if(null!=document.querySelector(".swipe-pagination")||null!=document.querySelector(".sticky-next-prev")){var c,u=function(){var e=document.createElement("a"),t=e.style
return t.cssText="position:sticky;position:-webkit-sticky;position:-ms-sticky;",-1!==t.position.indexOf("sticky")}()
if(null!=document.querySelector(".swipe-pagination")){var d=document.querySelector(".swipe-pages-wrapper")
c=document.querySelector(".swipe-pages-container")
var p=document.querySelector(".sticky-page-title.current")
d.scrollLeft=p.offsetLeft,e()
var f=document.querySelectorAll(".btn-scroll")
for(i=0;i<f.length;i++)f[i].addEventListener("click",n)
var h=document.querySelectorAll(".sticky-page-title"),m=t()
d.addEventListener("scroll",a(r,.06))}else c=document.querySelector(".sticky-next-prev")
var g=function(){window.matchMedia("(max-width: 575px)").matches?c.parentNode.classList.add("position-sticky"):c.parentNode.classList.remove("position-sticky")}
if(c.classList.contains("sticky-next-prev")&&u?(window.addEventListener("resize",g),g()):window.addEventListener("optimizedScroll",l),window.matchMedia("(max-width: 575px)").matches){var v=document.getElementsByTagName("html")[0],y=new MutationObserver(function(e){e.forEach(function(e){"style"==e.attributeName&&-1!=v.getAttribute("style").indexOf("padding")&&(c.parentNode.style.width=document.body.offsetWidth+"px",c.style.width=document.body.offsetWidth+"px")})}),b={attributes:!0}
y.observe(v,b)}}})
var _self="undefined"!=typeof window?window:"undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?self:{},Prism=function(){var e=/\blang(?:uage)?-(\w+)\b/i,t=0,n=_self.Prism={util:{encode:function(e){return e instanceof r?new r(e.type,n.util.encode(e.content),e.alias):"Array"===n.util.type(e)?e.map(n.util.encode):e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/\u00a0/g," ")},type:function(e){return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1]},objId:function(e){return e.__id||Object.defineProperty(e,"__id",{value:++t}),e.__id},clone:function(e){var t=n.util.type(e)
switch(t){case"Object":var r={}
for(var o in e)e.hasOwnProperty(o)&&(r[o]=n.util.clone(e[o]))
return r
case"Array":return e.map&&e.map(function(e){return n.util.clone(e)})}return e}},languages:{extend:function(e,t){var r=n.util.clone(n.languages[e])
for(var o in t)r[o]=t[o]
return r},insertBefore:function(e,t,r,o){o=o||n.languages
var i=o[e]
if(2==arguments.length){r=arguments[1]
for(var a in r)r.hasOwnProperty(a)&&(i[a]=r[a])
return i}var s={}
for(var l in i)if(i.hasOwnProperty(l)){if(l==t)for(var a in r)r.hasOwnProperty(a)&&(s[a]=r[a])
s[l]=i[l]}return n.languages.DFS(n.languages,function(t,n){n===o[e]&&t!=e&&(this[t]=s)}),o[e]=s},DFS:function(e,t,r,o){o=o||{}
for(var i in e)e.hasOwnProperty(i)&&(t.call(e,i,e[i],r||i),"Object"!==n.util.type(e[i])||o[n.util.objId(e[i])]?"Array"!==n.util.type(e[i])||o[n.util.objId(e[i])]||(o[n.util.objId(e[i])]=!0,n.languages.DFS(e[i],t,i,o)):(o[n.util.objId(e[i])]=!0,n.languages.DFS(e[i],t,null,o)))}},plugins:{},highlightAll:function(e,t){var r={callback:t,selector:'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'}
n.hooks.run("before-highlightall",r)
for(var o,i=r.elements||document.querySelectorAll(r.selector),a=0;o=i[a++];)n.highlightElement(o,e===!0,r.callback)},highlightElement:function(t,r,o){for(var i,a,s=t;s&&!e.test(s.className);)s=s.parentNode
s&&(i=(s.className.match(e)||[,""])[1].toLowerCase(),a=n.languages[i]),t.className=t.className.replace(e,"").replace(/\s+/g," ")+" language-"+i,s=t.parentNode,/pre/i.test(s.nodeName)&&(s.className=s.className.replace(e,"").replace(/\s+/g," ")+" language-"+i)
var l=t.textContent,c={element:t,language:i,grammar:a,code:l}
if(n.hooks.run("before-sanity-check",c),!c.code||!c.grammar)return void n.hooks.run("complete",c)
if(n.hooks.run("before-highlight",c),r&&_self.Worker){var u=new Worker(n.filename)
u.onmessage=function(e){c.highlightedCode=e.data,n.hooks.run("before-insert",c),c.element.innerHTML=c.highlightedCode,o&&o.call(c.element),n.hooks.run("after-highlight",c),n.hooks.run("complete",c)},u.postMessage(JSON.stringify({language:c.language,code:c.code,immediateClose:!0}))}else c.highlightedCode=n.highlight(c.code,c.grammar,c.language),n.hooks.run("before-insert",c),c.element.innerHTML=c.highlightedCode,o&&o.call(t),n.hooks.run("after-highlight",c),n.hooks.run("complete",c)},highlight:function(e,t,o){var i=n.tokenize(e,t)
return r.stringify(n.util.encode(i),o)},tokenize:function(e,t){var r=n.Token,o=[e],i=t.rest
if(i){for(var a in i)t[a]=i[a]
delete t.rest}e:for(var a in t)if(t.hasOwnProperty(a)&&t[a]){var s=t[a]
s="Array"===n.util.type(s)?s:[s]
for(var l=0;l<s.length;++l){var c=s[l],u=c.inside,d=!!c.lookbehind,p=!!c.greedy,f=0,h=c.alias
if(p&&!c.pattern.global){var m=c.pattern.toString().match(/[imuy]*$/)[0]
c.pattern=RegExp(c.pattern.source,m+"g")}c=c.pattern||c
for(var g=0,v=0;g<o.length;v+=(o[g].matchedStr||o[g]).length,++g){var y=o[g]
if(o.length>e.length)break e
if(!(y instanceof r)){c.lastIndex=0
var b=c.exec(y),w=1
if(!b&&p&&g!=o.length-1){if(c.lastIndex=v,b=c.exec(e),!b)break
for(var _=b.index+(d?b[1].length:0),E=b.index+b[0].length,C=g,x=v,S=o.length;S>C&&E>x;++C)x+=(o[C].matchedStr||o[C]).length,_>=x&&(++g,v=x)
if(o[g]instanceof r||o[C-1].greedy)continue
w=C-g,y=e.slice(v,x),b.index-=v}if(b){d&&(f=b[1].length)
var _=b.index+f,b=b[0].slice(f),E=_+b.length,k=y.slice(0,_),T=y.slice(E),A=[g,w]
k&&A.push(k)
var N=new r(a,u?n.tokenize(b,u):b,h,b,p)
A.push(N),T&&A.push(T),Array.prototype.splice.apply(o,A)}}}}}return o},hooks:{all:{},add:function(e,t){var r=n.hooks.all
r[e]=r[e]||[],r[e].push(t)},run:function(e,t){var r=n.hooks.all[e]
if(r&&r.length)for(var o,i=0;o=r[i++];)o(t)}}},r=n.Token=function(e,t,n,r,o){this.type=e,this.content=t,this.alias=n,this.matchedStr=r||null,this.greedy=!!o}
if(r.stringify=function(e,t,o){if("string"==typeof e)return e
if("Array"===n.util.type(e))return e.map(function(n){return r.stringify(n,t,e)}).join("")
var i={type:e.type,content:r.stringify(e.content,t,o),tag:"span",classes:["token",e.type],attributes:{},language:t,parent:o}
if("comment"==i.type&&(i.attributes.spellcheck="true"),e.alias){var a="Array"===n.util.type(e.alias)?e.alias:[e.alias]
Array.prototype.push.apply(i.classes,a)}n.hooks.run("wrap",i)
var s=""
for(var l in i.attributes)s+=(s?" ":"")+l+'="'+(i.attributes[l]||"")+'"'
return"<"+i.tag+' class="'+i.classes.join(" ")+'"'+(s?" "+s:"")+">"+i.content+"</"+i.tag+">"},!_self.document)return _self.addEventListener?(_self.addEventListener("message",function(e){var t=JSON.parse(e.data),r=t.language,o=t.code,i=t.immediateClose
_self.postMessage(n.highlight(o,n.languages[r],r)),i&&_self.close()},!1),_self.Prism):_self.Prism
var o=document.currentScript||[].slice.call(document.getElementsByTagName("script")).pop()
return o&&(n.filename=o.src,document.addEventListener&&!o.hasAttribute("data-manual")&&("loading"!==document.readyState?window.requestAnimationFrame?window.requestAnimationFrame(n.highlightAll):window.setTimeout(n.highlightAll,16):document.addEventListener("DOMContentLoaded",n.highlightAll))),_self.Prism}()
"undefined"!=typeof module&&module.exports&&(module.exports=Prism),"undefined"!=typeof global&&(global.Prism=Prism),Prism.languages.markup={comment:/<!--[\w\W]*?-->/,prolog:/<\?[\w\W]+?\?>/,doctype:/<!DOCTYPE[\w\W]+?>/i,cdata:/<!\[CDATA\[[\w\W]*?]]>/i,tag:{pattern:/<\/?(?!\d)[^\s>\/=$<]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\\1|\\?(?!\1)[\w\W])*\1|[^\s'">=]+))?)*\s*\/?>/i,inside:{tag:{pattern:/^<\/?[^\s>\/]+/i,inside:{punctuation:/^<\/?/,namespace:/^[^\s>\/:]+:/}},"attr-value":{pattern:/=(?:('|")[\w\W]*?(\1)|[^\s>]+)/i,inside:{punctuation:/[=>"']/}},punctuation:/\/?>/,"attr-name":{pattern:/[^\s>\/]+/,inside:{namespace:/^[^\s>\/:]+:/}}}},entity:/&#?[\da-z]{1,8};/i},Prism.hooks.add("wrap",function(e){"entity"===e.type&&(e.attributes.title=e.content.replace(/&amp;/,"&"))}),Prism.languages.xml=Prism.languages.markup,Prism.languages.html=Prism.languages.markup,Prism.languages.mathml=Prism.languages.markup,Prism.languages.svg=Prism.languages.markup,Prism.languages.css={comment:/\/\*[\w\W]*?\*\//,atrule:{pattern:/@[\w-]+?.*?(;|(?=\s*\{))/i,inside:{rule:/@[\w-]+/}},url:/url\((?:(["'])(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1|.*?)\)/i,selector:/[^\{\}\s][^\{\};]*?(?=\s*\{)/,string:{pattern:/("|')(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1/,greedy:!0},property:/(\b|\B)[\w-]+(?=\s*:)/i,important:/\B!important\b/i,"function":/[-a-z0-9]+(?=\()/i,punctuation:/[(){};:]/},Prism.languages.css.atrule.inside.rest=Prism.util.clone(Prism.languages.css),Prism.languages.markup&&(Prism.languages.insertBefore("markup","tag",{style:{pattern:/(<style[\w\W]*?>)[\w\W]*?(?=<\/style>)/i,lookbehind:!0,inside:Prism.languages.css,alias:"language-css"}}),Prism.languages.insertBefore("inside","attr-value",{"style-attr":{pattern:/\s*style=("|').*?\1/i,inside:{"attr-name":{pattern:/^\s*style/i,inside:Prism.languages.markup.tag.inside},punctuation:/^\s*=\s*['"]|['"]\s*$/,"attr-value":{pattern:/.+/i,inside:Prism.languages.css}},alias:"language-css"}},Prism.languages.markup.tag)),Prism.languages.clike={comment:[{pattern:/(^|[^\\])\/\*[\w\W]*?\*\//,lookbehind:!0},{pattern:/(^|[^\\:])\/\/.*/,lookbehind:!0}],string:{pattern:/(["'])(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,greedy:!0},"class-name":{pattern:/((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[a-z0-9_\.\\]+/i,lookbehind:!0,inside:{punctuation:/(\.|\\)/}},keyword:/\b(if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,"boolean":/\b(true|false)\b/,"function":/[a-z0-9_]+(?=\()/i,number:/\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)\b/i,operator:/--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,punctuation:/[{}[\];(),.:]/},Prism.languages.javascript=Prism.languages.extend("clike",{keyword:/\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield)\b/,number:/\b-?(0x[\dA-Fa-f]+|0b[01]+|0o[0-7]+|\d*\.?\d+([Ee][+-]?\d+)?|NaN|Infinity)\b/,"function":/[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\()/i,operator:/--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*\*?|\/|~|\^|%|\.{3}/}),Prism.languages.insertBefore("javascript","keyword",{regex:{pattern:/(^|[^\/])\/(?!\/)(\[.+?]|\\.|[^\/\\\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/,lookbehind:!0,greedy:!0}}),Prism.languages.insertBefore("javascript","string",{"template-string":{pattern:/`(?:\\\\|\\?[^\\])*?`/,greedy:!0,inside:{interpolation:{pattern:/\$\{[^}]+\}/,inside:{"interpolation-punctuation":{pattern:/^\$\{|\}$/,alias:"punctuation"},rest:Prism.languages.javascript}},string:/[\s\S]+/}}}),Prism.languages.markup&&Prism.languages.insertBefore("markup","tag",{script:{pattern:/(<script[\w\W]*?>)[\w\W]*?(?=<\/script>)/i,lookbehind:!0,inside:Prism.languages.javascript,alias:"language-javascript"}}),Prism.languages.js=Prism.languages.javascript,Prism.languages.actionscript=Prism.languages.extend("javascript",{keyword:/\b(?:as|break|case|catch|class|const|default|delete|do|else|extends|finally|for|function|if|implements|import|in|instanceof|interface|internal|is|native|new|null|package|private|protected|public|return|super|switch|this|throw|try|typeof|use|var|void|while|with|dynamic|each|final|get|include|namespace|native|override|set|static)\b/,operator:/\+\+|--|(?:[+\-*\/%^]|&&?|\|\|?|<<?|>>?>?|[!=]=?)=?|[~?@]/}),Prism.languages.actionscript["class-name"].alias="function",Prism.languages.markup&&Prism.languages.insertBefore("actionscript","string",{xml:{pattern:/(^|[^.])<\/?\w+(?:\s+[^\s>\/=]+=("|')(?:\\\1|\\?(?!\1)[\w\W])*\2)*\s*\/?>/,lookbehind:!0,inside:{rest:Prism.languages.markup}}}),Prism.languages.c=Prism.languages.extend("clike",{keyword:/\b(asm|typeof|inline|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while)\b/,operator:/\-[>-]?|\+\+?|!=?|<<?=?|>>?=?|==?|&&?|\|?\||[~^%?*\/]/,number:/\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)[ful]*\b/i}),Prism.languages.insertBefore("c","string",{macro:{pattern:/(^\s*)#\s*[a-z]+([^\r\n\\]|\\.|\\(?:\r\n?|\n))*/im,lookbehind:!0,alias:"property",inside:{string:{pattern:/(#\s*include\s*)(<.+?>|("|')(\\?.)+?\3)/,lookbehind:!0},directive:{pattern:/(#\s*)\b(define|elif|else|endif|error|ifdef|ifndef|if|import|include|line|pragma|undef|using)\b/,lookbehind:!0,alias:"keyword"}}},constant:/\b(__FILE__|__LINE__|__DATE__|__TIME__|__TIMESTAMP__|__func__|EOF|NULL|stdin|stdout|stderr)\b/}),delete Prism.languages.c["class-name"],delete Prism.languages.c.boolean,Prism.languages.cpp=Prism.languages.extend("c",{keyword:/\b(alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|class|compl|const|constexpr|const_cast|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|float|for|friend|goto|if|inline|int|long|mutable|namespace|new|noexcept|nullptr|operator|private|protected|public|register|reinterpret_cast|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/,"boolean":/\b(true|false)\b/,operator:/[-+]{1,2}|!=?|<{1,2}=?|>{1,2}=?|\->|:{1,2}|={1,2}|\^|~|%|&{1,2}|\|?\||\?|\*|\/|\b(and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/}),Prism.languages.insertBefore("cpp","keyword",{"class-name":{pattern:/(class\s+)[a-z0-9_]+/i,lookbehind:!0}}),!function(e){e.languages.ruby=e.languages.extend("clike",{comment:/#(?!\{[^\r\n]*?\}).*/,keyword:/\b(alias|and|BEGIN|begin|break|case|class|def|define_method|defined|do|each|else|elsif|END|end|ensure|false|for|if|in|module|new|next|nil|not|or|raise|redo|require|rescue|retry|return|self|super|then|throw|true|undef|unless|until|when|while|yield)\b/})
var t={pattern:/#\{[^}]+\}/,inside:{delimiter:{pattern:/^#\{|\}$/,alias:"tag"},rest:e.util.clone(e.languages.ruby)}}
e.languages.insertBefore("ruby","keyword",{regex:[{pattern:/%r([^a-zA-Z0-9\s\{\(\[<])(?:[^\\]|\\[\s\S])*?\1[gim]{0,3}/,inside:{interpolation:t}},{pattern:/%r\((?:[^()\\]|\\[\s\S])*\)[gim]{0,3}/,inside:{interpolation:t}},{pattern:/%r\{(?:[^#{}\\]|#(?:\{[^}]+\})?|\\[\s\S])*\}[gim]{0,3}/,inside:{interpolation:t}},{pattern:/%r\[(?:[^\[\]\\]|\\[\s\S])*\][gim]{0,3}/,inside:{interpolation:t}},{pattern:/%r<(?:[^<>\\]|\\[\s\S])*>[gim]{0,3}/,inside:{interpolation:t}},{pattern:/(^|[^\/])\/(?!\/)(\[.+?]|\\.|[^\/\r\n])+\/[gim]{0,3}(?=\s*($|[\r\n,.;})]))/,lookbehind:!0}],variable:/[@$]+[a-zA-Z_][a-zA-Z_0-9]*(?:[?!]|\b)/,symbol:/:[a-zA-Z_][a-zA-Z_0-9]*(?:[?!]|\b)/}),e.languages.insertBefore("ruby","number",{builtin:/\b(Array|Bignum|Binding|Class|Continuation|Dir|Exception|FalseClass|File|Stat|File|Fixnum|Float|Hash|Integer|IO|MatchData|Method|Module|NilClass|Numeric|Object|Proc|Range|Regexp|String|Struct|TMS|Symbol|ThreadGroup|Thread|Time|TrueClass)\b/,constant:/\b[A-Z][a-zA-Z_0-9]*(?:[?!]|\b)/}),e.languages.ruby.string=[{pattern:/%[qQiIwWxs]?([^a-zA-Z0-9\s\{\(\[<])(?:[^\\]|\\[\s\S])*?\1/,inside:{interpolation:t}},{pattern:/%[qQiIwWxs]?\((?:[^()\\]|\\[\s\S])*\)/,inside:{interpolation:t}},{pattern:/%[qQiIwWxs]?\{(?:[^#{}\\]|#(?:\{[^}]+\})?|\\[\s\S])*\}/,inside:{interpolation:t}},{pattern:/%[qQiIwWxs]?\[(?:[^\[\]\\]|\\[\s\S])*\]/,inside:{interpolation:t}},{pattern:/%[qQiIwWxs]?<(?:[^<>\\]|\\[\s\S])*>/,inside:{interpolation:t}},{pattern:/("|')(#\{[^}]+\}|\\(?:\r?\n|\r)|\\?.)*?\1/,inside:{interpolation:t}}]}(Prism),Prism.languages.css.selector={pattern:/[^\{\}\s][^\{\}]*(?=\s*\{)/,inside:{"pseudo-element":/:(?:after|before|first-letter|first-line|selection)|::[-\w]+/,"pseudo-class":/:[-\w]+(?:\(.*\))?/,"class":/\.[-:\.\w]+/,id:/#[-:\.\w]+/,attribute:/\[[^\]]+\]/}},Prism.languages.insertBefore("css","function",{hexcode:/#[\da-f]{3,6}/i,entity:/\\[\da-f]{1,8}/i,number:/[\d%\.]+/}),Prism.languages.java=Prism.languages.extend("clike",{keyword:/\b(abstract|continue|for|new|switch|assert|default|goto|package|synchronized|boolean|do|if|private|this|break|double|implements|protected|throw|byte|else|import|public|throws|case|enum|instanceof|return|transient|catch|extends|int|short|try|char|final|interface|static|void|class|finally|long|strictfp|volatile|const|float|native|super|while)\b/,number:/\b0b[01]+\b|\b0x[\da-f]*\.?[\da-fp\-]+\b|\b\d*\.?\d+(?:e[+-]?\d+)?[df]?\b/i,operator:{pattern:/(^|[^.])(?:\+[+=]?|-[-=]?|!=?|<<?=?|>>?>?=?|==?|&[&=]?|\|[|=]?|\*=?|\/=?|%=?|\^=?|[?:~])/m,lookbehind:!0}}),Prism.languages.insertBefore("java","function",{annotation:{alias:"punctuation",pattern:/(^|[^.])@\w+/,lookbehind:!0}}),Prism.languages.perl={comment:[{pattern:/(^\s*)=\w+[\s\S]*?=cut.*/m,lookbehind:!0},{pattern:/(^|[^\\$])#.*/,lookbehind:!0}],string:[/\b(?:q|qq|qx|qw)\s*([^a-zA-Z0-9\s\{\(\[<])(?:[^\\]|\\[\s\S])*?\1/,/\b(?:q|qq|qx|qw)\s+([a-zA-Z0-9])(?:[^\\]|\\[\s\S])*?\1/,/\b(?:q|qq|qx|qw)\s*\((?:[^()\\]|\\[\s\S])*\)/,/\b(?:q|qq|qx|qw)\s*\{(?:[^{}\\]|\\[\s\S])*\}/,/\b(?:q|qq|qx|qw)\s*\[(?:[^[\]\\]|\\[\s\S])*\]/,/\b(?:q|qq|qx|qw)\s*<(?:[^<>\\]|\\[\s\S])*>/,/("|`)(?:[^\\]|\\[\s\S])*?\1/,/'(?:[^'\\\r\n]|\\.)*'/],regex:[/\b(?:m|qr)\s*([^a-zA-Z0-9\s\{\(\[<])(?:[^\\]|\\[\s\S])*?\1[msixpodualngc]*/,/\b(?:m|qr)\s+([a-zA-Z0-9])(?:[^\\]|\\.)*?\1[msixpodualngc]*/,/\b(?:m|qr)\s*\((?:[^()\\]|\\[\s\S])*\)[msixpodualngc]*/,/\b(?:m|qr)\s*\{(?:[^{}\\]|\\[\s\S])*\}[msixpodualngc]*/,/\b(?:m|qr)\s*\[(?:[^[\]\\]|\\[\s\S])*\][msixpodualngc]*/,/\b(?:m|qr)\s*<(?:[^<>\\]|\\[\s\S])*>[msixpodualngc]*/,{pattern:/(^|[^-]\b)(?:s|tr|y)\s*([^a-zA-Z0-9\s\{\(\[<])(?:[^\\]|\\[\s\S])*?\2(?:[^\\]|\\[\s\S])*?\2[msixpodualngcer]*/,lookbehind:!0},{pattern:/(^|[^-]\b)(?:s|tr|y)\s+([a-zA-Z0-9])(?:[^\\]|\\[\s\S])*?\2(?:[^\\]|\\[\s\S])*?\2[msixpodualngcer]*/,lookbehind:!0},{pattern:/(^|[^-]\b)(?:s|tr|y)\s*\((?:[^()\\]|\\[\s\S])*\)\s*\((?:[^()\\]|\\[\s\S])*\)[msixpodualngcer]*/,lookbehind:!0},{pattern:/(^|[^-]\b)(?:s|tr|y)\s*\{(?:[^{}\\]|\\[\s\S])*\}\s*\{(?:[^{}\\]|\\[\s\S])*\}[msixpodualngcer]*/,lookbehind:!0},{pattern:/(^|[^-]\b)(?:s|tr|y)\s*\[(?:[^[\]\\]|\\[\s\S])*\]\s*\[(?:[^[\]\\]|\\[\s\S])*\][msixpodualngcer]*/,lookbehind:!0},{pattern:/(^|[^-]\b)(?:s|tr|y)\s*<(?:[^<>\\]|\\[\s\S])*>\s*<(?:[^<>\\]|\\[\s\S])*>[msixpodualngcer]*/,lookbehind:!0},/\/(?:[^\/\\\r\n]|\\.)*\/[msixpodualngc]*(?=\s*(?:$|[\r\n,.;})&|\-+*~<>!?^]|(lt|gt|le|ge|eq|ne|cmp|not|and|or|xor|x)\b))/],variable:[/[&*$@%]\{\^[A-Z]+\}/,/[&*$@%]\^[A-Z_]/,/[&*$@%]#?(?=\{)/,/[&*$@%]#?((::)*'?(?!\d)[\w$]+)+(::)*/i,/[&*$@%]\d+/,/(?!%=)[$@%][!"#$%&'()*+,\-.\/:;<=>?@[\\\]^_`{|}~]/],filehandle:{pattern:/<(?![<=])\S*>|\b_\b/,alias:"symbol"},vstring:{pattern:/v\d+(\.\d+)*|\d+(\.\d+){2,}/,alias:"string"},"function":{pattern:/sub [a-z0-9_]+/i,inside:{keyword:/sub/}},keyword:/\b(any|break|continue|default|delete|die|do|else|elsif|eval|for|foreach|given|goto|if|last|local|my|next|our|package|print|redo|require|say|state|sub|switch|undef|unless|until|use|when|while)\b/,number:/\b-?(0x[\dA-Fa-f](_?[\dA-Fa-f])*|0b[01](_?[01])*|(\d(_?\d)*)?\.?\d(_?\d)*([Ee][+-]?\d+)?)\b/,operator:/-[rwxoRWXOezsfdlpSbctugkTBMAC]\b|\+[+=]?|-[-=>]?|\*\*?=?|\/\/?=?|=[=~>]?|~[~=]?|\|\|?=?|&&?=?|<(?:=>?|<=?)?|>>?=?|![~=]?|[%^]=?|\.(?:=|\.\.?)?|[\\?]|\bx(?:=|\b)|\b(lt|gt|le|ge|eq|ne|cmp|not|and|or|xor)\b/,punctuation:/[{}[\];(),:]/},Prism.languages.php=Prism.languages.extend("clike",{keyword:/\b(and|or|xor|array|as|break|case|cfunction|class|const|continue|declare|default|die|do|else|elseif|enddeclare|endfor|endforeach|endif|endswitch|endwhile|extends|for|foreach|function|include|include_once|global|if|new|return|static|switch|use|require|require_once|var|while|abstract|interface|public|implements|private|protected|parent|throw|null|echo|print|trait|namespace|final|yield|goto|instanceof|finally|try|catch)\b/i,constant:/\b[A-Z0-9_]{2,}\b/,comment:{pattern:/(^|[^\\])(?:\/\*[\w\W]*?\*\/|\/\/.*)/,lookbehind:!0,greedy:!0}}),Prism.languages.insertBefore("php","class-name",{"shell-comment":{pattern:/(^|[^\\])#.*/,lookbehind:!0,alias:"comment"}}),Prism.languages.insertBefore("php","keyword",{delimiter:/\?>|<\?(?:php)?/i,variable:/\$\w+\b/i,"package":{pattern:/(\\|namespace\s+|use\s+)[\w\\]+/,lookbehind:!0,inside:{punctuation:/\\/}}}),Prism.languages.insertBefore("php","operator",{property:{pattern:/(->)[\w]+/,lookbehind:!0}}),Prism.languages.markup&&(Prism.hooks.add("before-highlight",function(e){"php"===e.language&&(e.tokenStack=[],e.backupCode=e.code,e.code=e.code.replace(/(?:<\?php|<\?)[\w\W]*?(?:\?>)/gi,function(t){return e.tokenStack.push(t),"{{{PHP"+e.tokenStack.length+"}}}"}))}),Prism.hooks.add("before-insert",function(e){"php"===e.language&&(e.code=e.backupCode,delete e.backupCode)}),Prism.hooks.add("after-highlight",function(e){if("php"===e.language){for(var t,n=0;t=e.tokenStack[n];n++)e.highlightedCode=e.highlightedCode.replace("{{{PHP"+(n+1)+"}}}",Prism.highlight(t,e.grammar,"php").replace(/\$/g,"$$$$"))
e.element.innerHTML=e.highlightedCode}}),Prism.hooks.add("wrap",function(e){"php"===e.language&&"markup"===e.type&&(e.content=e.content.replace(/(\{\{\{PHP[0-9]+\}\}\})/g,'<span class="token php">$1</span>'))}),Prism.languages.insertBefore("php","comment",{markup:{pattern:/<[^?]\/?(.*?)>/,inside:Prism.languages.markup},php:/\{\{\{PHP[0-9]+\}\}\}/})),Prism.languages.python={"triple-quoted-string":{pattern:/"""[\s\S]+?"""|'''[\s\S]+?'''/,alias:"string"},comment:{pattern:/(^|[^\\])#.*/,lookbehind:!0},string:{pattern:/("|')(?:\\\\|\\?[^\\\r\n])*?\1/,greedy:!0},"function":{pattern:/((?:^|\s)def[ \t]+)[a-zA-Z_][a-zA-Z0-9_]*(?=\()/g,lookbehind:!0},"class-name":{pattern:/(\bclass\s+)[a-z0-9_]+/i,lookbehind:!0},keyword:/\b(?:as|assert|async|await|break|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|pass|print|raise|return|try|while|with|yield)\b/,"boolean":/\b(?:True|False)\b/,number:/\b-?(?:0[bo])?(?:(?:\d|0x[\da-f])[\da-f]*\.?\d*|\.\d+)(?:e[+-]?\d+)?j?\b/i,operator:/[-+%=]=?|!=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]|\b(?:or|and|not)\b/,punctuation:/[{}[\];(),.:]/},Prism.languages.roboconf={comment:/#.*/,keyword:{pattern:/(^|\s)(?:(?:facet|instance of)(?=[ \t]+[\w-]+[ \t]*\{)|(?:external|import)\b)/,lookbehind:!0},component:{pattern:/[\w-]+(?=[ \t]*\{)/,alias:"variable"},property:/[\w.-]+(?=[ \t]*:)/,value:{pattern:/(=[ \t]*)[^,;]+/,lookbehind:!0,alias:"attr-value"},optional:{pattern:/\(optional\)/,alias:"builtin"},wildcard:{pattern:/(\.)\*/,lookbehind:!0,alias:"operator"},punctuation:/[{},.;:=]/},Prism.languages.sql={comment:{pattern:/(^|[^\\])(?:\/\*[\w\W]*?\*\/|(?:--|\/\/|#).*)/,lookbehind:!0},string:{pattern:/(^|[^@\\])("|')(?:\\?[\s\S])*?\2/,lookbehind:!0},variable:/@[\w.$]+|@("|'|`)(?:\\?[\s\S])+?\1/,"function":/\b(?:COUNT|SUM|AVG|MIN|MAX|FIRST|LAST|UCASE|LCASE|MID|LEN|ROUND|NOW|FORMAT)(?=\s*\()/i,keyword:/\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR VARYING|CHARACTER (?:SET|VARYING)|CHARSET|CHECK|CHECKPOINT|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMN|COLUMNS|COMMENT|COMMIT|COMMITTED|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS|CONTAINSTABLE|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|DATA(?:BASES?)?|DATE(?:TIME)?|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITER(?:S)?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE(?: PRECISION)?|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE KEY|ELSE|ENABLE|ENCLOSED BY|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPE(?:D BY)?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|IDENTITY(?:_INSERT|COL)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTO|INVOKER|ISOLATION LEVEL|JOIN|KEYS?|KILL|LANGUAGE SQL|LAST|LEFT|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MODIFIES SQL DATA|MODIFY|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL(?: CHAR VARYING| CHARACTER(?: VARYING)?| VARCHAR)?|NATURAL|NCHAR(?: VARCHAR)?|NEXT|NO(?: SQL|CHECK|CYCLE)?|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READ(?:S SQL DATA|TEXT)?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEATABLE|REPLICATION|REQUIRE|RESTORE|RESTRICT|RETURNS?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE MODE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|START(?:ING BY)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED BY|TEXT(?:SIZE)?|THEN|TIMESTAMP|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNPIVOT|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?)\b/i,"boolean":/\b(?:TRUE|FALSE|NULL)\b/i,number:/\b-?(?:0x)?\d*\.?[\da-f]+\b/,operator:/[-+*\/=%^~]|&&?|\|?\||!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|IN|LIKE|NOT|OR|IS|DIV|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,punctuation:/[;[\]()`,.]/},Prism.languages.yaml={scalar:{pattern:/([\-:]\s*(![^\s]+)?[ \t]*[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)[^\r\n]+(?:\3[^\r\n]+)*)/,lookbehind:!0,alias:"string"},comment:/#.*/,key:{pattern:/(\s*(?:^|[:\-,[{\r\n?])[ \t]*(![^\s]+)?[ \t]*)[^\r\n{[\]},#\s]+?(?=\s*:\s)/,lookbehind:!0,alias:"atrule"},directive:{pattern:/(^[ \t]*)%.+/m,lookbehind:!0,alias:"important"},datetime:{pattern:/([:\-,[{]\s*(![^\s]+)?[ \t]*)(\d{4}-\d\d?-\d\d?([tT]|[ \t]+)\d\d?:\d{2}:\d{2}(\.\d*)?[ \t]*(Z|[-+]\d\d?(:\d{2})?)?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(:\d{2}(\.\d*)?)?)(?=[ \t]*($|,|]|}))/m,lookbehind:!0,alias:"number"},"boolean":{pattern:/([:\-,[{]\s*(![^\s]+)?[ \t]*)(true|false)[ \t]*(?=$|,|]|})/im,lookbehind:!0,alias:"important"},"null":{pattern:/([:\-,[{]\s*(![^\s]+)?[ \t]*)(null|~)[ \t]*(?=$|,|]|})/im,lookbehind:!0,alias:"important"},string:{pattern:/([:\-,[{]\s*(![^\s]+)?[ \t]*)("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')(?=[ \t]*($|,|]|}))/m,lookbehind:!0},number:{pattern:/([:\-,[{]\s*(![^\s]+)?[ \t]*)[+\-]?(0x[\da-f]+|0o[0-7]+|(\d+\.?\d*|\.?\d+)(e[\+\-]?\d+)?|\.inf|\.nan)[ \t]*(?=$|,|]|})/im,lookbehind:!0},tag:/![^\s]+/,important:/[&*][\w]+/,punctuation:/---|[:[\]{}\-,|>?]|\.\.\./},!function(){"undefined"!=typeof self&&self.Prism&&self.document&&Prism.hooks.add("complete",function(e){if(e.code){var t=e.element.parentNode,n=/\s*\bline-numbers\b\s*/
if(t&&/pre/i.test(t.nodeName)&&(n.test(t.className)||n.test(e.element.className))&&!e.element.querySelector(".line-numbers-rows")){n.test(e.element.className)&&(e.element.className=e.element.className.replace(n,"")),n.test(t.className)||(t.className+=" line-numbers")
var r,o=e.code.match(/\n(?!$)/g),i=o?o.length+1:1,a=new Array(i+1)
a=a.join("<span></span>"),r=document.createElement("span"),r.setAttribute("aria-hidden","true"),r.className="line-numbers-rows",r.innerHTML=a,t.hasAttribute("data-start")&&(t.style.counterReset="linenumber "+(parseInt(t.getAttribute("data-start"),10)-1)),e.element.appendChild(r)}}})}(),define("prism",function(){}),define("app/topics",["bordeaux"],function(e){-1!==window.location.href.indexOf("gamesradar.com")&&e.topics()}),require.config({paths:{sponsoredPost:"lib/sponsoredPost",dfp:"app/dfp-shim",dfp_skin:"lib/dfp_skin",dfp_legacy:"lib/dfp",ads:"app/ads",gallery_shim:"app/gallery-shim",es6promise:"lib/es6promise",es6promise_init:"lib/es6promise_init",fetch:"lib/fetch",amazon_direct_match:"//c.amazon-adsystem.com/aax2/amzn_ads",amazon_direct_match_helper:"lib/amazon_direct_match_helper",lazysizes:"lib/lazysizes.min",respimage:"lib/respimage",fastclick:"lib/fastclick",moment:"lib/moment",swipejs:"lib/swipe",serialize:"lib/serialize",labelclick:"lib/labelclick",iframeResizer:"lib/iframeResizer.min",onscroll_helper:"lib/onscroll_helper",x_bidder:"//ox-d.futurenet.servedbyopenx.com/w/1.0/jstag?nc=8644-futurenet",x_bidder_helper:"lib/x_bidder_helper",autocomplete:"lib/autocomplete",hogan:"lib/hogan",react:"app/node_modules/react/dist/"+("undefined"!=typeof process?"react.min":"react"),react_dom:"app/node_modules/react-dom/dist/react-dom",activenav:"app/activenav",feat_helper:"lib/feat_helper",metrics:"lib/metrics",slotify_helper:"lib/slotify_helper",bordeaux:"bordeaux/interop-dist/"+("undefined"!=typeof process?"index.min":"index"),mfmwidget:"app/mfmwidget",hoist_mobile_mpu:"lib/hoistmobilempu",prism:"lib/prism"},shim:{hogan:{exports:"Hogan"}},waitSeconds:5}),require(["es6promise_init","fetch","app/utils","app/mediainserts","respimage","lazysizes","fastclick","labelclick","app/activenav","app/comments","app/engagement","app/date_utilities","app/localisation_utilities","app/prev_next","app/navigation_responsive","app/list_pagination","app/search","autocomplete","app/instant_search","app/fallback","app/gallery","app/socialite","app/image-gallery","app/poll","app/newsletter","app/event_tracking","app/suggest_next_article","app/component_tracking","app/hub_tweets","app/init","app/height_fix","app/trending_responsive","app/tabs","app/review_ordering","app/game-review-score-load","app/game-review-image-height","app/limit-list-links","app/read-more","app/enlargeimages","app/advancedsearch","app/magWidget","app/sticky_nav","prism","app/topics"]),define("main",function(){})
